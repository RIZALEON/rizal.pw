# VPS host options for the ASSM-RSYNC + KROG server

> **STATUS: AWAITING RIZAL'S APPROVAL.** Nothing has been rented, no account was created, and no card was used.
> Pick a provider and size, and say so directly, before anyone signs up. The account must be in Rizal's own name.

Prices checked Monday, Nov 16, 2026 (America/Denver) with a quick web check. They exclude tax/VAT and can change; confirm on the provider's page at signup.

## What the server needs
The server is stdlib Python (no database, no pip packages). It holds the ASSM sign-in (owner + bot profiles), RSYNC sync,
the KROG bot routes, and the append-only bot post log. Load is tiny.

| Need | Minimum | Recommended |
|---|---|---|
| CPU | 1 shared vCPU | 1–2 shared vCPU |
| RAM | 1 GB | 2 GB (room for Caddy, logs and updates) |
| Disk | 10 GB | 25 GB+ SSD |
| OS | Ubuntu 24.04/26.04 LTS or Debian 12/13 | same |
| Network | public IPv4 + IPv6, port 443 open | same, plus a DNS name for ASSM_SERVER_URL |

KROG's *model* is a separate decision (still open). A local LLM on the VPS would need 8–16 GB RAM or a GPU and costs far more;
the small VPS assumes KROG's model runs on the Neo or an approved API, and the VPS only signs KROG in and stores replies.

## Provider comparison (cheapest sensible plans)

| Provider | Plan | vCPU / RAM / Disk / Transfer | Approx. monthly | Source checked |
|---|---|---|---|---|
| **Hetzner Cloud** (Germany/Finland) | CX23 (shared x86) | 2 / 4 GB / 40 GB NVMe / 20 TB | **€5.49 + €0.50 IPv4 ≈ €5.99 (~$7)** | cloudtally.eu (verified Nov 10, 2026); Hetzner raised prices in 2026 and retired CX22/CPX11 in the EU |
| Hetzner Cloud (US: Ashburn / Hillsboro) | CPX11-class shared AMD | 2 / 2 GB / 40 GB / 1 TB (US traffic is lower) | **≈ $7/mo** (Apr 2026 US table: $6.99) | Hetzner price-adjustment notice (archived); US plan lineup differs, check at signup |
| **DigitalOcean** | Basic Droplet, Regular | 1 / 1 GB / 25 GB / 1,000 GiB | **$6.00** | digitalocean.com/pricing/droplets |
| DigitalOcean | Basic Droplet, Regular | 1 / 2 GB / 50 GB / 2,000 GiB | **$12.00** | same |
| **Vultr** | Cloud Compute, Regular Performance | 1 / 1 GB / 25 GB / 1 TB | **$5.00** | vultr.com/pricing |
| Vultr | Cloud Compute, Regular Performance | 1 / 2 GB / 55 GB / 2 TB | **$10.00** | same |

Optional extras: automated backups (~20% of the server price at DigitalOcean/Vultr, ~20% at Hetzner), a domain name if a
new subdomain of rizal.pw is not used (DNS for rizal.pw itself is free to add a record to).

**Suggested pick (for Rizal to approve or change):** Vultr 2 GB ($10) or DigitalOcean 2 GB ($12) in a US region near Denver
for low latency to the 17e, the Moto and the Pixel; or Hetzner CX23 (~€6) if an EU region is fine. 1 GB plans also work.

## Setup steps (after approval only)
1. Rizal creates the account himself (his name, his card, 2FA on). No agent signs up or pays.
2. Create the server: Ubuntu LTS, smallest approved size, add Rizal's SSH public key (never a password login).
3. DNS: point the chosen hostname (e.g. a subdomain of rizal.pw) at the server IP. That hostname becomes `ASSM_SERVER_URL`.
4. Harden: `apt update && apt -y upgrade`; `ufw allow 22,80,443/tcp && ufw enable`; unattended-upgrades on; disable SSH password auth.
5. Install: `apt -y install python3 caddy` (or Docker). Create user `assm`, copy `server/` to `/opt/assm-rsync/server`,
   copy `config/assm-server.env.example` to `/etc/assm-rsync/assm-server.env` (0600) and fill in `ASSM_SERVER_URL`.
6. Data: `mkdir -p /var/lib/assm-rsync/data && chown -R assm:assm /var/lib/assm-rsync && chmod 700 /var/lib/assm-rsync/data`.
   The owner trust store (trusted devices) is provisioned from Rizal's Neo by Rizal; it is **not** in this pack.
7. Service: install `deploy/assm-rsync.service` → `systemctl daemon-reload && systemctl enable --now assm-rsync`
   (or `docker run` per the Dockerfile comment). Caddy: `deploy/Caddyfile.example` → automatic HTTPS.
8. Check: `curl https://<host>/health`. Run `bot-selftest.py` against a throwaway port on the server.
9. Bots: Rizal creates KROG on the live server only with `owner-tools/make-bot-create.py` + his trusted-device signature
   (`POST /api/rsync/bot/create`). The unsigned bootstrap stays disabled (`ASSM_ALLOW_UNSIGNED_BOOTSTRAP=0`).
10. Clients: put the https host in each app/site per `INSTALL-PER-DEVICE.md`. Each install still needs Rizal's own direct command.

## Monthly cost summary
- Lowest: **$5–7/mo** (Vultr 1 GB, DigitalOcean 1 GB at $6, Hetzner CX23 ~€6).
- Comfortable: **$10–12/mo** (Vultr 2 GB $10, DigitalOcean 2 GB $12).
- Plus optional backups (~$1–2.40/mo) and optional domain (~$10–15/yr if a new one is wanted).
