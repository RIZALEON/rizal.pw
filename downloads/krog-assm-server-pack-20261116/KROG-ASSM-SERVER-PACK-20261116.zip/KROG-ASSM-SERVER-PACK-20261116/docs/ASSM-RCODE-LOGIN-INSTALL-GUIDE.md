# ASSM RCODE Login — Install Guide for every app, both sites, RMAIL and RWALLET

KROG-ASSM-SERVER-PACK-20261116 · written Monday, Nov 16, 2026 (America/Denver) by SCRIBE.
Covers the ASSM sign-in system (owner profile ЯID-0001-3QQS / @chaserizal) and the limited bot profiles (KROG, @krog, ЯID-BOT-0001).

> **Nothing in this guide installs itself.** Every edit goes directly into the app's existing Xcode project (or Android Studio /
> Ubuntu Touch project) and is installed with **Run** in Xcode (or the platform's run/install). Nothing is built, installed, pushed
> or deployed to rizal.pw or rizal.info without **Rizal's own direct command**.
>
> **Host:** every client points at `ASSM_SERVER_URL` (placeholder). The always-on VPS is **not approved yet** (see `VPS-HOST-OPTIONS.md`).
> Until then the only working servers are on the Neo (live owner server on loopback port 8752, KROG test server on loopback port 8753).
> Never put a LAN IP or a tunnel URL in any client.

> Checked against the Neo's sources copied at 6:13 PM MST on Nov 16, 2026 (ASSMKit, assmkit-android, assm-linux, server).

---

## 1. What the system is

| Piece | Where it lives | Role |
|---|---|---|
| **ASSM-RSYNC server** (`server.py` + `pwlogin.py` + `sync.py` + `p256.py` + `botauth.py` + `botcreate.py`) | Neo today; VPS later | Device-link approvals, owner password login, RSYNC sync (`/v1/sync/*`), bot login + bot post/reply |
| **ASSMKit** (Swift package) | `RC/APPS/GHOSTMACHINE/Packages/ASSMKit` | Native sign-in for every Apple app (macOS, iOS, iPadOS, watch): providers, device keys, owner unification, session |
| **assmkit-android** | `RCODE-android/android/assmkit-android` | Kotlin port for the Moto (RCODE Android, RDRAGON Android) |
| **assm-linux** | `tools/assm-linux` on RCODE's `linux` branch | CLI/lib for the Pixel 3a (Ubuntu Touch), the RVM and any Linux box |
| **assm-web-client.js** | `clients/web/` (this pack) | Web client for rizal.pw / rizal.info and WebViews (bot login + owner route wrappers) |
| **rlogin-page.js / rsite-auth.js / rassm.js** | the sites' `rdragon-cryptosocial/` | Existing owner web login + ASSM profile card |
| **KROGBotLogin.swift** | `clients/swift/KROG/` | KROG bot client for RCODE and RDRAGON (WK bridge `krogBot`) |
| **krog-reply.rzl.js** | `clients/krog/` | Both-reply rule (RDRAGON + KROG) and the append-only compare log |
| **RWALLET v6 (0.1.5)** | `wallet/rwallet` | Wallet bundle; reads the ЯID from the ASSM profile ("RID ЯID-0001-3QQS · owned by this wallet") |

### Identities
- **Owner:** `ЯID-0001-3QQS`, handle `@chaserizal`. Every provider an owner signs in with is **unified onto this one identity**
  (`unifyOnOwnerIdentity`). Owner devices become trusted only through approval by an ACTIVE trusted device.
- **Bots:** `ЯID-BOT-NNNN` (KROG = `ЯID-BOT-0001`, `@krog`). Role `bot`, scopes `signin`, `post`, `reply` only. Denied: `wallet`,
  `rwallet`, `approve`, `device-approve`, `sign`, `mint`, `trade`, `swap`, `buy`, `sell`, `password-set`. A bot never becomes a
  trusted device and can never log into the owner profile.

---

## 2. Server routes

All JSON. CORS allows `Content-Type, Authorization`. Bodies are never logged. Rate limits per IP on GET and POST.

### Owner / device link (ASSM RCODE)
| Method + route | Purpose |
|---|---|
| `POST /api/rsync/request` | `{t:"device.request", device, nonce, req_ts, req_sig, device_name}` (sig over `rsync-enroll-v1\n<pub>\n<nonce>\n<ts>`) → short code `XXXX-XXXX` = from sha256(device+"\n"+nonce) |
| `POST /api/rsync/approve` | `{t:"device.enroll", id, profile, device, nonce, …, ts, rgen:{scope, msg, pub, value}}` sealed by an ACTIVE trusted device; ts within 5 min; replay/duplicate refused. Bots get 403 |
| `GET  /api/rsync/request/<code>` | The new device polls its request status (pending / approved), code `NNNN-NNNN` |
| `GET  /api/rsync/entries` (also `.json`) | Last 200 signed entries in the window + `live` public URL (ASSMKit `ASSMEnrollEntriesPath`) |
| `GET  /api/rsync/device-status?pub=<base64 P-256>` | Is this device key enrolled / trusted? |
| `GET  /api/rsync/password/params` | Owner password parameters: `{scheme, salt, iter}` |
| `POST /api/rsync/password/set` | `{profile, handle, salt, iter, verifier, signer, nonce, ts, sig}` — **verifier only**, signed by an ACTIVE trusted device over `assm-password-set-v1\n` + profile, handle, salt, iter, verifier, signer, nonce, ts (newline-joined). Plaintext → 400 |
| `POST /api/rsync/password/login` | `{user, proof, device, device_name, nonce, ts, sig}` — sig over `assm-password-login-v1\n` + user, sha256hex(proof), device, device_name, nonce, ts. Never the password |
| `GET  /health`, `GET /api/rsync/health`, `GET /` | Health / version / mode / `live` URL / trusted-device count / pending codes |

Alias: any `/v1/assm/...` path is served as `/api/rsync/...`. Nonces: `[A-Za-z0-9]{8,64}`; `ts` must be within **120 s** of server time (password + bot routes).

### RSYNC sync (posts, replies, profile data both ways)
| Method + route | Purpose |
|---|---|
| `POST /v1/sync/changes` | Push signed changes from an enrolled device (bodies up to `SYNC_MAX_BODY`); bot keys refused |
| `POST /v1/sync/pull` | Pull changes since a cursor; used for the automatic catch-up. Records: `{id, kind: chat|message|setting, updatedAt, deviceId, deleted, payload}`, signed `rcode-sync-v1`, last-writer-wins |

### Bot routes (botauth.py + botcreate.py)
| Method + route | Auth | Purpose |
|---|---|---|
| `GET  /api/rsync/bot/params?user=@krog` | none | `{scheme, profile, handle, display, role, salt, iter, login_msg}` |
| `POST /api/rsync/bot/login` | bot device sig | `{t:"bot.login", user, proof, device, device_name, nonce, ts, sig}` → `{session, role:"bot", scopes, denied, expires_in, trusted:false}` |
| `GET  /api/rsync/bot/whoami` | Bearer | session info |
| `POST /api/rsync/bot/post` | Bearer | `{text}` (1–2000 chars) → appended to `bot-posts.jsonl` |
| `POST /api/rsync/bot/reply` | Bearer | `{text, parent_id, parent_author?}` |
| `POST /api/rsync/bot/logout` | Bearer | revoke session |
| `POST /api/rsync/bot/create` | **owner trusted-device sig** | create a bot profile (production path; see §6) |
| `/api/rsync/(wallet|rwallet|sign|mint|trade|swap|buy|sell|device/approve)` | — | always refused for bots (403) |

Bot login signature message:
```
"assm-bot-login-v1\n" + user + "\n" + sha256hex(proof) + "\n" + device + "\n" + device_name + "\n" + nonce + "\n" + ts
```
`device` = base64 raw 65-byte P-256 public key; `sig` = raw r||s (64 bytes) or DER, base64. Owner trusted keys are refused here.
Nonces are single-use. Wrong passwords: lockout after **5** failures, doubling from **60 s**. Sessions: **12 h**, stored server-side only as SHA-256.

---

## 3. Password scheme `pbkdf2-sha256-hmac-v1` (owner and bots)

```
dk       = PBKDF2-HMAC-SHA256(password, salt, iter, 32)      # iter >= 600000, salt >= 16 random bytes
verifier = HMAC-SHA256(key = dk, msg = "assm-password-verifier-v1")
login:     client sends proof = base64(dk), signed by its device key
server:    HMAC-SHA256(proof, "assm-password-verifier-v1") == stored verifier  (constant-time compare)
```
- The KDF runs **on the client**. The server stores only `salt`, `iter`, `verifier`. The plaintext never leaves the device.
- Clients must refuse `iter < 600000`.
- Swift: `CCKeyDerivationPBKDF(kCCPBKDF2, …, kCCPRFHmacAlgSHA256, 600000, …)` (see `KROGBot…derive(password:salt:iterations:)`).
- Web: `crypto.subtle.deriveBits({name:"PBKDF2", hash:"SHA-256", salt, iterations}, key, 256)` (see `ASSMWeb.pbkdf2`).
- Kotlin: `SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")`, 600000 iterations, 256-bit key.
- Python/Linux: `hashlib.pbkdf2_hmac("sha256", pw, salt, 600000, 32)`.

---

## 4. ASSMKit (Swift) — providers, keys, session

Source: `clients/swift/ASSMKit` (from `RC/APPS/GHOSTMACHINE/Packages/ASSMKit`). Read its `README.md` and `INTEGRATION.md` too.

### Install into an Apple app (in the app's own Xcode project)
1. Xcode → project → **Package Dependencies → Add Local…** → the `ASSMKit` folder. Add the `ASSMKit` library to the app target.
2. Pick or add an **`ASSMKitConfig`** preset for the app. Existing presets: `.rcode` (never change: `info.rizal.rcode`, defaults `rcode`,
   scheme `rcode`, env `RCODE_ASSM_BASE_URL`, plist `RCODEAuthConfig`), `.ghostmachineMac` (`info.rizal.ghostmachine.mac`,
   env `GHOSTMACHINE_ASSM_BASE_URL`, plist `ASSMAuthConfig`), `.ghostmachineIOS` (`info.rizal.ghostmachine.ios`), `.ghostMachine`
   (picks per platform). New apps (RDRAGON, RWALET, RMAIL, ЯBOT, ThundR) get their **own** preset with their own `keychainPrefix`,
   `defaultsPrefix`, `urlScheme`, `launchArgPrefix`, `baseURLEnvironmentKey`, `authConfigPlistName`, `cloudKitZoneName`.
3. In the `App` struct: `import ASSMKit` and `@StateObject private var auth = AuthManager.configured(.yourPreset)` so the config is
   set before anything touches the Keychain. `configured(_:)` calls `validate()` and refuses reserved names.
4. Bundle the auth plist (named by `authConfigPlistName`) and `OwnerProfile.plist` in the target's resources (templates below).
5. Present `SignInView` (sheet) — it shows passkey, Apple, Google, Microsoft, email/password, ASSM code/QR and ASSM username+password.
   `ApproveDeviceView` (approve other devices from a trusted one), `SetASSMPasswordView` (set the owner password, Apple only),
   `OwnerApprovalBanner`, `AccountViews` are also provided.
6. After sign-in/out, push the session into any WebView: `webView.evaluateJavaScript(ASSMKitBridge.sessionEventScript())`.
7. Entitlements: Sign in with Apple (Apple provider), Associated Domains `webcredentials:<RP>` (passkeys), outgoing network.
8. Press **Run** in Xcode on Rizal's command.

### Key API (`AuthManager`)
`shared`, `configured(_:)`, `account`, `isSignedIn`, `busy`, `lastError`, `presentSignIn`, `serverURLString` / `serverURL`,
`signIn(with:mode:)`, `signInWithPassword(username:password:mode:)` (RCODE server email login), `signInWithASSMPassword(user:password:)`
(ASSM-RSYNC owner password), `claimDeviceLink(code:)`, `cancelPending()`, `unifyOnOwnerIdentity(after:)`, `ownerIdentity`,
`ownerDeviceApproved`, `ownerPending`, `startOwnerEnrollmentIfNeeded()`, `retryOwnerEnrollment()`, `unlink(_:)`, `signOut()`.
Providers: `apple` (`AppleSignInProvider`), `google` / `microsoft` (`OAuthPKCEProvider`), `passkey` (`PasskeyProvider`),
`password` (`PasswordProvider`), `assm` (`ASSMProvider`). Helpers: `ASSMPasswordClient` (`scheme`, `iterations = 600_000`,
`minimumLength = 12`, `derive`, `verifier`, `setMessage`, `loginMessage`, `setPassword`, `login`, `approverIsTrusted`),
`ASSMApproveClient`, `ASSMApproverKey`, `ASSMDeviceStatus`, `ASSMRsyncSeal`, `KeychainStore`, `BackendClient`, `PKCE`,
`SyncCoordinator` / `ASSMSyncService` / `CloudKitSyncService` / `DeviceRegistry`.

### Providers
| Provider | How | Server |
|---|---|---|
| **ASSM** (code / QR) | `device.request` → 8-digit code + QR (`<scheme>://assm-approve?...`) → approved on a trusted device → poll `/api/rsync/request/<code>` + `device-status` | ASSM-RSYNC |
| **ASSM username + password** | `/password/params` → PBKDF2 600k → `/password/login` signed `assm-password-login-v1` by this app's device key. Set: Apple apps only | ASSM-RSYNC |
| **Apple** | Sign in with Apple (`ASAuthorizationAppleIDProvider`) | none (local) |
| **Google / Microsoft** | OAuth 2 auth code + **PKCE** (S256) in `ASWebAuthenticationSession`; public clients, IDs in the plist (still `REPLACE_…`) | Google / Entra |
| **Passkey** | WebAuthn via `/v1/auth/passkey/{register,login}/{options,finish}`; RP in `PasskeyRelyingParty` | RCODE account server (`DefaultSyncServerURL`) |
| **Email/password** | `/v1/auth/password/{login,signup}` | RCODE account server |
| **Device link** | `/v1/devices/link/{start,claim}` | RCODE account server |

`unifyOnOwnerIdentity(after:)` runs after **every** successful provider: it adds the owner ASSM identity (`ЯID-0001-3QQS` from
`OwnerProfile.plist`) to the account, then either marks the owner device approved (when the ASSM provider already approved this app's
key) or starts owner device-key enrollment. Skipped for isolated launches (`-<prefix>AuthPreview`, `-<prefix>RemoteOpen`).

> The RCODE account server (`/v1/auth/*`, `/v1/devices/*`, `/v1/account/*`) is **separate** from ASSM-RSYNC and is not in this pack;
> `DefaultSyncServerURL` is still `REPLACE_WITH_RCODE_SERVER_URL`. Passkey, email and device-link need it.

### Per-app P-256 device keys
- `ASSMDeviceKey` under `<keychainPrefix>.assm-device-key` (one per app per device, e.g. RCODE `info.rizal.rcode.assm-device-key`).
  Other items: `.account`, `.account.local`, `.session`, `.device`, `.assm-approver-key` (approver key; also its application tag).
- Each new key needs Rizal's one-time approval from a trusted device. Keys are never exported, bundled, uploaded or shared.
- Bot keys are separate (`<prefix>.krog-bot.devicekey`) and are refused as owner keys and vice versa.

### Reserved Keychain names (ASSMKit refuses them)
- Services: `info.rizal.rsign.assm`; prefixes: anything starting `info.rizal.rsign.` (RSIGN).
- Access group: `7D3P5F4V9M.info.rizal.rdragon.rmail` (RMAIL's shared group). Only RMAIL owns it; no ASSMKit config may use it.
- Saved logins (add-only): `<prefix>.saved-login.<name>`, e.g. `info.rizal.rcode.saved-login.krog`, `info.rizal.rmail.mac.saved-login.krog`,
  `io.rlab.rwalet.xcode.saved-login.krog`, `info.rizal.dragonskull.saved-login.krog`.

### `rlogin-session` event (wallets and WebViews)
`ASSMKitBridge.sessionEventName = "rlogin-session"`. `ASSMKitBridge.sessionEventScript()` dispatches on `window`:
```js
window.dispatchEvent(new CustomEvent("rlogin-session", { detail: {
  handle: "@chaserizal", from: "ЯID-0001-3QQS", out: false,           // out:true on sign-out
  source: "assmkit", app: "RCODE", deviceApproved: true, at: "2026-11-16T18:00:00.000Z" } }));
```
Read-only towards the web: it never writes `rdragon.csp.rlogin-session.v1` localStorage and never carries tokens/keys/passwords.
The web cards (`rlogin-strip.js`, `rlogin-page.js`) and RWALLET's `rwallet-assmkit-adapter.js` listen for it.

### Auth plist (`RCODEAuthConfig.plist` for RCODE, `ASSMAuthConfig.plist` for the others) — keys read by `AuthConfig`
```xml
<plist version="1.0"><dict>
  <key>GoogleClientID</key><string>REPLACE_WITH_GOOGLE_IOS_CLIENT_ID.apps.googleusercontent.com</string>
  <key>GoogleRedirectURI</key><string>REPLACE_WITH_REVERSED_CLIENT_ID:/oauth2redirect</string>
  <key>MicrosoftClientID</key><string>REPLACE_WITH_ENTRA_APPLICATION_CLIENT_ID</string>
  <key>MicrosoftTenant</key><string>common</string>
  <key>MicrosoftRedirectURI</key><string>msauth.info.rizal.APP://auth</string>
  <key>PasskeyRelyingParty</key><string>REPLACE_WITH_RP_DOMAIN</string>
  <key>ASSMBaseURL</key><string>https://ASSM_SERVER_URL</string>          <!-- the ASSM-RSYNC host -->
  <key>ASSMEnrollEntriesPath</key><string>/api/rsync/entries</string>
  <key>ASSMFallbackBaseURL</key><string>https://rizal.pw</string>        <!-- static feed; its `live` names the current host -->
  <key>ASSMDefaultProfile</key><string>ЯID-0001-3QQS</string>
  <key>DefaultSyncServerURL</key><string>REPLACE_WITH_RCODE_SERVER_URL</string>
  <key>CloudKitEnabled</key><false/>
  <key>CloudKitContainer</key><string>iCloud.info.rizal.APP</string>
</dict></plist>
```
Values starting `REPLACE_` are treated as unset. No secrets belong here. The env var named by `baseURLEnvironmentKey` overrides `ASSMBaseURL`.

### `OwnerProfile.plist` — keys read by `OwnerProfile`
```xml
<plist version="1.0"><dict>
  <key>ASSMProfileID</key><string>ЯID-0001-3QQS</string>
  <key>Handle</key><string>@chaserizal</string>
  <key>DisplayName</key><string>Rizal</string>
</dict></plist>
```

---

## 5. KROG bot client (Swift) — `KROGBotLogin.swift`
- `KROGBotClient(keychainPrefix:base:)` → `importPassword(_:)` (one-time, add-only), `login(deviceName:)`, `whoami()`,
  `post(_:)`, `reply(to:text:parentAuthor:)`, `logout()`. Static helpers `derive(password:salt:iterations:)`, `loginMessage(...)`.
- Errors: `reservedName`, `noPassword`, `noServer`, `wrong`, `lockedOut(s)`, `refused(msg)`, `server(code,msg)`.
- Base URL: `KROG_BOT_BASE_URL` env var; for the VPS set it (or the constant) to `https://ASSM_SERVER_URL`.
- RDRAGON: `KROGBotWK.install(on: webView)` registers WK handler **`krogBot`**. JS ops: `status`, `import {password}`, `login`,
  `post {text}`, `reply {parent_id, text, parent_author}`, `logout`; results come back on `window` event `krog-bot`.
  No wallet/sign/approve/mint op exists.
- RCODE: `KROGTestPanel` under Settings → "KROG bot (test)".
- Two RDRAGON variants are in the pack: `KROGBotLogin-RDRAGON.swift` is the copy in RDRAGON's project now (Grok Bot set its default host to
  `https://rizal.pw` for the 17e build; rizal.pw is a static site and does **not** accept bot sign-in, so KROG stays idle there), and
  `KROGBotLogin-RDRAGON-bottest-variant.swift` (default `http://127.0.0.1:8753`, the Neo test server). For the VPS, use `https://ASSM_SERVER_URL`.

## 6. Creating bot accounts
- **Test (Neo only):** `bot-bootstrap.py` — unsigned. In this pack it is **disabled by default**; it runs only with
  `ASSM_MODE=test ASSM_ALLOW_UNSIGNED_BOOTSTRAP=1`, and `run.sh` refuses to start production with it enabled.
- **Production:** `owner-tools/make-bot-create.py` on Rizal's Neo makes the password (written only to a 0600 file), salt and verifier,
  and an unsigned request with `msg_to_sign`. Rizal signs it with his ACTIVE trusted device; then `POST /api/rsync/bot/create`.
  The server checks the signer is an owner trusted device, the profile is `ЯID-BOT-*`, `iter >= 600000`, the nonce is new.
  Signature message:
```
"assm-bot-create-v1\n" + profile + "\n" + handle + "\n" + display + "\n" + scheme + "\n" + salt + "\n" + iter + "\n"
  + sha256hex(verifier) + "\n" + signer + "\n" + nonce + "\n" + ts
```

## 7. Both-reply rule (RDRAGON + KROG) — `krog-reply.rzl.js`
- Every user post and comment: **one** RDRAGON reply and **one** KROG reply. Neither replies to a bot item (RDRAGON, KROG, ThundR,
  @grok, `kind` `rdragon.reply`/`krog.reply`/`bot.*`, any `ЯID-BOT-*`) or to itself. Per-target dedupe: never a second reply.
- `KROGReply.init({rdragonReply, krogReply, publish, device})`, `KROGReply.onUserItem(item)`, `KROGReply.react(id, who, up|down|better)`,
  `KROGReply.readAll()` (read-only for the local viewer).
- Append-only compare log on the device (IndexedDB `krog.compare`, fallback localStorage `krog-rdragon-compare.jsonl`): first line
  `kind:"compare"`, later replies `kind:"amend"`, marks `kind:"reaction"`. No delete/clear. Never uploaded, never on a public site.
- Hook: call `KROGReply.onUserItem(...)` where `rdragon-cryptosocial.js` calls `bot(...)` (posts and comments) and in GHOSTMACHINE's
  `crypto-side-panel.js`. `publish("krog", …)` → `ASSMWeb.bot.reply(id, text)` (web) or `krogBot` op `reply` (RDRAGON iOS).

---

## 8. Per-app installation

All edits go into the **existing** project; install with **Run** in Xcode on Rizal's command. Host = `ASSM_SERVER_URL`.

| App | Platform(s) | Today | What to add |
|---|---|---|---|
| **RCODE** | macOS, iOS/iPadOS (Xcode `UntitledProjects/RCODE`); Android (`RCODE-android`); Linux branch | ASSMKit linked (verified Mac + 17e); KROG test row added (not built) | Set `ASSMBaseURL` in the auth plist; set KROG base URL; Android: `assmkit-android` config; Linux: `assm-linux --server` |
| **RDRAGON** | iOS (17e), "Designed for iPad" on the Neo; Android (Moto, vc36); Linux (Pixel, vc35) | No native ASSMKit; KROG file present, `KROGBotWK.install` commented out for the 17e build by Grok Bot | Add ASSMKit package + plists; add `KROGBotLogin.swift` to the target and re-enable `KROGBotWK.install(on: w)`; add `assm-web-client.js` + `krog-reply.rzl.js` to the bundled CryptoSocial; ATS: HTTPS host (no `NSAllowsLocalNetworking` needed for the VPS) |
| **GHOSTMACHINE** | macOS (+ iOS targets) | ASSMKit wired on Mac (uncommitted) | Back up first; set `ASSMBaseURL`; wire `rlogin-session` into `crypto-side-panel.js`; KROG hook beside `RDRAGON.reply` |
| **RWALET** | macOS/iOS (Xcode) | sign-in not wired; v6 wallet in source | Add ASSMKit; post `rlogin-session` into the wallet WebView; wallet listens via `rwallet-assmkit-adapter.js`. Saved login item `io.rlab.rwalet.xcode.saved-login.krog` is **not** wallet access |
| **RMAIL** | macOS (+ RDRAGON-RMAIL-Free) | ASSMKit wired, Mac unsigned, no own device key yet | Own device key + approval; `rmail` access group for shared session; set `ASSMBaseURL` |
| **ЯBOT** | macOS/iOS | no ASSMKit; v6 wallet in source (Swift label still says 0.1.4) | Add ASSMKit; `rlogin-session`; optional KROG panel |
| **TerraformR** | Godot game in RDRAGON / standalone | no ASSMKit; v6 in source, `TerraformR.pck` needs re-export, `RWALLET.sha256` needs regenerating | Read the owner ЯID from the host app's `rlogin-session` (no own login) |
| **ThundR** | iOS / widget / web | no ASSMKit; auto-replies unsigned | Read `rlogin-session`; keep ThundR out of the RDRAGON/KROG pair; ThundR notices only |

### RWALLET v6 (0.1.5)
- Bundle in `wallet/rwallet` (from `RC/APPS/RWALLET-V6-UNIFIED-20261116/rwallet`). Settings shows "RID ЯID-0001-3QQS · owned by this wallet".
- The wallet has **no login of its own**: it reads the ASSM profile. Wire `rwallet-assmkit-adapter.js` to listen for `rlogin-session`.
- Bots can never reach wallet routes. Regenerate `RWALLET.sha256` for any bundle whose folder layout differs (`js/`, `css/`).

### Websites (rizal.pw, rizal.info) — not touched by this pack
1. Add `<meta name="assm-server-url" content="https://ASSM_SERVER_URL">` (or `window.ASSM_SERVER_URL` in `rdragon-config.js`).
2. Include `assm-web-client.js` after `rdragon-config.js`; keep `rlogin-page.js`/`rsite-auth.js` owner-only.
3. rizal.pw: include `krog-reply.rzl.js` and call it next to `bot(...)`. rizal.info has only a static feed (`assm/feed.json`), so it needs
   a composer (or the full CryptoSocial app) before KROG can answer there.
4. **Never ship the KROG password in site JS.** KROG should sign in from a worker on Rizal's device or the server side.
5. Clear the leftover tunnel URL in `rdragon-config.js` `statsEndpoint` before any push.
6. Push/deploy only on Rizal's direct command.

### Android (Moto g 5G) — `assmkit-android` (Kotlin, package `info.rizal.assmkit`)
- Add the module to the app's `settings.gradle(.kts)` (`include(":assmkit-android")`) and `implementation(project(":assmkit-android"))`.
- Host: `AssmKitConfig.assmBaseUrl = "https://ASSM_SERVER_URL"` (was a quick-tunnel URL; redacted in this pack) and
  `AssmKitConfig.assmFallbackBaseUrl = "https://rizal.pw"` (live URL rediscovered from `<fallback>/api/rsync/entries`). See `core/Config.kt`.
- Same providers and order as `SignInView` (`ui/SignInScreen.kt`, `auth/Providers.kt`, `auth/Pkce.kt`, `auth/AssmAuth.kt`), device key in
  Android Keystore (`core/DeviceKey.kt`), canonical signing (`core/Canon.kt`), sync (`sync/Sync.kt`, `sync/SyncCoordinator.kt`), `core/UnlockGate.kt`.
- Tests: `AssmKitContractTest.kt`, `AssmPasswordTest.kt`. Network security config: HTTPS only, no cleartext, no LAN IPs.

### Linux (Pixel 3a Ubuntu Touch, RVM) — `assm-linux` (Python ≥ 3.9 + `cryptography`)
- Host: `assm_linux/config.py` → `"assm_base_url": "https://ASSM_SERVER_URL"` (tunnel URL redacted), `"assm_fallback_base_url": "https://rizal.pw"`,
  optional `"server_url"` (RCODE account server). ASSM password sign-in is **off** by default (`assm_password_enabled` / `RCODE_ASSM_PASSWORD=1`).
- Commands: `assm-linux signin [--assm|--password|--no-browser]`, `status`, `pull [--since C]`, `push records.json`, `signout`, `preview`.
- Keys: Secret Service / `secret-tool`, else a 0600 PEM in `~/.local/share/rcode-assm/` (dir 0700). Never in a click package.
- The sign-in page binds `127.0.0.1:<ephemeral>` only, with Host check, per-session token, strict CSP, 15-minute timeout.
- Tests: `python3 tests/test_assm_linux.py` (17 tests).

---

## 9. Security rules (all apps)
- No secrets, keys, `data/`, `trusted-devices.json`, logs, LAN IPs or tunnel URLs in any bundle, site, Drive or chat.
- Bots: never trusted devices, never the owner, never wallet/approve/sign/mint.
- Logs are append-only (TRANSCRIPT LAW); never delete or rewrite.
- Install/build/push only on Rizal's own direct command; edits go into the existing projects, then **Run** in Xcode.
