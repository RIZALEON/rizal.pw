# Install per device and per app — ASSM sign-in + KROG

KROG-ASSM-SERVER-PACK-20261116 · Monday, Nov 16, 2026 (America/Denver).

**Rules for every step below**
- Edits go **directly into each app's existing project** (Xcode, Android Studio, the Ubuntu Touch/Linux build). No new copies of apps.
- Apple apps are installed with **Run in Xcode**. Android/Linux use their normal run/install.
- **Nothing installs, builds, pushes or deploys without Rizal's own direct command.**
- The host URL is **`ASSM_SERVER_URL`** everywhere until Rizal approves a host (`VPS-HOST-OPTIONS.md`). Never a LAN IP or tunnel URL.
- The KROG password is never copied from Drive or chat: it lives only in the owner's 0600 secrets file on the Neo and in each app's
  own Keychain item (imported once, add-only).

## Where the host URL goes (summary)
| Layer | File / setting | Value |
|---|---|---|
| Server (VPS) | `/etc/assm-rsync/assm-server.env` → `ASSM_SERVER_URL` | `https://<approved host>` |
| Apple apps (ASSMKit) | auth plist (`RCODEAuthConfig.plist` / `ASSMAuthConfig.plist`) → `ASSMBaseURL` (env override: the preset's `baseURLEnvironmentKey`, e.g. `RCODE_ASSM_BASE_URL`) | same |
| KROG Swift client | `KROG_BOT_BASE_URL` env / `KROGBot.baseURL` | same |
| Web / WebViews | `window.ASSM_SERVER_URL` in `rdragon-config.js` or `<meta name="assm-server-url">` | same |
| Android | `assmkit-android` → `AssmKitConfig.assmBaseUrl` (`AssmKitConfig.kt`) | same |
| Linux / Ubuntu Touch | `assm-linux` → `assm_linux/config.py` `assm_base_url` | same |

---

## 1. MacBook Neo (macOS) — the trusted owner device
- Role: Rizal's ACTIVE trusted device. Signs device approvals, password set, and **bot.create** for KROG. Builds all Apple apps.
- Server: today runs the live owner server (loopback 8752) and the KROG test server (loopback 8753). Disk floor 3 GB applies to any build.
- Apps:
  - **RCODE (Mac)** — ASSMKit already linked. Set `ASSMBaseURL` in `RCODEAuthConfig.plist`; the "KROG bot (test)" row is in Settings. Run in Xcode.
  - **GHOSTMACHINE (Mac)** — back up the uncommitted ASSMKit work first; set `ASSMBaseURL`; wire `rlogin-session` + KROG hook in `crypto-side-panel.js`.
  - **RWALET (Mac)** — add ASSMKit package + plists; wallet WebView listens for `rlogin-session` via `rwallet-assmkit-adapter.js`.
  - **RMAIL (Mac) / RDRAGON-RMAIL-Free** — give RMAIL its own device key and approve it; `rmail` access group; set `ASSMBaseURL`.
    (RDRAGON-RMAIL-Free's pbxproj still lacks `web/`.)
  - **ЯBOT** — add ASSMKit; `rlogin-session`; Swift wallet label still reads 0.1.4.
  - **RDRAGON "Designed for iPad" on the Neo** — same steps as the 17e below.
- Owner steps for KROG on a live host: `server/owner-tools/make-bot-create.py` → sign on this Neo → `POST /api/rsync/bot/create`.

## 2. RVM (Linux VM on the Neo)
- Use `assm-linux` (from RCODE's `linux` branch, `clients/linux/assm-linux`). Configure the server URL; keys in a 0600 user data dir.
- RVM reaches the server over HTTPS once a host exists (today it's on the Reticulum mesh from the Neo; RVM was reported down).
- Apps there: RDRAGON Linux build (vc35, v6 wallet in source) and the RVM egg (wallet 0.1.4). Add `assm-web-client.js` + `krog-reply.rzl.js`
  to the bundled web layer; regenerate its SHA256 sums after edits (Linux `SRC.SHA256SUMS` is stale).
- The RVM repo backup decision (full disk image vs scripts) is still Rizal's.

## 3. iPhone 17e (iOS)
- **RDRAGON** (build 47 installed = rollback; Grok Bot owns the Xcode project for the next build — coordinate, don't collide):
  1. Add ASSMKit (local package) + `ASSMAuthConfig.plist` / `OwnerProfile.plist` with `ASSMBaseURL = https://ASSM_SERVER_URL`.
  2. Add `App/Sources/KROGBotLogin.swift` to the RDRAGON target; re-enable `KROGBotWK.install(on: w)` in `App.swift`.
  3. Bundled CryptoSocial: include `assm-web-client.js` and `krog-reply.rzl.js`; publish KROG replies through the `krogBot` WK bridge.
  4. One-time KROG password import (`krogBot` op `import`) into `info.rizal.dragonskull.saved-login.krog`.
  5. Build number must be above the installed one; signing profile may expire Thu Nov 19. Run in Xcode on Rizal's command.
- **RCODE (iOS)** — ASSMKit verified; set `ASSMBaseURL`; KROG test row.
- **ThundR / ЯBOT / RWALET iOS targets** — read `rlogin-session`; ThundR stays outside the RDRAGON+KROG pair.
- Network: the phone needs the HTTPS host. `127.0.0.1` on a phone is the phone itself, so the Neo-loopback test servers don't work from here.

## 4. Moto g 5G (Android)
- **RCODE Android** (`RCODE-android`) — include `:assmkit-android`; set the server URL; Android Keystore P-256 key; approve the device from the Neo.
  (Was not installed at last check; adb needed USB "Allow".)
- **RDRAGON Android** (vc36, v6 wallet in source) — add `assm-web-client.js` + `krog-reply.rzl.js` to the WebView bundle; KROG signs in
  through the web client with a bot-only key; regenerate `SRC.SHA256SUMS`.
- Sideband / Reticulum mesh: separate from ASSM; Moto timed out on the mesh at 5:43 PM MST.
- Network security config: HTTPS host only, no cleartext.

## 5. Pixel 3a (Ubuntu Touch)
- `assm-linux` for native sign-in; RDRAGON Linux (vc35) web layer with `assm-web-client.js` + `krog-reply.rzl.js`.
- Keys in the app's private confined data dir (0600), never in the click package. Approve the device from the Neo.
- Pixel also timed out on the mesh at 5:43 PM MST.

## 6. Websites (no device install; deploy only on Rizal's command)
- **rizal.pw**: `window.ASSM_SERVER_URL`, `assm-web-client.js`, `krog-reply.rzl.js` next to `bot(...)`; clear the old tunnel URL in
  `rdragon-config.js` `statsEndpoint`; never ship the KROG password.
- **rizal.info**: static feed only (`assm/feed.json`); needs a composer or the CryptoSocial app before KROG can reply.
- Wallet on the sites: v6 files present but not deployed; full vs view-only is still Rizal's decision.

## 7. From the Google Drive folder
1. Download `KROG-ASSM-SERVER-PACK-20261116*.zip` on the Neo (the build machine for every Apple app) and unzip outside any git repo.
2. Check `sha256sum -c SHA256SUMS` (macOS: `shasum -a 256 -c SHA256SUMS`).
3. Copy the needed client folder into each app's existing project as described above; never overwrite without a backup.
4. Phones get the apps through Run in Xcode (iOS) or the normal Android/Ubuntu Touch install — not straight from Drive.
