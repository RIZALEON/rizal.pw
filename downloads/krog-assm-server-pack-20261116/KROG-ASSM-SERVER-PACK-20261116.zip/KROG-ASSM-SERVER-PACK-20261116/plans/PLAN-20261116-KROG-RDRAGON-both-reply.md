# Plan: RDRAGON and KROG both reply, then we compare

Written Monday, Nov 16, 2026, 5:10 PM America/Denver. This plan sits beside the read-only survey `STATUS-20261116-KROG-survey.md`. It does not change that file. No code was changed.

Rizal's go at 5:09 PM America/Denver: "Have them both issue a response."
His reason at 5:10 PM America/Denver: "So we can analyze and determine and grow faster."

---

## Firm rule: both bots reply, every time

Every post and every comment gets **one reply from RDRAGON and one reply from KROG**, both every time.

This is a firm rule, not an option. It replaces survey question 4 (whether KROG should replace RDRAGON, sit beside it, or become its engine). The answer is: they sit beside each other, and both always answer.

### What they do not reply to

Neither bot replies to the other's replies, or to its own.

In practice:

- A user post or user comment → RDRAGON replies once, and KROG replies once.
- An RDRAGON reply is not a new prompt for KROG, and not a new prompt for RDRAGON.
- A KROG reply is not a new prompt for RDRAGON, and not a new prompt for KROG.
- Threaded comments that are themselves bot replies are skipped by both bots.
- If a bot already has a reply on that post or comment id, it does not write a second one.

Existing CryptoSocial code already says "Bot replies never trigger replies" for RDRAGON, and ThundR auto-reply already skips authors in a bot-handle list. The dual-reply work must keep that exclusion and extend it so RDRAGON and KROG each recognize the other as a bot, including `by: "RDRAGON"`, `kind: "rdragon.reply"`, a KROG bot identity (handle and event kind still to be named), and existing ThundR / `@grok` bot marks so a third bot comment does not start a loop.

ThundR auto-reply is a separate path and is not part of this pair unless Rizal later says it should be.

---

## Why: analyze, determine, grow faster

The pair is not for show. Each post becomes a side-by-side sample of how the two bots answered the same words, so we can see which reply was better, where one failed, and how to improve the prompts, models, and rules faster than watching either bot alone.

---

## Analysis log (local, append-only, never removed)

Each post or comment that receives the pair is logged locally with both replies side by side.

### Rules for the log

- **Append-only JSONL**, one record per post or comment id, on the device that ran the replies.
- **Never sent to an outside host.** No upload, no public mirror, no RSYNC read-mirror, no analytics endpoint, no tunnel. This stays on the device.
- **TRANSCRIPT LAW / never-remove-logs:** records are never deleted, overwritten, truncated, or rewritten in place. A later correction, a model upgrade, or a second look is a new append (for example a `kind: "amend"` or `kind: "reaction"` line that points at the original `id`), not an edit of the old line.
- Back up the log as a file copy if it must be moved. Do not "clean" it.

Suggested local path (name can move, the contract cannot): a folder on the device such as `krog-rdragon-compare.jsonl` next to the app's local data, not inside a git-tracked site bundle and not inside `site-posts.json`.

### Record shape

Each JSONL line is one object. Fields below are the minimum. Extra keys are allowed; existing keys are not removed.

```json
{
  "v": 1,
  "kind": "compare",
  "id": "cmp-<post-or-comment-id>",
  "target_id": "<post or comment id>",
  "target_kind": "post",
  "target_text": "<user text>",
  "target_by": "@handle",
  "target_ts": "<when the user wrote it>",
  "media": [],
  "rdragon": {
    "text": "<reply>",
    "ts": "<when the reply was written>",
    "model": "<model id>",
    "version": "<engine or app version>",
    "latency_ms": 0,
    "status": "answered"
  },
  "krog": {
    "text": "<reply>",
    "ts": "<when the reply was written>",
    "model": "<model id>",
    "version": "<engine or app version>",
    "latency_ms": 0,
    "status": "answered"
  },
  "logged_ts": "<when this line was appended>",
  "device": "<this device's short name, not an address>",
  "reactions": {
    "rdragon": { "up": 0, "down": 0, "better": null, "notes": null },
    "krog": { "up": 0, "down": 0, "better": null, "notes": null }
  },
  "engagement": {
    "rdragon": { "replies": 0, "likes": 0, "reposts": 0 },
    "krog": { "replies": 0, "likes": 0, "reposts": 0 }
  }
}
```

Notes on the fields:

- `target_id`, `target_text`, both reply bodies, both timestamps, model and version, and reply latency are required once that side has answered.
- If one bot is still pending, append a first line when the first reply lands (the other side `status: "pending"`), then append a later `kind: "amend"` line when the second reply lands, still pointing at the same `target_id`. Do not patch the first line.
- `reactions` and `engagement` start empty or zeroed so later 👍 / 👎 / "better" marks and reply/like/repost counts have a place to go. Those updates are also new append lines (`kind: "reaction"` or `kind: "engagement"`), never an overwrite.
- No secrets, no keys, no LAN IPs, no tunnel URLs, no device identifiers beyond a short local name. The existing CryptoSocial `rdSafe` filter already refuses those in RDRAGON text; the log should use the same rule on all three text fields before writing.

---

## Local viewer (proposal)

A simple local-only page to review and compare the two replies, for example `compare-viewer.html` opened from the app or from a `file://` / loopback page on the same device.

Suggested behavior:

- Read the JSONL from the local file (or a local app API that only serves this device). Never fetch it from rizal.pw, rizal.info, or any other host.
- One row per `target_id`: the user post or comment on the left or top, RDRAGON's latest amend on one side, KROG's on the other, with model, version, timestamp, and latency under each.
- Filters: date, pending vs both-answered, which reply was marked better, slower than a chosen latency.
- Actions: mark up / down / better on either side. That writes a new JSONL line; it does not edit the old one.
- No delete, no clear, no "reset log" button.
- Not shipped as a public site page and not listed on rizal.pw or rizal.info.

CryptoSocial already has 👍 / 👎 / "better" on RDRAGON replies. The viewer can reuse that idea for both columns and keep the marks in the local log.

---

## Where this plugs in (from the survey, still read-only)

- Composer hooks already call `bot(...)` on every user post and comment in `rdragon-cryptosocial.js` and in GHOSTMACHINE's `crypto-side-panel.js`. That path becomes "write the RDRAGON reply, write the KROG reply, append one compare record."
- The public-feed scanner today only auto-replies to the profile owner's handle. This plan does not change that scope; whether other users' public posts are included is still an open question for Rizal. If they are included later, they get both replies and a log line too.
- GHOSTMACHINE can later sign a KROG identity with ASSMKit; RDRAGON iOS and the sites cannot until that is added. Signing is separate from the local compare log. The log itself is unsigned local analysis data.
- Public site pages and git-tracked bundles must not gain this JSONL. It lives only in on-device storage.

No implementation, build, install, or push until Rizal's own direct command.

---

## Still open (the dual-reply rule is not)

These remain questions, and do not weaken the both-reply rule:

1. Which model KROG uses (API, local MLX/Ollama-class server, or the existing Granite / RSYNC chain).
2. Rate limits and a queue when both models are slow, so a late KROG reply still lands and is logged, rather than skipped.
3. Whether other users' posts on public rizal.pw / rizal.info get the pair.
4. Bot identity and signing for the public KROG comment (unsigned, ASSMKit bot RID, or an event kind next to `rdragon.reply`).
5. Whether to rebrand and self-host the Rakazo snapshot, or use "KROG" as the CryptoSocial persona only.
6. Clearing the leftover tunnel URL in `rdragon-config.js` `statsEndpoint` before any public push (the URL itself is omitted here).
