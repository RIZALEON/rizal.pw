# PLAN: KROG bot login on rizal.pw and in RDRAGON (Nov 16, 2026, 5:30 PM MST). Plan only, no site code edited.

Server: `RC/ASSM-RSYNC-BOTTEST-20261116` on `http://127.0.0.1:8753` (test copy, its own data, no tunnel).
Account: **KROG**, `@krog`, `ЯID-BOT-0001`, role `bot`, scopes signin/post/reply. Wallet, approve, sign, mint, trade, swap, buy, sell and password-set are refused.
Protocol (see botauth.py and the README): `GET /api/rsync/bot/params?user=@krog` → PBKDF2-SHA256(pw, salt, iter≥600000, 32) → `POST /api/rsync/bot/login`
with `proof`, signed (P-256) by a **bot-only** device key over `assm-bot-login-v1\n…` → bearer `session`. Then `POST /api/rsync/bot/reply {parent_id, text}`.
Rizal's rule: KROG replies **next to** RDRAGON on every post, both bots reply, neither replies to the other's or its own replies, and both replies are logged side by side.

## A. rizal.pw (working copy `cryptoapp/GHOSTMACHINE/rizal.pw/rdragon-cryptosocial/`)
1. **New file `krog-bot.js`** (`window.KROGBot`), which is the JS twin of `clients/KROGBotLogin-RCODE.swift`:
   - `params()`, `login()`, `reply(parentId, text, parentAuthor)`, `post(text)`, `logout()`.
   - PBKDF2 uses `crypto.subtle.deriveBits({name:"PBKDF2",hash:"SHA-256",salt,iterations},key,256)`. The device key is a non-extractable ECDSA P-256 key in IndexedDB `rdragon.csp.krog` (separate from `rdragon.csp.keys` "device", the owner key used in `rlogin-page.js` get()/put()). Signatures are WebCrypto raw r||s, which p256.py accepts.
   - The session is kept in memory or sessionStorage only. Never put the password in shipped JS.
2. **Where the password comes from:** the public site must **not** carry KROG's password, because every visitor would get it. Two options:
   - **(a) Recommended:** KROG signs in from a local worker on the Neo (Python, using the same protocol as `bot-selftest.py --live`), and the page only receives KROG's reply text.
   - **(b) Test only:** on Rizal's own browser, a one-time import box stores it in IndexedDB.
3. **Hook point `rdragon-cryptosocial.js`:**
   - `function bot(id,t,media,parent)` (line 137) is RDRAGON's auto-reply. It's called for comments at line 474 (`bot(ce.id, …)`) and for posts at line 492 (`bot(pe.id, …)`).
   - Add a sibling `krog(id,t,media,parent)` that's called right after each `bot(...)`. It would call `KROGBot.reply(id, text)` and store the result in `S.krog[id]`, rendered under RDRAGON's reply.
   - Skip when the author is `@krog` or RDRAGON, so neither bot replies to the other.
   - Append `{post, rdragon, krog}` to the local compare log (as in the KROG plan).
   - Expose `botReplyKROG: krog` next to `botReply: bot` in the public API object.
4. **Config `rdragon-config.js`:** add `krogBotBase: "http://127.0.0.1:8753"`, local only. Never a tunnel or LAN IP. Also clear the old tunnel address that's still there.
5. **Page include:** add `<script src="krog-bot.js">` after `rdragon-config.js` in the page that loads `rdragon-cryptosocial.js`.
6. **Login UI (optional):** `rlogin-page.js` and `rsite-auth.js` stay owner-only. KROG doesn't use the owner login page, and `signin(me)` in the cryptosocial API must never receive a KROG session.
7. **Caveats:**
   - An https page calling http://127.0.0.1 works in Chrome. Safari may block it as mixed content, so test from a local http copy.
   - The server's CORS already allows `Authorization`.
8. **Live later:** a live server needs Rizal's **signed** `bot.create` instead of the unsigned bootstrap, plus an https bot endpoint.

## B. RDRAGON iOS (`cryptoapp/RDRAGON/RDRAGONSKULL/source/ios`, iOS-only targets; runs on the Neo as "My Mac (Designed for iPad)" or in the Simulator)
Status: **paused.** Grok Bot is editing RDRAGON's Xcode project for the 17e build on Rizal's go. Two edits were made before the stop and were left in place:
- `App/Sources/KROGBotLogin.swift`: new file. It holds the `KROGBotClient` and the `KROGBotWK` handler "krogBot", with Keychain prefix `info.rizal.dragonskull`.
  **It is not in RDRAGON.xcodeproj or DragonSkull.xcodeproj yet.**
- `App/Sources/App.swift`: added one line after `REmbedWKHandler.install(on: w)`, `KROGBotWK.install(on: w)`. The backup is at `~/Backups/krog-bot-20261116/RDRAGON/App.swift`.
  **⚠ Until KROGBotLogin.swift is added to the RDRAGON target, this line won't compile ("cannot find 'KROGBotWK'").**
  Grok Bot should either add the file to the target (PBXFileReference, a group child under the Sources group next to RMailBlock4Native.swift, PBXBuildFile, and the RDRAGON target's Sources phase) or comment out that one line before building for the 17e.
  The pbxproj backups are at `~/Backups/krog-bot-20261116/RDRAGON/{RDRAGON,DragonSkull}.project.pbxproj`.
  project.yml globs `App/Sources`, so xcodegen would pick the file up by itself.
Remaining steps once Grok Bot is done:
1. Add `KROGBotLogin.swift` to the RDRAGON target.
2. Bundled feed `App/web/ghost-machine/site/rdragon-cryptosocial/rdragon-cryptosocial.js`, same `bot()` at line 137: add `krog()` like in A3, using the native bridge instead of fetch:
   `window.webkit.messageHandlers.krogBot.postMessage({rid, op:"reply", parent_id:id, text})`, with the result coming back on `window` event `krog-bot`.
   Use ops `status`/`import`/`login` first.
3. The password comes from a one-time `import` op into RDRAGON's own Keychain (`info.rizal.dragonskull.saved-login.krog`), because an iOS-on-Mac app can't read the login-keychain item.
4. ATS: project.yml already has `NSAllowsLocalNetworking: true`.
5. 17e/Moto: 127.0.0.1 on a phone is the phone itself, so the phones need a reachable bot endpoint. That's a separate decision (no tunnels without Rizal).

## C. Already done (for reference)
- RCODE (`~/Library/Developer/Xcode/UntitledProjects/RCODE`, branch offline-model, nothing committed):
  - `RCODE/Auth/KROGBotLogin.swift` is new. It holds `KROGBotClient` and `KROGTestPanel`.
  - `RCODE/UI/RCodeMenuPanel.swift` got 3 lines: the "KROG bot (test)" row under Settings, plus its sheet.
- Keychain items labeled "KROG" (account `@krog`, add-only) are saved under `io.rlab.rwalet.xcode.saved-login.krog` (RWALET), `info.rizal.rmail.mac.saved-login.krog` (RMAIL) and `info.rizal.rcode.saved-login.krog` (RCODE).
