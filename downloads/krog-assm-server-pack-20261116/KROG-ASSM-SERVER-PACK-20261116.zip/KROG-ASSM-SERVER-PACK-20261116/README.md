# KROG-ASSM-SERVER-PACK-20261116

One pack for the ASSM sign-in + RSYNC + KROG bot server and every client, built Monday, Nov 16, 2026 (America/Denver) by SCRIBE.

> **Status:** distributable pack + docs only. **Nothing was built, installed, deployed or pushed.** No website or app was touched.
> The always-on host (a rented VPS, ~$5–12/month) is **awaiting Rizal's approval** — see `docs/VPS-HOST-OPTIONS.md`.
> The host is the placeholder **`ASSM_SERVER_URL`** everywhere. Every install needs **Rizal's own direct command**; Apple apps are
> edited in their existing Xcode projects and installed with **Run** in Xcode.

| Folder | What |
|---|---|
| `server/` | Multi-profile ASSM-RSYNC server (owner + bots, KROG), owner-signed bot creation, Dockerfile, systemd unit, run script, config |
| `clients/swift/ASSMKit` | Swift package for every Apple app |
| `clients/swift/KROG` | `KROGBotLogin` Swift clients: RCODE, RDRAGON (as in its project now), RDRAGON bot-test variant |
| `clients/swift/RCODE-Auth-plists` | RCODE's auth + owner plists (tunnel URL replaced with `ASSM_SERVER_URL`) as templates |
| `clients/android/assmkit-android` | Kotlin port for the Moto |
| `clients/linux/assm-linux` | Python client for the Pixel 3a (Ubuntu Touch) and the RVM |
| `clients/web/assm-web-client.js` | Web client for rizal.pw / rizal.info / WebViews (bot login, owner route wrappers) |
| `clients/krog/krog-reply.rzl.js` | Both-reply rule (RDRAGON + KROG once each; no bot↔bot, no self) + append-only local compare log |
| `wallet/rwallet` | RWALLET v6 unified bundle **0.1.5** |
| `docs/` | `ASSM-RCODE-LOGIN-INSTALL-GUIDE.md`, `INSTALL-PER-DEVICE.md`, `VPS-HOST-OPTIONS.md` |
| `plans/` | The two KROG plans (both-reply; bot login on the site and RDRAGON) |
| `MANIFEST.md`, `SHA256SUMS` | Source path + date for every file; checksums |

Excluded by rule: every `data/`, `secrets/` (incl. `bot-login.txt`), `keys/`, private keys, logs, pid files, `trusted-devices.json`, `.git`,
Neo launchd plists, the tunnel publisher script, `server.py.pre-*` backups. Tunnel URLs and LAN addresses were replaced with placeholders
(see MANIFEST "Redactions"). The KROG password is **not** in this pack.

Verify: `sha256sum -c SHA256SUMS` (macOS: `shasum -a 256 -c SHA256SUMS`).
