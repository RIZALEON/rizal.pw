# assm-linux: RCODE sign-in + sync for Linux

The Linux side of ASSMKit, written in Python 3. It has the same providers and order as `SignInView` and the Android
`assmkit-android` screen. Every option ends on **ЯID-0001-3QQS** with this machine's own P-256 device key,
approved once. Sync uses the same signed ASSM-RSYNC calls (`/api/rsync/request|approve|device-status`,
`/v1/sync/changes|pull`). The live URL is rediscovered from `https://rizal.pw/api/rsync/entries` (`live`).

## Requirements
- Python ≥ 3.9 with `cryptography` (Debian/Ubuntu `python3-cryptography`, Fedora `python3-cryptography`)
- Optional: `secretstorage` (Secret Service via D-Bus) or `secret-tool` (libsecret-tools), and `qrcode` (QR on the page and in the terminal)

## Usage
```
tools/assm-linux/assm-linux signin              # opens the sign-in window in the system browser
tools/assm-linux/assm-linux signin --no-browser            # prints the URL instead
tools/assm-linux/assm-linux signin --assm       # terminal: 8-digit code + ASCII QR, waits for approval
tools/assm-linux/assm-linux signin --password   # ASSM username + password (only if enabled)
tools/assm-linux/assm-linux status              # key store, account, device-status on ASSM
tools/assm-linux/assm-linux pull [--since C]    # signed pull, records as JSON
tools/assm-linux/assm-linux push records.json   # signed push (list of wire records: id, kind, updated_at, device_id, deleted, payload)
tools/assm-linux/assm-linux signout             # forget the account (device key stays approved)
tools/assm-linux/assm-linux preview             # sign-in window with sample data: no key, no network
python3 tools/assm-linux/tests/test_assm_linux.py   # 17 tests
```

## The sign-in window
`signin` opens **one** HTTP listener on `127.0.0.1:<ephemeral port>`, which is the only one this client opens. It serves
the page and receives the OAuth redirects, and it closes when sign-in finishes, on "Not now" or after 15 minutes.
- Binds 127.0.0.1 only. `Host` must be `127.0.0.1:<port>` (blocks DNS rebinding).
- The page and API need a per-session token. OAuth callbacks need the PKCE `state`. A strict CSP is set.

| Option | How on Linux |
|---|---|
| Google | system browser + PKCE, Google *Desktop app* client, redirect `http://127.0.0.1:<port>/callback/google` |
| Apple | system browser; Apple only returns to https, so `https://rizal.pw/auth/apple/desktop` relays the `form_post` to `http://127.0.0.1:<port>/callback/apple` (port is in `state`) |
| Email | RCODE server `/v1/auth/password/login|signup` |
| Passkey | WebAuthn needs an https RP, so it goes through the bridge `https://rizal.pw/auth/passkey/desktop`, which returns the server session to `/callback/passkey` |
| Microsoft | system browser + PKCE, public client, redirect `http://127.0.0.1/callback/microsoft` (Entra ignores the loopback port) |
| ASSM | 8-digit code + QR (`rsync-enroll-v1`), approved once on a trusted device; polls device-status |
| ASSM username + password | `/api/rsync/password/{params,login}`, PBKDF2-HMAC-SHA256 600k on this machine, proof = base64(dk), signed `assm-password-login-v1`. **Off by default** (`assm_password_enabled`, or `RCODE_ASSM_PASSWORD=1`). The password field is cleared after sending and never stored. Password *set* stays Apple-only. |
| Device link | RCODE server `/v1/devices/link/claim` |
| Approve a device | code lookup + `device.enroll` seal signed by a separate approver key (`rcode_assm_approver`); Rizal adds that key to the trusted list on Neo |

## Keys and files
- Device key: Secret Service (`service=info.rizal.rcode.assm-device-key`, `account=rcode_assm_device`). If no keyring
  is available it falls back to `~/.local/share/rcode-assm/rcode_assm_device.pem` (0600, dir 0700). Force a backend with `RCODE_ASSM_KEYSTORE=secret|file`.
- `~/.config/rcode-assm/config.json` overrides the public config (client IDs, server URL). `state.json` and
  `account.json` (0600) hold the learned live URL, the pending request and the linked identities. No passwords or tokens are written to disk.
- Env: `RCODE_ASSM_BASE_URL` / `RCODE_ASSM_FALLBACK_URL` override the ASSM bases (used by the tests).

Placeholders and the registration checklist are in `android/assmkit-android/README.md` (the same accounts cover Linux):
a Google *Desktop app* client (ID + secret), an Entra loopback redirect, the Apple desktop return URL, and the passkey bridge.
