"""Linux ASSMKit tests. Vectors match the Android ContractTest (computed with ASSM-RSYNC sync.py _canon).
A fake ASSM-RSYNC runs on 127.0.0.1 (test-only) and verifies every signature the way the server does."""
import base64, glob, http.client, json, os, socket, stat, sys, tempfile, threading, time, unittest, urllib.parse

TMP = tempfile.mkdtemp(prefix="assm-linux-test-")
os.environ.update(XDG_CONFIG_HOME=os.path.join(TMP, "cfg"), XDG_DATA_HOME=os.path.join(TMP, "data"), RCODE_ASSM_KEYSTORE="file")
os.environ.pop("RCODE_ASSM_BASE_URL", None)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature

from assm_linux import assm, auth, canon, config, keystore, loopback, net, sync


def verify(pub_b64, msg, sig_b64):
    pub = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), base64.b64decode(pub_b64))
    raw = base64.b64decode(sig_b64)
    assert len(raw) == 64
    pub.verify(encode_dss_signature(int.from_bytes(raw[:32], "big"), int.from_bytes(raw[32:], "big")),
               msg.encode(), ec.ECDSA(hashes.SHA256()))
    return True


class FakeAssm:
    """Minimal ASSM-RSYNC: /health, /api/rsync/request(+/<code>), device-status, approve, /v1/sync/*, entries."""

    def __init__(self, live_for_feed=None):
        self.requests, self.approved, self.records, self.trusted_approvers, self.live_for_feed = {}, set(), [], set(), live_for_feed
        self.nonces = set()
        self.pw = {}          # profile -> (salt, iter, verifier)
        self.pw_fail = 0
        f = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass

            def _j(self, code, o):
                b = json.dumps(o).encode()
                self.send_response(code); self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)

            def do_GET(self):
                u = urllib.parse.urlparse(self.path); q = urllib.parse.parse_qs(u.query)
                if u.path == "/health": return self._j(200, {"ok": True})
                if u.path == "/api/rsync/entries": return self._j(200, {"entries": [], "live": f.live_for_feed})
                if u.path == "/api/rsync/password/params":
                    user = q["user"][0]
                    if user not in ("ЯID-0001-3QQS", "@chaserizal") or "ЯID-0001-3QQS" not in f.pw:
                        return self._j(404, {"error": "no password"})
                    salt, it, _ = f.pw["ЯID-0001-3QQS"]
                    return self._j(200, {"scheme": "pbkdf2-sha256-hmac-v1", "profile": "ЯID-0001-3QQS", "handle": "@chaserizal",
                                         "salt": base64.b64encode(salt).decode(), "iter": it})
                if u.path == "/api/rsync/device-status":
                    pub = q["pub"][0]
                    return self._j(200, {"trusted": False, "enrolled": pub in f.approved, "pending": pub in f.requests,
                                         "status": "enrolled" if pub in f.approved else "pending", "profile": "ЯID-0001-3QQS"})
                if u.path.startswith("/api/rsync/request/"):
                    code = u.path.rsplit("/", 1)[1]
                    for r in f.requests.values():
                        if canon.short_code(r["device"], r["nonce"]) == code:
                            return self._j(200, dict(r, code=code, status="approved" if r["device"] in f.approved else "pending"))
                    return self._j(404, {"error": "no request"})
                self._j(404, {"error": "nf"})

            def do_POST(self):
                o = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                p = self.path
                try:
                    if p == "/api/rsync/request":
                        assert o["t"] == "device.request"
                        verify(o["device"], f"rsync-enroll-v1\n{o['device']}\n{o['nonce']}\n{o['req_ts']}", o["req_sig"])
                        f.requests[o["device"]] = o
                        return self._j(201, {"ok": True})
                    if p == "/api/rsync/approve":
                        g = o["rgen"]
                        body = {k: v for k, v in o.items() if k not in ("cid", "rgen")}
                        assert o["cid"] == canon.sha256_hex(canon.canon(body)) and g["msg"] == assm.PREFIX + o["cid"]
                        verify(g["pub"], g["msg"], g["value"])
                        if g["pub"] not in f.trusted_approvers: return self._j(403, {"error": "untrusted signer"})
                        f.approved.add(o["device"]); return self._j(201, {"ok": True})
                    if p == "/api/rsync/password/login":
                        import hashlib, hmac as _h
                        assert o["t"] == "password.login" and 8 <= len(o["nonce"]) <= 64 and o["nonce"].isalnum()
                        if f.pw_fail >= 3: return self._j(429, {"error": "locked", "retry_after_s": 42})
                        if o["nonce"] in f.nonces: return self._j(409, {"error": "replay"})
                        f.nonces.add(o["nonce"])
                        verify(o["device"], auth.pw_login_message(o["user"], o["proof"], o["device"], o["device_name"], o["nonce"], o["ts"]), o["sig"])
                        _, _, ver = f.pw["ЯID-0001-3QQS"]
                        dk = base64.b64decode(o["proof"])
                        if not _h.compare_digest(_h.new(dk, b"assm-password-verifier-v1", hashlib.sha256).digest(), ver):
                            f.pw_fail += 1; return self._j(401, {"error": "wrong username or password"})
                        f.approved.add(o["device"])
                        return self._j(200, {"ok": True, "profile": "ЯID-0001-3QQS", "handle": "@chaserizal"})
                    if p in ("/v1/sync/changes", "/v1/sync/pull"):
                        if o["device"] not in f.approved: return self._j(403, {"error": "not enrolled"})
                        if o["nonce"] in f.nonces: return self._j(409, {"error": "replay"})
                        f.nonces.add(o["nonce"])
                        action = "push" if p.endswith("changes") else "pull"
                        h = canon.sha256_hex(canon.canon(o["records"])) if action == "push" else (o.get("since") or "")
                        verify(o["device"], f"rcode-sync-v1\n{action}\n{o['identity']}\n{o['device']}\n{o['nonce']}\n{o['ts']}\n{h}", o["sig"])
                        if action == "push":
                            f.records += o["records"]; return self._j(200, {"accepted": len(o["records"])})
                        return self._j(200, {"records": f.records, "cursor": "c1"})
                except Exception as e:
                    return self._j(400, {"error": repr(e)})
                self._j(404, {"error": "nf"})

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.base = f"http://127.0.0.1:{self.httpd.server_address[1]}"
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def close(self):
        self.httpd.shutdown(); self.httpd.server_close()


class Vectors(unittest.TestCase):
    def test_canon_matches_server(self):
        payload = {"id": "ABC", "chat_id": "C1", "sender": "Rizal", "text": "héllo \"q\"\n\ttab ЯID", "sent_at": "2026-11-16T17:00:00Z", "is_user": True}
        rec = {"id": "msg:ABC", "kind": "message", "updated_at": "2026-11-16T17:00:00.123Z", "device_id": "d1", "deleted": False,
               "payload": payload, "sent_at": "2026-11-16T17:00:00Z", "dropped": None}
        c = canon.canon([rec])
        self.assertEqual(c, '[{"deleted":false,"device_id":"d1","id":"msg:ABC","kind":"message","payload":{"chat_id":"C1","id":"ABC","is_user":true,"sender":"Rizal","sent_at":"2026-11-16T17:00:00Z","text":"héllo \\"q\\"\\n\\ttab ЯID"},"sent_at":"2026-11-16T17:00:00Z","updated_at":"2026-11-16T17:00:00.123Z"}]')
        self.assertEqual(canon.sha256_hex(c), "8a9e87a45af8dbe91f9a68cc658e6b5cbb09c4936f1759eebfcebac477322f18")

    def test_short_code_and_encoding(self):
        self.assertEqual(canon.short_code("BAbc+/==", "Xyz123abc"), "0726-4264")
        self.assertEqual(net.query_encode("BAbc+/=="), "BAbc%2B%2F%3D%3D")
        self.assertEqual(assm.normalize_code("0726 4264"), "0726-4264")
        self.assertEqual(assm.normalize_code("rcode://assm-approve?device=BAbc%2B%2F%3D%3D&nonce=Xyz123abc"), "0726-4264")
        self.assertIsNone(assm.normalize_code("123"))

    def test_iso_and_pkce(self):
        self.assertEqual(canon.iso_js(1794848400.123), "2026-11-16T17:00:00.123Z")
        self.assertEqual(auth.Pkce("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk").challenge, "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM")
        self.assertTrue(net.is_valid_base("https://x.example") and net.is_valid_base("http://127.0.0.1:8752"))
        self.assertFalse(net.is_valid_base("http://evil.example"))

    def test_qr_payload_and_enroll_signature(self):
        k = keystore.DeviceKey("t_enroll")
        r = assm.EnrollRequest.make(k, "RCODE Linux test")
        self.assertTrue(verify(r.device, f"rsync-enroll-v1\n{r.device}\n{r.nonce}\n{r.req_ts}", r.req_sig))
        self.assertTrue(r.qr_payload.startswith("rcode://assm-approve?device="))
        q = urllib.parse.parse_qs(urllib.parse.urlparse(r.qr_payload).query)
        self.assertEqual(q["device"][0], r.device)
        self.assertEqual(set(r.body()), {"t", "device", "nonce", "req_ts", "req_sig", "device_name"})


class KeyStore(unittest.TestCase):
    def test_file_fallback_is_0600_and_persistent(self):
        k = keystore.DeviceKey("rcode_assm_device_t", keystore.backend("file"))
        pub = k.public_key_base64()
        self.assertEqual(len(base64.b64decode(pub)), 65)
        p = os.path.join(config.DATA_DIR, "rcode_assm_device_t.pem")
        self.assertEqual(stat.S_IMODE(os.stat(p).st_mode), 0o600)
        self.assertEqual(stat.S_IMODE(os.stat(config.DATA_DIR).st_mode), 0o700)
        self.assertEqual(keystore.DeviceKey("rcode_assm_device_t", keystore.backend("file")).public_key_base64(), pub)
        self.assertTrue(verify(pub, "hello", k.sign("hello")))

    def test_default_alias_matches_android(self):
        self.assertEqual(keystore.DeviceKey(store=keystore.backend("file")).alias, "rcode_assm_device")

    def test_secret_service_forced_without_bus_fails_cleanly(self):
        env = os.environ.pop("DBUS_SESSION_BUS_ADDRESS", None)
        try:
            try:
                b = keystore.backend("secret")
                self.assertIn(b.name, ("secret-service", "secret-tool"))
            except keystore.KeyStoreError:
                pass
        finally:
            if env: os.environ["DBUS_SESSION_BUS_ADDRESS"] = env


class LiveFlow(unittest.TestCase):
    def setUp(self):
        self.srv = FakeAssm()
        os.environ["RCODE_ASSM_BASE_URL"] = self.srv.base
        os.environ["RCODE_ASSM_FALLBACK_URL"] = self.srv.base  # never touch the real rizal.pw in tests
        net.save_state(pending_enroll=None, owner_approved=False, assm_learned_live=None)

    def tearDown(self):
        os.environ.pop("RCODE_ASSM_FALLBACK_URL", None)
        os.environ.pop("RCODE_ASSM_BASE_URL", None)
        self.srv.close()

    def test_enroll_approve_sync(self):
        key = keystore.DeviceKey("rcode_assm_device_flow")
        en = assm.Enrollment(key)
        req = en.start()
        self.assertIn(key.public_key_base64(), self.srv.requests)
        self.assertFalse(en.poll_once())
        # same key, same pending code on restart (no second request needed)
        self.assertEqual(assm.Enrollment(key).start().short_code, req.short_code)
        # a trusted approver (another device) approves by code
        approver = keystore.DeviceKey("rcode_assm_approver_flow")
        live = net.Live()
        pr = assm.lookup_request(live, req.short_code)
        with self.assertRaises(PermissionError):
            assm.approve(live, pr, "ЯID-0001-3QQS", approver)
        self.srv.trusted_approvers.add(approver.public_key_base64())
        self.assertTrue(assm.approve(live, pr, "ЯID-0001-3QQS", approver))
        self.assertTrue(en.poll_once())
        self.assertTrue(net.state()["owner_approved"])
        self.assertIsNone(assm.Enrollment(key).start())  # already approved -> no new request
        svc = sync.SyncService(key, "ЯID-0001-3QQS")
        rec = sync.record("msg:1", "message", {"id": "1", "text": "hi from linux", "sent_at": "2026-11-16T17:00:00Z"}, "linux-1")
        self.assertEqual(svc.push([rec])["accepted"], 1)
        recs, cur = svc.pull()
        self.assertEqual((recs[0]["id"], cur), ("msg:1", "c1"))
        self.assertEqual(svc.pull("c1")[1], "c1")

    def test_unapproved_device_cannot_sync(self):
        with self.assertRaises(sync.SyncHttpError) as e:
            sync.SyncService(keystore.DeviceKey("rcode_assm_device_x"), "ЯID-0001-3QQS").pull()
        self.assertEqual(e.exception.status, 403)

    def test_heal_learns_live_url_from_rizal_pw_feed(self):
        os.environ.pop("RCODE_ASSM_BASE_URL")
        feed = FakeAssm(live_for_feed=self.srv.base)  # stands in for rizal.pw
        os.environ["RCODE_ASSM_FALLBACK_URL"] = feed.base
        cfg = dict(config.load(), assm_base_url="http://127.0.0.1:9")
        try:
            live = net.Live(cfg)
            self.assertTrue(live.heal())
            self.assertEqual(live.base(), self.srv.base)
        finally:
            net.save_state(assm_learned_live=None)
            feed.close()


def _req(port, method, path, host=None, body=None, token=None):
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
    h = {"Host": host or f"127.0.0.1:{port}", "Content-Type": "application/json"}
    if token: h["X-RCODE-Session"] = token
    c.request(method, path, json.dumps(body) if body is not None else None, h)
    r = c.getresponse()
    return r.status, r.read().decode(), dict(r.getheaders())


class SignInWindow(unittest.TestCase):
    def test_loopback_guards_and_lifetime(self):
        s = loopback.SignInSession(open_browser=False, timeout=30)
        self.assertEqual(s.httpd.server_address[0], "127.0.0.1")
        self.assertNotEqual(s.port, 0)
        t = threading.Thread(target=s.run); t.start()
        time.sleep(0.3)
        self.assertEqual(_req(s.port, "GET", "/")[0], 403)                                   # no token
        self.assertEqual(_req(s.port, "GET", "/?t=" + s.token, host="evil.test")[0], 421)  # DNS rebinding
        st, html, hdr = _req(s.port, "GET", "/?t=" + s.token)
        self.assertEqual(st, 200); self.assertIn("Continue with passkey", html); self.assertIn("default-src 'none'", hdr["Content-Security-Policy"])
        order = [html.index(x) for x in ('pill("google"', 'pill("apple"', "Continue with email", 'pill("passkey"', 'pill("microsoft"', 'pill("assm"')]
        self.assertEqual(order, sorted(order))
        state = json.loads(_req(s.port, "GET", "/api/state", token=s.token)[1])
        self.assertFalse(state["providers"]["google"]); self.assertTrue(state["providers"]["assm"])
        self.assertFalse(state["providers"]["assm-password"])                               # off by default
        st, b, _ = _req(s.port, "POST", "/api/assm-password", body={"username": "a", "password": "b"}, token=s.token)
        self.assertEqual(st, 400); self.assertIn("not available yet", b)
        st, b, _ = _req(s.port, "POST", "/api/email", body={"username": "a@b.c", "password": "x"}, token=s.token)
        self.assertIn("not configured", b)
        # an OAuth callback with an unknown state is rejected
        st, _, hdr = _req(s.port, "GET", "/callback/google?code=x&state=forged")
        self.assertEqual(st, 303)
        time.sleep(0.3)
        self.assertIn("did not match", json.loads(_req(s.port, "GET", "/api/state", token=s.token)[1])["error"])
        # "Not now" closes the listener
        _req(s.port, "POST", "/api/close", body={}, token=s.token)
        t.join(5)
        self.assertFalse(t.is_alive())
        with self.assertRaises(OSError):
            socket.create_connection(("127.0.0.1", s.port), timeout=1).close()

    def test_oauth_urls_use_pkce_and_loopback(self):
        cfg = dict(config.load(), google_desktop_client_id="g.apps.googleusercontent.com", microsoft_client_id="m-id", apple_services_id="info.rizal.rcode.web")
        pk = auth.Pkce()
        g = urllib.parse.parse_qs(urllib.parse.urlparse(auth.google_auth_url(cfg, "http://127.0.0.1:5555/callback/google", pk)).query)
        self.assertEqual((g["code_challenge_method"][0], g["code_challenge"][0], g["redirect_uri"][0]), ("S256", pk.challenge, "http://127.0.0.1:5555/callback/google"))
        m = urllib.parse.parse_qs(urllib.parse.urlparse(auth.microsoft_auth_url(cfg, "http://127.0.0.1:5555/callback/microsoft", pk)).query)
        self.assertEqual(m["code_challenge_method"][0], "S256")
        a = urllib.parse.parse_qs(urllib.parse.urlparse(auth.apple_auth_url(cfg, 5555, pk)).query)
        self.assertEqual((a["redirect_uri"][0], a["state"][0]), ("https://rizal.pw/auth/apple/desktop", "5555." + pk.state))

    def test_full_assm_signin_through_window(self):
        srv = FakeAssm()
        os.environ["RCODE_ASSM_BASE_URL"] = srv.base
        os.environ["RCODE_ASSM_FALLBACK_URL"] = srv.base
        net.save_state(pending_enroll=None, owner_approved=False, assm_learned_live=None)
        try:
            s = loopback.SignInSession(open_browser=False, timeout=60)
            s.enrollment_interval = 0.2
            t = threading.Thread(target=s.run); t.start(); time.sleep(0.3)
            _req(s.port, "POST", "/api/start", body={"provider": "assm"}, token=s.token)
            for _ in range(50):
                st = json.loads(_req(s.port, "GET", "/api/state", token=s.token)[1])
                if st.get("assm"): break
                time.sleep(0.1)
            code = st["assm"]["code"]
            self.assertRegex(code, r"^\d{4}-\d{4}$")
            approver = keystore.DeviceKey("rcode_assm_approver_w"); srv.trusted_approvers.add(approver.public_key_base64())
            assm.approve(net.Live(), assm.lookup_request(net.Live(), code), "ЯID-0001-3QQS", approver)
            t.join(20)
            self.assertFalse(t.is_alive(), "window should close after approval")
            acct = auth.Account().data
            self.assertTrue(any(i["provider"] == "assm" and i["subject"] == "ЯID-0001-3QQS" and i["verified"] for i in acct["identities"]))
        finally:
            os.environ.pop("RCODE_ASSM_BASE_URL", None); os.environ.pop("RCODE_ASSM_FALLBACK_URL", None); srv.close()


class AssmPassword(unittest.TestCase):
    def test_vectors_match_assmkit(self):
        self.assertEqual(auth.pw_derive("password", b"salt", 1).hex(), "120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b")
        self.assertEqual(auth.pw_login_message("@h", "abc", "D", "n", "N", "T"),
                         "assm-password-login-v1\n@h\nba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad\nD\nn\nN\nT")
        n = auth.pw_nonce(); self.assertTrue(8 <= len(n) <= 64 and n.isalnum())

    def test_off_by_default(self):
        self.assertFalse(config.load()["assm_password_enabled"])
        with self.assertRaises(auth.AuthError) as e:
            auth.assm_password_signin(config.load(), "@chaserizal", "x", None)
        self.assertIn("not available yet", str(e.exception))

    def test_login_flow_against_server_routes(self):
        import hashlib, hmac as _h
        srv = FakeAssm()
        salt = b"0123456789abcdef"
        dk = auth.pw_derive("correct horse battery", salt, 600000)
        srv.pw["ЯID-0001-3QQS"] = (salt, 600000, _h.new(dk, b"assm-password-verifier-v1", hashlib.sha256).digest())
        cfg = dict(config.load(), assm_password_enabled=True, assm_base_url=srv.base)
        live = net.Live(cfg)
        os.environ["RCODE_ASSM_BASE_URL"] = srv.base
        try:
            key = keystore.DeviceKey("rcode_assm_device_pw")
            with self.assertRaises(auth.AuthError) as e:
                auth.assm_password_signin(cfg, "@nobody", "x", key, live)
            self.assertEqual(str(e.exception), "Wrong username or password.")          # 404 params
            with self.assertRaises(auth.AuthError) as e:
                auth.assm_password_signin(cfg, "@chaserizal", "wrong password!", key, live)
            self.assertEqual(str(e.exception), "Wrong username or password.")          # 401
            cred = auth.assm_password_signin(cfg, "@chaserizal", "correct horse battery", key, live)
            self.assertEqual(cred["profile"], "ЯID-0001-3QQS")
            self.assertIn(key.public_key_base64(), srv.approved)                         # key ACTIVE
            st = assm.device_status(live, key.public_key_base64()); self.assertTrue(st.approved)
            srv.pw_fail = 3
            with self.assertRaises(auth.AuthError) as e:
                auth.assm_password_signin(cfg, "@chaserizal", "correct horse battery", key, live)
            self.assertIn("42 s", str(e.exception))                                      # 429 retry_after_s
            for f in glob.glob(os.path.join(TMP, "**", "*"), recursive=True):             # never stored
                if os.path.isfile(f):
                    self.assertNotIn(b"correct horse", open(f, "rb").read())
        finally:
            os.environ.pop("RCODE_ASSM_BASE_URL", None); srv.close()


class AccountUnify(unittest.TestCase):
    def test_every_provider_unifies_on_owner_identity(self):
        a = auth.Account(); a.sign_out()
        started = []
        a.complete({"provider": "google", "subject": "g-123", "email": "r@x", "proof": {}}, lambda: started.append(1))
        ids = {(i["provider"], i["subject"]): i for i in a.data["identities"]}
        self.assertIn(("google", "g-123"), ids); self.assertFalse(ids[("assm", "ЯID-0001-3QQS")]["verified"])
        self.assertEqual(started, [1])
        a.complete({"provider": "microsoft", "subject": "m-9", "proof": {}})
        self.assertEqual(len(a.data["identities"]), 3)
        a.on_owner_approved()
        self.assertTrue([i for i in a.data["identities"] if i["provider"] == "assm"][0]["verified"])
        self.assertEqual(stat.S_IMODE(os.stat(auth.ACCOUNT_FILE()).st_mode), 0o600)
        self.assertNotIn("token", open(auth.ACCOUNT_FILE()).read())


if __name__ == "__main__":
    unittest.main(verbosity=2)
