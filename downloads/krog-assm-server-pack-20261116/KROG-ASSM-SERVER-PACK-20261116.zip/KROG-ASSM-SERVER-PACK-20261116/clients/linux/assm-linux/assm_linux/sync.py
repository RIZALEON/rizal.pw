"""ASSM-RSYNC REST sync (port of ASSMSyncService / Android AssmSyncService). Signed with the device key:
rcode-sync-v1\\n<action>\\n<identity>\\n<pub>\\n<nonce>\\n<ts>\\n<hash>; hash = sha256(canon(records)) for push,
the `since` cursor (or "") for pull."""
from . import assm, canon, net

KINDS = ("chat", "message", "setting")


class SyncHttpError(Exception):
    def __init__(self, status, msg):
        super().__init__(msg)
        self.status = status


def record(id, kind, payload, device_id, deleted=False, updated_at=None):
    o = {"id": id, "kind": kind, "updated_at": updated_at or canon.iso_js(), "device_id": device_id,
         "deleted": bool(deleted), "payload": payload}
    if isinstance(payload, dict) and payload.get("sent_at"):
        o["sent_at"] = payload["sent_at"]
    return o


class SyncService:
    def __init__(self, key, identity, live=None):
        self.key, self.identity, self.live = key, identity, live or net.Live()

    def push(self, records):
        if not records:
            return {}
        for r in records:
            if r.get("kind") not in KINDS:
                raise ValueError("kind must be chat|message|setting")
        return self._call("/v1/sync/changes", "push", None, records)

    def pull(self, since=None):
        o = self._call("/v1/sync/pull", "pull", since, None)
        recs = [r for r in o.get("records") or [] if isinstance(r, dict) and r.get("id") and r.get("kind") in KINDS]
        return recs, (o.get("cursor") or None)

    def _call(self, path, action, since, records):
        try:
            return self._once(path, action, since, records)
        except OSError:
            if self.live.heal():
                return self._once(path, action, since, records)
            raise

    def envelope(self, action, since, records):
        pub = self.key.public_key_base64()
        n = assm.nonce()
        ts = canon.iso_js()
        h = canon.sha256_hex(canon.canon(records)) if records is not None else (since or "")
        sig = self.key.sign(f"rcode-sync-v1\n{action}\n{self.identity}\n{pub}\n{n}\n{ts}\n{h}")
        o = {"identity": self.identity, "device": pub, "ts": ts, "nonce": n, "sig": sig}
        if records is not None:
            o["records"] = records
        if action == "pull" and since is not None:
            o["since"] = since
        return o

    def _once(self, path, action, since, records):
        r = net.post_json(self.live.base() + path, self.envelope(action, since, records), 20)
        if r.status in (502, 503, 504, 530) or (r.status == 404 and not isinstance(r.json(), dict)):
            raise OSError(f"ASSM live URL unreachable (HTTP {r.status})")
        if r.status == 200:
            return r.obj()
        if r.status == 403:
            raise SyncHttpError(403, r.obj().get("error") or "device is not a trusted or enrolled signer for this identity")
        if r.status == 409:
            raise SyncHttpError(409, "replayed sync nonce")
        if r.status == 429:
            raise SyncHttpError(429, "rate limited (429); backing off")
        raise SyncHttpError(r.status, r.error())
