"""Small stdlib HTTP client + ASSM live-URL discovery (port of Android Http/Net/Assm)."""
import json, os, urllib.error, urllib.parse, urllib.request

from . import config

UA = "RCODE-Linux/assmkit"
STATE_FILE = lambda: os.path.join(config.CONFIG_DIR, "state.json")


class Resp:
    def __init__(self, status, body):
        self.status, self.body = status, body

    def json(self):
        try:
            return json.loads(self.body)
        except Exception:
            return None

    def obj(self):
        j = self.json()
        return j if isinstance(j, dict) else {}

    def error(self):
        return self.obj().get("error") or f"HTTP {self.status}"


def call(method, url, body=None, timeout=20, ctype="application/json", bearer=None):
    data = None
    if body is not None:
        data = body.encode() if isinstance(body, str) else body
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("User-Agent", UA)
    req.add_header("Accept", "application/json")
    if data is not None:
        req.add_header("Content-Type", ctype)
    if bearer:
        req.add_header("Authorization", "Bearer " + bearer)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return Resp(r.status, r.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        return Resp(e.code, e.read().decode("utf-8", "replace"))


def get(url, timeout=15):
    return call("GET", url, timeout=timeout)


def post_json(url, obj, timeout=20, bearer=None):
    return call("POST", url, json.dumps(obj, ensure_ascii=False), timeout, bearer=bearer)


def post_form(url, form, timeout=20):
    return call("POST", url, urllib.parse.urlencode(form), timeout, "application/x-www-form-urlencoded")


def query_encode(v):
    """RFC 3986 unreserved-only, so base64 + / = survive."""
    return urllib.parse.quote(v, safe="-._~")


def is_valid_base(s):
    try:
        u = urllib.parse.urlparse(s.strip())
    except Exception:
        return False
    return u.scheme == "https" or (u.scheme == "http" and u.hostname in ("127.0.0.1", "localhost", "::1"))


def parse_feed(text):
    try:
        v = json.loads(text)
    except Exception:
        out = []
        for l in text.splitlines():
            try:
                out.append(json.loads(l))
            except Exception:
                pass
        return [o for o in out if isinstance(o, dict)], None
    if isinstance(v, list):
        return [o for o in v if isinstance(o, dict)], None
    if isinstance(v, dict):
        return [o for o in v.get("entries") or [] if isinstance(o, dict)], (v.get("live") or None)
    return [], None


def _state():
    try:
        with open(STATE_FILE()) as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(**kw):
    s = _state()
    s.update(kw)
    os.makedirs(config.CONFIG_DIR, mode=0o700, exist_ok=True)
    fd = os.open(STATE_FILE() + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(s, f, ensure_ascii=False, indent=1)
    os.replace(STATE_FILE() + ".tmp", STATE_FILE())


def state():
    return _state()


class Live:
    """Live ASSM-RSYNC base: env override, then learned URL, then default; heals from rizal.pw `live`."""

    def __init__(self, cfg=None):
        self.cfg = cfg or config.load()

    def base(self):
        env = os.environ.get("RCODE_ASSM_BASE_URL", "")
        if env and is_valid_base(env):
            return env.rstrip("/")
        learned = _state().get("assm_learned_live", "")
        if learned and is_valid_base(learned):
            return learned.rstrip("/")
        return self.cfg["assm_base_url"].rstrip("/")

    def fallback(self):
        env = os.environ.get("RCODE_ASSM_FALLBACK_URL", "")
        if env and is_valid_base(env):
            return env.rstrip("/")
        return self.cfg["assm_fallback_base_url"].rstrip("/")

    def health(self, base=None):
        try:
            return get((base or self.base()) + "/health", 8).status == 200
        except Exception:
            return False

    def refresh_from_fallback(self):
        try:
            r = get(self.fallback() + self.cfg["assm_enroll_entries_path"])
        except Exception:
            return False
        if r.status != 200:
            return False
        live = (parse_feed(r.body)[1] or "").rstrip("/")
        if not live or not is_valid_base(live) or live == self.base():
            return False
        if self.health(live):
            save_state(assm_learned_live=live)
            return True
        return False

    def heal(self):
        """True if the base changed."""
        return False if self.health() else self.refresh_from_fallback()
