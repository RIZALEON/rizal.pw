"""ASSM approve-code/QR enrollment (rsync-enroll-v1), same wire format as ASSMKit/Android."""
import base64, os, platform, secrets, socket, time

from . import canon, config, net


def nonce():
    """12 random bytes, base64 without + / = (rsync-core.js)."""
    return "".join(c for c in base64.b64encode(secrets.token_bytes(12)).decode() if c not in "+/=")


def device_name():
    host = socket.gethostname() or "linux"
    distro = ""
    try:
        with open("/etc/os-release") as f:
            for l in f:
                if l.startswith("NAME="):
                    distro = l.split("=", 1)[1].strip().strip('"')
    except Exception:
        pass
    return f"RCODE Linux · {host}" + (f" ({distro})" if distro else "")


class EnrollRequest:
    def __init__(self, device, nonce, req_ts, req_sig, device_name):
        self.device, self.nonce, self.req_ts, self.req_sig, self.device_name = device, nonce, req_ts, req_sig, device_name
        self.short_code = canon.short_code(device, nonce)

    @classmethod
    def make(cls, key, name=None):
        pub = key.public_key_base64()
        n = nonce()
        ts = canon.iso_js()
        sig = key.sign(f"rsync-enroll-v1\n{pub}\n{n}\n{ts}")
        return cls(pub, n, ts, sig, name or device_name())

    def body(self):
        return {"t": "device.request", "device": self.device, "nonce": self.nonce,
                "req_ts": self.req_ts, "req_sig": self.req_sig, "device_name": self.device_name}

    @property
    def qr_payload(self):
        q = net.query_encode
        scheme = config.load()["url_scheme"]
        return (f"{scheme}://assm-approve?device={q(self.device)}&nonce={q(self.nonce)}"
                f"&ts={q(self.req_ts)}&sig={q(self.req_sig)}&name={q(self.device_name)}")


class DeviceStatus(dict):
    @property
    def approved(self):
        return bool(self.get("trusted") or self.get("enrolled"))


def device_status(live, pub):
    try:
        r = net.get(live.base() + "/api/rsync/device-status?pub=" + net.query_encode(pub))
    except Exception:
        return None
    if r.status != 200:
        return None
    return DeviceStatus(r.obj())


def post_request(live, req):
    try:
        r = net.post_json(live.base() + "/api/rsync/request", req.body(), 15)
    except Exception:
        return False
    return r.status in (200, 201)


def feed_has_enroll(live, req, profile):
    path = live.cfg["assm_enroll_entries_path"]
    for base in (live.base(), live.fallback()):
        try:
            r = net.get(base + path)
        except Exception:
            continue
        if r.status != 200:
            continue
        entries, lv = net.parse_feed(r.body)
        if base == live.fallback() and lv and net.is_valid_base(lv) and lv.rstrip("/") != live.base():
            net.save_state(assm_learned_live=lv.rstrip("/"))
        for e in entries:
            if (e.get("t") == "device.enroll" and e.get("device") == req.device and e.get("nonce") == req.nonce
                    and (e.get("profile") == profile or not profile)):
                return True
    return False


class Enrollment:
    """Owner enrollment: request once, show code + QR, poll until Rizal approves on a trusted device."""

    def __init__(self, key, live=None, profile=None):
        self.key, self.live = key, live or net.Live()
        self.profile = profile or self.live.cfg["owner_profile"]
        self.req = None

    def status(self):
        return device_status(self.live, self.key.public_key_base64())

    def start(self):
        st = self.status()
        if st is not None and st.approved:
            return None  # already approved: no new request
        pend = net.state().get("pending_enroll")
        if pend and pend.get("device") == self.key.public_key_base64():
            self.req = EnrollRequest(pend["device"], pend["nonce"], pend["req_ts"], pend["req_sig"], pend["device_name"])
        else:
            self.req = EnrollRequest.make(self.key)
            net.save_state(pending_enroll=self.req.body())
        if not post_request(self.live, self.req):
            if self.live.heal():
                post_request(self.live, self.req)
        return self.req

    def poll_once(self):
        st = self.status()
        if st is not None and st.approved:
            self._approved(st)
            return True
        if self.req and feed_has_enroll(self.live, self.req, self.profile):
            self._approved(st or DeviceStatus())
            return True
        return False

    def _approved(self, st):
        net.save_state(pending_enroll=None, owner_approved=True, owner_profile=st.get("profile") or self.profile,
                       approved_at=canon.iso_js())

    def wait(self, timeout=900, interval=4, on_tick=None, stop=None):
        end = time.time() + timeout
        while time.time() < end and not (stop and stop()):
            if self.poll_once():
                return True
            if on_tick:
                on_tick()
            time.sleep(interval)
        return False


# ---- approving another device (ASSMRsyncSeal / rsync-core.js), with the separate approver key ----

SCOPE = "yaseed.mint"
PREFIX = f"yaseed-artifact-v1\n{SCOPE}\n"
_LOCAL = {"seq", "prev", "hash", "cid", "rgen", "_src", "_rx", "cosig"}


def normalize_code(raw):
    """8 digits, XXXX-XXXX, or an rcode://assm-approve?... payload."""
    import urllib.parse
    t = (raw or "").strip()
    if t.startswith(config.load()["url_scheme"] + "://"):
        q = urllib.parse.parse_qs(urllib.parse.urlparse(t).query)
        if q.get("device") and q.get("nonce"):
            return canon.short_code(q["device"][0], q["nonce"][0])
    d = "".join(c for c in t if c.isdigit())
    return d[:4] + "-" + d[4:] if len(d) == 8 else None


def _js_millis(ts):
    from datetime import datetime
    return int(datetime.strptime(ts, "%Y-%m-%dT%H:%M:%S.%fZ").replace(tzinfo=__import__("datetime").timezone.utc).timestamp() * 1000)


def _b36(n):
    s = ""
    while True:
        n, r = divmod(n, 36)
        s = "0123456789abcdefghijklmnopqrstuvwxyz"[r] + s
        if n == 0:
            return s


def approve_entry(req, profile, ts=None):
    ts = ts or canon.iso_js()
    return {"id": "enroll-" + req["nonce"] + "-" + _b36(_js_millis(ts)), "t": "device.enroll", "profile": profile,
            "device": req["device"], "nonce": req["nonce"], "req_ts": req["req_ts"], "req_sig": req["req_sig"],
            "device_name": req.get("device_name") or "device", "ts": ts}


def seal(entry, approver_key):
    pub = approver_key.public_key_base64()
    body = {k: v for k, v in entry.items() if k not in _LOCAL and v is not None}
    body["signer"] = pub
    cid = canon.sha256_hex(canon.canon(body))
    msg = PREFIX + cid
    o = dict(body)
    o["cid"] = cid
    o["rgen"] = {"scope": SCOPE, "msg": msg, "pub": pub, "value": approver_key.sign(msg)}
    return o


def lookup_request(live, code):
    r = net.get(live.base() + "/api/rsync/request/" + code)
    if r.status == 404:
        raise LookupError("No pending request for that code. Check the digits, or it may have expired.")
    if r.status != 200:
        raise LookupError("ASSM server: " + r.error())
    o = r.obj()
    pick = lambda *ks: next((o[k] for k in ks if o.get(k)), None)
    req = {"code": pick("code"), "status": pick("status") or "pending", "device": pick("device"), "nonce": pick("nonce"),
           "req_ts": pick("req_ts", "reqTs"), "req_sig": pick("req_sig", "reqSig"),
           "device_name": pick("device_name", "deviceName") or "device", "profile": pick("profile")}
    if not all(req[k] for k in ("device", "nonce", "req_ts", "req_sig")):
        raise LookupError("The server sent a request RCODE could not read.")
    req["code"] = req["code"] or canon.short_code(req["device"], req["nonce"])
    return req


def approve(live, req, profile, approver_key):
    """POST /api/rsync/approve. 403 = this approver key is not on the ACTIVE trusted list (Rizal adds it on Neo)."""
    if req.get("status") != "pending":
        raise ValueError("This request is not pending.")
    r = net.post_json(live.base() + "/api/rsync/approve", seal(approve_entry(req, profile), approver_key))
    if r.status in (200, 201):
        return True
    err = r.obj().get("error") or ""
    if r.status == 403 or "untrusted" in err.lower() or "not an active trusted" in err.lower():
        raise PermissionError("approver key not on the ACTIVE trusted-devices list: " + approver_key.public_key_base64())
    if r.status == 409:
        raise ValueError("That request was already approved (replay protected).")
    raise ValueError("ASSM server: " + (err or f"HTTP {r.status}"))
