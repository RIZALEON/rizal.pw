"""This machine's P-256 ASSM device key.

Order: Secret Service over D-Bus (GNOME Keyring / KWallet via the `secretstorage` module or the
`secret-tool` CLI from libsecret), then a 0600 PEM file under ~/.local/share/rcode-assm/ (dir 0700).
Force with RCODE_ASSM_KEYSTORE=secret|file. The private key is never printed or sent anywhere;
only the raw 65-byte public point (base64) and raw r||s signatures leave this module.
"""
import base64, os, shutil, subprocess
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature

from . import config

SERVICE = "info.rizal.rcode.assm-device-key"   # same service name as the Apple keychain item
LABEL = "RCODE ASSM device key"


class KeyStoreError(Exception):
    pass


def _attrs(alias):
    return {"service": SERVICE, "account": alias}


class _SecretStorage:
    name = "secret-service"

    def __init__(self):
        import secretstorage  # noqa: F401  (optional dependency)
        self.ss = secretstorage
        self.conn = secretstorage.dbus_init()
        self.col = secretstorage.get_default_collection(self.conn)
        if self.col.is_locked():
            self.col.unlock()  # keyring prompt = the "approve once / unlock" step on Linux
            if self.col.is_locked():
                raise KeyStoreError("keyring stayed locked")

    def get(self, alias):
        for it in self.col.search_items(_attrs(alias)):
            return it.get_secret()
        return None

    def put(self, alias, data):
        self.col.create_item(LABEL, _attrs(alias), data, replace=True)

    def delete(self, alias):
        for it in self.col.search_items(_attrs(alias)):
            it.delete()


class _SecretTool:
    name = "secret-tool"

    def __init__(self):
        self.bin = shutil.which("secret-tool")
        if not self.bin or not os.environ.get("DBUS_SESSION_BUS_ADDRESS"):
            raise KeyStoreError("secret-tool or session bus missing")
        # probe the bus: lookup of a missing item exits 1 quickly, a dead bus errors on stderr
        p = subprocess.run([self.bin, "lookup", "service", SERVICE, "account", "__probe__"],
                           capture_output=True, timeout=10)
        if p.returncode not in (0, 1) or b"rror" in p.stderr:
            raise KeyStoreError("secret service unavailable")

    def get(self, alias):
        p = subprocess.run([self.bin, "lookup", "service", SERVICE, "account", alias], capture_output=True, timeout=30)
        return p.stdout if p.returncode == 0 and p.stdout else None

    def put(self, alias, data):
        p = subprocess.run([self.bin, "store", "--label", LABEL, "service", SERVICE, "account", alias],
                           input=data, capture_output=True, timeout=60)
        if p.returncode != 0:
            raise KeyStoreError("secret-tool store failed")

    def delete(self, alias):
        subprocess.run([self.bin, "clear", "service", SERVICE, "account", alias], capture_output=True, timeout=30)


class _FileStore:
    name = "file"

    def __init__(self, root=None):
        self.root = root or config.DATA_DIR
        os.makedirs(self.root, mode=0o700, exist_ok=True)
        os.chmod(self.root, 0o700)

    def _p(self, alias):
        return os.path.join(self.root, alias + ".pem")

    def get(self, alias):
        p = self._p(alias)
        if not os.path.exists(p):
            return None
        if os.stat(p).st_mode & 0o077:
            os.chmod(p, 0o600)
        with open(p, "rb") as f:
            return f.read()

    def put(self, alias, data):
        p = self._p(alias)
        fd = os.open(p + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.replace(p + ".tmp", p)
        os.chmod(p, 0o600)

    def delete(self, alias):
        p = self._p(alias)
        if os.path.exists(p):
            os.remove(p)


def backend(force=None, file_root=None):
    force = force or os.environ.get("RCODE_ASSM_KEYSTORE")
    if force == "file":
        return _FileStore(file_root)
    errors = []
    for cls in (_SecretStorage, _SecretTool):
        try:
            return cls()
        except Exception as e:  # missing module, no bus, locked keyring
            errors.append(f"{cls.name}: {type(e).__name__}")
    if force == "secret":
        raise KeyStoreError("Secret Service not available (" + "; ".join(errors) + ")")
    return _FileStore(file_root)


class DeviceKey:
    """P-256 key, aliases match Android: <prefix>_assm_device / <prefix>_assm_approver."""

    def __init__(self, alias=None, store=None):
        self.alias = alias or (config.load()["prefix"] + "_assm_device")
        self.store = store or backend()
        self._key = None

    def exists(self):
        return self.store.get(self.alias) is not None

    def _load_or_create(self):
        if self._key is not None:
            return self._key
        pem = self.store.get(self.alias)
        if pem:
            self._key = serialization.load_pem_private_key(pem, password=None)
        else:
            self._key = ec.generate_private_key(ec.SECP256R1())
            self.store.put(self.alias, self._key.private_bytes(
                serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        return self._key

    def public_key_base64(self):
        raw = self._load_or_create().public_key().public_bytes(
            serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint)
        return base64.b64encode(raw).decode()

    def sign(self, message):
        der = self._load_or_create().sign(message.encode("utf-8"), ec.ECDSA(hashes.SHA256()))
        r, s = decode_dss_signature(der)
        return base64.b64encode(r.to_bytes(32, "big") + s.to_bytes(32, "big")).decode()

    def reset(self):
        """Explicit user action only (`assm-linux reset-key`): a new key needs a new approval."""
        self.store.delete(self.alias)
        self._key = None
