"""assm-linux: RCODE sign-in + ASSM-RSYNC sync for Linux.

  assm-linux signin [--no-browser] [--timeout S]   open the sign-in window (all providers)
  assm-linux signin --assm [--no-qr]               terminal ASSM approve-code flow (no browser)
  assm-linux signin --password                     ASSM username + password (off unless enabled)
  assm-linux status                                account, key store, device-status on ASSM
  assm-linux pull [--since CURSOR]                 signed /v1/sync/pull, records as JSON
  assm-linux push FILE.json                        signed /v1/sync/changes (list of wire records)
  assm-linux signout                               forget the account (device key stays)
  assm-linux preview [--no-browser]                sign-in window with sample data (no key, no network)
"""
import argparse, json, sys

from . import assm, auth, config, keystore, loopback, net, sync


def _qr_ascii(data):
    try:
        import qrcode
        q = qrcode.QRCode(border=1)
        q.add_data(data)
        q.make()
        q.print_ascii(invert=True)
    except Exception:
        pass


def cmd_signin(a):
    cfg = config.load()
    if a.password:
        import getpass
        if not cfg.get("assm_password_enabled"):
            raise auth.AuthError("ASSM username + password sign-in is off (set assm_password_enabled or RCODE_ASSM_PASSWORD=1).")
        user = input("ASSM username (ЯID or @handle): ")
        cred = auth.assm_password_signin(cfg, user, getpass.getpass("ASSM password: "), keystore.DeviceKey())
        acct = auth.Account(cfg)
        acct.complete(cred)
        net.save_state(pending_enroll=None, owner_approved=True, owner_profile=cred["profile"])
        acct.on_owner_approved()
        print(f"Signed in: this device key is ACTIVE for {cred['profile']}.")
        return 0
    if a.assm:
        key = keystore.DeviceKey()
        acct = auth.Account(cfg)
        en = assm.Enrollment(key)

        def start():
            req = en.start()
            if req is None:
                return None
            print(f"\nApprove on a trusted ASSM device:  {req.short_code}\n")
            if not a.no_qr:
                _qr_ascii(req.qr_payload)
            print("rizal.pw › ЯLOGIN › Other options › approve from another device")
            return req

        req = acct.complete({"provider": "assm", "subject": cfg["owner_profile"], "proof": {}}, start)
        if req is None or en.wait(timeout=a.timeout, on_tick=lambda: print(".", end="", flush=True)):
            acct.on_owner_approved()
            print(f"\nApproved: this device signs sync for {cfg['owner_profile']}.")
            return 0
        print("\nNot approved yet (timed out). Run again; the same code is reused.")
        return 2
    s = loopback.SignInSession(cfg, open_browser=not a.no_browser, timeout=a.timeout)
    print(f"Sign-in window: {s.url}\n(listening on 127.0.0.1:{s.port} until you finish)", flush=True)
    r = s.run()
    print("signed in and approved" if r.get("approved") else ("kept offline" if r.get("closed") else "not finished"))
    return 0 if r.get("approved") or r.get("closed") else 2


def cmd_preview(a):
    s = loopback.SignInSession(preview=True, open_browser=not a.no_browser, timeout=a.timeout)
    print(s.url, flush=True)
    s.run()
    return 0


def cmd_status(a):
    cfg = config.load()
    key = keystore.DeviceKey()
    live = net.Live(cfg)
    print("key store :", key.store.name)
    acct = auth.Account(cfg).data
    print("account   :", json.dumps(acct, ensure_ascii=False) if acct else "signed out")
    if not key.exists():
        print("device key: none yet (created on first sign-in)")
        return 0
    pub = key.public_key_base64()
    print("device key:", pub[:16] + "…")
    print("live base :", live.base())
    st = assm.device_status(live, pub)
    if st is None and live.heal():
        st = assm.device_status(live, pub)
    print("ASSM      :", json.dumps(st) if st is not None else "unreachable")
    return 0


def _svc():
    cfg = config.load()
    st = net.state()
    if not st.get("owner_approved"):
        print("This device is not approved yet: run `assm-linux signin` first.", file=sys.stderr)
        sys.exit(2)
    return sync.SyncService(keystore.DeviceKey(), st.get("owner_profile") or cfg["owner_profile"])


def cmd_pull(a):
    recs, cur = _svc().pull(a.since)
    print(json.dumps({"records": recs, "cursor": cur}, ensure_ascii=False, indent=1))
    return 0


def cmd_push(a):
    with open(a.file) as f:
        recs = json.load(f)
    print(json.dumps(_svc().push(recs), ensure_ascii=False))
    return 0


def cmd_signout(a):
    auth.Account().sign_out()
    print("signed out (device key kept; it stays approved)")
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(prog="assm-linux", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = p.add_subparsers(dest="cmd", required=True)
    s = sp.add_parser("signin"); s.add_argument("--assm", action="store_true"); s.add_argument("--password", action="store_true"); s.add_argument("--no-browser", action="store_true")
    s.add_argument("--no-qr", action="store_true"); s.add_argument("--timeout", type=int, default=900); s.set_defaults(f=cmd_signin)
    s = sp.add_parser("preview"); s.add_argument("--no-browser", action="store_true"); s.add_argument("--timeout", type=int, default=600); s.set_defaults(f=cmd_preview)
    sp.add_parser("status").set_defaults(f=cmd_status)
    s = sp.add_parser("pull"); s.add_argument("--since"); s.set_defaults(f=cmd_pull)
    s = sp.add_parser("push"); s.add_argument("file"); s.set_defaults(f=cmd_push)
    sp.add_parser("signout").set_defaults(f=cmd_signout)
    a = p.parse_args(argv)
    try:
        return a.f(a)
    except KeyboardInterrupt:
        return 130
    except (auth.AuthError, sync.SyncHttpError, keystore.KeyStoreError) as e:
        print("error:", e, file=sys.stderr)
        return 1
