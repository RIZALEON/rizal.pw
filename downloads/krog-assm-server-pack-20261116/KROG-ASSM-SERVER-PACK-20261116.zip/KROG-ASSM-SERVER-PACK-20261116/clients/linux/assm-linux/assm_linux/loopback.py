"""The Linux sign-in window: one short-lived HTTP listener on 127.0.0.1:<ephemeral port>, opened in the
system browser. It serves the sign-in page and receives the OAuth/PKCE redirects, and it closes as soon
as sign-in finishes, is cancelled ("Not now") or times out. It is the only listener this client opens.

Guards: binds 127.0.0.1 only; Host must be 127.0.0.1:<port> (DNS-rebinding); page + API need the
per-session token; OAuth callbacks need the PKCE state.
"""
import hmac, json, secrets, threading, time, urllib.parse, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import assm, auth, config, keystore, net, page


def qr_svg(data):
    try:
        import qrcode, qrcode.image.svg
        img = qrcode.make(data, image_factory=qrcode.image.svg.SvgPathImage, border=2, box_size=8)
        return img.to_string(encoding="unicode")
    except Exception:
        return None


class SignInSession:
    def __init__(self, cfg=None, preview=False, open_browser=True, timeout=900, mode="signin"):
        self.cfg = cfg or config.load()
        self.preview = preview or self.cfg.get("auth_preview")
        self.open_browser = open_browser
        self.timeout = timeout
        self.token = secrets.token_urlsafe(24)
        self.lock = threading.Lock()
        self.ui = {"mode": mode, "busy": None, "error": None, "assm": None, "done": False, "approved": False,
                   "approve": None, "closed": False}
        self.pending = {}  # state -> (provider, Pkce)
        self.account = auth.Account(self.cfg)
        self._key = None
        self.enrollment = None
        self.enrollment_interval = 4
        self.finished = threading.Event()
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), self._handler())
        self.httpd.daemon_threads = True
        self.port = self.httpd.server_address[1]
        if self.preview:
            payload = "rcode://assm-approve?device=PREVIEW&nonce=preview&ts=2026-11-16T12%3A00%3A00.000Z&sig=preview&name=RCODE%20Linux"
            self.ui["assm"] = {"code": "4821-0937", "qr": qr_svg(payload), "status": "pending"}

    @property
    def url(self):
        return f"http://127.0.0.1:{self.port}/?t={self.token}"

    def redirect_uri(self, provider):
        return f"http://127.0.0.1:{self.port}/callback/{provider}"

    def key(self):
        if self._key is None:
            self._key = keystore.DeviceKey()
        return self._key

    # ---- state ----
    def snapshot(self):
        c = self.cfg
        ph = config.is_placeholder
        with self.lock:
            s = dict(self.ui)
        s["providers"] = {
            "google": not (ph(c["google_desktop_client_id"]) or ph(c["google_desktop_client_secret"])),
            "apple": not ph(c["apple_services_id"]),
            "password": not ph(c["server_url"]),
            "passkey": not (ph(c["server_url"]) or ph(c["passkey_rp_id"])),
            "microsoft": not ph(c["microsoft_client_id"]),
            "assm": True,
            "device-link": not ph(c["server_url"]),
            "assm-password": bool(c.get("assm_password_enabled")),
        }
        s["app"] = c["app_name"]
        s["profile"] = c["owner_profile"]
        s["account"] = self.account.data
        s["preview"] = bool(self.preview)
        return s

    def set(self, **kw):
        with self.lock:
            self.ui.update(kw)

    # ---- flows ----
    def start_owner_enrollment(self):
        if self.preview:
            return
        self.enrollment = assm.Enrollment(self.key())
        req = self.enrollment.start()
        if req is None:
            self._approved()
            return
        self.set(assm={"code": req.short_code, "qr": qr_svg(req.qr_payload), "status": "pending"})
        threading.Thread(target=self._poll, daemon=True).start()

    def _poll(self):
        if self.enrollment.wait(timeout=self.timeout, interval=self.enrollment_interval, stop=lambda: self.finished.is_set()):
            self._approved()

    def _approved(self):
        self.account.on_owner_approved()
        self.set(approved=True, done=True, busy=None, assm=None)
        threading.Timer(3.0, self.finish).start()

    def complete(self, cred):
        try:
            self.account.complete(cred, self.start_owner_enrollment)
            self.set(busy=None, error=None)
        except Exception as e:
            self.set(busy=None, error=str(e))

    def start_provider(self, provider, mode):
        if self.preview:
            raise auth.AuthError("Preview mode: providers are not live.")
        pk = auth.Pkce()
        if provider == "google":
            url = auth.google_auth_url(self.cfg, self.redirect_uri("google"), pk)
        elif provider == "microsoft":
            url = auth.microsoft_auth_url(self.cfg, self.redirect_uri("microsoft"), pk)
        elif provider == "apple":
            url = auth.apple_auth_url(self.cfg, self.port, pk)
        elif provider == "passkey":
            url = auth.passkey_bridge_url(self.cfg, self.port, pk, mode)
        else:
            raise auth.AuthError("unknown provider")
        with self.lock:
            self.pending[pk.state] = (provider, pk)
        self.set(busy=provider, error=None)
        return url

    def callback(self, provider, params):
        state = params.get("state", "")
        if provider == "apple" and "." in state:
            state = state.split(".", 1)[1]
        with self.lock:
            entry = self.pending.pop(state, None)
        if not entry or entry[0] != provider:
            self.set(busy=None, error="Sign-in response did not match this window (state). Try again.")
            return
        if params.get("error"):
            self.set(busy=None, error=f"{provider}: " + (params.get("error_description") or params["error"]))
            return
        pk = entry[1]
        try:
            if provider == "google":
                cred = auth.google_exchange(self.cfg, self.redirect_uri("google"), pk, params.get("code", ""))
            elif provider == "microsoft":
                cred = auth.microsoft_exchange(self.cfg, self.redirect_uri("microsoft"), pk, params.get("code", ""))
            elif provider == "apple":
                cred = auth.apple_credential(pk, params)
            else:  # passkey bridge hands back the RCODE server session
                sess = json.loads(auth.base64.urlsafe_b64decode(params.get("session", "") + "==="))
                cred = {"provider": "passkey", "subject": sess.get("credential_id") or "passkey", "proof": {}, "session": sess}
        except Exception as e:
            self.set(busy=None, error=str(e))
            return
        self.complete(cred)

    def api(self, path, body):
        if path == "/api/state":
            return self.snapshot()
        if path == "/api/start":
            p = body.get("provider")
            if p == "assm":
                self.set(busy="assm", error=None)
                if not self.preview:
                    threading.Thread(target=self.complete, args=({"provider": "assm", "subject": self.cfg["owner_profile"], "proof": {}},), daemon=True).start()
                return {"ok": True}
            return {"redirect": self.start_provider(p, body.get("mode", "signin"))}
        if path == "/api/email":
            self.set(busy="password", error=None)
            cred = auth.email_signin(self.cfg, body.get("username", ""), body.get("password", ""), body.get("mode", "signin"))
            threading.Thread(target=self.complete, args=(cred,), daemon=True).start()
            return {"ok": True}
        if path == "/api/assm-password":
            if self.preview:
                raise auth.AuthError("Preview mode: providers are not live.")
            cred = auth.assm_password_signin(self.cfg, body.pop("username", ""), body.pop("password", ""), self.key())
            body.clear()
            self.account.complete(cred)   # no enrollment needed: the server made this key ACTIVE
            net.save_state(pending_enroll=None, owner_approved=True, owner_profile=cred["profile"])
            self._approved()
            return {"ok": True}
        if path == "/api/link":
            cred = auth.device_link_claim(self.cfg, body.get("code", ""))
            threading.Thread(target=self.complete, args=(cred,), daemon=True).start()
            return {"ok": True}
        if path == "/api/approve/lookup":
            code = assm.normalize_code(body.get("code", ""))
            if not code:
                raise ValueError("Enter the 8-digit code (1234-5678) from the other device.")
            req = assm.lookup_request(net.Live(self.cfg), code)
            self.set(approve={"request": req, "error": None, "success": None})
            return {"request": req}
        if path == "/api/approve/confirm":
            req = (self.ui.get("approve") or {}).get("request")
            if not req:
                raise ValueError("Look up a request first.")
            prof = (body.get("profile") or self.cfg["owner_profile"]).strip()
            approver = keystore.DeviceKey(self.cfg["prefix"] + "_assm_approver")
            try:
                assm.approve(net.Live(self.cfg), req, prof, approver)
            except PermissionError:
                cmd = f'python3 add-trusted-device.py add "{approver.public_key_base64()}" "RCODE Linux"'
                raise ValueError("This machine's approver key is not on the ACTIVE trusted-devices list. Rizal adds it on Neo with: " + cmd)
            self.set(approve={"request": dict(req, status="approved"), "success": f"Approved {req['device_name']} into {prof}."})
            return {"ok": True}
        if path == "/api/cancel":
            self.set(busy=None, error=None, assm=None if not self.preview else self.ui["assm"])
            return {"ok": True}
        if path == "/api/close":
            self.set(closed=True)
            threading.Timer(0.5, self.finish).start()
            return {"ok": True}
        raise KeyError(path)

    # ---- http ----
    def _handler(self):
        sess = self

        class H(BaseHTTPRequestHandler):
            server_version = "RCODE-signin"

            def log_message(self, *a):
                pass

            def _send(self, code, body, ctype="application/json", extra=None):
                b = body.encode() if isinstance(body, str) else body
                self.send_response(code)
                self.send_header("Content-Type", ctype + "; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Referrer-Policy", "no-referrer")
                self.send_header("X-Frame-Options", "DENY")
                for k, v in (extra or {}).items():
                    self.send_header(k, v)
                self.send_header("Content-Length", str(len(b)))
                self.end_headers()
                self.wfile.write(b)

            def _host_ok(self):
                return self.headers.get("Host") == f"127.0.0.1:{sess.port}"

            def _tok_ok(self, q):
                t = q.get("t", [""])[0] or self.headers.get("X-RCODE-Session", "")
                return hmac.compare_digest(t, sess.token)

            def _route(self, method):
                u = urllib.parse.urlparse(self.path)
                q = urllib.parse.parse_qs(u.query)
                if not self._host_ok():
                    return self._send(421, '{"error":"bad host"}')
                body = {}
                if method == "POST":
                    raw = self.rfile.read(min(int(self.headers.get("Content-Length") or 0), 65536)).decode("utf-8", "replace")
                    if (self.headers.get("Content-Type") or "").startswith("application/x-www-form-urlencoded"):
                        body = {k: v[0] for k, v in urllib.parse.parse_qs(raw).items()}
                    else:
                        try:
                            body = json.loads(raw or "{}")
                        except Exception:
                            body = {}
                if u.path.startswith("/callback/"):
                    prov = u.path.rsplit("/", 1)[1]
                    if prov not in ("google", "microsoft", "apple", "passkey"):
                        return self._send(404, "{}")
                    params = {k: v[0] for k, v in q.items()}
                    params.update(body)
                    threading.Thread(target=sess.callback, args=(prov, params), daemon=True).start()
                    return self._send(303, "", "text/plain", {"Location": sess.url})
                if not self._tok_ok(q):
                    return self._send(403, '{"error":"session"}')
                if u.path == "/" and method == "GET":
                    return self._send(200, page.HTML.replace("__TOKEN__", sess.token), "text/html",
                                      {"Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src data:; connect-src 'self'; form-action 'none'"})
                if u.path.startswith("/api/"):
                    try:
                        return self._send(200, json.dumps(sess.api(u.path, body), ensure_ascii=False))
                    except KeyError:
                        return self._send(404, '{"error":"not found"}')
                    except Exception as e:
                        sess.set(busy=None)
                        return self._send(400, json.dumps({"error": str(e)}, ensure_ascii=False))
                return self._send(404, "{}")

            def do_GET(self):
                self._route("GET")

            def do_POST(self):
                self._route("POST")

        return H

    def finish(self):
        if not self.finished.is_set():
            self.finished.set()
            threading.Thread(target=self.httpd.shutdown, daemon=True).start()

    def run(self):
        """Blocks until signed in + approved, "Not now", or timeout; the port is closed on return."""
        t = threading.Thread(target=self.httpd.serve_forever, kwargs={"poll_interval": 0.2}, daemon=True)
        t.start()
        if self.open_browser:
            webbrowser.open(self.url)
        self.finished.wait(self.timeout)
        self.finish()
        t.join(5)
        self.httpd.server_close()
        return self.snapshot()
