"""Providers + account state (port of ASSMKit AuthManager / Android AssmAuth).

Every provider ends the same way: optional exchange with the RCODE account server (POST
<server>/v1/auth/<provider> {subject, proof, device, link}), then unify onto the owner ASSM identity
(ЯID-0001-3QQS) and start the one-time owner device-key enrollment. ASSMKit never approves a key itself.
"""
import base64, hashlib, json, os, platform, secrets, socket, time, urllib.parse, uuid

from . import config, net


class AuthError(Exception):
    pass


PROVIDERS = ("google", "apple", "password", "passkey", "microsoft", "assm", "assm-password", "device-link")
ACCOUNT_FILE = lambda: os.path.join(config.CONFIG_DIR, "account.json")


def b64url(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


class Pkce:
    def __init__(self, verifier=None):
        self.verifier = verifier or b64url(secrets.token_bytes(32))
        self.challenge = b64url(hashlib.sha256(self.verifier.encode()).digest())
        self.state = b64url(secrets.token_bytes(16))
        self.nonce = b64url(secrets.token_bytes(16))


def jwt_claims(token):
    """Unverified payload read for display (sub/email/name). The server verifies the signature."""
    try:
        p = token.split(".")[1]
        return json.loads(base64.urlsafe_b64decode(p + "=" * (-len(p) % 4)))
    except Exception:
        return {}


def device_info():
    st = net.state()
    did = st.get("device_id")
    if not did:
        did = str(uuid.uuid4())
        net.save_state(device_id=did)
    cfg = config.load()
    return {"id": did, "name": f"{cfg['app_name']} Linux {socket.gethostname()}", "os": f"Linux {platform.release()}",
            "model": platform.machine() or "linux", "app_version": __import__("assm_linux").__version__}


# ---- OAuth (system browser + PKCE + loopback http://127.0.0.1:<ephemeral>/callback/<provider>) ----

def google_auth_url(cfg, redirect, pk):
    return "https://accounts.google.com/o/oauth2/v2/auth?" + urllib.parse.urlencode({
        "client_id": cfg["google_desktop_client_id"], "redirect_uri": redirect, "response_type": "code",
        "scope": "openid email profile", "code_challenge": pk.challenge, "code_challenge_method": "S256",
        "state": pk.state, "nonce": pk.nonce, "prompt": "select_account"})


def google_exchange(cfg, redirect, pk, code):
    r = net.post_form("https://oauth2.googleapis.com/token", {
        "client_id": cfg["google_desktop_client_id"], "client_secret": cfg["google_desktop_client_secret"],
        "code": code, "code_verifier": pk.verifier, "grant_type": "authorization_code", "redirect_uri": redirect})
    tok = r.obj().get("id_token")
    if r.status != 200 or not tok:
        raise AuthError("Google sign-in failed: " + r.error())
    c = jwt_claims(tok)
    return {"provider": "google", "subject": c.get("sub", ""), "email": c.get("email"), "display_name": c.get("name"),
            "proof": {"id_token": tok, "nonce": pk.nonce}}


def microsoft_auth_url(cfg, redirect, pk):
    return f"https://login.microsoftonline.com/{cfg['microsoft_tenant']}/oauth2/v2.0/authorize?" + urllib.parse.urlencode({
        "client_id": cfg["microsoft_client_id"], "redirect_uri": redirect, "response_type": "code",
        "response_mode": "query", "scope": "openid profile email", "code_challenge": pk.challenge,
        "code_challenge_method": "S256", "state": pk.state, "nonce": pk.nonce, "prompt": "select_account"})


def microsoft_exchange(cfg, redirect, pk, code):
    r = net.post_form(f"https://login.microsoftonline.com/{cfg['microsoft_tenant']}/oauth2/v2.0/token", {
        "client_id": cfg["microsoft_client_id"], "code": code, "code_verifier": pk.verifier,
        "grant_type": "authorization_code", "redirect_uri": redirect, "scope": "openid profile email"})
    tok = r.obj().get("id_token")
    if r.status != 200 or not tok:
        raise AuthError("Microsoft sign-in failed: " + r.error())
    c = jwt_claims(tok)
    return {"provider": "microsoft", "subject": c.get("oid") or c.get("sub", ""), "email": c.get("email") or c.get("preferred_username"),
            "display_name": c.get("name"), "proof": {"id_token": tok, "nonce": pk.nonce}}


def apple_auth_url(cfg, port, pk):
    # Apple only returns to https; the rizal.pw relay forwards form_post to http://127.0.0.1:<port>/callback/apple.
    return "https://appleid.apple.com/auth/authorize?" + urllib.parse.urlencode({
        "client_id": cfg["apple_services_id"], "redirect_uri": cfg["apple_return_url"],
        "response_type": "code id_token", "response_mode": "form_post", "scope": "name email",
        "state": f"{port}.{pk.state}", "nonce": hashlib.sha256(pk.nonce.encode()).hexdigest()})


def apple_credential(pk, form):
    tok = form.get("id_token")
    if not tok:
        raise AuthError("Apple sign-in returned no identity token.")
    c = jwt_claims(tok)
    name = None
    try:
        u = json.loads(form.get("user") or "{}").get("name") or {}
        name = " ".join(x for x in (u.get("firstName"), u.get("lastName")) if x) or None
    except Exception:
        pass
    return {"provider": "apple", "subject": c.get("sub", ""), "email": c.get("email"), "display_name": name,
            "proof": {"id_token": tok, "authorization_code": form.get("code"), "nonce": pk.nonce}}


def passkey_bridge_url(cfg, port, pk, mode):
    # WebAuthn needs an https RP origin (rizal.pw), not 127.0.0.1; the bridge returns the server session.
    return cfg["passkey_bridge_url"] + "?" + urllib.parse.urlencode({
        "return": f"http://127.0.0.1:{port}/callback/passkey", "state": pk.state, "mode": mode, "rp_id": cfg["passkey_rp_id"]})


# ---- server-backed providers ----

def _server(cfg):
    if config.is_placeholder(cfg["server_url"]):
        raise AuthError("This option needs the RCODE account server (server_url), which is not configured yet.")
    return cfg["server_url"].rstrip("/")


def email_signin(cfg, username, password, mode):
    if not username.strip() or not password:
        raise AuthError("Enter your email/username and password.")
    path = "/v1/auth/password/signup" if mode == "signup" else "/v1/auth/password/login"
    r = net.post_json(_server(cfg) + path, {"username": username.strip(), "password": password, "device": device_info()})
    if r.status != 200:
        raise AuthError(r.error())
    return {"provider": "password", "subject": username.strip().lower(), "email": username.strip() if "@" in username else None,
            "proof": {}, "session": r.obj()}


def device_link_claim(cfg, code):
    if not code.strip():
        raise AuthError("Enter the link code shown on your other device.")
    r = net.post_json(_server(cfg) + "/v1/devices/link/claim", {"code": code.strip().upper(), "device": device_info()})
    if r.status != 200:
        raise AuthError(r.error())
    return {"provider": "device-link", "subject": "device-link", "proof": {}, "session": r.obj()}


PW_SCHEME = "pbkdf2-sha256-hmac-v1"
PW_MIN_ITER = 600_000


def pw_derive(password, salt, iterations):
    """PBKDF2-HMAC-SHA256, 32 bytes (pwlogin.py / ASSMPasswordClient.derive)."""
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations, 32)


def pw_login_message(user, proof, device, device_name, nonce, ts):
    ph = hashlib.sha256(proof.encode()).hexdigest()
    return "assm-password-login-v1\n" + "\n".join([user, ph, device, device_name, nonce, ts])


def pw_nonce():
    return secrets.token_hex(16)  # 32 letters/digits (server: 8-64, single use)


def assm_password_signin(cfg, user, password, key, live=None, device_name=None):
    """ASSM username (ЯID or @handle) + password against ASSM-RSYNC /api/rsync/password/{params,login}
    (INTEGRATION.md section 4). Behind assm_password_enabled (OFF by default). The password is derived here
    and never sent, stored or logged; proof = base64(dk). On 200 this device key is ACTIVE for the profile.
    Password SET is Apple-only (ASSMKit, approver key) and not built here."""
    if not cfg.get("assm_password_enabled"):
        raise AuthError("ASSM username + password sign-in is not available yet.")
    from . import assm as _assm
    u = (user or "").strip()
    if not u or not password:
        raise AuthError("Enter your ASSM username (ЯID or @handle) and password.")
    live = live or net.Live(cfg)
    try:
        r = net.get(live.base() + "/api/rsync/password/params?user=" + net.query_encode(u))
    except Exception:
        if not live.heal():
            raise AuthError("The ASSM server isn't reachable right now.")
        r = net.get(live.base() + "/api/rsync/password/params?user=" + net.query_encode(u))
    if r.status == 404:
        raise AuthError("Wrong username or password.")  # same message as a wrong password
    p = r.obj()
    try:
        salt = base64.b64decode(p["salt"]); it = int(p["iter"])
    except Exception:
        raise AuthError(f"Server error {r.status}: bad params")
    if r.status != 200 or p.get("scheme", PW_SCHEME) != PW_SCHEME or it < PW_MIN_ITER:
        raise AuthError(f"Server error {r.status}: bad params")
    proof = base64.b64encode(pw_derive(password, salt, it)).decode()
    password = None  # noqa: F841  (not kept)
    pub = key.public_key_base64()
    name = device_name or _assm.device_name()
    n, ts = pw_nonce(), __import__("assm_linux.canon", fromlist=["iso_js"]).iso_js()
    sig = key.sign(pw_login_message(u, proof, pub, name, n, ts))
    r = net.post_json(live.base() + "/api/rsync/password/login", {"t": "password.login", "user": u, "proof": proof,
                      "device": pub, "device_name": name, "nonce": n, "ts": ts, "sig": sig})
    o = r.obj()
    if r.status in (200, 201):
        if not o.get("profile"):
            raise AuthError("Server error 200: no profile")
        return {"provider": "assm-password", "subject": o["profile"], "display_name": o.get("handle"), "proof": {},
                "profile": o["profile"], "handle": o.get("handle")}
    if r.status == 401:
        raise AuthError("Wrong username or password.")
    if r.status == 409:
        raise AuthError("That request was already used. Try again.")
    if r.status == 429:
        raise AuthError(f"Too many attempts. Try again in {max(1, int(o.get('retry_after_s') or 60))} s.")
    raise AuthError(f"Server error {r.status}: " + (o.get("error") or "unexpected response"))


# ---- account (no secrets on disk; the access token stays in memory) ----

class Account:
    def __init__(self, cfg=None):
        self.cfg = cfg or config.load()
        self.access_token = None
        self.data = self._load()

    def _load(self):
        try:
            with open(ACCOUNT_FILE()) as f:
                return json.load(f)
        except Exception:
            return None

    def _save(self, a):
        os.makedirs(config.CONFIG_DIR, mode=0o700, exist_ok=True)
        fd = os.open(ACCOUNT_FILE() + ".tmp", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(a, f, ensure_ascii=False, indent=1)
        os.replace(ACCOUNT_FILE() + ".tmp", ACCOUNT_FILE())
        self.data = a

    def complete(self, cred, start_owner_enrollment=None):
        session = cred.get("session")
        linking = self.data is not None and cred["provider"] != "device-link"
        if session is None and cred["provider"] != "assm" and not config.is_placeholder(self.cfg["server_url"]):
            r = net.post_json(self.cfg["server_url"].rstrip("/") + "/v1/auth/" + cred["provider"],
                              {"subject": cred["subject"], "proof": cred.get("proof") or {}, "device": device_info(), "link": linking},
                              bearer=self.access_token if linking else None)
            if r.status != 200:
                raise AuthError(r.error())
            session = r.obj()
        now = int(time.time() * 1000)
        ident = {"provider": cred["provider"], "subject": cred["subject"], "email": cred.get("email"),
                 "display_name": cred.get("display_name"), "linked_at": now, "verified": session is not None}
        iid = lambda i: i["provider"] + ":" + i["subject"]
        if session is not None:
            self.access_token = session.get("access_token") or None
            sa = session.get("account") or {}
            ids = sa.get("identities") or []
            if cred["provider"] != "device-link" and all(iid(i) != iid(ident) for i in ids):
                ids = ids + [ident]
            acct = {"account_id": sa.get("id", "server"), "display_name": sa.get("display_name") or cred.get("display_name")
                    or cred.get("email") or f"{self.cfg['app_name']} user", "identities": ids}
        elif self.data:
            acct = dict(self.data)
            acct["identities"] = [i for i in acct["identities"] if iid(i) != iid(ident)] + [ident]
        else:
            acct = {"account_id": "local-" + str(uuid.uuid4()), "display_name": cred.get("display_name") or cred.get("email")
                    or self.cfg["owner_display_name"], "identities": [ident]}
        self._save(acct)
        self.unify_on_owner_identity(start_owner_enrollment)
        return acct

    def unify_on_owner_identity(self, start_owner_enrollment=None):
        a = self.data or {"account_id": "local-owner-" + self.cfg["owner_profile"], "display_name": self.cfg["owner_display_name"], "identities": []}
        prof = self.cfg["owner_profile"]
        if not any(i["provider"] == "assm" and i["subject"] == prof for i in a["identities"]):
            a = dict(a)
            a["identities"] = a["identities"] + [{"provider": "assm", "subject": prof, "email": None,
                                                  "display_name": self.cfg["owner_handle"], "linked_at": int(time.time() * 1000), "verified": False}]
            self._save(a)
        if start_owner_enrollment:
            return start_owner_enrollment()

    def on_owner_approved(self):
        prof = self.cfg["owner_profile"]
        a = self.data or {"account_id": "local-owner-" + prof, "display_name": self.cfg["owner_display_name"], "identities": []}
        a = dict(a)
        a["identities"] = [i for i in a["identities"] if not (i["provider"] == "assm" and i["subject"] == prof)] + [
            {"provider": "assm", "subject": prof, "email": None, "display_name": self.cfg["owner_handle"],
             "linked_at": int(time.time() * 1000), "verified": True}]
        self._save(a)

    def sign_out(self):
        """Forgets the account; the device key stays (re-approval is never needed for the same key)."""
        self.access_token = None
        if os.path.exists(ACCOUNT_FILE()):
            os.remove(ACCOUNT_FILE())
        self.data = None
