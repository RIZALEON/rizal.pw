"""Sign-in page served by the loopback session. Same order as ASSMKit SignInView / Android SignInScreen."""
HTML = r"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sign in to RCODE</title><style>
:root{--bg:#121214;--card:#1f1f23;--line:#3a3a40;--fg:#f2f2f5;--mut:#a5a5ad;--acc:#8b5cf6;--acc2:#b693ff}
*{box-sizing:border-box}html,body{margin:0;height:100%}
body{background:radial-gradient(1200px 600px at 50% 70%,#2a1840 0%,var(--bg) 60%);color:var(--fg);font:15px/1.4 system-ui,-apple-system,"Segoe UI",Cantarell,Ubuntu,sans-serif;display:flex;flex-direction:column;align-items:center;padding:18px}
.top{width:100%;max-width:460px;text-align:right}.link{color:var(--mut);background:none;border:0;font:inherit;cursor:pointer}
.card{width:100%;max-width:460px;background:rgba(40,40,46,.85);border:1px solid var(--line);border-radius:28px;padding:26px 22px 20px;margin-top:8px}
.logo{width:54px;height:54px;border-radius:12px;background:var(--acc);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:28px;margin:0 auto}
h1{font-size:24px;font-weight:600;text-align:center;margin:14px 0 6px}.sub{color:var(--mut);text-align:center;margin:0 0 20px}
.pill{display:flex;align-items:center;width:100%;height:50px;margin:10px 0;border-radius:25px;border:1px solid var(--line);background:#2b2b31;color:var(--fg);font:600 16px system-ui,sans-serif;cursor:pointer;padding:0 22px}
.pill .ic{width:24px;text-align:center;color:var(--fg)}.pill .tx{flex:1;text-align:center;margin-right:24px}
.pill.hi{background:var(--acc);border-color:var(--acc)}.pill[disabled]{opacity:.45;cursor:default}
.box{background:#2a2a30;border:1px solid var(--line);border-radius:18px;padding:14px;margin:12px 0}
input{width:100%;height:44px;border-radius:12px;border:1px solid var(--line);background:#18181b;color:var(--fg);padding:0 12px;font:inherit;margin:6px 0}
.btn{width:100%;height:44px;border-radius:12px;border:0;background:var(--acc);color:#fff;font:600 15px system-ui,sans-serif;cursor:pointer;margin-top:6px}
.code{font:600 30px ui-monospace,"DejaVu Sans Mono",monospace;color:var(--acc2);text-align:center;letter-spacing:1px;margin:6px 0}
.qr{background:#fff;border-radius:10px;width:170px;height:170px;margin:8px auto;padding:6px}.qr svg{width:100%;height:100%}
.c{text-align:center}.mut{color:var(--mut);font-size:12px}.err{color:#ff7b7b;text-align:center;margin:8px 0}.ok{color:#7be0a0;text-align:center}
.acc{color:var(--acc2)}.foot{color:var(--mut);margin-top:14px}b{font-weight:600}
</style></head><body>
<div class="top"><button class="link" id="notnow1">Not now</button></div>
<div class="card" id="card"></div>
<button class="link foot" id="notnow2">Not now. Keep using RCODE offline</button>
<script>
const T="__TOKEN__";let S=null,open={email:false,link:false,approve:false,apw:false},mode="signin";
const $=s=>document.querySelector(s);
async function api(p,b){const r=await fetch(p+"?t="+T,{method:b===undefined?"GET":"POST",headers:{"Content-Type":"application/json","X-RCODE-Session":T},body:b===undefined?undefined:JSON.stringify(b)});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||("HTTP "+r.status));return j}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function pill(id,ic,tx,hi){const on=S.providers[id];return `<button class="pill${hi?" hi":""}" data-p="${id}" ${on?"":"disabled title=\"Not configured yet\""}><span class="ic">${ic}</span><span class="tx">${tx}</span></button>`}
let localErr=null;
function render(){if(!S)return;const c=$("#card");let h="";
 if(S.done||S.closed){h=`<div class="logo">R</div><h1>${S.closed?"Using RCODE offline":"You're signed in"}</h1><p class="sub">${S.closed?"You can sign in later from RCODE.":"This device is approved on <b>"+esc(S.profile)+"</b> and syncs with your Mac, iPhone, iPad and Android."}</p><p class="c mut">You can close this tab.</p>`;c.innerHTML=h;return}
 h+=`<div class="logo">R</div><h1>${mode=="signup"?"Create your account":"Welcome back"}</h1><p class="sub">One account on your Mac, iPhone, iPad, Android and Linux, synced.</p>`;
 h+=pill("google","G","Continue with Google")+pill("apple","A","Continue with Apple");
 h+=`<button class="pill" data-x="email" ${S.providers.password?"":"disabled title=\"Not configured yet\""}><span class="ic">&#9993;</span><span class="tx">Continue with email</span></button>`;
 if(open.email)h+=`<div class="box"><input id="eu" placeholder="Email or username" autocomplete="username"><input id="ep" type="password" placeholder="Password" autocomplete="${mode=="signup"?"new-password":"current-password"}"><button class="btn" id="ego">${mode=="signup"?"Sign up":"Sign in"}</button></div>`;
 h+=pill("passkey","<svg width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"><circle cx=\"8\" cy=\"15\" r=\"4\"/><path d=\"M11 12l9-9M17 6l3 3M15 8l2 2\"/></svg>","Continue with passkey",true)+pill("microsoft","&#9638;","Continue with Microsoft")+pill("assm","&#1071;","Continue with ASSM");
 if(S.providers["assm-password"]){h+=`<button class="pill" data-x="apw"><span class="ic">&#1071;</span><span class="tx">ASSM username + password</span></button>`;
  if(open.apw)h+=`<div class="box"><input id="au" placeholder="ЯID or @handle" autocomplete="username"><input id="ap" type="password" placeholder="ASSM password" autocomplete="current-password"><button class="btn" id="ago">Sign in</button></div>`}
 if(S.assm)h+=`<div class="box c"><b>Approve on a trusted ASSM device</b><div class="code">${esc(S.assm.code)}</div>${S.assm.qr?`<div class="qr">${S.assm.qr}</div>`:""}<div class="mut">rizal.pw &rsaquo; ЯLOGIN &rsaquo; Other options &rsaquo; approve from another device</div><button class="link" id="cancel" style="color:var(--fg);margin-top:6px">Cancel</button></div>`;
 else if(S.busy)h+=`<p class="c mut">Waiting for ${esc(S.busy)}&hellip; finish in the browser tab that opened.</p>`;
 const err=localErr||S.error;if(err)h+=`<p class="err">${esc(err)}</p>`;
 h+=`<p class="c"><button class="link" data-x="link" style="color:var(--fg)">${open.link?"&#9662;":"&#8227;"} Have a link code from another device?</button></p>`;
 if(open.link)h+=`<div class="box"><input id="lc" placeholder="Link code"><button class="btn" id="lgo" ${S.providers["device-link"]?"":"disabled"}>Link this device</button></div>`;
 h+=`<p class="c"><button class="link acc" data-x="approve">Approve a device</button></p>`;
 if(open.approve){const a=S.approve||{};h+=`<div class="box"><input id="ac" placeholder="8-digit code from the other device (1234-5678)"><button class="btn" id="alook">Look up</button>`;
  if(a.request)h+=`<p class="c">${esc(a.request.device_name)} &middot; <b>${esc(a.request.code)}</b> &middot; ${esc(a.request.status)}</p><input id="aprof" value="${esc(S.profile)}"><button class="btn" id="aok">Approve into this profile</button>`;
  if(a.success)h+=`<p class="ok">${esc(a.success)}</p>`;h+=`</div>`}
 h+=`<p class="c mut" style="font-size:14px">${mode=="signup"?"Already have an account?":"Don't have an account?"} <button class="link" id="mode" style="color:var(--fg);font-weight:600">${mode=="signup"?"Sign in":"Sign up"}</button></p>`;
 if(S.preview)h+=`<p class="c mut">Preview: no key, no network</p>`;
 c.innerHTML=h;bind()}
function bind(){
 document.querySelectorAll("[data-p]").forEach(b=>b.onclick=async()=>{localErr=null;try{const r=await api("/api/start",{provider:b.dataset.p,mode});if(r.redirect)location.href=r.redirect;else tick()}catch(e){localErr=e.message;render()}});
 document.querySelectorAll("[data-x]").forEach(b=>b.onclick=()=>{open[b.dataset.x]=!open[b.dataset.x];render()});
 const on=(id,f)=>{const e=$("#"+id);if(e)e.onclick=async()=>{localErr=null;try{await f();tick()}catch(x){localErr=x.message;render()}}};
 on("ego",()=>{const b={username:$("#eu").value,password:$("#ep").value,mode};$("#ep").value="";return api("/api/email",b)});
 on("ago",()=>{const b={username:$("#au").value,password:$("#ap").value};$("#ap").value="";return api("/api/assm-password",b)});
 on("lgo",()=>api("/api/link",{code:$("#lc").value}));
 on("alook",()=>api("/api/approve/lookup",{code:$("#ac").value}));
 on("aok",()=>api("/api/approve/confirm",{profile:$("#aprof").value}));
 on("cancel",()=>api("/api/cancel",{}));
 const m=$("#mode");if(m)m.onclick=()=>{mode=mode=="signup"?"signin":"signup";render()}}
async function tick(){try{const n=await api("/api/state");const changed=JSON.stringify(n)!==JSON.stringify(S);S=n;if(changed&&!document.activeElement?.matches("input"))render()}catch(e){}}
["#notnow1","#notnow2"].forEach(s=>$(s).onclick=async()=>{await api("/api/close",{}).catch(()=>{});S&&(S.closed=true);render()});
tick();setInterval(tick,1500);
</script></body></html>"""
