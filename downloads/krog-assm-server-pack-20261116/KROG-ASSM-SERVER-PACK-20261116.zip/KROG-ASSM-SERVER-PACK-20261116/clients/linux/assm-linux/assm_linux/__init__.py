"""ASSMKit for Linux: RCODE's unified sign-in + ASSM-RSYNC sync on Linux desktops.

Same providers and order as ASSMKit SignInView (Google, Apple, email, passkey, Microsoft, ASSM approve
code/QR, device link; ASSM username+password behind an off-by-default flag). Every sign-in ends on the
owner ASSM identity (ЯID-0001-3QQS) with this machine's own P-256 device key, approved once by Rizal,
and the same ASSM-RSYNC routes (/api/rsync/request|device-status, /v1/sync/changes|pull).
"""
__version__ = "0.1.0"
