"""Config (mirrors RCODEAuthConfig.plist / AssmKitConfig). Public values only; overrides in
~/.config/rcode-assm/config.json. Placeholders dim the provider buttons."""
import json, os

CONFIG_DIR = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"), "rcode-assm")
DATA_DIR = os.path.join(os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share"), "rcode-assm")

DEFAULTS = {
    "app_name": "RCODE",
    "prefix": "rcode",
    "url_scheme": "rcode",
    "owner_profile": "ЯID-0001-3QQS",
    "owner_handle": "@chaserizal",
    "owner_display_name": "Rizal",
    "assm_base_url": "https://ASSM_SERVER_URL",
    "assm_fallback_base_url": "https://rizal.pw",      # live URL rediscovered from <fallback>/api/rsync/entries
    "assm_enroll_entries_path": "/api/rsync/entries",
    "server_url": "REPLACE_WITH_RCODE_SERVER_URL",     # optional RCODE account server (email, passkey, device link)
    "google_desktop_client_id": "REPLACE_WITH_GOOGLE_DESKTOP_CLIENT_ID.apps.googleusercontent.com",
    "google_desktop_client_secret": "REPLACE_WITH_GOOGLE_DESKTOP_CLIENT_SECRET",  # Google "Desktop app" clients require it; not confidential
    "microsoft_client_id": "REPLACE_WITH_ENTRA_APPLICATION_CLIENT_ID",
    "microsoft_tenant": "common",
    "apple_services_id": "REPLACE_WITH_APPLE_SERVICES_ID",
    "apple_return_url": "https://rizal.pw/auth/apple/desktop",       # https relay -> http://127.0.0.1:<port>/callback/apple
    "passkey_rp_id": "REPLACE_WITH_RP_DOMAIN",
    "passkey_bridge_url": "https://rizal.pw/auth/passkey/desktop",   # WebAuthn needs an https RP origin
    "assm_password_enabled": False,   # OFF: no server verifies an ASSM password today
    "auth_preview": False,
}


def is_placeholder(v):
    return not v or str(v).startswith("REPLACE_WITH")


def load():
    c = dict(DEFAULTS)
    p = os.path.join(CONFIG_DIR, "config.json")
    if os.path.isfile(p):
        with open(p) as f:
            c.update({k: v for k, v in json.load(f).items() if k in DEFAULTS})
    if os.environ.get("RCODE_ASSM_PASSWORD") == "1":
        c["assm_password_enabled"] = True
    return c
