"""Canonical JSON, field-for-field with ASSMRsyncSeal.swift / Android Canon / ASSM-RSYNC sync.py:
sorted keys, no spaces, unicode unescaped, nulls dropped from objects."""
import hashlib
from datetime import datetime, timezone


def json_string(s):
    out = ['"']
    for ch in s:
        if ch == '"': out.append('\\"')
        elif ch == '\\': out.append('\\\\')
        elif ch == '\b': out.append('\\b')
        elif ch == '\f': out.append('\\f')
        elif ch == '\n': out.append('\\n')
        elif ch == '\r': out.append('\\r')
        elif ch == '\t': out.append('\\t')
        elif ord(ch) < 0x20: out.append('\\u%04x' % ord(ch))
        else: out.append(ch)
    out.append('"')
    return "".join(out)


def canon(v):
    if v is None: return "null"
    if v is True: return "true"
    if v is False: return "false"
    if isinstance(v, (list, tuple)): return "[" + ",".join(canon(x) for x in v) + "]"
    if isinstance(v, dict):
        return "{" + ",".join(json_string(k) + ":" + canon(v[k]) for k in sorted(v) if v[k] is not None) + "}"
    if isinstance(v, int): return str(v)
    if isinstance(v, float):
        return str(int(v)) if v == int(v) and abs(v) < 9.0e18 else repr(v)
    return json_string(str(v))


def sha256_hex(s):
    return hashlib.sha256(s.encode("utf-8") if isinstance(s, str) else s).hexdigest()


def iso_js(t=None):
    """JS toISOString(): milliseconds + Z."""
    d = datetime.fromtimestamp(t, timezone.utc) if t is not None else datetime.now(timezone.utc)
    return d.strftime("%Y-%m-%dT%H:%M:%S.") + "%03dZ" % (d.microsecond // 1000)


def short_code(device, nonce):
    """sha256(device + "\\n" + nonce) -> first 10 hex -> mod 1e8 -> XXXX-XXXX (ASSMRsyncSeal.shortCode)."""
    n = int(sha256_hex(device + "\n" + nonce)[:10], 16) % 100_000_000
    s = "%08d" % n
    return s[:4] + "-" + s[4:]
