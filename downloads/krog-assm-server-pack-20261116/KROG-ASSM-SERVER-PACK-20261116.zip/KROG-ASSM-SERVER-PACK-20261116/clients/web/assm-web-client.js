/* assm-web-client.js — ASSM-RSYNC web client for rizal.pw and rizal.info (and WebViews)
 * KROG-ASSM-SERVER-PACK-20261116, Nov 16, 2026. NOT installed on either site.
 *
 * Host: window.ASSM_SERVER_URL (set in rdragon-config.js / a <meta name="assm-server-url">). Placeholder until
 *       Rizal approves a host: "https://ASSM_SERVER_URL". Never a LAN IP or a tunnel URL.
 *
 * Bot login (KROG) protocol, from botauth.py:
 *   GET  /api/rsync/bot/params?user=@krog -> {scheme, profile, handle, salt, iter}
 *   proof = base64(PBKDF2-HMAC-SHA256(password, salt, iter>=600000, 32 bytes))
 *   sig   = ECDSA P-256 (raw r||s, base64) by a BOT-ONLY device key over
 *           "assm-bot-login-v1\n" + user\nsha256hex(proof)\ndevice\ndevice_name\nnonce\nts
 *   POST /api/rsync/bot/login -> {session (Bearer), role:"bot", scopes, denied, trusted:false}
 *   POST /api/rsync/bot/post {text} | /api/rsync/bot/reply {text,parent_id,parent_author?} | GET /bot/whoami | POST /bot/logout
 *
 * SECURITY: a public page must never ship the bot password. Use bot.login() only (a) from a local worker on
 * Rizal's own device, or (b) after a one-time import into this browser's IndexedDB on Rizal's own browser.
 * The bot device key is a NON-extractable WebCrypto key in IndexedDB "assm.bot.keys", separate from the owner
 * device key ("rdragon.csp.keys"/"device") used by rlogin-page.js. Sessions live in memory only.
 */
(function (root) {
  "use strict";
  var enc = new TextEncoder();
  function base() {
    var m = root.document && root.document.querySelector && root.document.querySelector('meta[name="assm-server-url"]');
    var u = root.ASSM_SERVER_URL || (m && m.content) || "https://ASSM_SERVER_URL";
    return String(u).replace(/\/+$/, "");
  }
  function b64(buf) { var s = "", a = new Uint8Array(buf); for (var i = 0; i < a.length; i++) s += String.fromCharCode(a[i]); return btoa(s); }
  function unb64(s) { var b = atob(s), a = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) a[i] = b.charCodeAt(i); return a; }
  function hex(buf) { return Array.prototype.map.call(new Uint8Array(buf), function (x) { return ("0" + x.toString(16)).slice(-2); }).join(""); }
  function nonce() { var a = new Uint8Array(16); crypto.getRandomValues(a); return hex(a); }
  function isoNow() { return new Date().toISOString().replace(/\.\d{3}Z$/, "Z"); }

  function req(method, path, body, bearer) {
    var h = { "Content-Type": "application/json" };
    if (bearer) h.Authorization = "Bearer " + bearer;
    return fetch(base() + path, { method: method, headers: h, body: body ? JSON.stringify(body) : undefined, credentials: "omit" })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { j.status = r.status; return j; }); });
  }

  // ---- IndexedDB helper for the bot device key (non-extractable) ----
  function idb(name, store) {
    return new Promise(function (res, rej) {
      var r = indexedDB.open(name, 1);
      r.onupgradeneeded = function () { r.result.createObjectStore(store); };
      r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); };
    });
  }
  function kvGet(db, store, k) { return new Promise(function (res) { var g = db.transaction(store).objectStore(store).get(k); g.onsuccess = function () { res(g.result); }; g.onerror = function () { res(undefined); }; }); }
  function kvAdd(db, store, k, v) { return new Promise(function (res) { var tx = db.transaction(store, "readwrite"); tx.objectStore(store).add(v, k); tx.oncomplete = function () { res(true); }; tx.onerror = function () { res(false); }; }); }

  function botKey(handle) {
    var id = "bot:" + handle;
    return idb("assm.bot.keys", "k").then(function (db) {
      return kvGet(db, "k", id).then(function (kp) {
        if (kp) return kp;
        return crypto.subtle.generateKey({ name: "ECDSA", namedCurve: "P-256" }, false, ["sign", "verify"]).then(function (n) {
          return kvAdd(db, "k", id, n).then(function () { return n; }); // add-only
        });
      });
    }).then(function (kp) {
      return crypto.subtle.exportKey("raw", kp.publicKey).then(function (raw) { return { kp: kp, pub: b64(raw) }; });
    });
  }

  function pbkdf2(password, saltB64, iter) {
    if (iter < 600000) return Promise.reject(new Error("refusing iter < 600000"));
    return crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]).then(function (k) {
      return crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: unb64(saltB64), iterations: iter }, k, 256);
    });
  }

  var bot = {
    session: null, me: null,
    params: function (user) { return req("GET", "/api/rsync/bot/params?user=" + encodeURIComponent(user)); },
    login: function (user, password, deviceName) {
      var self = this, p, key, proof;
      return this.params(user).then(function (pr) {
        if (!pr.ok) throw new Error(pr.error || "no bot login");
        if (pr.scheme !== "pbkdf2-sha256-hmac-v1") throw new Error("unknown scheme");
        p = pr; return pbkdf2(password, pr.salt, pr.iter);
      }).then(function (dk) {
        password = null; proof = b64(dk); return botKey(p.handle);
      }).then(function (k) {
        key = k; return crypto.subtle.digest("SHA-256", enc.encode(proof));
      }).then(function (ph) {
        var o = { t: "bot.login", user: p.handle, proof: proof, device: key.pub, device_name: (deviceName || "web bot device").slice(0, 80),
                  nonce: nonce(), ts: isoNow() };
        var msg = "assm-bot-login-v1\n" + [o.user, hex(ph), o.device, o.device_name, o.nonce, o.ts].join("\n");
        return crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, key.kp.privateKey, enc.encode(msg)).then(function (sig) {
          o.sig = b64(sig); return req("POST", "/api/rsync/bot/login", o);
        });
      }).then(function (r) {
        if (!r.ok) throw new Error(r.error || ("login failed " + r.status));
        self.session = r.session; self.me = { profile: r.profile, handle: r.handle, scopes: r.scopes, denied: r.denied };
        try { root.dispatchEvent(new CustomEvent("assm-bot-session", { detail: self.me })); } catch (e) {}
        return self.me;
      });
    },
    whoami: function () { return req("GET", "/api/rsync/bot/whoami", null, this.session); },
    post: function (text) { return req("POST", "/api/rsync/bot/post", { text: text }, this.session); },
    reply: function (parentId, text, parentAuthor) { return req("POST", "/api/rsync/bot/reply", { parent_id: parentId, text: text, parent_author: parentAuthor }, this.session); },
    logout: function () { var s = this.session; this.session = null; this.me = null; return req("POST", "/api/rsync/bot/logout", {}, s); }
  };

  // ---- Owner-side routes (thin wrappers; the signed bodies are built exactly as in rlogin-page.js / ASSMKit) ----
  var owner = {
    health: function () { return req("GET", "/health"); },
    request: function (body) { return req("POST", "/api/rsync/request", body); },              // device link / approval request
    approve: function (body) { return req("POST", "/api/rsync/approve", body); },              // signed by an ACTIVE trusted device
    requestStatus: function (code) { return req("GET", "/api/rsync/request/" + encodeURIComponent(code)); },
    entries: function (qs) { return req("GET", "/api/rsync/entries" + (qs ? "?" + qs : "")); },
    deviceStatus: function (pub) { return req("GET", "/api/rsync/device-status?device=" + encodeURIComponent(pub)); },
    passwordParams: function (user) { return req("GET", "/api/rsync/password/params" + (user ? "?user=" + encodeURIComponent(user) : "")); },
    passwordSet: function (body) { return req("POST", "/api/rsync/password/set", body); },     // signed by trusted device; verifier only
    passwordLogin: function (body) { return req("POST", "/api/rsync/password/login", body); }, // proof only, never the password
    syncChanges: function (body) { return req("POST", "/v1/sync/changes", body); },
    syncPull: function (body) { return req("POST", "/v1/sync/pull", body); }
  };

  root.ASSMWeb = { base: base, bot: bot, owner: owner, pbkdf2: pbkdf2, version: "2026.11.16-pack" };
})(typeof window !== "undefined" ? window : globalThis);
