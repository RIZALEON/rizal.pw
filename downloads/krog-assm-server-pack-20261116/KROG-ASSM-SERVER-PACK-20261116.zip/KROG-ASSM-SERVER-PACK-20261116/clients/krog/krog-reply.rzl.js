/* krog-reply.rzl.js — KROG + RDRAGON both-reply module (web / WKWebView / Android WebView)
 * KROG-ASSM-SERVER-PACK-20261116. Written Nov 16, 2026 (America/Denver). NOT installed anywhere.
 *
 * Rizal's rule (Nov 16, 2026, 5:09 PM MST): every user post and every user comment gets
 *   ONE reply from RDRAGON and ONE reply from KROG. Neither bot replies to the other's
 *   replies, or to its own. Both replies are logged side by side so they can be compared
 *   ("so we can analyze and determine and grow faster").
 *
 * Analysis log: append-only, local to this device, never uploaded, never edited, never cleared.
 *   Storage: IndexedDB "krog.compare" / store "log" (autoIncrement). Fallback: localStorage key
 *   "krog-rdragon-compare.jsonl" (append by concatenation only). No delete/clear API exists here.
 *
 * Usage (after rdragon-config.js and assm-web-client.js):
 *   KROGReply.init({
 *     rdragonReply: (target) => Promise<string>,   // existing RDRAGON bot() / RDRAGON.reply
 *     krogReply:    (target) => Promise<string>,   // KROG model call (local server / API, Rizal's choice)
 *     publish:      (who, target, text) => Promise<any>, // render + post the reply (KROG via ASSMWeb.bot.reply)
 *     device:       "neo"                          // short local name only, never an address
 *   });
 *   // call on every new user post/comment:
 *   KROGReply.onUserItem({ id, kind: "post"|"comment", text, by: "@handle", ts, media: [], parent_id });
 */
(function (root) {
  "use strict";

  var BOT_HANDLES = ["rdragon", "@rdragon", "krog", "@krog", "@thundr", "thundr", "@grok", "grok", "rbot", "@rbot"];
  var BOT_KINDS = ["rdragon.reply", "krog.reply", "bot.reply", "bot.post", "thundr.reply"];
  var BOT_PROFILES = ["ЯID-BOT-0001"]; // KROG; extend with every bot ЯID
  var DB = "krog.compare", STORE = "log", LS_KEY = "krog-rdragon-compare.jsonl";

  var cfg = null;
  var answered = { rdragon: Object.create(null), krog: Object.create(null) }; // per target id, per bot
  var inflight = Object.create(null);

  // Same spirit as CryptoSocial rdSafe: never log or publish keys, secrets, LAN IPs or tunnel URLs.
  var UNSAFE = [
    /-----BEGIN [A-Z ]*PRIVATE KEY-----/i,
    /\b(?:10|127|192\.168|172\.(?:1[6-9]|2\d|3[01]))\.\d{1,3}\.\d{1,3}(?:\.\d{1,3})?\b/,
    /\b[a-z0-9-]+\.trycloudflare\.com\b/i, /\bngrok(?:-free)?\.(?:io|app|dev)\b/i,
    /\b(?:password|passwd|secret|api[_-]?key|bearer)\s*[:=]\s*\S+/i,
    /\b[A-Za-z0-9+\/]{86,88}={0,2}\b/ // raw P-256 / long base64 blobs
  ];
  function safe(t) {
    t = String(t == null ? "" : t);
    for (var i = 0; i < UNSAFE.length; i++) if (UNSAFE[i].test(t)) return "[redacted by krog-reply safety filter]";
    return t;
  }

  function isBotItem(item) {
    if (!item) return true;
    var by = String(item.by || item.author || "").toLowerCase();
    if (BOT_HANDLES.indexOf(by) >= 0) return true;
    if (item.kind && BOT_KINDS.indexOf(String(item.kind)) >= 0) return true;
    if (item.t && BOT_KINDS.indexOf(String(item.t)) >= 0) return true;
    if (item.profile && BOT_PROFILES.indexOf(String(item.profile)) >= 0) return true;
    if (item.role === "bot" || item.bot === true) return true;
    return false;
  }

  // ---------- append-only local log ----------
  var dbp = null;
  function openDB() {
    if (dbp) return dbp;
    dbp = new Promise(function (res) {
      try {
        if (!root.indexedDB) return res(null);
        var r = root.indexedDB.open(DB, 1);
        r.onupgradeneeded = function () { r.result.createObjectStore(STORE, { autoIncrement: true }); };
        r.onsuccess = function () { res(r.result); };
        r.onerror = function () { res(null); };
      } catch (e) { res(null); }
    });
    return dbp;
  }
  function append(rec) {
    rec.logged_ts = new Date().toISOString();
    var line = JSON.stringify(rec);
    return openDB().then(function (db) {
      if (db) return new Promise(function (res) {
        var tx = db.transaction(STORE, "readwrite");
        tx.objectStore(STORE).add(line); // add() only: never put()/delete()/clear()
        tx.oncomplete = function () { res(true); };
        tx.onerror = function () { res(false); };
      });
      try { root.localStorage.setItem(LS_KEY, (root.localStorage.getItem(LS_KEY) || "") + line + "\n"); } catch (e) {}
      return true;
    });
  }
  /** Read-only export for the local compare viewer (array of JSONL lines). */
  function readAll() {
    return openDB().then(function (db) {
      if (!db) return ((root.localStorage && root.localStorage.getItem(LS_KEY)) || "").split("\n").filter(Boolean);
      return new Promise(function (res) {
        var out = [], c = db.transaction(STORE, "readonly").objectStore(STORE).openCursor();
        c.onsuccess = function () { var cur = c.result; if (cur) { out.push(cur.value); cur.continue(); } else res(out); };
        c.onerror = function () { res(out); };
      });
    });
  }

  function side(text, t0, meta) {
    return { text: safe(text), ts: new Date().toISOString(), model: (meta && meta.model) || null,
             version: (meta && meta.version) || null, latency_ms: Date.now() - t0, status: "answered" };
  }
  function pending() { return { text: null, ts: null, model: null, version: null, latency_ms: null, status: "pending" }; }

  function runOne(who, target, t0) {
    if (answered[who][target.id]) return Promise.resolve(null); // never a second reply from the same bot
    answered[who][target.id] = true;
    var fn = who === "krog" ? cfg.krogReply : cfg.rdragonReply;
    return Promise.resolve().then(function () { return fn(target); }).then(function (text) {
      if (!text) throw new Error("empty reply");
      var meta = (cfg.meta && cfg.meta[who]) || {};
      var s = side(text, t0, meta);
      return Promise.resolve(cfg.publish ? cfg.publish(who, target, s.text) : null).then(function () { return s; });
    }).catch(function (e) {
      return { text: null, ts: new Date().toISOString(), latency_ms: Date.now() - t0, status: "failed", error: String(e && e.message || e).slice(0, 200) };
    });
  }

  function onUserItem(item) {
    if (!cfg) throw new Error("KROGReply.init() first");
    if (isBotItem(item)) return Promise.resolve({ skipped: "bot item" });   // no bot→bot, no self-replies
    if (!item || !item.id) return Promise.resolve({ skipped: "no id" });
    if (inflight[item.id]) return inflight[item.id];
    var target = { id: String(item.id), kind: item.kind === "comment" ? "comment" : "post", text: safe(item.text),
                   by: item.by || null, ts: item.ts || null, media: item.media || [], parent_id: item.parent_id || null };
    var t0 = Date.now(), firstLogged = false, cmpId = "cmp-" + target.id;
    function base() {
      return { v: 1, kind: "compare", id: cmpId, target_id: target.id, target_kind: target.kind, target_text: target.text,
               target_by: target.by, target_ts: target.ts, media: target.media, device: cfg.device || "device",
               reactions: { rdragon: { up: 0, down: 0, better: null, notes: null }, krog: { up: 0, down: 0, better: null, notes: null } },
               engagement: { rdragon: { replies: 0, likes: 0, reposts: 0 }, krog: { replies: 0, likes: 0, reposts: 0 } } };
    }
    var res = { rdragon: null, krog: null };
    function landed(who, s) {
      if (!s) return;
      res[who] = s;
      if (!firstLogged) {
        firstLogged = true;
        var r = base(); r.rdragon = res.rdragon || pending(); r.krog = res.krog || pending();
        return append(r);
      }
      // second reply: a NEW amend line pointing at the same target (never patch the first line)
      var a = { v: 1, kind: "amend", id: cmpId, target_id: target.id, device: cfg.device || "device" };
      a[who] = s;
      return append(a);
    }
    var p = Promise.all([
      runOne("rdragon", target, t0).then(function (s) { return landed("rdragon", s); }),
      runOne("krog", target, t0).then(function (s) { return landed("krog", s); })
    ]).then(function () { delete inflight[item.id]; return res; });
    inflight[item.id] = p;
    return p;
  }

  /** 👍 / 👎 / "better" from the viewer: a new reaction line, never an edit. */
  function react(targetId, who, mark, notes) {
    if (who !== "rdragon" && who !== "krog") throw new Error("who must be rdragon or krog");
    if (["up", "down", "better"].indexOf(mark) < 0) throw new Error("mark must be up, down or better");
    return append({ v: 1, kind: "reaction", id: "cmp-" + targetId, target_id: String(targetId), who: who, mark: mark,
                    notes: notes ? safe(notes).slice(0, 500) : null, device: (cfg && cfg.device) || "device" });
  }

  function init(c) {
    if (!c || typeof c.rdragonReply !== "function" || typeof c.krogReply !== "function")
      throw new Error("KROGReply.init needs rdragonReply and krogReply functions");
    cfg = c;
    return api;
  }

  var api = { init: init, onUserItem: onUserItem, react: react, readAll: readAll, isBotItem: isBotItem, safe: safe,
              rule: "RDRAGON and KROG each reply once to every user post and comment; neither replies to a bot item or itself." };
  root.KROGReply = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
