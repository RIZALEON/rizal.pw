package info.rizal.assmkit.core

import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * rsync-core.js / ASSM-RSYNC `sync.py` canonical JSON, field-for-field with ASSMRsyncSeal.swift:
 * sorted keys, no spaces, unicode unescaped, nulls dropped from objects.
 */
object Canon {
    fun canon(v: Any?): String = when (v) {
        null, JSONObject.NULL -> "null"
        is JSONArray -> (0 until v.length()).joinToString(",", "[", "]") { canon(v.opt(it)) }
        is List<*> -> v.joinToString(",", "[", "]") { canon(it) }
        is JSONObject -> {
            val keys = v.keys().asSequence().toList().sorted()
            keys.filter { v.opt(it) != null && v.opt(it) != JSONObject.NULL }
                .joinToString(",", "{", "}") { jsonString(it) + ":" + canon(v.opt(it)) }
        }
        is Map<*, *> -> {
            val keys = v.keys.map { it.toString() }.sorted()
            keys.filter { v[it] != null && v[it] != JSONObject.NULL }
                .joinToString(",", "{", "}") { jsonString(it) + ":" + canon(v[it]) }
        }
        is Boolean -> if (v) "true" else "false"
        is Int, is Long, is Short, is Byte -> v.toString()
        is Double, is Float -> {
            val d = (v as Number).toDouble()
            if (d == Math.rint(d) && !d.isInfinite() && Math.abs(d) < 9.0E18) d.toLong().toString() else d.toString()
        }
        is Number -> v.toString()
        is String -> jsonString(v)
        else -> jsonString(v.toString())
    }

    fun jsonString(s: String): String {
        val sb = StringBuilder("\"")
        for (ch in s) {
            when (ch) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> if (ch.code < 0x20) sb.append(String.format(Locale.US, "\\u%04x", ch.code)) else sb.append(ch)
            }
        }
        return sb.append('"').toString()
    }

    fun sha256Hex(s: String): String = sha256Hex(s.toByteArray(Charsets.UTF_8))
    fun sha256Hex(b: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }
}

/** Date helpers matching the Swift side exactly. */
object Iso {
    private fun fmt(p: String) = SimpleDateFormat(p, Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }

    /** JS `new Date().toISOString()`: milliseconds + Z (record `updated_at`, envelope `ts`, enroll `req_ts`). */
    fun js(date: Date = Date()): String = fmt("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").format(date)

    /** Swift JSONEncoder `.iso8601` (payload `sent_at` / `updated_at`): whole seconds + Z. */
    fun swift(date: Date): String = fmt("yyyy-MM-dd'T'HH:mm:ss'Z'").format(date)

    /** Accepts both forms (and +00:00 offsets). */
    fun parse(s: String?): Date? {
        if (s.isNullOrBlank()) return null
        var t = s.trim()
        if (t.endsWith("+00:00")) t = t.dropLast(6) + "Z"
        val pats = listOf("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'")
        // Normalise fractional seconds to 3 digits so SimpleDateFormat reads them as ms.
        val m = Regex("""^(.*T\d\d:\d\d:\d\d)\.(\d+)Z$""").find(t)
        if (m != null) {
            val frac = (m.groupValues[2] + "000").take(3)
            t = m.groupValues[1] + "." + frac + "Z"
        }
        for (p in pats) runCatching { return fmt(p).parse(t) }
        return null
    }

    /** JS `Date.parse(iso)` → integer ms (for `enroll-{nonce}-{ms.toString(36)}`). */
    fun jsMillis(iso: String): Long = parse(iso)?.time ?: System.currentTimeMillis()
}
