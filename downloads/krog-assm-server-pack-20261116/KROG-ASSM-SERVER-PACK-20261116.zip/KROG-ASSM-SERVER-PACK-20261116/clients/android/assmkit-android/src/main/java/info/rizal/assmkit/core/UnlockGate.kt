package info.rizal.assmkit.core

import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.lang.ref.WeakReference
import java.security.Signature
import kotlin.coroutines.resume

class UnlockCancelled : Exception("Unlock cancelled — fingerprint, face or the device PIN is required.")

/**
 * Port of the Apple `UnlockGate`: fingerprint / face / device PIN via BiometricPrompt.
 * Only ever triggered by the foreground UI; there is no background or timer signing without the user.
 */
object UnlockGate {
    private var activityRef: WeakReference<FragmentActivity>? = null
    fun attach(a: FragmentActivity) { activityRef = WeakReference(a) }
    val available: Boolean get() = activityRef?.get()?.let { !it.isFinishing } == true

    private fun info(title: String, subtitle: String) = BiometricPrompt.PromptInfo.Builder()
        .setTitle(title)
        .setSubtitle(subtitle)
        .setAllowedAuthenticators(BIOMETRIC_STRONG or DEVICE_CREDENTIAL)
        .build()

    /** Refreshes the time-bound auth window for the device key. */
    suspend fun require(reason: String) {
        val a = activityRef?.get() ?: throw UnlockCancelled()
        val ok = withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->
                val p = BiometricPrompt(a, ContextCompat.getMainExecutor(a), object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { if (cont.isActive) cont.resume(true) }
                    override fun onAuthenticationError(code: Int, msg: CharSequence) { if (cont.isActive) cont.resume(false) }
                })
                p.authenticate(info("RCODE", reason))
            }
        }
        if (!ok) throw UnlockCancelled()
    }

    /** Per-use auth: unlocks exactly this Signature (approver key). */
    suspend fun unlockSignature(reason: String, sig: Signature): Signature {
        val a = activityRef?.get() ?: throw UnlockCancelled()
        val out = withContext(Dispatchers.Main) {
            suspendCancellableCoroutine<Signature?> { cont ->
                val p = BiometricPrompt(a, ContextCompat.getMainExecutor(a), object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        if (cont.isActive) cont.resume(result.cryptoObject?.signature)
                    }
                    override fun onAuthenticationError(code: Int, msg: CharSequence) { if (cont.isActive) cont.resume(null) }
                })
                p.authenticate(info("Approve a device", reason), BiometricPrompt.CryptoObject(sig))
            }
        }
        return out ?: throw UnlockCancelled()
    }
}
