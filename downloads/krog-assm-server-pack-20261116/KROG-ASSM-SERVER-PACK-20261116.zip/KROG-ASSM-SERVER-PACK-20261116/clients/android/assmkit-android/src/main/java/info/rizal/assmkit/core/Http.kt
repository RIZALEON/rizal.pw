package info.rizal.assmkit.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.HttpURLConnection
import java.net.URL

data class HttpResult(val status: Int, val body: String) {
    val ok get() = status in 200..299
    fun json(): Any? = runCatching { JSONTokener(body).nextValue() }.getOrNull()
    fun obj(): JSONObject = (json() as? JSONObject) ?: JSONObject()
    fun error(): String = obj().optString("error").ifBlank { "HTTP $status" }
}

/** Tiny HttpURLConnection wrapper (no extra deps; keeps the APK small). Never logs bodies. */
object Http {
    suspend fun get(url: String, timeoutMs: Int = 15_000): HttpResult = call("GET", url, null, timeoutMs)
    suspend fun post(url: String, body: String, timeoutMs: Int = 20_000): HttpResult = call("POST", url, body, timeoutMs)

    /** application/x-www-form-urlencoded POST (OAuth token endpoints). */
    suspend fun postForm(url: String, form: String, timeoutMs: Int = 20_000): HttpResult =
        call("POST", url, form, timeoutMs, "application/x-www-form-urlencoded")

    /** JSON with a bearer token (RCODE account server). */
    suspend fun postAuthed(url: String, body: String, bearer: String?, timeoutMs: Int = 20_000): HttpResult =
        call("POST", url, body, timeoutMs, "application/json", bearer)

    suspend fun call(method: String, url: String, body: String?, timeoutMs: Int,
                     contentType: String = "application/json", bearer: String? = null): HttpResult = withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.useCaches = false
            c.setRequestProperty("accept", "application/json")
            if (bearer != null) c.setRequestProperty("authorization", "Bearer $bearer")
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("content-type", contentType)
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code >= 400) c.errorStream else c.inputStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            HttpResult(code, text)
        } finally {
            c.disconnect()
        }
    }

    /** Reads `{entries:[...], live?}`, a bare JSON array, or JSONL (same as ASSMProvider.fetchFeed). */
    fun parseFeed(text: String): Pair<List<JSONObject>, String?> {
        val v = runCatching { JSONTokener(text).nextValue() }.getOrNull()
        if (v is JSONArray) return (0 until v.length()).mapNotNull { v.optJSONObject(it) } to null
        if (v is JSONObject) {
            val arr = v.optJSONArray("entries") ?: JSONArray()
            return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) } to v.optString("live").ifBlank { null }
        }
        val lines = text.lines().mapNotNull { l -> runCatching { JSONObject(l) }.getOrNull() }
        return lines to null
    }
}
