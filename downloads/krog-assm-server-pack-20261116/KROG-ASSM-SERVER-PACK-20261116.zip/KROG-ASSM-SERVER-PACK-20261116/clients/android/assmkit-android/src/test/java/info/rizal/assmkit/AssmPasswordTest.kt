package info.rizal.assmkit

import info.rizal.assmkit.auth.AssmPasswordClient
import info.rizal.assmkit.auth.AuthException
import info.rizal.assmkit.core.Canon
import info.rizal.assmkit.sync.SyncSigner
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.math.BigInteger
import java.net.InetSocketAddress
import java.security.KeyPairGenerator
import java.security.Signature
import java.security.interfaces.ECPublicKey
import java.security.spec.ECGenParameterSpec
import java.util.Base64
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Vectors shared with ASSMKit (GHOSTMACHINE assmkit 3274919) and the Linux client; fake pwlogin routes on 127.0.0.1. */
class AssmPasswordTest {
    @Test fun pbkdf2VectorMatchesAssmKit() {
        val dk = AssmPasswordClient.derive("password".toCharArray(), "salt".toByteArray(), 1)
        assertEquals("120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b", dk.joinToString("") { "%02x".format(it) })
    }

    @Test fun loginMessageMatchesServer() {
        assertEquals("assm-password-login-v1\n@h\nba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad\nD\nn\nN\nT",
            AssmPasswordClient.loginMessage("@h", "abc", "D", "n", "N", "T"))
        val n = AssmPasswordClient.nonce(); assertTrue(n.length in 8..64 && n.all { it.isLetterOrDigit() })
    }

    @Test fun offByDefault() = assertFalse(AssmKitConfig.assmPasswordEnabled)

    private class SoftSigner : SyncSigner {
        val kp = KeyPairGenerator.getInstance("EC").apply { initialize(ECGenParameterSpec("secp256r1")) }.generateKeyPair()
        override fun publicKeyBase64(): String {
            val w = (kp.public as ECPublicKey).w
            fun b32(x: BigInteger) = x.toByteArray().let { if (it.size > 32) it.copyOfRange(it.size - 32, it.size) else ByteArray(32 - it.size) + it }
            return Base64.getEncoder().encodeToString(byteArrayOf(4) + b32(w.affineX) + b32(w.affineY))
        }
        override fun sign(message: String): String {
            val s = Signature.getInstance("SHA256withECDSA").apply { initSign(kp.private); update(message.toByteArray()) }
            return Base64.getEncoder().encodeToString(info.rizal.assmkit.core.KeystoreKey.derToRaw(s.sign()))
        }
        fun verify(msg: String, sig: String): Boolean {
            val raw = Base64.getDecoder().decode(sig)
            fun int(b: ByteArray) = BigInteger(1, b).toByteArray().let { byteArrayOf(2, it.size.toByte()) + it }
            val body = int(raw.copyOfRange(0, 32)) + int(raw.copyOfRange(32, 64))
            val der = byteArrayOf(0x30, body.size.toByte()) + body
            return Signature.getInstance("SHA256withECDSA").apply { initVerify(kp.public); update(msg.toByteArray()) }.verify(der)
        }
    }

    @Test fun loginAgainstPwloginRoutes() = runBlocking {
        val salt = "0123456789abcdef".toByteArray()
        val dk = AssmPasswordClient.derive("correct horse battery".toCharArray(), salt, 600_000)
        val verifier = Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(dk, "HmacSHA256")) }.doFinal("assm-password-verifier-v1".toByteArray())
        val signer = SoftSigner()
        var lock = false
        fun route(path: String, query: String, body: String): Pair<Int, JSONObject> = when (path) {
            "/api/rsync/password/params" -> {
                val user = java.net.URLDecoder.decode(query.substringAfter("user="), "UTF-8")
                if (user != "@chaserizal" && user != "ЯID-0001-3QQS") 404 to JSONObject().put("error", "no password")
                else 200 to JSONObject().put("scheme", "pbkdf2-sha256-hmac-v1").put("profile", "ЯID-0001-3QQS")
                    .put("handle", "@chaserizal").put("salt", Base64.getEncoder().encodeToString(salt)).put("iter", 600_000)
            }
            "/api/rsync/password/login" -> {
                val o = JSONObject(body)
                if (lock) 429 to JSONObject().put("retry_after_s", 42)
                else if (!(o.getString("t") == "password.login" && signer.verify(AssmPasswordClient.loginMessage(o.getString("user"),
                        o.getString("proof"), o.getString("device"), o.getString("device_name"), o.getString("nonce"), o.getString("ts")), o.getString("sig"))))
                    400 to JSONObject().put("error", "bad sig")
                else {
                    val got = Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(Base64.getDecoder().decode(o.getString("proof")), "HmacSHA256")) }
                        .doFinal("assm-password-verifier-v1".toByteArray())
                    if (!got.contentEquals(verifier)) 401 to JSONObject().put("error", "wrong username or password")
                    else 200 to JSONObject().put("ok", true).put("profile", "ЯID-0001-3QQS").put("handle", "@chaserizal")
                }
            }
            else -> 404 to JSONObject()
        }
        val srv = java.net.ServerSocket(0, 50, java.net.InetAddress.getByName("127.0.0.1"))
        val loop = Thread {
            while (!srv.isClosed) {
                val sock = runCatching { srv.accept() }.getOrNull() ?: break
                sock.use { c ->
                    val inp = java.io.BufferedInputStream(c.getInputStream())
                    fun line(): String { val sb = StringBuilder(); while (true) { val ch = inp.read(); if (ch < 0 || ch == '\n'.code) break; if (ch != '\r'.code) sb.append(ch.toChar()) }; return sb.toString() }
                    val req = line().split(" ")
                    var len = 0
                    while (true) { val h = line(); if (h.isEmpty()) break; if (h.lowercase().startsWith("content-length:")) len = h.substringAfter(":").trim().toInt() }
                    val body = ByteArray(len).also { var o = 0; while (o < len) { val n = inp.read(it, o, len - o); if (n < 0) break; o += n } }.decodeToString()
                    val (code, o) = route(req[1].substringBefore("?"), req[1].substringAfter("?", ""), body)
                    val b = o.toString().toByteArray()
                    c.getOutputStream().apply {
                        write("HTTP/1.1 $code X\r\nContent-Type: application/json\r\nContent-Length: ${b.size}\r\nConnection: close\r\n\r\n".toByteArray()); write(b); flush()
                    }
                }
            }
        }.apply { isDaemon = true; start() }
        val base = "http://127.0.0.1:${srv.localPort}"
        try {
            suspend fun err(user: String, pw: String) = try {
                AssmPasswordClient.login(base, user, pw.toCharArray(), "RCODE test", signer); fail("expected failure"); ""
            } catch (e: AuthException) { e.message ?: "" }
            assertEquals("Wrong username or password.", err("@nobody", "x"))
            assertEquals("Wrong username or password.", err("@chaserizal", "wrong password!"))
            val pw = "correct horse battery".toCharArray()
            assertEquals("ЯID-0001-3QQS" to "@chaserizal", AssmPasswordClient.login(base, "@chaserizal", pw, "RCODE test", signer))
            assertTrue("password chars cleared", pw.all { it == '\u0000' })
            lock = true
            assertTrue(err("@chaserizal", "correct horse battery").contains("42 s"))
        } finally { srv.close(); loop.join(2000) }
        Unit
    }
}
