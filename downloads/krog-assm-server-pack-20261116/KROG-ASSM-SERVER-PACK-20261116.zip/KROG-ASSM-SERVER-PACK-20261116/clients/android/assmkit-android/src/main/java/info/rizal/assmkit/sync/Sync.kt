package info.rizal.assmkit.sync

import info.rizal.assmkit.core.Canon
import info.rizal.assmkit.core.Http
import info.rizal.assmkit.core.Iso
import info.rizal.assmkit.core.KeystoreKey
import info.rizal.assmkit.assm.Assm
import org.json.JSONArray
import org.json.JSONObject
import java.util.Date

/** One synced item (SyncService.swift). `payload` is the app's own JSON object for that item. */
data class SyncRecord(
    val id: String,
    val kind: String, // chat | message | setting
    val updatedAt: Date,
    val deviceId: String,
    val deleted: Boolean,
    val payload: JSONObject,
) {
    /** Wire object, identical to ASSMSyncService.json(for:). */
    fun toWire(): JSONObject {
        val o = JSONObject()
            .put("id", id).put("kind", kind).put("updated_at", Iso.js(updatedAt))
            .put("device_id", deviceId).put("deleted", deleted).put("payload", payload)
        payload.optString("sent_at").ifBlank { null }?.let { o.put("sent_at", it) }
        return o
    }

    /** Last-writer-wins key: (updated_at, device_id). */
    fun newerThan(o: SyncRecord): Boolean =
        updatedAt.time > o.updatedAt.time || (updatedAt.time == o.updatedAt.time && deviceId > o.deviceId)

    override fun equals(other: Any?): Boolean = other is SyncRecord && id == other.id && kind == other.kind &&
        updatedAt == other.updatedAt && deviceId == other.deviceId && deleted == other.deleted &&
        payload.toString() == other.payload.toString()
    override fun hashCode(): Int = id.hashCode()

    companion object {
        fun fromWire(o: JSONObject): SyncRecord? {
            val id = o.optString("id").ifBlank { return null }
            val kind = o.optString("kind").takeIf { it == "chat" || it == "message" || it == "setting" } ?: return null
            val dev = o.optString("device_id").ifBlank { return null }
            val upd = Iso.parse(o.optString("updated_at")) ?: Date()
            val payload = when (val p = o.opt("payload")) {
                is JSONObject -> p
                is String -> runCatching { JSONObject(p) }.getOrElse { JSONObject() }
                else -> JSONObject()
            }
            return SyncRecord(id, kind, upd, dev, o.optBoolean("deleted"), payload)
        }
    }
}

class SyncHttpError(val status: Int, msg: String) : Exception(msg)

/**
 * REST chat/message sync against the live ASSM API (port of ASSMSyncService.swift).
 * Every call is signed by this install's Keystore device key:
 *   "rcode-sync-v1\n" + action + "\n" + identity + "\n" + pub + "\n" + nonce + "\n" + ts + "\n" + hash
 * hash = sha256(canon(records)) for push, the `since` cursor (or "") for pull.
 */
/** Signs sync envelopes. Production: the Keystore device key. Tests: a software P-256 key (test double). */
interface SyncSigner {
    fun publicKeyBase64(): String
    fun sign(message: String): String
}

object KeystoreSyncSigner : SyncSigner {
    override fun publicKeyBase64(): String = KeystoreKey.device.publicKeyBase64()
    override fun sign(message: String): String = KeystoreKey.device.sign(message)
}

class AssmSyncService(
    private val base: () -> String,
    private val identity: String,
    private val signer: SyncSigner = KeystoreSyncSigner,
    /** Learns a new live URL (quick tunnel restarted). Returns true if the base changed. */
    private val heal: (suspend () -> Boolean)? = null,
) {

    suspend fun push(records: List<SyncRecord>) {
        if (records.isEmpty()) return
        signedCall("/v1/sync/changes", "push", null, records)
    }

    suspend fun pull(since: String?): Pair<List<SyncRecord>, String?> {
        val o = signedCall("/v1/sync/pull", "pull", since, null)
        val arr = o.optJSONArray("records") ?: JSONArray()
        val recs = (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(SyncRecord::fromWire) }
        return recs to o.optString("cursor").ifBlank { null }
    }

    private suspend fun signedCall(path: String, action: String, since: String?, records: List<SyncRecord>?): JSONObject =
        try {
            signedCallOnce(path, action, since, records)
        } catch (e: java.io.IOException) {
            // Dead quick tunnel: learn the new live URL from the rizal.pw feed and retry once.
            if (heal?.invoke() == true) signedCallOnce(path, action, since, records) else throw e
        }

    private suspend fun signedCallOnce(path: String, action: String, since: String?, records: List<SyncRecord>?): JSONObject {
        val key = signer
        val pub = key.publicKeyBase64()
        val nonce = Assm.nonce()
        val ts = Iso.js()
        val recArr = records?.let { rs -> JSONArray().apply { rs.forEach { put(it.toWire()) } } }
        val hash = if (recArr != null) Canon.sha256Hex(Canon.canon(recArr)) else (since?.takeIf { it.isNotEmpty() } ?: "")
        val msg = "rcode-sync-v1\n$action\n$identity\n$pub\n$nonce\n$ts\n$hash"
        val sig = key.sign(msg) // UserNotAuthenticatedException bubbles up → "unlock to sync"
        val obj = JSONObject().put("identity", identity).put("device", pub).put("ts", ts).put("nonce", nonce).put("sig", sig)
        if (recArr != null) obj.put("records", recArr)
        if (action == "pull" && since != null) obj.put("since", since)
        val r = Http.post(base() + path, obj.toString(), 20_000)
        // Cloudflare answers a dead quick tunnel with 530/502/HTML 404: treat as unreachable.
        if (r.status in listOf(502, 503, 504, 530) || (r.status == 404 && r.json() !is JSONObject)) {
            throw java.io.IOException("ASSM live URL unreachable (HTTP ${r.status})")
        }
        when {
            r.status == 200 -> return r.obj()
            r.status == 403 -> throw SyncHttpError(403, r.obj().optString("error").ifBlank { "device is not a trusted or enrolled signer for this identity" })
            r.status == 409 -> throw SyncHttpError(409, "replayed sync nonce")
            r.status == 429 -> throw SyncHttpError(429, "rate limited (429); backing off")
            else -> throw SyncHttpError(r.status, r.error())
        }
    }
}
