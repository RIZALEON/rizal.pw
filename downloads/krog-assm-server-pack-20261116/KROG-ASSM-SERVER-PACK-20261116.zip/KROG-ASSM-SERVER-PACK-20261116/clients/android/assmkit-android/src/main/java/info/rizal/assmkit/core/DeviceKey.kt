package info.rizal.assmkit.core

import android.content.pm.PackageManager
import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyInfo
import android.security.keystore.KeyProperties
import android.security.keystore.StrongBoxUnavailableException
import android.security.keystore.UserNotAuthenticatedException
import android.util.Base64
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.Signature
import java.security.spec.ECGenParameterSpec

/**
 * Per-install P-256 keys in the Android Keystore (StrongBox when available, else TEE).
 * Private keys are non-exportable by construction; this class never reads, logs or exports them.
 *
 * - DEVICE key ("rcode_assm_device"): this install's ASSM identity. Signs the enroll request and
 *   every /v1/sync call. User-auth bound with a validity window (lock-screen unlock or biometric
 *   counts), so background sync works right after the phone is unlocked and asks again otherwise.
 * - APPROVER key ("rcode_assm_approver"): signs `device.enroll` seals when approving another device.
 *   Auth-per-use: every approval needs a fresh fingerprint/face/PIN (BiometricPrompt CryptoObject).
 *
 * Public key wire format matches WebCrypto exportKey('raw'): base64 of the 65-byte X9.63 point
 * (= last 65 bytes of the 91-byte SPKI). Signatures are base64 raw r||s (64 bytes).
 */
class KeystoreKey(private val alias: String, private val perUseAuth: Boolean) {

    data class Info(val strongBox: Boolean, val authBound: Boolean, val hardware: String)

    private val ks: KeyStore get() = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    fun exists(): Boolean = ks.containsAlias(alias)

    fun ensure(ctx: Context): Info {
        if (!exists()) generate(ctx)
        return info()
    }

    private fun generate(ctx: Context) {
        val hasStrongBox = ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_STRONGBOX_KEYSTORE)
        val attempts = buildList {
            if (hasStrongBox) add(true to true)
            add(false to true)
            add(false to false) // no secure lock screen: still non-exportable, just not auth-bound
        }
        var last: Throwable? = null
        for ((sb, auth) in attempts) {
            try {
                val b = KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN)
                    .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                    .setDigests(KeyProperties.DIGEST_SHA256)
                if (sb) b.setIsStrongBoxBacked(true)
                if (auth) {
                    b.setUserAuthenticationRequired(true)
                    b.setUserAuthenticationParameters(
                        if (perUseAuth) 0 else DEVICE_KEY_AUTH_SECONDS,
                        KeyProperties.AUTH_BIOMETRIC_STRONG or KeyProperties.AUTH_DEVICE_CREDENTIAL,
                    )
                    b.setInvalidatedByBiometricEnrollment(false)
                }
                val g = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
                g.initialize(b.build())
                g.generateKeyPair()
                return
            } catch (e: StrongBoxUnavailableException) {
                last = e
            } catch (e: Exception) {
                last = e
                runCatching { ks.deleteEntry(alias) }
            }
        }
        throw IllegalStateException("Could not create the $alias key: ${last?.javaClass?.simpleName}")
    }

    fun info(): Info {
        val pk = privateKey() ?: return Info(false, false, "none")
        return runCatching {
            val f = KeyFactory.getInstance(pk.algorithm, "AndroidKeyStore")
            val ki = f.getKeySpec(pk, KeyInfo::class.java)
            val level = if (Build.VERSION.SDK_INT >= 31) when (ki.securityLevel) {
                KeyProperties.SECURITY_LEVEL_STRONGBOX -> "StrongBox"
                KeyProperties.SECURITY_LEVEL_TRUSTED_ENVIRONMENT -> "TEE"
                KeyProperties.SECURITY_LEVEL_SOFTWARE -> "software"
                else -> "unknown"
            } else if (@Suppress("DEPRECATION") ki.isInsideSecureHardware) "TEE" else "software"
            Info(level == "StrongBox", ki.isUserAuthenticationRequired, level)
        }.getOrDefault(Info(false, false, "unknown"))
    }

    private fun privateKey(): PrivateKey? = runCatching { ks.getKey(alias, null) as? PrivateKey }.getOrNull()

    /** base64 raw 65-byte uncompressed point. Public data only. */
    fun publicKeyBase64(): String {
        val cert = ks.getCertificate(alias) ?: error("no key")
        val spki = cert.publicKey.encoded
        val raw = spki.copyOfRange(spki.size - 65, spki.size)
        require(raw[0] == 0x04.toByte()) { "unexpected public key format" }
        return Base64.encodeToString(raw, Base64.NO_WRAP)
    }

    /** A Signature ready for BiometricPrompt.CryptoObject (per-use auth keys). */
    fun signatureForPrompt(): Signature =
        Signature.getInstance("SHA256withECDSA").apply { initSign(privateKey() ?: error("no key")) }

    /** Signs with a time-bound key; throws [UserNotAuthenticatedException] when an unlock is needed. */
    @Throws(UserNotAuthenticatedException::class)
    fun sign(message: String): String {
        val s = Signature.getInstance("SHA256withECDSA")
        s.initSign(privateKey() ?: error("no key"))
        s.update(message.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(derToRaw(s.sign()), Base64.NO_WRAP)
    }

    companion object {
        /** Lock-screen unlock or biometric keeps the device key usable for this long. */
        const val DEVICE_KEY_AUTH_SECONDS = 6 * 60 * 60

        val device = KeystoreKey("${info.rizal.assmkit.AssmKitConfig.prefix}_assm_device", perUseAuth = false)
        val approver = KeystoreKey("${info.rizal.assmkit.AssmKitConfig.prefix}_assm_approver", perUseAuth = true)

        fun finish(sig: Signature, message: String): String {
            sig.update(message.toByteArray(Charsets.UTF_8))
            return Base64.encodeToString(derToRaw(sig.sign()), Base64.NO_WRAP)
        }

        /** ASN.1 DER ECDSA-Sig-Value → 64-byte r||s. */
        fun derToRaw(der: ByteArray): ByteArray {
            var i = 0
            require(der[i++] == 0x30.toByte())
            var len = der[i++].toInt() and 0xFF
            if (len and 0x80 != 0) i += (len and 0x7F)
            fun readInt(): ByteArray {
                require(der[i++] == 0x02.toByte())
                val l = der[i++].toInt() and 0xFF
                val v = der.copyOfRange(i, i + l); i += l
                return v
            }
            val r = BigInteger(1, readInt()); val s = BigInteger(1, readInt())
            return fixed(r) + fixed(s)
        }

        private fun fixed(n: BigInteger): ByteArray {
            val b = n.toByteArray()
            return when {
                b.size == 32 -> b
                b.size > 32 -> b.copyOfRange(b.size - 32, b.size)
                else -> ByteArray(32 - b.size) + b
            }
        }
    }
}
