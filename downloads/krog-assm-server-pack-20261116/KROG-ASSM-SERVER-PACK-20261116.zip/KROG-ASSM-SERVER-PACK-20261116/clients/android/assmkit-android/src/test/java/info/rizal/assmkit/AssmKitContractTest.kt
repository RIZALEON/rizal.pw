package info.rizal.assmkit

import info.rizal.assmkit.auth.AuthProviderKind
import info.rizal.assmkit.auth.Jwt
import info.rizal.assmkit.auth.Pkce
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AssmKitContractTest {
    @Test fun rcodePresetKeepsOriginalNames() {
        // Already-approved Moto key + prefs must keep working after the move into the module.
        assertEquals("rcode", AssmKitConfig.prefix)
        assertEquals("rcode", AssmKitConfig.urlScheme)
        assertEquals("ЯID-0001-3QQS", AssmKitConfig.defaultProfile)
        assertEquals("https://rizal.pw", AssmKitConfig.assmFallbackBaseUrl)
        assertEquals("/api/rsync/entries", AssmKitConfig.assmEnrollEntriesPath)
    }

    @Test fun pkceRfc7636Vector() {
        assertEquals("E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM", Pkce.challenge("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk"))
        assertTrue(Pkce.verifier().length in 43..128)
    }

    @Test fun providerRawValuesMatchSwift() {
        assertEquals(listOf("google", "apple", "password", "passkey", "microsoft", "assm"),
            AuthProviderKind.values().take(6).map { it.raw })
    }

    @Test fun placeholdersDimProvidersAndPasswordFlagIsOff() {
        assertTrue(AssmKitConfig.isPlaceholder(AssmKitConfig.googleWebClientId))
        assertTrue(AssmKitConfig.isPlaceholder(AssmKitConfig.microsoftClientId))
        assertTrue(AssmKitConfig.isPlaceholder(AssmKitConfig.appleServicesId))
        assertTrue(AssmKitConfig.isPlaceholder(AssmKitConfig.passkeyRpId))
        assertFalse(AssmKitConfig.assmPasswordEnabled)
    }

    @Test fun jwtClaimsDecode() {
        val payload = java.util.Base64.getUrlEncoder().withoutPadding().encodeToString("""{"sub":"abc","name":"R"}""".toByteArray())
        assertEquals("abc", Jwt.claims("x.$payload.y").optString("sub"))
    }
}
