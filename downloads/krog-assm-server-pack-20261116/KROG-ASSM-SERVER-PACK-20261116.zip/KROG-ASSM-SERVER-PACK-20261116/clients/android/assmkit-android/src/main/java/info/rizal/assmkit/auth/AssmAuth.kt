package info.rizal.assmkit.auth

import android.app.Activity
import info.rizal.assmkit.AssmKitConfig
import info.rizal.assmkit.core.Http
import info.rizal.assmkit.core.OwnerProfile
import info.rizal.assmkit.core.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Android counterpart of ASSMKit `AuthManager`'s sign-in half. Every provider goes through [complete]
 * and then [unifyOnOwnerIdentity]: the account always carries the owner ASSM identity (ЯID-0001-3QQS)
 * and the device-key session is the owner enrollment for this app's Keystore key, approved once by
 * Rizal from a trusted device. ASSMKit never approves or trusts a key itself.
 *
 * @param startOwnerEnrollment host hook: device-status check → device.request + 8-digit code/QR → approval → sync.
 */
class AssmAuth(
    private val prefs: Prefs,
    private val scope: CoroutineScope,
    private val startOwnerEnrollment: () -> Unit,
    private val markOwnerApproved: () -> Unit = {},
) {
    private val _busy = MutableStateFlow<AuthProviderKind?>(null)
    val busy: StateFlow<AuthProviderKind?> = _busy
    private val _error = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _error
    private val _account = MutableStateFlow(AssmAccount.parse(prefs.sp.getString(key("account"), null)))
    val account: StateFlow<AssmAccount?> = _account
    private val _show = MutableStateFlow(false)
    /** Host shows the sign-in screen while true (Swift `presentSignIn`). */
    val presentSignIn: StateFlow<Boolean> = _show
    /** Server session token, memory only (no account server exists yet; nothing secret is persisted). */
    @Volatile private var accessToken: String? = null
    private var job: Job? = null

    private fun key(k: String) = "${AssmKitConfig.prefix}.assmkit.$k"
    private val device get() = DeviceInfo.json(prefs.deviceId)

    fun present(show: Boolean = true) { _show.value = show; if (show) _error.value = null }

    fun isConfigured(kind: AuthProviderKind): Boolean = when (kind) {
        AuthProviderKind.GOOGLE -> GoogleProvider.isConfigured
        AuthProviderKind.APPLE -> AppleWebProvider.isConfigured
        AuthProviderKind.PASSWORD -> EmailProvider.isConfigured
        AuthProviderKind.PASSKEY -> PasskeyProvider.isConfigured
        AuthProviderKind.MICROSOFT -> MicrosoftProvider.isConfigured
        AuthProviderKind.ASSM -> true
        AuthProviderKind.ASSM_PASSWORD -> AssmPasswordClient.isEnabled
        AuthProviderKind.DEVICE_LINK -> DeviceLinkProvider.isConfigured
    }

    fun signIn(kind: AuthProviderKind, mode: AuthMode, activity: Activity) = run(kind) {
        when (kind) {
            AuthProviderKind.GOOGLE -> GoogleProvider.signIn(activity)
            AuthProviderKind.APPLE -> AppleWebProvider.signIn(activity)
            AuthProviderKind.MICROSOFT -> MicrosoftProvider.signIn(activity)
            AuthProviderKind.PASSKEY -> PasskeyProvider.signIn(activity, mode, device)
            // ASSM approve-code / QR: the owner enrollment *is* the sign-in; approval marks it done.
            AuthProviderKind.ASSM -> ProviderCredential(AuthProviderKind.ASSM, OwnerProfile.PROFILE_ID, displayName = OwnerProfile.HANDLE)
            else -> throw AuthException("Use the form for ${kind.displayName}.")
        }
    }

    fun signInWithPassword(username: String, password: String, mode: AuthMode) =
        run(AuthProviderKind.PASSWORD) { EmailProvider.signIn(username, password, mode, device) }

    /** ASSM username + password (off by default). On success the server made this device key ACTIVE; the
     *  owner enrollment hook then sees it in device-status and starts sync with no approve code. */
    fun signInWithAssmPassword(username: String, password: CharArray, deviceName: String) =
        run(AuthProviderKind.ASSM_PASSWORD) { AssmPasswordClient.signIn(prefs, username, password, deviceName) }

    fun claimDeviceLink(code: String) = run(AuthProviderKind.DEVICE_LINK) { DeviceLinkProvider.claim(code, device) }

    fun cancel() { job?.cancel(); OAuthRedirects.cancel(); _busy.value = null }

    private fun run(kind: AuthProviderKind, body: suspend () -> ProviderCredential) {
        if (AssmKitConfig.authPreview) { _error.value = "Preview mode: sign-in is disabled."; return }
        job?.cancel()
        _busy.value = kind; _error.value = null
        job = scope.launch {
            try {
                complete(body())
                // ASSM keeps the screen up to show the 8-digit code + QR until approval closes it.
                if (kind != AuthProviderKind.ASSM) _show.value = false
            } catch (e: AuthCancelled) {
            } catch (e: kotlinx.coroutines.CancellationException) { throw e
            } catch (e: Exception) {
                _error.value = e.message ?: e.javaClass.simpleName
            } finally { _busy.value = null }
        }
    }

    /** Exchange the provider proof with the RCODE server when one is set, then save and unify. */
    suspend fun complete(cred: ProviderCredential) {
        var session = cred.session
        val linking = _account.value != null && cred.provider != AuthProviderKind.DEVICE_LINK
        if (session == null && cred.provider != AuthProviderKind.ASSM && cred.provider != AuthProviderKind.ASSM_PASSWORD && !AssmKitConfig.isPlaceholder(AssmKitConfig.serverUrl)) {
            val body = JSONObject().put("subject", cred.subject).put("proof", JSONObject(cred.proof)).put("device", device).put("link", linking)
            val r = Http.postAuthed(AssmKitConfig.serverUrl.trimEnd('/') + "/v1/auth/" + cred.provider.raw, body.toString(), if (linking) accessToken else null)
            if (!r.ok) throw AuthException(r.error())
            session = r.obj()
        }
        val now = System.currentTimeMillis()
        val identity = LinkedIdentity(cred.provider.raw, cred.subject, cred.email, cred.displayName, now, verified = session != null)
        val acct = if (session != null) {
            accessToken = session.optString("access_token").ifBlank { null }
            val sa = session.optJSONObject("account") ?: JSONObject()
            val ids = sa.optJSONArray("identities")?.let { a -> (0 until a.length()).map { LinkedIdentity.parse(a.getJSONObject(it)) } } ?: emptyList()
            AssmAccount(sa.optString("id", "server"), sa.optString("display_name").ifBlank { cred.displayName ?: cred.email ?: "${AssmKitConfig.appName} user" },
                if (cred.provider == AuthProviderKind.DEVICE_LINK || ids.any { it.id == identity.id }) ids else ids + identity)
        } else _account.value?.let { a -> a.copy(identities = a.identities.filter { it.id != identity.id } + identity) }
            ?: AssmAccount("local-" + java.util.UUID.randomUUID().toString(), cred.displayName ?: cred.email ?: OwnerProfile.DISPLAY_NAME, listOf(identity))
        save(acct)
        unifyOnOwnerIdentity(cred)
    }

    /** Same rule as Swift: add the owner ASSM identity, then start (or mark) the owner device-key enrollment. */
    fun unifyOnOwnerIdentity(cred: ProviderCredential) {
        val a = _account.value ?: return
        if (a.identities.none { it.provider == "assm" && it.subject == OwnerProfile.PROFILE_ID }) {
            save(a.copy(identities = a.identities + LinkedIdentity("assm", OwnerProfile.PROFILE_ID, null, OwnerProfile.HANDLE, System.currentTimeMillis(), false)))
        }
        prefs.ownerOptOut = false
        startOwnerEnrollment()
    }

    /** Owner device key approved: mark the ASSM identity verified. */
    fun onOwnerApproved() {
        val a = _account.value ?: AssmAccount("local-owner-${OwnerProfile.PROFILE_ID}", OwnerProfile.DISPLAY_NAME, emptyList())
        save(a.copy(identities = a.identities.filter { !(it.provider == "assm" && it.subject == OwnerProfile.PROFILE_ID) } +
            LinkedIdentity("assm", OwnerProfile.PROFILE_ID, null, OwnerProfile.HANDLE, System.currentTimeMillis(), true)))
        markOwnerApproved()
    }

    fun signOut() { accessToken = null; prefs.sp.edit().remove(key("account")).apply(); _account.value = null }

    private fun save(a: AssmAccount) { prefs.sp.edit().putString(key("account"), a.json().toString()).apply(); _account.value = a }
}
