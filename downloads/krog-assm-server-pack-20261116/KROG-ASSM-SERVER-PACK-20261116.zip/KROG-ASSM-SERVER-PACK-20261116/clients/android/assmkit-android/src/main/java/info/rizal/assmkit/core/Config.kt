package info.rizal.assmkit.core

import android.content.Context
import android.content.SharedPreferences
import info.rizal.assmkit.AssmKitConfig
import java.net.URL

/** Mirrors RCODE/Auth/RCODEAuthConfig.plist + OwnerProfile.plist. Public values only. */
object OwnerProfile {
    const val PROFILE_ID = "ЯID-0001-3QQS"
    const val HANDLE = "@chaserizal"
    const val DISPLAY_NAME = "Rizal"
}

class Prefs(ctx: Context) {
    val sp: SharedPreferences = ctx.getSharedPreferences(AssmKitConfig.prefix, Context.MODE_PRIVATE)

    /** Same keys as the Apple app's UserDefaults where one exists. */
    var assmBaseOverride: String
        get() = sp.getString("${AssmKitConfig.prefix}.assmBaseURL", "") ?: ""
        set(v) = sp.edit().putString("${AssmKitConfig.prefix}.assmBaseURL", v.trim()).apply()
    /** Live URL learned from the rizal.pw fallback feed's `live` field (quick-tunnel URLs change). */
    var assmLearnedLive: String
        get() = sp.getString("${AssmKitConfig.prefix}.assmLearnedLive", "") ?: ""
        set(v) = sp.edit().putString("${AssmKitConfig.prefix}.assmLearnedLive", v.trim()).apply()
    var modelServer: String
        get() = sp.getString("${AssmKitConfig.prefix}.modelServer", AssmKitConfig.defaultModelServer) ?: AssmKitConfig.defaultModelServer
        set(v) = sp.edit().putString("${AssmKitConfig.prefix}.modelServer", v.trim()).apply()
    var modelDownloadUrl: String
        get() = sp.getString("${AssmKitConfig.prefix}.modelDownloadURL", "") ?: ""
        set(v) = sp.edit().putString("${AssmKitConfig.prefix}.modelDownloadURL", v.trim()).apply()
    var approveProfile: String
        get() = sp.getString("${AssmKitConfig.prefix}.assmApproveProfile", "")?.ifBlank { null } ?: AssmKitConfig.defaultProfile
        set(v) = sp.edit().putString("${AssmKitConfig.prefix}.assmApproveProfile", v).apply()
    var ownerApproved: Boolean
        get() = sp.getBoolean("${AssmKitConfig.prefix}.ownerDeviceApproved", false)
        set(v) = sp.edit().putBoolean("${AssmKitConfig.prefix}.ownerDeviceApproved", v).apply()
    var ownerOptOut: Boolean
        get() = sp.getBoolean("${AssmKitConfig.prefix}.ownerOptOut", false)
        set(v) = sp.edit().putBoolean("${AssmKitConfig.prefix}.ownerOptOut", v).apply()
    var syncCursor: String?
        get() = sp.getString("${AssmKitConfig.prefix}.sync.cursor", null)
        set(v) = sp.edit().apply { if (v == null) remove("${AssmKitConfig.prefix}.sync.cursor") else putString("${AssmKitConfig.prefix}.sync.cursor", v) }.apply()
    var selectedChat: String?
        get() = sp.getString("${AssmKitConfig.prefix}.selectedChat", null)
        set(v) = sp.edit().putString("${AssmKitConfig.prefix}.selectedChat", v).apply()

    /** Random per-install id (`device_id` on sync records). */
    val deviceId: String
        get() {
            sp.getString("${AssmKitConfig.prefix}.deviceId", null)?.let { return it }
            val id = java.util.UUID.randomUUID().toString().lowercase()
            sp.edit().putString("${AssmKitConfig.prefix}.deviceId", id).apply()
            return id
        }

    fun liveBase(): String {
        val env = assmBaseOverride
        if (env.isNotBlank() && Net.isValidBase(env)) return env.trimEnd('/')
        val learned = assmLearnedLive
        if (learned.isNotBlank() && Net.isValidBase(learned)) return learned.trimEnd('/')
        return AssmKitConfig.assmBaseUrl
    }
    fun fallbackBase(): String = AssmKitConfig.assmFallbackBaseUrl
}

object Net {
    /** HTTPS only, plain http only on loopback (same rule as BackendClient.validated on Apple). */
    fun isValidBase(s: String): Boolean = runCatching {
        val u = URL(s.trim())
        u.protocol == "https" || (u.protocol == "http" && (u.host == "127.0.0.1" || u.host == "localhost" || u.host == "::1"))
    }.getOrDefault(false)

    /** Strict RFC 3986 unreserved-only query encoding so base64 `+ / =` survive (the iOS banner bug). */
    fun queryEncode(v: String): String {
        val sb = StringBuilder()
        for (b in v.toByteArray(Charsets.UTF_8)) {
            val c = b.toInt() and 0xFF
            val ch = c.toChar()
            if (ch in 'A'..'Z' || ch in 'a'..'z' || ch in '0'..'9' || ch == '-' || ch == '.' || ch == '_' || ch == '~') sb.append(ch)
            else sb.append('%').append("%02X".format(c))
        }
        return sb.toString()
    }
}
