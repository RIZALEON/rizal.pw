package info.rizal.assmkit.sync

import android.security.keystore.UserNotAuthenticatedException
import info.rizal.assmkit.core.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.Date

data class SyncState(
    val serviceName: String = "This device only",
    val lastSync: Date? = null,
    val lastError: String? = null,
    val pending: Int = 0,
    val needsUnlock: Boolean = false,
)

/**
 * Port of SyncCoordinator.swift: batched outbox (25 per push), exponential backoff (2 s → 60 s,
 * also on 429), newer edits stay queued, last-writer-wins merge on (updated_at, device_id).
 */
class SyncCoordinator(private val scope: CoroutineScope, private val prefs: Prefs) {
    private val _state = MutableStateFlow(SyncState())
    val state: StateFlow<SyncState> = _state
    private val _incoming = MutableSharedFlow<List<SyncRecord>>(extraBufferCapacity = 16)
    val incoming: SharedFlow<List<SyncRecord>> = _incoming

    private var service: AssmSyncService? = null
    private val local = HashMap<String, SyncRecord>()
    private val outbox = LinkedHashMap<String, SyncRecord>()
    private val lock = Mutex()
    private var flushJob: Job? = null
    private var backoff = 2_000L

    companion object { const val PUSH_BATCH = 25 }

    /** First pull after configure (each app process) is a full pull, so nothing is skipped by a stale cursor. */
    private var didFullPull = false

    fun configure(svc: AssmSyncService?) {
        didFullPull = false
        service = svc
        _state.value = _state.value.copy(serviceName = if (svc != null) "ASSM sync" else "This device only")
        if (svc != null) scheduleFlush(400)
    }

    val isLive get() = service != null

    fun upsert(r: SyncRecord) {
        scope.launch {
            lock.withLock {
                mergeLocked(listOf(r), emit = false)
                outbox[r.id] = r
                _state.value = _state.value.copy(pending = outbox.size)
            }
            scheduleFlush(400)
        }
    }

    private fun scheduleFlush(afterMs: Long) {
        if (flushJob?.isActive == true) return
        flushJob = scope.launch { delay(afterMs); flushOutbox() }
    }

    suspend fun flushOutbox() {
        val svc = service ?: return
        val batch = lock.withLock { outbox.values.sortedBy { it.updatedAt.time }.take(PUSH_BATCH) }
        if (batch.isEmpty()) return
        try {
            svc.push(batch)
            lock.withLock {
                for (r in batch) if (outbox[r.id] == r) outbox.remove(r.id) // newer edits stay queued
                _state.value = _state.value.copy(pending = outbox.size, lastError = null, needsUnlock = false)
            }
            backoff = 2_000
            flushJob = null
            if (lock.withLock { outbox.isNotEmpty() }) scheduleFlush(1_100)
        } catch (e: UserNotAuthenticatedException) {
            flushJob = null
            _state.value = _state.value.copy(needsUnlock = true, lastError = "Unlock the phone to sync")
        } catch (e: Exception) {
            flushJob = null
            _state.value = _state.value.copy(lastError = e.message ?: e.javaClass.simpleName)
            val wait = if (e is SyncHttpError && e.status == 429) maxOf(backoff, 10_000) else backoff
            scheduleFlush(wait)
            backoff = minOf(backoff * 2, 60_000)
        }
    }

    suspend fun syncNow() {
        val svc = service ?: return
        try {
            val full = !didFullPull
            val (recs, cursor) = svc.pull(if (full) null else prefs.syncCursor)
            lock.withLock { mergeLocked(recs, emit = true) }
            if (cursor != null) prefs.syncCursor = cursor
            if (full) didFullPull = true
            _state.value = _state.value.copy(lastSync = Date(), lastError = null, needsUnlock = false)
            if (lock.withLock { outbox.isNotEmpty() }) scheduleFlush(400)
        } catch (e: UserNotAuthenticatedException) {
            _state.value = _state.value.copy(needsUnlock = true, lastError = "Unlock the phone to sync")
        } catch (e: Exception) {
            _state.value = _state.value.copy(lastError = e.message ?: e.javaClass.simpleName)
        }
    }

    /** Pull loop while the app is in the foreground (pull is a POST; the server allows 10 POST/min/IP). */
    fun startPolling(intervalMs: Long = 30_000): Job = scope.launch {
        while (true) {
            syncNow()
            delay(if (_state.value.lastError?.contains("429") == true) 60_000 else intervalMs)
        }
    }

    private suspend fun mergeLocked(records: List<SyncRecord>, emit: Boolean) {
        val changed = ArrayList<SyncRecord>()
        for (r in records) {
            val old = local[r.id]
            if (old != null && !r.newerThan(old)) continue
            local[r.id] = r
            changed.add(r)
        }
        if (emit && changed.isNotEmpty()) _incoming.emit(changed)
    }
}
