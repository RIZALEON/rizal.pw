package info.rizal.assmkit

/**
 * Per-host-app config for ASSMKit-Android (mirrors Swift `ASSMKitConfig` + `RCODEAuthConfig.plist`).
 * Public values only, no secrets. The host app sets this once in `Application.onCreate`, before
 * anything touches the Keystore or prefs. The `.rcode` defaults reproduce RCODE's original prefs keys,
 * prefs file and Keystore aliases byte-for-byte, so already-approved keys keep working.
 */
object AssmKitConfig {
    // Identity of the host app
    var appName = "RCODE"
    var prefix = "rcode"                 // prefs file + "<prefix>." keys, "<prefix>_assm_device" Keystore alias
    var urlScheme = "rcode"              // QR payload: <scheme>://assm-approve?...
    var packageName = "info.rizal.rcode"
    var appVersion = "0.1.0-android"

    // ASSM-RSYNC (works now)
    var assmBaseUrl = "https://ASSM_SERVER_URL"
    var assmFallbackBaseUrl = "https://rizal.pw"   // live URL is rediscovered from <fallback>/api/rsync/entries
    var assmEnrollEntriesPath = "/api/rsync/entries"
    var defaultProfile = "ЯID-0001-3QQS"
    var defaultModelServer = "http://127.0.0.1:4991/v1"

    // Optional RCODE account server (email/password, passkeys, device link, provider token exchange).
    // Placeholder until Rizal runs one; without it providers sign in locally and unify on the owner ASSM identity.
    var serverUrl = "REPLACE_WITH_RCODE_SERVER_URL"

    // Provider registrations (Rizal's developer accounts). Placeholders dim the buttons.
    var googleWebClientId = "REPLACE_WITH_GOOGLE_WEB_CLIENT_ID.apps.googleusercontent.com"
    var microsoftClientId = "REPLACE_WITH_ENTRA_APPLICATION_CLIENT_ID"
    var microsoftTenant = "common"
    var oauthRedirectUri = "info.rizal.rcode:/oauth2redirect"          // Custom Tabs return (Microsoft)
    var appleServicesId = "REPLACE_WITH_APPLE_SERVICES_ID"             // Sign in with Apple for the web (Services ID)
    var appleWebReturnUrl = "https://rizal.pw/auth/apple/android"       // https relay page (Apple requires https)
    var passkeyRpId = "REPLACE_WITH_RP_DOMAIN"                          // e.g. rizal.pw, needs /.well-known/assetlinks.json

    /** ASSM username + password. OFF: no server verifies an ASSM password today (rizal.pw only unlocks
     *  vault.json in the browser). Stays a stub until Rizal picks how the password is checked. */
    var assmPasswordEnabled = false

    /** Screenshot / preview: show the sign-in screen without Keystore, enrollment or sync. */
    var authPreview = false

    fun isPlaceholder(v: String) = v.isBlank() || v.startsWith("REPLACE_WITH")
}
