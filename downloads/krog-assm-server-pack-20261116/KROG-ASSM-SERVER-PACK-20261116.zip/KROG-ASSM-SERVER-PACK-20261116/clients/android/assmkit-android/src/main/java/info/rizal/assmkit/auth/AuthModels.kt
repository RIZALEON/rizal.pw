package info.rizal.assmkit.auth

import android.os.Build
import info.rizal.assmkit.AssmKitConfig
import org.json.JSONArray
import org.json.JSONObject

/** Same raw values as Swift `AuthProviderKind` (used in `/v1/auth/<provider>`). */
enum class AuthProviderKind(val raw: String, val displayName: String) {
    GOOGLE("google", "Google"), APPLE("apple", "Apple"), PASSWORD("password", "Email"),
    PASSKEY("passkey", "Passkey"), MICROSOFT("microsoft", "Microsoft"), ASSM("assm", "ASSM"),
    ASSM_PASSWORD("assm-password", "ASSM password"), DEVICE_LINK("device-link", "Device link"),
}

enum class AuthMode { SIGN_IN, SIGN_UP }

class AuthException(msg: String) : Exception(msg)
class AuthCancelled : Exception("cancelled")

data class LinkedIdentity(
    val provider: String, val subject: String, val email: String?, val displayName: String?,
    val linkedAt: Long, val verified: Boolean,
) {
    val id get() = "$provider:$subject"
    fun json(): JSONObject = JSONObject().put("provider", provider).put("subject", subject).put("email", email ?: JSONObject.NULL)
        .put("display_name", displayName ?: JSONObject.NULL).put("linked_at", linkedAt).put("verified", verified)
    companion object {
        fun parse(o: JSONObject) = LinkedIdentity(o.optString("provider"), o.optString("subject"),
            o.optString("email").ifBlank { null }?.takeIf { it != "null" }, o.optString("display_name").ifBlank { null }?.takeIf { it != "null" },
            o.optLong("linked_at"), o.optBoolean("verified"))
    }
}

/** Public account record (no tokens, no keys). Stored in the host app's prefs. */
data class AssmAccount(val accountId: String, val displayName: String, val identities: List<LinkedIdentity>) {
    fun json(): JSONObject = JSONObject().put("account_id", accountId).put("display_name", displayName)
        .put("identities", JSONArray(identities.map { it.json() }))
    companion object {
        fun parse(s: String?): AssmAccount? = runCatching {
            val o = JSONObject(s ?: return null)
            val ids = o.optJSONArray("identities") ?: JSONArray()
            AssmAccount(o.getString("account_id"), o.optString("display_name"), (0 until ids.length()).map { LinkedIdentity.parse(ids.getJSONObject(it)) })
        }.getOrNull()
    }
}

/** What a provider hands to [AssmAuth.complete]. `proof` goes to the RCODE server, never logged. */
data class ProviderCredential(
    val provider: AuthProviderKind, val subject: String, val email: String? = null, val displayName: String? = null,
    val proof: Map<String, String> = emptyMap(), val session: JSONObject? = null,
)

/** Mirrors Swift `DeviceInfo` (snake_case on the wire). */
object DeviceInfo {
    fun json(deviceId: String): JSONObject = JSONObject().put("id", deviceId)
        .put("name", "${AssmKitConfig.appName} ${Build.MODEL ?: "Android"}")
        .put("os", "Android ${Build.VERSION.RELEASE}").put("model", Build.MODEL ?: "Android")
        .put("app_version", AssmKitConfig.appVersion)
}
