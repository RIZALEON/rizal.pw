package info.rizal.assmkit.ui

import android.app.Activity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import info.rizal.assmkit.AssmKitConfig
import info.rizal.assmkit.auth.AssmAuth
import info.rizal.assmkit.auth.AuthMode
import info.rizal.assmkit.auth.AuthProviderKind

object AssmColors {
    val background = Color(0xFF0B0B0E)
    val userBubble = Color(0xFF8A5CD6)
    val glassCard = Color(0xB33A3A3E)
    val glassBorder = Color(0x1FFFFFFF)
    val accent = Color(0xFFC17BF2)
    val code = Color(0xFFB388FF)
    val error = Color(0xFFFF8A80)
}

/** Pending ASSM owner enrollment, shown in the card (8-digit code + QR). */
data class PendingAssm(val shortCode: String, val qrPayload: String?)

/**
 * Same screen and order as ASSMKit `SignInView`: Google, Apple, email (expands), passkey (highlighted),
 * Microsoft, ASSM; pending code + QR; error; link code; Approve a device; sign up / sign in.
 * The ASSM username + password form only appears when [AssmKitConfig.assmPasswordEnabled] (off).
 */
@Composable
fun SignInScreen(
    auth: AssmAuth,
    pending: PendingAssm?,
    onApproveDevice: () -> Unit,
    onNotNow: () -> Unit,
    onCancelPending: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val busy by auth.busy.collectAsState()
    val error by auth.lastError.collectAsState()
    var mode by rememberSaveable { mutableStateOf(AuthMode.SIGN_IN) }
    var showEmail by rememberSaveable { mutableStateOf(false) }
    var showAssmPw by rememberSaveable { mutableStateOf(false) }
    var showLink by rememberSaveable { mutableStateOf(false) }
    var user by rememberSaveable { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var linkCode by rememberSaveable { mutableStateOf("") }
    val activity = LocalContext.current as? Activity

    fun go(kind: AuthProviderKind) { activity?.let { auth.signIn(kind, mode, it) } }

    Box(modifier.fillMaxSize().background(AssmColors.background)
        .background(Brush.radialGradient(listOf(AssmColors.userBubble.copy(alpha = 0.35f), Color.Transparent), radius = 1400f)),
        contentAlignment = Alignment.TopCenter) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().navigationBarsPadding().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth()) {
                Spacer(Modifier.weight(1f))
                Text("Not now", color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp, modifier = Modifier.clickable(onClick = onNotNow).padding(8.dp))
            }
            Column(Modifier.widthIn(max = 420.dp).fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(AssmColors.glassCard)
                .border(1.dp, AssmColors.glassBorder, RoundedCornerShape(28.dp)).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(AssmColors.userBubble), contentAlignment = Alignment.Center) {
                    Text("R", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                }
                Text(if (mode == AuthMode.SIGN_IN) "Welcome back" else "Create your ${AssmKitConfig.appName} account",
                    color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                Text("One account on your Mac, iPhone, iPad and Android, synced.", color = Color.White.copy(alpha = 0.6f),
                    fontSize = 14.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(2.dp))

                Pill("Continue with Google", "G", busy == AuthProviderKind.GOOGLE, !auth.isConfigured(AuthProviderKind.GOOGLE)) { go(AuthProviderKind.GOOGLE) }
                Pill("Continue with Apple", "A", busy == AuthProviderKind.APPLE, !auth.isConfigured(AuthProviderKind.APPLE)) { go(AuthProviderKind.APPLE) }
                Pill("Continue with email", "✉", busy == AuthProviderKind.PASSWORD && showEmail, false) { showEmail = !showEmail }
                AnimatedVisibility(showEmail) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Field(user, { user = it }, "Email or username", KeyboardType.Email)
                        Field(pass, { pass = it }, "Password", KeyboardType.Password, secret = true)
                        Pill(if (mode == AuthMode.SIGN_UP) "Create account" else "Sign in", "›", busy == AuthProviderKind.PASSWORD,
                            !auth.isConfigured(AuthProviderKind.PASSWORD), highlighted = true) {
                            val p = pass; pass = ""; auth.signInWithPassword(user, p, mode)
                        }
                    }
                }
                Pill("Continue with passkey", "⚿", busy == AuthProviderKind.PASSKEY, !auth.isConfigured(AuthProviderKind.PASSKEY), highlighted = true) { go(AuthProviderKind.PASSKEY) }
                Pill("Continue with Microsoft", "▦", busy == AuthProviderKind.MICROSOFT, !auth.isConfigured(AuthProviderKind.MICROSOFT)) { go(AuthProviderKind.MICROSOFT) }
                Pill("Continue with ASSM", "Я", busy == AuthProviderKind.ASSM, false) { go(AuthProviderKind.ASSM) }

                if (AssmKitConfig.assmPasswordEnabled) {
                    Text(if (showAssmPw) "Hide ASSM username + password" else "ASSM username + password", color = AssmColors.accent,
                        fontSize = 13.sp, modifier = Modifier.clickable { showAssmPw = !showAssmPw })
                    AnimatedVisibility(showAssmPw) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Field(user, { user = it }, "ЯID or @handle", KeyboardType.Text)
                            Field(pass, { pass = it }, "ASSM password", KeyboardType.Password, secret = true)
                            Pill("Sign in with ASSM password", "Я", busy == AuthProviderKind.ASSM_PASSWORD, false, highlighted = true) {
                                val p = pass.toCharArray(); pass = ""
                                auth.signInWithAssmPassword(user, p, "${AssmKitConfig.appName} " + (android.os.Build.MODEL ?: "Android"))
                            }
                        }
                    }
                }

                pending?.let { p ->
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.05f)).padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Approve on a trusted ASSM device", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(p.shortCode, color = AssmColors.code, fontSize = 28.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        p.qrPayload?.let { q -> Image(Qr.bitmap(q), "Approve QR", Modifier.size(180.dp).clip(RoundedCornerShape(8.dp))) }
                        Text("rizal.pw › ЯLOGIN › Other options › approve from another device", color = Color.White.copy(alpha = 0.55f),
                            fontSize = 11.sp, textAlign = TextAlign.Center)
                        Text("Cancel", color = Color.White, fontSize = 13.sp, modifier = Modifier.clickable(onClick = onCancelPending))
                    }
                }
                error?.let { Text(it, color = AssmColors.error, fontSize = 13.sp, textAlign = TextAlign.Center) }

                Text((if (showLink) "▾ " else "▸ ") + "Have a link code from another device?", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp,
                    modifier = Modifier.clickable { showLink = !showLink }.padding(top = 4.dp))
                AnimatedVisibility(showLink) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.weight(1f)) { Field(linkCode, { linkCode = it }, "ABC-123-XYZ", KeyboardType.Ascii) }
                        Text("Link", color = if (linkCode.length >= 4) AssmColors.accent else AssmColors.accent.copy(alpha = 0.4f),
                            fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable(enabled = linkCode.length >= 4) { auth.claimDeviceLink(linkCode) }.padding(12.dp))
                    }
                }
                Text("Approve a device", color = AssmColors.accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable(onClick = onApproveDevice))
                Row {
                    Text(if (mode == AuthMode.SIGN_IN) "Don't have an account? " else "Already have an account? ", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
                    Text(if (mode == AuthMode.SIGN_IN) "Sign up" else "Sign in", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable { mode = if (mode == AuthMode.SIGN_IN) AuthMode.SIGN_UP else AuthMode.SIGN_IN })
                }
            }
            Text("Not now. Keep using ${AssmKitConfig.appName} offline", color = Color.White.copy(alpha = 0.55f), fontSize = 13.sp,
                modifier = Modifier.clickable(onClick = onNotNow).padding(16.dp))
        }
    }
}

@Composable
private fun Pill(title: String, icon: String, loading: Boolean, dimmed: Boolean, highlighted: Boolean = false, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(50.dp).clip(CircleShape)
        .background(if (highlighted) AssmColors.userBubble else Color.White.copy(alpha = 0.08f))
        .border(1.dp, if (highlighted) Color.Transparent else AssmColors.glassBorder, CircleShape)
        .clickable(enabled = !loading, onClick = onClick).alpha(if (dimmed) 0.45f else 1f).padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) {
            if (loading) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
            else Text(icon, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
        Spacer(Modifier.size(24.dp))
    }
}

@Composable
private fun Field(value: String, onChange: (String) -> Unit, label: String, type: KeyboardType, secret: Boolean = false) {
    OutlinedTextField(value, onChange, placeholder = { Text(label, color = Color.White.copy(alpha = 0.45f)) }, singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = type, autoCorrectEnabled = false),
        shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White,
            focusedBorderColor = AssmColors.accent, unfocusedBorderColor = AssmColors.glassBorder, cursorColor = Color.White,
            focusedContainerColor = Color.White.copy(alpha = 0.06f), unfocusedContainerColor = Color.White.copy(alpha = 0.06f)))
}
