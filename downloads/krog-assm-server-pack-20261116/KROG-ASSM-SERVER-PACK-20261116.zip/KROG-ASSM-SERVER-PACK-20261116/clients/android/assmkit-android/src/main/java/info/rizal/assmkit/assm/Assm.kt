package info.rizal.assmkit.assm

import android.util.Base64
import info.rizal.assmkit.core.Canon
import info.rizal.assmkit.core.Http
import info.rizal.assmkit.core.Iso
import info.rizal.assmkit.core.KeystoreKey
import info.rizal.assmkit.core.Net
import info.rizal.assmkit.core.Prefs
import org.json.JSONObject
import java.security.SecureRandom

/** `t:"device.request"` from rsync-core.js, field-for-field (ASSMEnrollRequest.swift). */
data class EnrollRequest(
    val device: String, val nonce: String, val reqTs: String, val reqSig: String,
    val deviceName: String, val shortCode: String,
) {
    fun body(): JSONObject = JSONObject()
        .put("t", "device.request").put("device", device).put("nonce", nonce)
        .put("req_ts", reqTs).put("req_sig", reqSig).put("device_name", deviceName)

    val qrPayload: String
        get() = "${info.rizal.assmkit.AssmKitConfig.urlScheme}://assm-approve?device=${Net.queryEncode(device)}&nonce=${Net.queryEncode(nonce)}" +
            "&ts=${Net.queryEncode(reqTs)}&sig=${Net.queryEncode(reqSig)}&name=${Net.queryEncode(deviceName)}"

    companion object {
        /** Signs with the device key. Throws UserNotAuthenticatedException if an unlock is needed. */
        fun make(deviceName: String): EnrollRequest {
            val key = KeystoreKey.device
            val pub = key.publicKeyBase64()
            val nonce = Assm.nonce()
            val ts = Iso.js()
            val sig = key.sign("rsync-enroll-v1\n$pub\n$nonce\n$ts")
            return EnrollRequest(pub, nonce, ts, sig, deviceName, Assm.shortCode(pub, nonce))
        }
    }
}

data class DeviceStatus(
    val trusted: Boolean, val enrolled: Boolean, val pending: Boolean,
    val status: String, val name: String?, val profile: String?, val code: String?,
) {
    val isApproved get() = trusted || enrolled
}

/** A pending request from GET /api/rsync/request/<code>. */
data class PendingRequest(
    val code: String, val status: String, val device: String, val nonce: String,
    val reqTs: String, val reqSig: String, val deviceName: String, val profile: String?, val platform: String?,
) {
    val isPending get() = status == "pending"
    val isApproved get() = status == "approved"

    companion object {
        fun parse(o: JSONObject): PendingRequest? {
            fun s(vararg k: String) = k.firstNotNullOfOrNull { o.optString(it).ifBlank { null } }
            val device = s("device") ?: return null
            val nonce = s("nonce") ?: return null
            val ts = s("req_ts", "reqTs") ?: return null
            val sig = s("req_sig", "reqSig") ?: return null
            return PendingRequest(s("code") ?: Assm.shortCode(device, nonce), s("status") ?: "pending",
                device, nonce, ts, sig, s("device_name", "deviceName") ?: "device", s("profile"), s("platform", "os"))
        }
    }
}

object Assm {
    private val rng = SecureRandom()

    /** 12 random bytes, base64 without + / = (rsync-core.js). */
    fun nonce(): String {
        val b = ByteArray(12); rng.nextBytes(b)
        return java.util.Base64.getEncoder().encodeToString(b).filter { it != '+' && it != '/' && it != '=' }
    }

    /** sha256(device + "\n" + nonce) → first 10 hex → mod 1e8 → "XXXX-XXXX". */
    fun shortCode(device: String, nonce: String): String {
        val hex = Canon.sha256Hex("$device\n$nonce")
        val n = hex.take(10).toLong(16) % 100_000_000L
        val s = "%08d".format(n)
        return s.take(4) + "-" + s.takeLast(4)
    }

    /** Accepts 8 digits, XXXX-XXXX, or an rcode://assm-approve?... payload. */
    fun normalizeCode(raw: String): String? {
        val t = raw.trim()
        if (t.startsWith(info.rizal.assmkit.AssmKitConfig.urlScheme + "://")) {
            val q = android.net.Uri.parse(t)
            val d = q.getQueryParameter("device"); val n = q.getQueryParameter("nonce")
            if (d != null && n != null) return shortCode(d, n)
        }
        val digits = t.filter { it.isDigit() }
        if (digits.length != 8) return null
        return digits.take(4) + "-" + digits.takeLast(4)
    }

    // ---- seal (ASSMRsyncSeal.swift) ----
    const val SCOPE = "yaseed.mint"
    const val PREFIX = "yaseed-artifact-v1\n$SCOPE\n"
    private val LOCAL = setOf("seq", "prev", "hash", "cid", "rgen", "_src", "_rx", "cosig")

    fun body(entry: JSONObject): JSONObject {
        val o = JSONObject()
        for (k in entry.keys()) if (k !in LOCAL && !entry.isNull(k)) o.put(k, entry.get(k))
        return o
    }

    fun cid(entry: JSONObject): String = Canon.sha256Hex(Canon.canon(body(entry)))

    /** rsync-core.js approveEntry(req, profile, ts). */
    fun approveEntry(req: PendingRequest, profile: String, ts: String = Iso.js()): JSONObject = JSONObject()
        .put("id", "enroll-" + req.nonce + "-" + java.lang.Long.toString(Iso.jsMillis(ts), 36))
        .put("t", "device.enroll").put("profile", profile).put("device", req.device).put("nonce", req.nonce)
        .put("req_ts", req.reqTs).put("req_sig", req.reqSig).put("device_name", req.deviceName).put("ts", ts)

    data class SealParts(val body: JSONObject, val cid: String, val message: String)

    fun sealParts(entry: JSONObject, pub: String): SealParts {
        val b = body(entry).put("signer", pub)
        val h = cid(b)
        return SealParts(b, h, PREFIX + h)
    }

    fun finishSeal(p: SealParts, pub: String, value: String): JSONObject {
        val o = JSONObject(p.body.toString())
        o.put("cid", p.cid)
        o.put("rgen", JSONObject().put("scope", SCOPE).put("msg", p.message).put("pub", pub).put("value", value))
        return o
    }

    // ---- live API ----
    suspend fun deviceStatus(prefs: Prefs, pub: String): DeviceStatus? {
        val r = runCatching { Http.get(prefs.liveBase() + "/api/rsync/device-status?pub=" + Net.queryEncode(pub)) }.getOrNull()
        if (r == null || r.status != 200) return null
        val o = r.obj()
        return DeviceStatus(o.optBoolean("trusted"), o.optBoolean("enrolled"), o.optBoolean("pending"),
            o.optString("status", "unknown"), o.optString("name").ifBlank { null },
            o.optString("profile").ifBlank { null }, o.optString("code").ifBlank { null })
    }

    suspend fun postRequest(prefs: Prefs, req: EnrollRequest): Boolean {
        val r = runCatching { Http.post(prefs.liveBase() + "/api/rsync/request", req.body().toString(), 15_000) }.getOrNull()
        return r != null && (r.status == 200 || r.status == 201)
    }

    /** Live entries, then the static fallback (adopting its `live` URL for next time). */
    suspend fun feedHasEnroll(prefs: Prefs, req: EnrollRequest, profile: String): Boolean {
        val path = info.rizal.assmkit.AssmKitConfig.assmEnrollEntriesPath
        for (base in listOf(prefs.liveBase(), prefs.fallbackBase())) {
            val r = runCatching { Http.get(base + path) }.getOrNull() ?: continue
            if (r.status != 200) continue
            val (entries, live) = Http.parseFeed(r.body)
            if (base == prefs.fallbackBase() && live != null && Net.isValidBase(live) && live != prefs.liveBase()) {
                prefs.assmLearnedLive = live
            }
            if (entries.any {
                    it.optString("t") == "device.enroll" && it.optString("device") == req.device &&
                        it.optString("nonce") == req.nonce && (it.optString("profile") == profile || profile.isEmpty())
                }) return true
        }
        return false
    }

    /** If the live URL is down, read rizal.pw's `live` field and adopt the new quick-tunnel URL. */
    suspend fun refreshLiveFromFallback(prefs: Prefs): Boolean {
        val r = runCatching { Http.get(prefs.fallbackBase() + "/api/rsync/entries") }.getOrNull() ?: return false
        if (r.status != 200) return false
        val live = Http.parseFeed(r.body).second?.trimEnd('/') ?: return false
        if (!Net.isValidBase(live) || live == prefs.liveBase()) return false
        // Only switch to a URL that actually answers.
        val ok = runCatching { Http.get("$live/health", 8_000).status == 200 }.getOrDefault(false)
        if (ok) prefs.assmLearnedLive = live
        return ok
    }

    /** Health check, then feed lookup if the live URL is dead. True if the base changed. */
    suspend fun healLive(prefs: Prefs): Boolean = if (health(prefs)) false else refreshLiveFromFallback(prefs)

    suspend fun health(prefs: Prefs): Boolean =
        runCatching { Http.get(prefs.liveBase() + "/health", 8_000).status == 200 }.getOrDefault(false)
}
