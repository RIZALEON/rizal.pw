package info.rizal.assmkit.auth

import java.security.MessageDigest
import java.security.SecureRandom

/** RFC 7636 PKCE + state/nonce helpers (same as Swift `PKCE` / `Nonce`). */
object Pkce {
    private val rng = SecureRandom()
    private fun b64url(b: ByteArray) = java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(b)
    fun random(n: Int = 32): String = b64url(ByteArray(n).also { rng.nextBytes(it) })
    fun verifier(): String = random(48)
    fun challenge(verifier: String): String = b64url(MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII)))
    fun sha256Hex(s: String): String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
    fun query(params: Map<String, String>): String =
        params.entries.joinToString("&") { java.net.URLEncoder.encode(it.key, "UTF-8") + "=" + java.net.URLEncoder.encode(it.value, "UTF-8") }
}
