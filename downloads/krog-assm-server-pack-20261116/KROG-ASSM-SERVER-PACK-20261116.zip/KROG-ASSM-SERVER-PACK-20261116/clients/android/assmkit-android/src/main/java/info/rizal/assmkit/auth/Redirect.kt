package info.rizal.assmkit.auth

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import kotlinx.coroutines.CompletableDeferred

/** One pending browser sign-in at a time; [AssmRedirectActivity] completes it. */
object OAuthRedirects {
    @Volatile private var pending: CompletableDeferred<Uri>? = null
    fun begin(): CompletableDeferred<Uri> = CompletableDeferred<Uri>().also { pending?.cancel(); pending = it }
    fun deliver(uri: Uri) { pending?.complete(uri); pending = null }
    fun cancel() { pending?.cancel(); pending = null }
}

/**
 * Receives `<package>:/oauth2redirect…` from the Custom Tab (registered in the module manifest with
 * the host app's `assmRedirectScheme` placeholder), hands it to the waiting provider, and closes.
 */
class AssmRedirectActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        intent?.data?.let { OAuthRedirects.deliver(it) }
        packageManager.getLaunchIntentForPackage(packageName)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP); startActivity(it)
        }
        finish()
    }
}
