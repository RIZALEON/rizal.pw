package info.rizal.assmkit.auth

import android.app.Activity
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent
import androidx.credentials.CreatePublicKeyCredentialRequest
import androidx.credentials.CreatePublicKeyCredentialResponse
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetPublicKeyCredentialOption
import androidx.credentials.PublicKeyCredential
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.CreateCredentialCancellationException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import info.rizal.assmkit.AssmKitConfig
import info.rizal.assmkit.core.Canon
import info.rizal.assmkit.core.Http
import info.rizal.assmkit.core.Iso
import info.rizal.assmkit.core.KeystoreKey
import info.rizal.assmkit.core.Net
import info.rizal.assmkit.core.UnlockGate
import kotlinx.coroutines.CancellationException
import org.json.JSONObject

/** Google: Credential Manager + Sign in with Google (official Android API). Needs the Web client ID. */
object GoogleProvider {
    val isConfigured get() = !AssmKitConfig.isPlaceholder(AssmKitConfig.googleWebClientId)
    suspend fun signIn(activity: Activity): ProviderCredential {
        if (!isConfigured) throw AuthException("Google sign-in needs Rizal's Google OAuth client IDs (see ASSMKIT-ANDROID.md).")
        val nonce = Pkce.random(24)
        val option = GetGoogleIdOption.Builder()
            .setServerClientId(AssmKitConfig.googleWebClientId)
            .setFilterByAuthorizedAccounts(false).setAutoSelectEnabled(false).setNonce(nonce).build()
        val res = try {
            CredentialManager.create(activity).getCredential(activity, GetCredentialRequest(listOf(option)))
        } catch (e: GetCredentialCancellationException) { throw AuthCancelled() }
        val c = res.credential
        if (c !is CustomCredential || c.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL)
            throw AuthException("Google returned an unexpected credential.")
        val g = GoogleIdTokenCredential.createFrom(c.data)
        return ProviderCredential(AuthProviderKind.GOOGLE, subject = g.id, email = g.id, displayName = g.displayName,
            proof = mapOf("id_token" to g.idToken, "nonce" to nonce))
    }
}

/** Microsoft (Entra ID): Custom Tabs + PKCE (AppAuth-style), public client, custom-scheme redirect. */
object MicrosoftProvider {
    val isConfigured get() = !AssmKitConfig.isPlaceholder(AssmKitConfig.microsoftClientId)
    private val base get() = "https://login.microsoftonline.com/${AssmKitConfig.microsoftTenant}/oauth2/v2.0"

    suspend fun signIn(activity: Activity): ProviderCredential {
        if (!isConfigured) throw AuthException("Microsoft sign-in needs Rizal's Entra app client ID (see ASSMKIT-ANDROID.md).")
        val verifier = Pkce.verifier(); val state = Pkce.random(16); val nonce = Pkce.random(16)
        val redirect = AssmKitConfig.oauthRedirectUri + "/microsoft"
        val url = "$base/authorize?" + Pkce.query(mapOf(
            "client_id" to AssmKitConfig.microsoftClientId, "response_type" to "code", "redirect_uri" to redirect,
            "response_mode" to "query", "scope" to "openid profile email offline_access", "state" to state, "nonce" to nonce,
            "code_challenge" to Pkce.challenge(verifier), "code_challenge_method" to "S256", "prompt" to "select_account"))
        val back = openAndAwait(activity, url)
        if (back.getQueryParameter("state") != state) throw AuthException("Microsoft sign-in: state mismatch.")
        back.getQueryParameter("error")?.let { throw if (it == "access_denied") AuthCancelled() else AuthException("Microsoft: $it") }
        val code = back.getQueryParameter("code") ?: throw AuthException("Microsoft sign-in returned no code.")
        val tok = Http.postForm("$base/token", Pkce.query(mapOf(
            "client_id" to AssmKitConfig.microsoftClientId, "grant_type" to "authorization_code", "code" to code,
            "redirect_uri" to redirect, "code_verifier" to verifier, "scope" to "openid profile email offline_access")))
        if (!tok.ok) throw AuthException("Microsoft token exchange: " + tok.obj().optString("error_description").ifBlank { tok.error() })
        val idToken = tok.obj().optString("id_token").ifBlank { throw AuthException("Microsoft returned no id_token.") }
        val claims = Jwt.claims(idToken)
        // Only the id_token goes to the RCODE server; Microsoft access/refresh tokens are dropped.
        return ProviderCredential(AuthProviderKind.MICROSOFT, subject = claims.optString("oid").ifBlank { claims.optString("sub") },
            email = claims.optString("email").ifBlank { claims.optString("preferred_username") }.ifBlank { null },
            displayName = claims.optString("name").ifBlank { null }, proof = mapOf("id_token" to idToken, "nonce" to nonce))
    }
}

/**
 * Apple on Android = Sign in with Apple for the web in a Custom Tab. Apple only redirects to a
 * registered https URL with response_mode=form_post, so rizal.pw needs a small relay page
 * ([AssmKitConfig.appleWebReturnUrl]) that forwards `id_token` + `state` to
 * `<package>:/oauth2redirect/apple#...`. No Apple client secret ever lives on the phone.
 */
object AppleWebProvider {
    val isConfigured get() = !AssmKitConfig.isPlaceholder(AssmKitConfig.appleServicesId)
    suspend fun signIn(activity: Activity): ProviderCredential {
        if (!isConfigured) throw AuthException("Apple sign-in on Android needs Rizal's Apple Services ID and the rizal.pw relay page (see ASSMKIT-ANDROID.md).")
        val state = Pkce.random(16); val nonce = Pkce.random(16)
        val url = "https://appleid.apple.com/auth/authorize?" + Pkce.query(mapOf(
            "client_id" to AssmKitConfig.appleServicesId, "redirect_uri" to AssmKitConfig.appleWebReturnUrl,
            "response_type" to "code id_token", "response_mode" to "form_post", "scope" to "name email",
            "state" to state, "nonce" to Pkce.sha256Hex(nonce)))
        val back = openAndAwait(activity, url)
        val frag = Uri.parse("x://x?" + (back.fragment ?: back.query ?: ""))
        if (frag.getQueryParameter("state") != state) throw AuthException("Apple sign-in: state mismatch.")
        val idToken = frag.getQueryParameter("id_token") ?: throw AuthException("Apple sign-in returned no id_token.")
        val claims = Jwt.claims(idToken)
        return ProviderCredential(AuthProviderKind.APPLE, subject = claims.optString("sub"), email = claims.optString("email").ifBlank { null },
            proof = mapOf("id_token" to idToken, "nonce" to nonce, "code" to (frag.getQueryParameter("code") ?: "")))
    }
}

/** Passkeys: Credential Manager WebAuthn against the RCODE server's options/finish routes (same as Swift). */
object PasskeyProvider {
    val isConfigured get() = !AssmKitConfig.isPlaceholder(AssmKitConfig.passkeyRpId) && !AssmKitConfig.isPlaceholder(AssmKitConfig.serverUrl)
    suspend fun signIn(activity: Activity, mode: AuthMode, device: JSONObject): ProviderCredential {
        if (!isConfigured) throw AuthException("Passkeys need the RCODE server and rizal.pw assetlinks.json (see ASSMKIT-ANDROID.md).")
        val register = mode == AuthMode.SIGN_UP
        val srv = AssmKitConfig.serverUrl.trimEnd('/')
        val o = Http.post("$srv/v1/auth/passkey/${if (register) "register" else "login"}/options",
            JSONObject().put("mode", if (register) "register" else "login").put("device", device).toString())
        if (!o.ok) throw AuthException("Passkey options: " + o.error())
        val opts = o.obj()
        val cm = CredentialManager.create(activity)
        val finish = JSONObject().put("request_id", opts.optString("request_id", opts.optString("requestId"))).put("device", device)
        if (register) {
            val req = JSONObject().put("challenge", opts.optString("challenge"))
                .put("rp", JSONObject().put("id", AssmKitConfig.passkeyRpId).put("name", AssmKitConfig.appName))
                .put("user", JSONObject().put("id", opts.optString("user_id", opts.optString("userId")))
                    .put("name", opts.optString("user_name", "owner")).put("displayName", opts.optString("user_name", "owner")))
                .put("pubKeyCredParams", org.json.JSONArray().put(JSONObject().put("type", "public-key").put("alg", -7)))
                .put("authenticatorSelection", JSONObject().put("residentKey", "required").put("userVerification", "required"))
            val r = try { cm.createCredential(activity, CreatePublicKeyCredentialRequest(req.toString())) as CreatePublicKeyCredentialResponse }
                    catch (e: CreateCredentialCancellationException) { throw AuthCancelled() }
            val j = JSONObject(r.registrationResponseJson); val resp = j.getJSONObject("response")
            finish.put("credential_id", j.optString("id")).put("client_data_json", resp.optString("clientDataJSON"))
                .put("attestation_object", resp.optString("attestationObject"))
        } else {
            val req = JSONObject().put("challenge", opts.optString("challenge")).put("rpId", AssmKitConfig.passkeyRpId)
                .put("userVerification", "required").put("allowCredentials", org.json.JSONArray())
            val r = try { cm.getCredential(activity, GetCredentialRequest(listOf(GetPublicKeyCredentialOption(req.toString())))) }
                    catch (e: GetCredentialCancellationException) { throw AuthCancelled() }
            val pk = r.credential as? PublicKeyCredential ?: throw AuthException("No passkey returned.")
            val j = JSONObject(pk.authenticationResponseJson); val resp = j.getJSONObject("response")
            finish.put("credential_id", j.optString("id")).put("client_data_json", resp.optString("clientDataJSON"))
                .put("authenticator_data", resp.optString("authenticatorData")).put("signature", resp.optString("signature"))
                .put("user_handle", resp.optString("userHandle"))
        }
        val f = Http.post("$srv/v1/auth/passkey/${if (register) "register" else "login"}/finish", finish.toString())
        if (!f.ok) throw AuthException("Passkey: " + f.error())
        return ProviderCredential(AuthProviderKind.PASSKEY, subject = finish.optString("credential_id"), session = f.obj())
    }
}

/** Email + password against the RCODE server (`/v1/auth/password/login|signup`, same as Swift PasswordProvider). */
object EmailProvider {
    val isConfigured get() = !AssmKitConfig.isPlaceholder(AssmKitConfig.serverUrl)
    suspend fun signIn(username: String, password: String, mode: AuthMode, device: JSONObject): ProviderCredential {
        if (!isConfigured) throw AuthException("Email sign-in needs the RCODE account server URL (Change server).")
        if (username.isBlank() || password.isEmpty()) throw AuthException("Enter your email and password.")
        val path = if (mode == AuthMode.SIGN_UP) "/v1/auth/password/signup" else "/v1/auth/password/login"
        val r = Http.post(AssmKitConfig.serverUrl.trimEnd('/') + path,
            JSONObject().put("username", username.trim()).put("password", password).put("device", device).toString())
        if (!r.ok) throw AuthException(r.error())
        return ProviderCredential(AuthProviderKind.PASSWORD, subject = username.trim().lowercase(), email = username.trim(), session = r.obj())
    }
}

/**
 * ASSM username + password (ASSM-RSYNC `pwlogin.py`, INTEGRATION.md section 4), same as ASSMKit
 * ASSMPasswordClient (GHOSTMACHINE assmkit 3274919). Behind [AssmKitConfig.assmPasswordEnabled] (OFF).
 *
 *   GET  <live>/api/rsync/password/params?user=ЯID|@handle -> {scheme, profile, handle, salt, iter} | 404
 *   dk    = PBKDF2WithHmacSHA256(password, salt, iter >= 600000, 256 bits)   (on this phone only)
 *   proof = base64(dk)
 *   POST <live>/api/rsync/password/login {t:"password.login", user, proof, device, device_name, nonce, ts, sig}
 *   sig over "assm-password-login-v1\n"+user+"\n"+sha256hex(proof)+"\n"+device+"\n"+device_name+"\n"+nonce+"\n"+ts
 *   with this install's Keystore device key. 200 = the device key is ACTIVE for the profile.
 *
 * The plaintext password is never sent, stored or logged; the form clears it right after sending.
 * Password SET is not on Android (Apple ASSMKit only, needs an approver key).
 */
object AssmPasswordClient {
    const val SCHEME = "pbkdf2-sha256-hmac-v1"
    const val MIN_ITERATIONS = 600_000
    val isEnabled get() = AssmKitConfig.assmPasswordEnabled

    fun derive(password: CharArray, salt: ByteArray, iterations: Int): ByteArray {
        val spec = javax.crypto.spec.PBEKeySpec(password, salt, iterations, 256)
        try {
            return javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally { spec.clearPassword() }
    }

    fun loginMessage(user: String, proof: String, device: String, deviceName: String, nonce: String, ts: String): String =
        "assm-password-login-v1\n" + listOf(user, Canon.sha256Hex(proof), device, deviceName, nonce, ts).joinToString("\n")

    /** 32 letters/digits (server: 8-64, single use). */
    fun nonce(): String {
        val b = ByteArray(16); java.security.SecureRandom().nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }

    /**
     * @param base live ASSM base, @param signer device-key signer (Keystore in the app, software key in tests).
     * Returns (profile, handle).
     */
    suspend fun login(base: String, user: String, password: CharArray, deviceName: String, signer: info.rizal.assmkit.sync.SyncSigner): Pair<String, String?> {
        try {
            val u = user.trim()
            if (u.isEmpty() || password.isEmpty()) throw AuthException("Enter your ASSM username (ЯID or @handle) and password.")
            val pr = runCatching { Http.get("$base/api/rsync/password/params?user=" + Net.queryEncode(u)) }.getOrNull()
                ?: throw AuthException("The ASSM server isn't reachable right now.")
            if (pr.status == 404) throw AuthException("Wrong username or password.")
            val p = pr.obj()
            val salt = runCatching { java.util.Base64.getDecoder().decode(p.getString("salt")) }.getOrNull()
            val iter = p.optInt("iter", 0)
            if (pr.status != 200 || salt == null || iter < MIN_ITERATIONS || p.optString("scheme", SCHEME) != SCHEME)
                throw AuthException("Server error ${pr.status}: bad params")
            val dk = derive(password, salt, iter)
            val proof = java.util.Base64.getEncoder().encodeToString(dk)
            dk.fill(0)
            val pub = signer.publicKeyBase64()
            val n = nonce(); val ts = Iso.js()
            val sig = signer.sign(loginMessage(u, proof, pub, deviceName, n, ts))
            val body = JSONObject().put("t", "password.login").put("user", u).put("proof", proof).put("device", pub)
                .put("device_name", deviceName).put("nonce", n).put("ts", ts).put("sig", sig)
            val r = runCatching { Http.post("$base/api/rsync/password/login", body.toString(), 20_000) }.getOrNull()
                ?: throw AuthException("The ASSM server isn't reachable right now.")
            val o = r.obj()
            when (r.status) {
                200, 201 -> return (o.optString("profile").ifBlank { throw AuthException("Server error 200: no profile") }) to o.optString("handle").ifBlank { null }
                401 -> throw AuthException("Wrong username or password.")
                409 -> throw AuthException("That request was already used. Try again.")
                429 -> throw AuthException("Too many attempts. Try again in ${maxOf(1, o.optInt("retry_after_s", 60))} s.")
                else -> throw AuthException("Server error ${r.status}: " + o.optString("error").ifBlank { "unexpected response" })
            }
        } finally { password.fill('\u0000') }
    }

    /** App path: Keystore device key (unlock if the time-bound key needs it), live base with heal. */
    suspend fun signIn(prefs: info.rizal.assmkit.core.Prefs, username: String, password: CharArray, deviceName: String): ProviderCredential {
        if (!isEnabled) { password.fill('\u0000'); throw AuthException("ASSM username + password sign-in is not available yet.") }
        if (!info.rizal.assmkit.assm.Assm.health(prefs)) info.rizal.assmkit.assm.Assm.refreshLiveFromFallback(prefs)
        // Time-bound Keystore key: unlock once up front (fingerprint / PIN) so the login signature can't stall.
        try { KeystoreKey.device.sign("assm-password-unlock-probe") }
        catch (e: android.security.keystore.UserNotAuthenticatedException) { UnlockGate.require("Unlock to sign in with your ASSM password") }
        val signer = info.rizal.assmkit.sync.KeystoreSyncSigner
        val (profile, handle) = login(prefs.liveBase(), username, password, deviceName, signer)
        return ProviderCredential(AuthProviderKind.ASSM_PASSWORD, subject = profile, displayName = handle)
    }
}

/** Device link: claim a code started on another signed-in device (`/v1/devices/link/claim`). */
object DeviceLinkProvider {
    val isConfigured get() = !AssmKitConfig.isPlaceholder(AssmKitConfig.serverUrl)
    suspend fun claim(code: String, device: JSONObject): ProviderCredential {
        if (!isConfigured) throw AuthException("Device linking needs the RCODE account server URL (Change server).")
        val r = Http.post(AssmKitConfig.serverUrl.trimEnd('/') + "/v1/devices/link/claim",
            JSONObject().put("code", code.trim().uppercase()).put("device", device).toString())
        if (!r.ok) throw AuthException(r.error())
        return ProviderCredential(AuthProviderKind.DEVICE_LINK, subject = "device-link", session = r.obj())
    }
}

internal suspend fun openAndAwait(activity: Activity, url: String): Uri {
    val wait = OAuthRedirects.begin()
    CustomTabsIntent.Builder().setShowTitle(true).build().launchUrl(activity, Uri.parse(url))
    return try { wait.await() } catch (e: CancellationException) { throw AuthCancelled() }
}

/** Unverified JWT claim read for display only; the RCODE server verifies signatures. */
object Jwt {
    fun claims(jwt: String): JSONObject = runCatching {
        val p = jwt.split(".")[1]
        JSONObject(String(java.util.Base64.getUrlDecoder().decode(p)))
    }.getOrDefault(JSONObject())
}
