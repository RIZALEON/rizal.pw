# assmkit-android

The Android port of ASSMKit (GHOSTMACHINE `Packages/ASSMKit`), used by RCODE (`:app` → `implementation(project(":assmkit-android"))`).
It has the same sign-in screen and order as `SignInView`:

1. Continue with Google: Credential Manager `GetGoogleIdOption`
2. Continue with Apple: Custom Tab, `form_post` through the rizal.pw relay to `info.rizal.rcode:/oauth2redirect/apple`
3. Continue with email: RCODE server `/v1/auth/password/login|signup`
4. Continue with passkey: Credential Manager WebAuthn, server `/v1/auth/passkey/{login,register}/{options,finish}`
5. Continue with Microsoft: Custom Tab + PKCE, redirect `info.rizal.rcode:/oauth2redirect/microsoft`
6. Continue with ASSM: 8-digit approve code + QR (`rsync-enroll-v1`), approved once on a trusted device
7. ASSM username + password: ASSM-RSYNC `/api/rsync/password/{params,login}`. **Off by default** (`ASSM_PASSWORD_SIGNIN=false`).
8. Have a link code from another device? `/v1/devices/link/claim` · Approve a device (approver key, code or QR scan)
9. Not now. Keep using RCODE offline

Every option ends on the owner identity **ЯID-0001-3QQS** with this install's Keystore device key (`rcode_assm_device`,
which unlocks with BiometricPrompt). Sync then uses the same signed ASSM-RSYNC calls as Apple
(`/api/rsync/request|approve|device-status`, `/v1/sync/changes|pull`). The live URL is rediscovered from
`https://rizal.pw/api/rsync/entries` (`live`). ASSMKit never approves or trusts a key itself.

Preset strings (`rcode.` prefs, `rcode_assm_*` key aliases, `rcode://` scheme) are unchanged from the pre-module app,
so the Moto's already-approved key keeps working.

## ASSM password (off by default)
Matches ASSMKit `ASSMPasswordClient` (assmkit 3274919):
- `dk = PBKDF2WithHmacSHA256(password, salt, iter ≥ 600000, 256 bits)` and `proof = base64(dk)`.
- The login is signed with the device key over
  `assm-password-login-v1\nuser\nsha256hex(proof)\ndevice\ndevice_name\nnonce\nts`.
- 200 makes the key ACTIVE. 401 shows "Wrong username or password". 409 is a replay. 429 shows `retry_after_s`.
- The password field is cleared right after sending and the CharArray is zeroed. The password is never stored.
- Password **set** isn't on Android (Apple only, approver key). Turn it on with `buildConfigField("Boolean", "ASSM_PASSWORD_SIGNIN", "true")`.

## Placeholders: Rizal's registration checklist
Fill these in `AssmKitConfig` (set them in `RcodeApplication`). Until then, those buttons are dimmed.

| What | Where | Value to register |
|---|---|---|
| Google, Android client | Google Cloud Console › Credentials › OAuth client › Android | package `info.rizal.rcode`, SHA-1 `AC:FC:EC:82:0E:FA:2C:56:F0:35:92:96:F5:CB:E1:E7:F7:B7:93:8C`, SHA-256 `F0:DB:E9:A2:1E:B8:D0:7D:8F:D2:11:CE:8F:BF:20:22:42:10:86:54:E0:CE:34:DF:6B:76:37:17:6E:E3:E5:0B` (debug keystore) |
| Google, Web client | same project › OAuth client › Web | client ID goes into `googleWebClientId` (Credential Manager `serverClientId`) |
| Microsoft | Entra ID › App registrations › new, *Mobile and desktop* platform | public client; redirect `info.rizal.rcode:/oauth2redirect/microsoft`; Linux also needs `http://127.0.0.1/callback/microsoft` (loopback, any port); client ID → `microsoftClientId`; tenant `common` |
| Apple | developer.apple.com › Identifiers › Services ID (Sign in with Apple) | domain `rizal.pw`, return URLs `https://rizal.pw/auth/apple/android` and `https://rizal.pw/auth/apple/desktop`; Services ID → `appleServicesId`. rizal.pw needs a relay page that turns the `form_post` into `info.rizal.rcode:/oauth2redirect/apple#id_token=…&state=…` (Android) or a POST to `http://127.0.0.1:<port from state>/callback/apple` (Linux). |
| Passkeys | `https://rizal.pw/.well-known/assetlinks.json` | `delegate_permission/common.get_login_creds` for `info.rizal.rcode` with the SHA-256 above; RP ID `rizal.pw` → `passkeyRpId`; Linux needs the bridge page `https://rizal.pw/auth/passkey/desktop` |
| RCODE account server | `serverUrl` | base URL serving `/v1/auth/*` and `/v1/devices/link/claim` (email, passkey, device link and verified provider exchange) |
| ASSM password | `ASSM_PASSWORD_SIGNIN` (app buildConfigField) | turn on once Rizal has set a password from an Apple device |

A release keystore would need its own SHA-1/SHA-256 registered as well. Nothing here signs with anything other than the debug keystore.
