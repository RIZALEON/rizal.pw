plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// ASSMKit for Android: the same sign-in + ASSM-RSYNC sync as the Swift ASSMKit package.
android {
    namespace = "info.rizal.assmkit"
    compileSdk = 35
    defaultConfig {
        minSdk = 30
        consumerProguardFiles("consumer-rules.pro")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    testOptions { unitTests { isReturnDefaultValues = true } }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    api("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    api("androidx.biometric:biometric:1.1.0")
    api("androidx.fragment:fragment-ktx:1.8.5")
    // Official sign-in APIs
    implementation("androidx.credentials:credentials:1.3.0")                  // Credential Manager (Google + passkeys)
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    implementation("androidx.browser:browser:1.8.0")                         // Custom Tabs (Microsoft, Apple on web)
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")           // approve-code QR scan + render
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
