import Foundation
import Security

/// Small Keychain wrapper. Tokens and keys only ever live here, never in UserDefaults or files.
/// `synchronizable: true` uses iCloud Keychain (Apple devices on the same Apple ID); it needs the
/// Keychain Sharing capability when signed with Rizal's Team, so callers fall back to a local store.
public struct KeychainStore: Sendable {
    public let service: String
    public var synchronizable = false

    public init(service: String, synchronizable: Bool = false) {
        self.service = service
        self.synchronizable = synchronizable
    }

    /// Runtime guard: never read, write or delete RSIGN / RMAIL items (see ASSMKitConfig.isReserved).
    public var isReserved: Bool { ASSMKitConfig.isReserved(service) }

    public func set(_ data: Data, for key: String) throws {
        if isReserved { throw ASSMKitConfig.ValidationError.reservedName(service) }
        var query = baseQuery(key)
        SecItemDelete(query as CFDictionary)
        query[kSecValueData as String] = data
        query[kSecAttrAccessible as String] = synchronizable
            ? kSecAttrAccessibleAfterFirstUnlock
            : kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        let status = SecItemAdd(query as CFDictionary, nil)
        guard status == errSecSuccess else { throw KeychainError(status: status) }
    }

    public func data(for key: String) -> Data? {
        if isReserved { return nil }
        var query = baseQuery(key)
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &out) == errSecSuccess else { return nil }
        return out as? Data
    }

    public func remove(_ key: String) {
        if isReserved { return }
        SecItemDelete(baseQuery(key) as CFDictionary)
    }

    public func setCodable<T: Encodable>(_ value: T, for key: String) throws {
        try set(JSONCoding.encoder.encode(value), for: key)
    }

    public func codable<T: Decodable>(_ type: T.Type, for key: String) -> T? {
        guard let d = data(for: key) else { return nil }
        return try? JSONCoding.decoder.decode(type, from: d)
    }

    private func baseQuery(_ key: String) -> [String: Any] {
        var q: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: key,
        ]
        if synchronizable {
            q[kSecAttrSynchronizable as String] = kCFBooleanTrue
            #if os(macOS)
            q[kSecUseDataProtectionKeychain as String] = true
            #endif
        }
        return q
    }
}

public struct KeychainError: LocalizedError {
    public let status: OSStatus
    public var errorDescription: String? {
        (SecCopyErrorMessageString(status, nil) as String?) ?? "Keychain error \(status)"
    }
}

public enum JSONCoding {
    public static var encoder: JSONEncoder {
        let e = JSONEncoder()
        e.keyEncodingStrategy = .convertToSnakeCase
        e.dateEncodingStrategy = .iso8601
        return e
    }
    public static var decoder: JSONDecoder {
        let d = JSONDecoder()
        d.keyDecodingStrategy = .convertFromSnakeCase
        d.dateDecodingStrategy = .iso8601
        return d
    }
}
