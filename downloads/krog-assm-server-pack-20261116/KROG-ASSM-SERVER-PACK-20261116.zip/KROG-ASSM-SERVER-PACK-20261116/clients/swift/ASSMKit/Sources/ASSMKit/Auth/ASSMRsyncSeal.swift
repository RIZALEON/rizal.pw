import Foundation
import CryptoKit

/// rsync-core.js 0.3.2 / ASSM-RSYNC server.py seal helpers, field-for-field.
/// `canon`, `cid`, `approveEntry` and `seal` must stay byte-identical to the JS/Python copies.
/// RCODE uses this only for `device.enroll` approvals. It never signs mints.
public nonisolated enum ASSMRsyncSeal: Sendable {
    public static let scope = "yaseed.mint"
    public static let prefix = "yaseed-artifact-v1\n" + scope + "\n"
    public static let enrollPrefix = "rsync-enroll-v1\n"
    /// Keys excluded from the hashed body (rsync-core.js `LOCAL`).
    public static let localKeys: Set<String> = ["seq", "prev", "hash", "cid", "rgen", "_src", "_rx", "cosig"]

    /// Sorted-key JSON, no spaces, unicode unescaped — matches JS `canon` and Python `json.dumps(ensure_ascii=False)`.
    public static func canon(_ value: Any?) -> String {
        switch value {
        case nil, is NSNull:
            return "null"
        case let arr as [Any]:
            return "[" + arr.map { canon($0) }.joined(separator: ",") + "]"
        case let dict as [String: Any]:
            let parts = dict.keys.sorted().compactMap { k -> String? in
                guard let v = dict[k], !(v is NSNull) else { return nil }
                return jsonString(k) + ":" + canon(v)
            }
            return "{" + parts.joined(separator: ",") + "}"
        case let b as Bool:
            return b ? "true" : "false"
        case let n as Int:
            return String(n)
        case let n as Int64:
            return String(n)
        case let n as UInt64:
            return String(n)
        case let n as Double:
            if n.rounded() == n, n >= Double(Int64.min), n <= Double(Int64.max) {
                return String(Int64(n))
            }
            return String(n)
        case let n as NSNumber:
            // Bool is bridged as NSNumber; distinguish it.
            if CFGetTypeID(n) == CFBooleanGetTypeID() {
                return n.boolValue ? "true" : "false"
            }
            if CFNumberIsFloatType(n) {
                let d = n.doubleValue
                if d.rounded() == d, d >= Double(Int64.min), d <= Double(Int64.max) {
                    return String(Int64(d))
                }
                return String(d)
            }
            return n.stringValue
        case let s as String:
            return jsonString(s)
        default:
            return jsonString(String(describing: value!))
        }
    }

    public static func jsonString(_ s: String) -> String {
        var out = "\""
        for ch in s.unicodeScalars {
            switch ch {
            case "\"": out += "\\\""
            case "\\": out += "\\\\"
            case "\u{08}": out += "\\b"
            case "\u{0C}": out += "\\f"
            case "\n": out += "\\n"
            case "\r": out += "\\r"
            case "\t": out += "\\t"
            default:
                if ch.value < 0x20 {
                    out += String(format: "\\u%04x", ch.value)
                } else {
                    out.unicodeScalars.append(ch)
                }
            }
        }
        out += "\""
        return out
    }

    public static func body(_ entry: [String: Any]) -> [String: Any] {
        var o: [String: Any] = [:]
        for (k, v) in entry where !localKeys.contains(k) && !(v is NSNull) {
            o[k] = v
        }
        return o
    }

    public static func cid(of entry: [String: Any]) -> String {
        let digest = SHA256.hash(data: Data(canon(body(entry)).utf8))
        return digest.map { String(format: "%02x", $0) }.joined()
    }

    /// JS `Date.parse(iso)` → integer milliseconds, then `.toString(36)`.
    public static func jsMillis(_ iso: String) -> Int64 {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        f.timeZone = TimeZone(secondsFromGMT: 0)
        if let d = f.date(from: iso) {
            return Int64((d.timeIntervalSince1970 * 1000.0).rounded())
        }
        f.formatOptions = [.withInternetDateTime]
        if let d = f.date(from: iso) {
            return Int64((d.timeIntervalSince1970 * 1000.0).rounded())
        }
        return Int64((Date().timeIntervalSince1970 * 1000.0).rounded())
    }

    /// JS `new Date().toISOString()` — milliseconds and a trailing Z.
    public static func jsISO8601(_ date: Date = Date()) -> String {
        let ms = Int64((date.timeIntervalSince1970 * 1000.0).rounded())
        let d = Date(timeIntervalSince1970: TimeInterval(ms) / 1000.0)
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        f.timeZone = TimeZone(secondsFromGMT: 0)
        return f.string(from: d)
    }

    /// sha256(device + "\n" + nonce) → first 10 hex digits → mod 1e8 → "XXXX-XXXX".
    public static func shortCode(device: String, nonce: String) -> String {
        let digest = SHA256.hash(data: Data((device + "\n" + nonce).utf8))
        let hex = digest.map { String(format: "%02x", $0) }.joined()
        let n = (UInt64(hex.prefix(10), radix: 16) ?? 0) % 100_000_000
        let s = String(format: "%08llu", n)
        return String(s.prefix(4)) + "-" + String(s.suffix(4))
    }

    /// rsync-core.js `approveEntry(req, profile, ts)` — `id` is `enroll-{nonce}-{Date.parse(ts).toString(36)}`.
    public static func approveEntry(request: ASSMPendingRequest, profile: String, ts: String? = nil) -> [String: Any] {
        let ts = ts ?? jsISO8601()
        let id = "enroll-" + request.nonce + "-" + String(jsMillis(ts), radix: 36)
        return [
            "id": id,
            "t": "device.enroll",
            "profile": profile,
            "device": request.device,
            "nonce": request.nonce,
            "req_ts": request.reqTs,
            "req_sig": request.reqSig,
            "device_name": request.deviceName,
            "ts": ts,
        ]
    }

    /// rsync-core.js `seal(e, signer)`: add `signer`, hash body, attach `cid` + `rgen`.
    /// `signature` is base64 of raw r||s (64 bytes) or DER; the server accepts both.
    public static func seal(_ entry: [String: Any], pub: String, signature: (String) throws -> String) throws -> [String: Any] {
        var b = body(entry)
        b["signer"] = pub
        let hashed = Self.cid(of: b)
        let msg = prefix + hashed
        let value = try signature(msg)
        var o = b
        o["cid"] = hashed
        o["rgen"] = [
            "scope": scope,
            "msg": msg,
            "pub": pub,
            "value": value,
        ] as [String: Any]
        return o
    }


    /// Prepares the hashed body + message so the caller can sign on the main actor (one biometric prompt).
    public static func sealParts(_ entry: [String: Any], pub: String) -> (body: [String: Any], cid: String, message: String) {
        var b = body(entry)
        b["signer"] = pub
        let hashed = cid(of: b)
        return (b, hashed, prefix + hashed)
    }

    public static func finishSeal(body: [String: Any], cid hashed: String, pub: String, value: String) -> [String: Any] {
        var o = body
        o["cid"] = hashed
        o["rgen"] = [
            "scope": scope,
            "msg": prefix + hashed,
            "pub": pub,
            "value": value,
        ] as [String: Any]
        return o
    }

    public static func jsonData(_ object: [String: Any]) throws -> Data {
        try JSONSerialization.data(withJSONObject: object, options: [.sortedKeys])
    }
}

/// A pending `device.request` as returned by GET /api/rsync/request/<code>.
public nonisolated struct ASSMPendingRequest: Sendable {
    public var code: String
    public var status: String
    public var expiresAt: Date?
    public var device: String
    public var nonce: String
    public var reqTs: String
    public var reqSig: String
    public var deviceName: String
    public var profile: String?
    public var platform: String?

    public var isPending: Bool { status == "pending" }
    public var isApproved: Bool { status == "approved" }

    public static func parse(_ obj: [String: Any]) -> ASSMPendingRequest? {
        // Support both snake_case server keys and already-mapped keys.
        func s(_ k: String, _ alt: String? = nil) -> String? {
            (obj[k] as? String) ?? (alt.flatMap { obj[$0] as? String })
        }
        guard let device = s("device"), let nonce = s("nonce"),
              let reqTs = s("req_ts") ?? s("reqTs"),
              let reqSig = s("req_sig") ?? s("reqSig") else { return nil }
        let code = s("code") ?? ASSMRsyncSeal.shortCode(device: device, nonce: nonce)
        let expires: Date?
        if let s = obj["expires_at"] as? String {
            let f = ISO8601DateFormatter()
            f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            expires = f.date(from: s) ?? {
                f.formatOptions = [.withInternetDateTime]
                return f.date(from: s)
            }()
        } else if let n = obj["expires_at"] as? Double {
            expires = Date(timeIntervalSince1970: n)
        } else if let n = obj["expires_at"] as? Int {
            expires = Date(timeIntervalSince1970: TimeInterval(n))
        } else if let n = obj["expires_at"] as? NSNumber {
            expires = Date(timeIntervalSince1970: n.doubleValue)
        } else {
            expires = nil
        }
        return ASSMPendingRequest(
            code: code,
            status: s("status") ?? "pending",
            expiresAt: expires,
            device: device,
            nonce: nonce,
            reqTs: reqTs,
            reqSig: reqSig,
            deviceName: s("device_name") ?? s("deviceName") ?? "device",
            profile: s("profile"),
            platform: s("platform") ?? s("os")
        )
    }
}
