import Foundation
import CryptoKit
import AuthenticationServices
import LocalAuthentication
#if canImport(UIKit)
import UIKit
#else
import AppKit
#endif

public enum Base64URL {
    public static func encode(_ data: Data) -> String {
        data.base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }
    public static func decode(_ string: String) -> Data? {
        var s = string.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        while s.count % 4 != 0 { s += "=" }
        return Data(base64Encoded: s)
    }
}

public enum Nonce {
    public static func random(bytes: Int = 32) -> String {
        var data = Data(count: bytes)
        _ = data.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault, bytes, $0.baseAddress!) }
        return Base64URL.encode(data)
    }
    public static func sha256Hex(_ s: String) -> String {
        SHA256.hash(data: Data(s.utf8)).map { String(format: "%02x", $0) }.joined()
    }
}

public enum PKCE {
    public static func verifier() -> String { Nonce.random(bytes: 48) }
    public static func challenge(for verifier: String) -> String {
        Base64URL.encode(Data(SHA256.hash(data: Data(verifier.utf8))))
    }
}

/// Reads (does not verify) JWT claims for display. The backend MUST verify signatures.
public enum JWT {
    public static func claims(_ token: String) -> [String: Any] {
        let parts = token.split(separator: ".")
        guard parts.count >= 2, let data = Base64URL.decode(String(parts[1])),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return [:] }
        return obj
    }
}

public enum PresentationAnchor {
    public static func current() -> ASPresentationAnchor {
        #if canImport(UIKit)
        let scenes = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }
        if let key = scenes.flatMap(\.windows).first(where: \.isKeyWindow) { return key }
        if let scene = scenes.first { return UIWindow(windowScene: scene) }
        return ASPresentationAnchor()
        #else
        return NSApplication.shared.keyWindow ?? NSApplication.shared.windows.first ?? ASPresentationAnchor()
        #endif
    }
}

/// Face ID / Touch ID / Optic ID, falling back to the device passcode or Mac password.
/// Required before RCODE uses any signing key (ASSM rule: every signature needs an unlock; bots never sign).
public enum UnlockGate {
    public static func require(reason: String) async throws {
        let context = LAContext()
        var err: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &err) else {
            throw AuthError.unavailable("This device has no passcode/biometrics set up, so it can't unlock a signing key.")
        }
        do { _ = try await context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: reason) }
        catch { throw AuthError.cancelled }
    }
}
