import Foundation
import Combine

/// Picks a SyncService and merges changes. Chats/settings hook in by calling `upsert` and observing `incoming`.
/// TODO(after merge with offline-model chat work): map ChatSession/Message to SyncRecord payloads.
@MainActor
public final class SyncCoordinator: ObservableObject {
    @Published public private(set) var serviceName = "This device only"
    @Published public private(set) var lastSync: Date?
    @Published public private(set) var lastError: String?
    @Published public private(set) var incoming: [SyncRecord] = []

    private var service: SyncService = LocalOnlySyncService()
    private var local: [String: SyncRecord] = [:]
    private static let cursorKey = ASSMKitConfig.current.defaultsKey("sync.cursor")

    public func configure(api: BackendClient?, config: AuthConfig) {
        service.stopLive()
        if let api { service = RESTSyncService(api: api) }
        else if config.cloudKitEnabled, !AuthConfig.isPlaceholder(config.cloudKitContainer) {
            service = CloudKitSyncService(containerIdentifier: config.cloudKitContainer)
        } else { service = LocalOnlySyncService() }
        serviceName = service.name
        service.startLive { [weak self] in self?.merge($0) }
    }

    /// Use a pre-built service (ASSM-signed sync after this device is enrolled).
    public func configureService(_ svc: SyncService) {
        didFullPull = false
        service.stopLive()
        service = svc
        serviceName = svc.name
        service.startLive { [weak self] in self?.merge($0) }
    }

    public func upsert(_ record: SyncRecord) {
        merge([record])
        // Batched + retried (was one request per record, which hit the server's 429 limit
        // on a full-history push and silently dropped records).
        outbox[record.id] = record
        scheduleFlush(after: 0.4)
    }

    // MARK: Outbox (batched, retried pushes)

    private var outbox: [String: SyncRecord] = [:]
    private var flushTask: Task<Void, Never>?
    private var flushBackoff: Double = 2
    private static let pushBatchSize = 25

    /// Records waiting to reach the server (for status display).
    public var pendingPushCount: Int { outbox.count }

    private func scheduleFlush(after seconds: Double) {
        guard flushTask == nil else { return }
        flushTask = Task { [weak self] in
            try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
            await self?.flushOutbox()
        }
    }

    /// Pushes queued records in batches; on failure keeps them and retries with backoff (max 60 s).
    public func flushOutbox() async {
        flushTask = nil
        guard !outbox.isEmpty else { return }
        let batch = Array(outbox.values.sorted { $0.updatedAt < $1.updatedAt }.prefix(Self.pushBatchSize))
        do {
            try await service.push(batch)
            for r in batch where outbox[r.id] == r { outbox[r.id] = nil }   // newer edits stay queued
            flushBackoff = 2
            lastError = nil
            if !outbox.isEmpty { scheduleFlush(after: 1.1) }
        } catch {
            lastError = error.localizedDescription
            scheduleFlush(after: flushBackoff)
            flushBackoff = min(flushBackoff * 2, 60)
        }
    }

    public func syncNow() async {
        do {
            // First pull of each launch is a full pull (since nil), so records that an earlier run
            // advanced the cursor past without applying still reach the chat list.
            let full = isRemote && !didFullPull
            let cursor = full ? nil : UserDefaults.standard.string(forKey: Self.cursorKey)
            let result = try await service.pull(since: cursor)
            merge(result.records)
            if let c = result.cursor { UserDefaults.standard.set(c, forKey: Self.cursorKey) }
            if full { didFullPull = true }
            lastSync = Date(); lastError = nil
            if !outbox.isEmpty { scheduleFlush(after: 0.4) }
        } catch { lastError = error.localizedDescription }
    }

    // MARK: Cross-device polling (pull was only at launch/approval, so other devices' messages never showed)

    private var didFullPull = false
    private var pollTask: Task<Void, Never>?

    /// True when sync goes to a server (ASSM), not "This device only".
    public var isRemote: Bool { service is ASSMSyncService || service is RESTSyncService || service is CloudKitSyncService }

    /// Pulls every `seconds` while the app runs (server allows 60 sync calls/min per IP).
    public func startPolling(every seconds: Double = 20) {
        guard pollTask == nil else { return }
        pollTask = Task { [weak self] in
            while !Task.isCancelled {
                guard let self else { return }
                if self.isRemote { await self.syncNow() }
                try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
            }
        }
    }

    public func reset() {
        service.stopLive()
        service = LocalOnlySyncService(); serviceName = service.name
        UserDefaults.standard.removeObject(forKey: Self.cursorKey)
        local = [:]; incoming = []
    }

    /// Last-writer-wins on updatedAt; ties broken by deviceId so every device converges.
    private func merge(_ records: [SyncRecord]) {
        var changed: [SyncRecord] = []
        for r in records {
            if let old = local[r.id], (old.updatedAt, old.deviceId) >= (r.updatedAt, r.deviceId) { continue }
            local[r.id] = r
            changed.append(r)
        }
        if !changed.isEmpty { incoming = changed }
    }
}
