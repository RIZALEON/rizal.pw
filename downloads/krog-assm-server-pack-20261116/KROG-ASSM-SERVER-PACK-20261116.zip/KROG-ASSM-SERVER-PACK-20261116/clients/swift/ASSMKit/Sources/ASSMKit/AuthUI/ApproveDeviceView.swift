import SwiftUI
#if os(iOS)
import UIKit
import Vision
import VisionKit
#elseif os(macOS)
import AppKit
#endif

/// "Approve a device" — enter an 8-digit ASSM code, review the pending request, then Approve
/// (signs with this device's Secure Enclave / Keychain approver key, one biometric prompt)
/// or Deny (local dismiss only; the server has no deny endpoint).
public struct ApproveDeviceView: View {
    /// Public initializer (ASSMKit): implicit memberwise inits are internal to the package.
    public init(showsClose: Bool = true) { self.showsClose = showsClose }
    public var showsClose = true
    @Environment(\.dismiss) private var dismiss
    @StateObject private var client = ASSMApproveClient()
    @State private var showScanner = false
    @FocusState private var codeFocused: Bool

    public var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    codeCard
                    if let req = client.request { requestCard(req) }
                    if client.deniedLocally || client.errorMessage != nil || client.successMessage != nil || client.untrusted {
                        statusCard
                    }
                    approverKeyCard
                }
                .padding(20)
            }
            .background(ASSMTheme.C.background.ignoresSafeArea())
            .navigationTitle("Approve a device")
            #if os(iOS)
            .navigationBarTitleDisplayMode(.inline)
            #endif
            .toolbar {
                if showsClose {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Close") { dismiss() }
                    }
                }
            }
            .environment(\.colorScheme, .dark)
            #if os(iOS)
            .sheet(isPresented: $showScanner) {
                ApprovalCodeScanner { raw in
                    showScanner = false
                    client.applyScanned(raw)
                }
                .ignoresSafeArea()
            }
            #endif
        }
        #if os(macOS)
        .frame(minWidth: 480, minHeight: 620)
        #endif
    }

    private var codeCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Enter the 8-digit code")
                .font(ASSMTheme.F.title)
                .foregroundStyle(.white)
            Text("The new device shows this code while it waits for approval. On iPhone you can also scan the QR.")
                .font(.footnote)
                .foregroundStyle(ASSMTheme.C.secondary)

            HStack(spacing: 8) {
                TextField("1234-5678", text: $client.codeText)
                    .font(.system(.title2, design: .monospaced).weight(.semibold))
                    .multilineTextAlignment(.center)
                    .textFieldStyle(.plain)
                    .padding(.horizontal, 14)
                    .frame(minHeight: 48)
                    .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.06)))
                    .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(ASSMTheme.C.glassBorder))
                    .focused($codeFocused)
                    #if os(iOS)
                    .keyboardType(.numberPad)
                    .textContentType(.oneTimeCode)
                    .textInputAutocapitalization(.never)
                    #endif
                    .onSubmit { Task { await client.fetch() } }
                    .assmOnChange(of: client.codeText) { new in
                        let digits = new.filter(\.isNumber)
                        if digits.count == 8 {
                            let formatted = String(digits.prefix(4)) + "-" + String(digits.suffix(4))
                            if new != formatted { client.codeText = formatted }
                        }
                    }

                #if os(iOS)
                if ApprovalCodeScanner.isUsable {
                    Button {
                        showScanner = true
                    } label: {
                        Image(systemName: "qrcode.viewfinder")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundStyle(.white)
                            .frame(width: 48, height: 48)
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                            .overlay(RoundedRectangle(cornerRadius: 12, style: .continuous).strokeBorder(ASSMTheme.C.glassBorder))
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Scan QR code")
                }
                #endif
            }

            Button {
                Task { await client.fetch() }
            } label: {
                Text(client.busy && client.request == nil ? "Looking up…" : "Look up request")
                    .font(.headline)
                    .frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.plain)
            .foregroundStyle(.white)
            .background(ASSMTheme.C.userBubble, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .disabled(client.busy || ASSMApproveClient.normalizeCode(client.codeText) == nil)
            .opacity(ASSMApproveClient.normalizeCode(client.codeText) == nil ? 0.45 : 1)
        }
        .padding(16)
        .rcodeGlassPanel()
    }

    private func requestCard(_ req: ASSMPendingRequest) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Requesting device")
                .font(ASSMTheme.F.title)
                .foregroundStyle(.white)
            detail("Name", req.deviceName)
            detail("Platform", req.platform?.isEmpty == false ? req.platform! : "Not reported")
            detail("Requested", formatISO(req.reqTs))
            detail("Expires", req.expiresAt.map { formatDate($0) } ?? "About 5 minutes after request")
            detail("Status", req.status)
            detail("Code", req.code)

            VStack(alignment: .leading, spacing: 6) {
                Text("Profile")
                    .font(.caption)
                    .foregroundStyle(ASSMTheme.C.secondary)
                TextField("\(ASSMKitConfig.current.appName)", text: $client.profile)
                    .textFieldStyle(.plain)
                    .padding(.horizontal, 12)
                    .frame(minHeight: 40)
                    .background(RoundedRectangle(cornerRadius: 10).fill(Color.white.opacity(0.06)))
                    .overlay(RoundedRectangle(cornerRadius: 10).strokeBorder(ASSMTheme.C.glassBorder))
                    #if os(iOS)
                    .textInputAutocapitalization(.never)
                    #endif
                    .autocorrectionDisabled()
            }

            HStack(spacing: 10) {
                Button(role: .destructive) {
                    client.denyLocally()
                } label: {
                    Text("Deny")
                        .font(.headline)
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.plain)
                .foregroundStyle(.white)
                .background(Color.red.opacity(0.55), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                .disabled(client.busy || !req.isPending)

                Button {
                    Task { await client.approve() }
                } label: {
                    Text(client.busy ? "Signing…" : "Approve")
                        .font(.headline)
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
                .buttonStyle(.plain)
                .foregroundStyle(ASSMTheme.C.sendGlyph)
                .background(ASSMTheme.C.sendFill, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                .disabled(client.busy || !req.isPending)
            }

            Text("Approve asks for Face ID, Touch ID or your passcode, then signs with this device’s approver key. Deny only dismisses the request here — it expires on the server by itself.")
                .font(.caption)
                .foregroundStyle(ASSMTheme.C.secondary)
        }
        .padding(16)
        .rcodeGlassPanel()
    }

    private var statusCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            if client.untrusted {
                Text("Approver key is not trusted")
                    .font(.headline)
                    .foregroundStyle(Color(rcodeHex: 0xFFB020))
            }
            if let ok = client.successMessage {
                Text(ok)
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(Color(rcodeHex: 0x6FCF97))
            }
            if let err = client.errorMessage {
                Text(err)
                    .font(.footnote)
                    .foregroundStyle(client.untrusted ? Color(rcodeHex: 0xFFB020) : Color(rcodeHex: 0xFF8A80))
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: ASSMTheme.R.glassCard, style: .continuous)
                .fill(client.untrusted ? Color(rcodeHex: 0xFFB020, opacity: 0.12) : Color.white.opacity(0.05))
        )
        .overlay(
            RoundedRectangle(cornerRadius: ASSMTheme.R.glassCard, style: .continuous)
                .strokeBorder(client.untrusted ? Color(rcodeHex: 0xFFB020, opacity: 0.6) : ASSMTheme.C.glassBorder)
        )
    }

    private var approverKeyCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("This device’s approver key")
                .font(ASSMTheme.F.title)
                .foregroundStyle(.white)
            Text("Created on this device, in the Secure Enclave when available (Keychain otherwise). The private key never leaves the device. The server will reject Approve until this public key is on its trusted-devices list.")
                .font(.footnote)
                .foregroundStyle(ASSMTheme.C.secondary)

            if let err = client.keyError {
                Text(err).font(.footnote).foregroundStyle(Color(rcodeHex: 0xFF8A80))
                Button("Create or load key") { client.refreshApproverKey() }
                    .font(.footnote)
            }

            if let pub = client.approverPub {
                Text(pub)
                    .font(ASSMTheme.F.code)
                    .foregroundStyle(ASSMTheme.Syntax.text)
                    .textSelection(.enabled)
                    .padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(ASSMTheme.C.codeCard, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                Button {
                    copyToPasteboard(pub)
                } label: {
                    Label("Copy public key", systemImage: "doc.on.doc")
                        .font(.footnote.weight(.semibold))
                }
                .buttonStyle(.plain)
                .foregroundStyle(Color(rcodeHex: 0xC17BF2))
            }

            if let cmd = client.trustCommand {
                Text("To trust this key (run on the ASSM server; \(ASSMKitConfig.current.appName) will not do this):")
                    .font(.caption)
                    .foregroundStyle(ASSMTheme.C.secondary)
                Text(cmd)
                    .font(ASSMTheme.F.code)
                    .foregroundStyle(ASSMTheme.Syntax.text)
                    .textSelection(.enabled)
                    .padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(ASSMTheme.C.codeCard, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                Button {
                    copyToPasteboard(cmd)
                } label: {
                    Label("Copy trust command", systemImage: "doc.on.doc")
                        .font(.footnote.weight(.semibold))
                }
                .buttonStyle(.plain)
                .foregroundStyle(Color(rcodeHex: 0xC17BF2))
            }
        }
        .padding(16)
        .rcodeGlassPanel()
    }

    private func detail(_ label: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(label)
                .font(.caption)
                .foregroundStyle(ASSMTheme.C.secondary)
                .frame(width: 88, alignment: .leading)
            Text(value)
                .font(.subheadline)
                .foregroundStyle(.white)
                .textSelection(.enabled)
            Spacer(minLength: 0)
        }
    }

    private func formatISO(_ s: String) -> String {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let d = f.date(from: s) { return formatDate(d) }
        f.formatOptions = [.withInternetDateTime]
        if let d = f.date(from: s) { return formatDate(d) }
        return s
    }

    private func formatDate(_ d: Date) -> String {
        d.formatted(.dateTime.month(.abbreviated).day().hour().minute().second())
    }

    private func copyToPasteboard(_ s: String) {
        #if os(iOS)
        UIPasteboard.general.string = s
        #else
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(s, forType: .string)
        #endif
    }
}

private extension View {
    /// Two-value `onChange` is macOS 14+ / iOS 17+; older macOS uses the single-value form.
    @ViewBuilder func assmOnChange<V: Equatable>(of value: V, perform: @escaping (V) -> Void) -> some View {
        if #available(macOS 14.0, iOS 17.0, *) {
            self.onChange(of: value) { _, new in perform(new) }
        } else {
            self.onChange(of: value, perform: perform)
        }
    }

    func rcodeGlassPanel() -> some View {
        self
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: ASSMTheme.R.glassCard, style: .continuous))
            .background(ASSMTheme.C.glassCard, in: RoundedRectangle(cornerRadius: ASSMTheme.R.glassCard, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: ASSMTheme.R.glassCard, style: .continuous).strokeBorder(ASSMTheme.C.glassBorder, lineWidth: 1))
    }
}

#if os(iOS)
/// VisionKit data scanner for an 8-digit code or `rcode://assm-approve` QR. Typed entry always works if this is unavailable.
public struct ApprovalCodeScanner: UIViewControllerRepresentable {
    /// Public initializer (ASSMKit): implicit memberwise inits are internal to the package.
    public init(onCode: @escaping (String) -> Void) { self.onCode = onCode }
    public var onCode: (String) -> Void

    public static var isUsable: Bool {
        DataScannerViewController.isSupported && DataScannerViewController.isAvailable
    }

    public func makeCoordinator() -> Coordinator { Coordinator(onCode: onCode) }

    public func makeUIViewController(context: Context) -> DataScannerViewController {
        let vc = DataScannerViewController(
            recognizedDataTypes: [.barcode(symbologies: [.qr]), .text()],
            qualityLevel: .balanced,
            recognizesMultipleItems: false,
            isHighFrameRateTrackingEnabled: false,
            isHighlightingEnabled: true
        )
        vc.delegate = context.coordinator
        return vc
    }

    public func updateUIViewController(_ vc: DataScannerViewController, context: Context) {
        if !vc.isScanning { try? vc.startScanning() }
    }

    public final class Coordinator: NSObject, DataScannerViewControllerDelegate {
        public let onCode: (String) -> Void
        private var sent = false
        public init(onCode: @escaping (String) -> Void) { self.onCode = onCode }

        public func dataScanner(_ dataScanner: DataScannerViewController, didAdd addedItems: [RecognizedItem], allItems: [RecognizedItem]) {
            emit(addedItems)
        }

        public func dataScanner(_ dataScanner: DataScannerViewController, didTapOn item: RecognizedItem) {
            emit([item])
        }

        private func emit(_ items: [RecognizedItem]) {
            guard !sent else { return }
            for item in items {
                switch item {
                case .barcode(let b):
                    if let v = b.payloadStringValue { sent = true; onCode(v); return }
                case .text(let t):
                    if ASSMApproveClient.normalizeCode(t.transcript) != nil { sent = true; onCode(t.transcript); return }
                default:
                    break
                }
            }
        }
    }
}
#endif
