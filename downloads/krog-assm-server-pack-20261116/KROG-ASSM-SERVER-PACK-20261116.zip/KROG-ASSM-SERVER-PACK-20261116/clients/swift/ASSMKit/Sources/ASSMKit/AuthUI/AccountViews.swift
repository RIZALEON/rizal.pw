import SwiftUI

/// Small badge for the chat header: "Sign in" when signed out, the account name when signed in.
public struct AccountBadge: View {
    /// Public initializer (ASSMKit): implicit memberwise inits are internal to the package.
    public init() {}
    @EnvironmentObject private var auth: AuthManager
    @State private var showAccount = false

    public var body: some View {
        Button {
            if auth.isSignedIn { showAccount = true } else { auth.presentSignIn = true }
        } label: {
            HStack(spacing: 5) {
                Image(systemName: auth.isSignedIn ? "person.crop.circle.fill.badge.checkmark" : "person.crop.circle")
                Text(auth.account?.displayName ?? "Sign in").font(.caption2).lineLimit(1)
            }
            .padding(.horizontal, 8).padding(.vertical, 3)
            .background(Capsule().fill(Color.accentColor.opacity(auth.isSignedIn ? 0.15 : 0.08)))
        }
        .buttonStyle(.borderless)
        .help(auth.isSignedIn ? "Account and devices" : "Sign in to sync across devices (optional; offline works without it)")
        .sheet(isPresented: $showAccount) { AccountView().environmentObject(auth) }
    }
}

public struct AccountView: View {
    /// Public initializer (ASSMKit): implicit memberwise inits are internal to the package.
    public init() {}
    @EnvironmentObject private var auth: AuthManager
    @Environment(\.dismiss) private var dismiss
    @State private var confirmSignOut = false
    @State private var approverTrusted = false

    public var body: some View {
        NavigationStack {
            List {
                if let acct = auth.account {
                    Section {
                        LabeledContent("Name", value: acct.displayName)
                        LabeledContent("Account", value: acct.isLocalOnly ? "This device (no server yet)" : acct.accountId)
                        LabeledContent("Sync", value: auth.sync.serviceName)
                    }
                    Section("Sign-in methods") {
                        ForEach(acct.identities) { id in
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(id.provider.displayName)
                                    Text(id.email ?? id.displayName ?? id.subject).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                }
                                Spacer()
                                if !id.verified { Text("unverified").font(.caption2).foregroundStyle(.orange) }
                                Button("Unlink", role: .destructive) { Task { await auth.unlink(id) } }
                                    .buttonStyle(.borderless).disabled(acct.identities.count < 2)
                            }
                        }
                        Menu("Link another…") {
                            ForEach(AuthProviderKind.allCases.filter { k in k != .password && !acct.has(k) }) { k in
                                Button(k.displayName) { Task { await auth.signIn(with: k) } }
                            }
                        }
                    }
                    Section {
                        NavigationLink("Devices") { DevicesView().environmentObject(auth) }
                        if approverTrusted {
                            NavigationLink("Set ASSM password") { SetASSMPasswordView().environmentObject(auth) }
                        }
                    } footer: {
                        if approverTrusted { Text("Lets you sign in on a new device with your ASSM username and password.") }
                    }
                    if let err = auth.lastError { Text(err).font(.footnote).foregroundStyle(.red) }
                    Section {
                        Button("Sign out of this device", role: .destructive) { confirmSignOut = true }
                    } footer: { Text("Offline mode keeps working after you sign out.") }
                }
            }
            .task { if !ASSMKitConfig.current.isIsolatedLaunch { approverTrusted = await ASSMPasswordClient.approverIsTrusted(config: auth.config) } }
            .navigationTitle("Account")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
            .confirmationDialog("Sign out of \(ASSMKitConfig.current.appName) on this device?", isPresented: $confirmSignOut) {
                Button("Sign out", role: .destructive) { Task { await auth.signOut(); dismiss() } }
            }
        }
        #if os(macOS)
        .frame(minWidth: 480, minHeight: 520)
        #endif
    }
}

public struct DevicesView: View {
    /// Public initializer (ASSMKit): implicit memberwise inits are internal to the package.
    public init() {}
    @EnvironmentObject private var auth: AuthManager
    @ObservedObject private var registry = AuthManager.shared.devices
    @State private var link: DeviceLinkCode?
    @State private var error: String?
    @State private var pendingRemoval: RegisteredDevice?
    @State private var pendingTrust: RegisteredDevice?

    public var body: some View {
        List {
            Section {
                ForEach(registry.devices) { d in
                    HStack(spacing: 12) {
                        Image(systemName: icon(for: d.os)).frame(width: 24)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(d.name + (d.id == registry.currentID ? " (this device)" : ""))
                            Text("\(d.os) · last seen \(d.lastSeen.formatted(.relative(presentation: .named)))")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Button(d.trusted ? "Trusted" : "Not trusted") { pendingTrust = d }
                            .font(.caption).buttonStyle(.borderless)
                            .foregroundStyle(d.trusted ? .green : .secondary)
                            .disabled(d.id == registry.currentID)
                        if d.id != registry.currentID {
                            Button(role: .destructive) { pendingRemoval = d } label: { Image(systemName: "trash") }
                                .buttonStyle(.borderless)
                        }
                    }
                }
            } header: { Text("Devices on this account") }

            Section {
                NavigationLink("Approve a device") { ApproveDeviceView(showsClose: false) }
            } footer: {
                Text("Enter the 8-digit code from a new device waiting for ASSM approval, or scan its QR on iPhone.")
            }

            Section {
                if let link {
                    VStack(spacing: 10) {
                        QRCodeView(payload: link.qrPayload).frame(maxWidth: 220)
                        Text(link.code).font(.system(.title2, design: .monospaced).weight(.bold)).textSelection(.enabled)
                        Text("On the new device: open \(ASSMKitConfig.current.appName) › Sign in › \"Have a link code?\" and scan or type this. Expires \(link.expiresAt.formatted(date: .omitted, time: .shortened)).")
                            .font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity)
                }
                Button(link == nil ? "Link a new device" : "Make a new code") {
                    Task {
                        do { link = try await registry.startLink(); error = nil }
                        catch { self.error = error.localizedDescription }
                    }
                }
            } footer: {
                Text("Apple devices on the same iCloud account pick up your \(ASSMKitConfig.current.appName) account through iCloud Keychain. Android, Linux and other devices link with a code.")
            }
            if let e = error ?? registry.lastError { Text(e).font(.footnote).foregroundStyle(.red) }
        }
        .navigationTitle("Devices")
        .task { await registry.refresh() }
        .refreshable { await registry.refresh() }
        .confirmationDialog("Remove \(pendingRemoval?.name ?? "device")? It will be signed out.",
                            isPresented: Binding(get: { pendingRemoval != nil }, set: { if !$0 { pendingRemoval = nil } })) {
            Button("Remove", role: .destructive) {
                if let d = pendingRemoval { Task { do { try await registry.remove(d) } catch { self.error = error.localizedDescription } } }
            }
        }
        .confirmationDialog("\(pendingTrust?.trusted == true ? "Stop trusting" : "Trust") \(pendingTrust?.name ?? "device")?",
                            isPresented: Binding(get: { pendingTrust != nil }, set: { if !$0 { pendingTrust = nil } })) {
            Button(pendingTrust?.trusted == true ? "Stop trusting" : "Trust") {
                if let d = pendingTrust { Task { do { try await registry.setTrusted(d, !d.trusted) } catch { self.error = error.localizedDescription } } }
            }
        }
    }

    private func icon(for os: String) -> String {
        let o = os.lowercased()
        if o.hasPrefix("macos") { return "laptopcomputer" }
        if o.hasPrefix("ipados") { return "ipad" }
        if o.hasPrefix("ios") { return "iphone" }
        if o.hasPrefix("android") { return "candybarphone" }
        if o.hasPrefix("visionos") { return "visionpro" }
        return "desktopcomputer"
    }
}
