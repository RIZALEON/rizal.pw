import Foundation

/// One-key lookup from `GET /api/rsync/device-status?pub=`. No other devices are returned.
public struct ASSMDeviceStatus: Sendable {
    public var trusted: Bool
    public var enrolled: Bool
    public var pending: Bool
    public var status: String
    public var name: String?
    public var profile: String?
    public var code: String?

    /// Already accepted: on the trusted-devices list, or enrolled via device.enroll.
    public var isApproved: Bool { trusted || enrolled }

    public static func parse(_ obj: [String: Any]) -> ASSMDeviceStatus {
        ASSMDeviceStatus(
            trusted: obj["trusted"] as? Bool ?? false,
            enrolled: obj["enrolled"] as? Bool ?? false,
            pending: obj["pending"] as? Bool ?? false,
            status: obj["status"] as? String ?? "unknown",
            name: obj["name"] as? String,
            profile: obj["profile"] as? String,
            code: obj["code"] as? String
        )
    }

    /// Live ASSM API base: env, UserDefaults override, then the bundled live URL.
    public static func liveBase(config: AuthConfig) -> URL? {
        if let env = ProcessInfo.processInfo.environment[ASSMKitConfig.current.baseURLEnvironmentKey], !env.trimmingCharacters(in: .whitespaces).isEmpty {
            return try? BackendClient.validated(env)
        }
        if let u = UserDefaults.standard.string(forKey: ASSMKitConfig.current.defaultsKey("assmBaseURL")), !u.trimmingCharacters(in: .whitespaces).isEmpty {
            return try? BackendClient.validated(u)
        }
        // Quick-tunnel URLs change on restart: use the URL learned from the rizal.pw feed's `live` field.
        if let u = UserDefaults.standard.string(forKey: ASSMLiveURL.learnedKey), !u.trimmingCharacters(in: .whitespaces).isEmpty,
           let v = try? BackendClient.validated(u) {
            return v
        }
        return try? BackendClient.validated(config.assmBaseURL)
    }

    /// Strict query-value encoding (RFC 3986 unreserved only), so base64 survives form decoding.
    public static func queryEncoded(_ value: String) -> String {
        var allowed = CharacterSet.alphanumerics
        allowed.insert(charactersIn: "-._~")
        return value.addingPercentEncoding(withAllowedCharacters: allowed) ?? value
    }

    public static func fetch(pub: String, config: AuthConfig) async -> ASSMDeviceStatus? {
        guard let base = liveBase(config: config),
              let endpoint = URL(string: "/api/rsync/device-status", relativeTo: base),
              var comps = URLComponents(url: endpoint, resolvingAgainstBaseURL: true)
        else { return nil }
        // Base64 '+', '/' and '=' must be percent-encoded: servers decode a bare '+' as a space.
        comps.percentEncodedQueryItems = [URLQueryItem(name: "pub", value: queryEncoded(pub))]
        guard let url = comps.url else { return nil }
        var r = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
        r.setValue("application/json", forHTTPHeaderField: "accept")
        guard let (data, resp) = try? await URLSession.shared.data(for: r),
              (resp as? HTTPURLResponse)?.statusCode == 200,
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
        else { return nil }
        return parse(obj)
    }
}

/// Self-healing live ASSM base. The cloudflared quick tunnel gets a new URL whenever it restarts
/// (and Cloudflare drops idle quick tunnels), which left every device pushing to a dead URL.
/// If the current base does not answer `/health`, read `live` from the static rizal.pw feed,
/// check that URL's `/health`, and remember it (UserDefaults `rcode.assmLearnedLive`).
@MainActor
public enum ASSMLiveURL {
    public static let learnedKey = ASSMKitConfig.current.defaultsKey("assmLearnedLive")
    private static var lastCheck: Date?

    @discardableResult
    public static func refresh(config: AuthConfig, force: Bool = false) async -> Bool {
        if !force, let t = lastCheck, Date().timeIntervalSince(t) < 20 { return false }
        lastCheck = Date()
        if let cur = ASSMDeviceStatus.liveBase(config: config), await healthy(cur) { return false }
        guard let fb = try? BackendClient.validated(config.assmFallbackBaseURL),
              let url = URL(string: config.assmEnrollEntriesPath, relativeTo: fb) else { return false }
        var r = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
        r.setValue("application/json", forHTTPHeaderField: "accept")
        guard let (data, resp) = try? await URLSession.shared.data(for: r),
              (resp as? HTTPURLResponse)?.statusCode == 200,
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let live = obj["live"] as? String,
              let lu = try? BackendClient.validated(live),
              await healthy(lu) else { return false }
        if UserDefaults.standard.string(forKey: learnedKey) == live { return false }
        UserDefaults.standard.set(live, forKey: learnedKey)
        return true
    }

    public static func healthy(_ base: URL) async -> Bool {
        guard let url = URL(string: "/health", relativeTo: base) else { return false }
        var r = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 8)
        r.setValue("application/json", forHTTPHeaderField: "accept")
        guard let (data, resp) = try? await URLSession.shared.data(for: r),
              (resp as? HTTPURLResponse)?.statusCode == 200,
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return false }
        return obj["ok"] as? Bool == true
    }
}
