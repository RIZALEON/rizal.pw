import Foundation
import AuthenticationServices
#if os(macOS)
import Security
#endif

/// Real Sign in with Apple. Needs the "Sign in with Apple" capability on Rizal's Team to run.
@MainActor
public final class AppleSignInProvider: NSObject, AuthProvider, ASAuthorizationControllerDelegate,
                                 ASAuthorizationControllerPresentationContextProviding {
    public let kind: AuthProviderKind = .apple
    /// Dimmed in SignInView when the running build provably lacks the Sign in with Apple entitlement
    /// (e.g. an unsigned / CODE_SIGNING_ALLOWED=NO Mac build). Unknown (nil) counts as configured.
    public var isConfigured: Bool { Self.hasAppleSignInEntitlement != false }

    /// Shown instead of ASAuthorizationError 1000 (`.unknown`), which is what an unsigned build gets.
    public static let unsignedBuildMessage = "Apple sign-in needs a signed build. Use ASSM for now"

    /// `com.apple.developer.applesignin` on the running process. macOS: read via SecTask (reliable,
    /// public API). iOS/visionOS: SecTask is not public, so nil (unknown) and the button stays enabled;
    /// error 1000 is still mapped to the friendly message.
    public static let hasAppleSignInEntitlement: Bool? = {
        #if os(macOS)
        guard let task = SecTaskCreateFromSelf(nil) else { return nil }
        let value = SecTaskCopyValueForEntitlement(task, "com.apple.developer.applesignin" as CFString, nil)
        if let arr = value as? [String] { return !arr.isEmpty }
        return value != nil
        #else
        return nil
        #endif
    }()

    /// Maps Apple's errors to what the user should see. 1000 (`.unknown`) on a build without the
    /// entitlement -> `unsignedBuildMessage`.
    public static func friendlyError(_ error: Error) -> Error {
        guard let e = error as? ASAuthorizationError else { return error }
        switch e.code {
        case .canceled: return AuthError.cancelled
        case .unknown: return AuthError.unavailable(unsignedBuildMessage)
        default: return error
        }
    }

    private var continuation: CheckedContinuation<ProviderCredential, Error>?
    private var rawNonce = ""

    public func signIn(mode: AuthMode) async throws -> ProviderCredential {
        if Self.hasAppleSignInEntitlement == false { throw AuthError.unavailable(Self.unsignedBuildMessage) }
        rawNonce = Nonce.random()
        let request = ASAuthorizationAppleIDProvider().createRequest()
        request.requestedScopes = [.fullName, .email]
        request.nonce = Nonce.sha256Hex(rawNonce)
        let controller = ASAuthorizationController(authorizationRequests: [request])
        controller.delegate = self
        controller.presentationContextProvider = self
        return try await withCheckedThrowingContinuation { cont in
            continuation = cont
            controller.performRequests()
        }
    }

    /// Apple can revoke a user; RCODE only reports it (sessions end on explicit sign-out).
    public static func credentialState(for userID: String) async -> ASAuthorizationAppleIDProvider.CredentialState {
        await withCheckedContinuation { cont in
            ASAuthorizationAppleIDProvider().getCredentialState(forUserID: userID) { state, _ in
                cont.resume(returning: state)
            }
        }
    }

    public func authorizationController(controller: ASAuthorizationController,
                                 didCompleteWithAuthorization authorization: ASAuthorization) {
        guard let cred = authorization.credential as? ASAuthorizationAppleIDCredential else {
            finish(.failure(AuthError.invalidResponse)); return
        }
        var proof = ["nonce": rawNonce]
        if let t = cred.identityToken.flatMap({ String(data: $0, encoding: .utf8) }) { proof["id_token"] = t }
        if let c = cred.authorizationCode.flatMap({ String(data: $0, encoding: .utf8) }) { proof["authorization_code"] = c }
        let name = [cred.fullName?.givenName, cred.fullName?.familyName].compactMap { $0 }.joined(separator: " ")
        finish(.success(ProviderCredential(provider: .apple, subject: cred.user, email: cred.email,
                                           displayName: name.isEmpty ? nil : name, proof: proof)))
    }

    public func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {
        finish(.failure(Self.friendlyError(error)))   // .canceled -> cancelled (as before); 1000 -> unsignedBuildMessage
    }

    public func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
        PresentationAnchor.current()
    }

    private func finish(_ result: Result<ProviderCredential, Error>) {
        continuation?.resume(with: result)
        continuation = nil
    }
}
