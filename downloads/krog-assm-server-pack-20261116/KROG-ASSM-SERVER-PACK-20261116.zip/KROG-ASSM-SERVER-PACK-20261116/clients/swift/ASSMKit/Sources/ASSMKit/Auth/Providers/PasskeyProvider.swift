import Foundation
import AuthenticationServices

/// Passkeys (WebAuthn) via ASAuthorizationPlatformPublicKeyCredentialProvider.
/// Needs: a real relying-party domain in RCODEAuthConfig.plist, the Associated Domains capability
/// `webcredentials:<domain>`, an apple-app-site-association file on that domain, and the RCODE server
/// to issue challenges and verify results (BACKEND-AUTH-SYNC.md §Passkeys).
@MainActor
public final class PasskeyProvider: NSObject, AuthProvider, ASAuthorizationControllerDelegate,
                             ASAuthorizationControllerPresentationContextProviding {
    public let kind: AuthProviderKind = .passkey
    private let relyingParty: String
    private let server: () -> URL?
    private var continuation: CheckedContinuation<ASAuthorizationCredential, Error>?

    public init(relyingParty: String, server: @escaping () -> URL?) {
        self.relyingParty = relyingParty
        self.server = server
    }

    public var isConfigured: Bool { !AuthConfig.isPlaceholder(relyingParty) }

    private struct Options: Decodable { let challenge: String; let requestId: String; var userId: String?; var userName: String? }
    private struct OptionsBody: Encodable { let mode: String; let device: DeviceInfo }
    private struct FinishBody: Encodable {
        let requestId: String
        let credentialId: String
        let clientDataJson: String
        var authenticatorData: String?
        var signature: String?
        var userHandle: String?
        var attestationObject: String?
        let device: DeviceInfo
    }

    public func signIn(mode: AuthMode) async throws -> ProviderCredential {
        guard isConfigured else { throw AuthError.notConfigured("Passkey relying-party domain") }
        guard let base = server() else { throw AuthError.needsServer("Passkey sign-in") }
        let api = BackendClient(baseURL: base)
        let register = mode == .signUp
        let opts: Options = try await api.send("POST", register ? "/v1/auth/passkey/register/options" : "/v1/auth/passkey/login/options",
                                               body: OptionsBody(mode: register ? "register" : "login", device: .current))
        guard let challenge = Base64URL.decode(opts.challenge) else { throw AuthError.invalidResponse }
        let provider = ASAuthorizationPlatformPublicKeyCredentialProvider(relyingPartyIdentifier: relyingParty)
        let request: ASAuthorizationRequest
        if register {
            guard let uid = opts.userId.flatMap(Base64URL.decode) else { throw AuthError.invalidResponse }
            request = provider.createCredentialRegistrationRequest(challenge: challenge, name: opts.userName ?? "\(ASSMKitConfig.current.appName) user", userID: uid)
        } else {
            request = provider.createCredentialAssertionRequest(challenge: challenge)
        }
        let credential = try await perform(request)

        let body: FinishBody
        if let a = credential as? ASAuthorizationPlatformPublicKeyCredentialAssertion {
            body = FinishBody(requestId: opts.requestId, credentialId: Base64URL.encode(a.credentialID),
                              clientDataJson: Base64URL.encode(a.rawClientDataJSON),
                              authenticatorData: Base64URL.encode(a.rawAuthenticatorData),
                              signature: Base64URL.encode(a.signature), userHandle: Base64URL.encode(a.userID),
                              device: .current)
        } else if let r = credential as? ASAuthorizationPlatformPublicKeyCredentialRegistration {
            body = FinishBody(requestId: opts.requestId, credentialId: Base64URL.encode(r.credentialID),
                              clientDataJson: Base64URL.encode(r.rawClientDataJSON),
                              attestationObject: r.rawAttestationObject.map(Base64URL.encode), device: .current)
        } else { throw AuthError.invalidResponse }

        let session: SessionResponse = try await api.send("POST", register ? "/v1/auth/passkey/register/finish" : "/v1/auth/passkey/login/finish", body: body)
        return ProviderCredential(provider: .passkey, subject: body.credentialId,
                                  displayName: session.account.displayName, session: session)
    }

    private func perform(_ request: ASAuthorizationRequest) async throws -> ASAuthorizationCredential {
        let controller = ASAuthorizationController(authorizationRequests: [request])
        controller.delegate = self
        controller.presentationContextProvider = self
        return try await withCheckedThrowingContinuation { cont in
            continuation = cont
            controller.performRequests()
        }
    }

    public func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
        continuation?.resume(returning: authorization.credential); continuation = nil
    }

    public func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {
        let e: Error = (error as? ASAuthorizationError)?.code == .canceled ? AuthError.cancelled : error
        continuation?.resume(throwing: e); continuation = nil
    }

    public func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
        PresentationAnchor.current()
    }
}
