import Foundation

/// Reads RCODEAuthConfig.plist from the app bundle. Values starting with `REPLACE_` are placeholders.
/// No secrets live here: Google/Microsoft are public (PKCE) clients, so only client IDs are needed.
public nonisolated struct AuthConfig: Sendable {
    public var googleClientID = ""
    public var googleRedirectURI = ""
    public var microsoftClientID = ""
    public var microsoftTenant = "common"
    public var microsoftRedirectURI = ""
    public var passkeyRelyingParty = ""
    public var assmBaseURL = ""
    public var assmEnrollEntriesPath = "/api/rsync/entries"
    /// Static read-only feed (rizal.pw GitHub Pages). Used when the live API is unreachable; its `live` field names the current live URL.
    public var assmFallbackBaseURL = ""
    /// Default profile written into a device.enroll approval. The user can change it on the Approve screen.
    public var assmDefaultProfile = ""
    public var defaultServerURL = ""
    public var cloudKitEnabled = false
    public var cloudKitContainer = ""

    public static let shared = AuthConfig.load()

    public static func isPlaceholder(_ value: String) -> Bool {
        let v = value.trimmingCharacters(in: .whitespaces)
        return v.isEmpty || v.hasPrefix("REPLACE_")
    }

    public static func load(bundle: Bundle = .main) -> AuthConfig {
        var c = AuthConfig()
        guard let url = bundle.url(forResource: ASSMKitConfig.current.authConfigPlistName, withExtension: "plist"),
              let data = try? Data(contentsOf: url),
              let dict = try? PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any]
        else { return c }
        func s(_ k: String) -> String? { dict[k] as? String }
        c.googleClientID = s("GoogleClientID") ?? ""
        c.googleRedirectURI = s("GoogleRedirectURI") ?? ""
        c.microsoftClientID = s("MicrosoftClientID") ?? ""
        c.microsoftTenant = s("MicrosoftTenant") ?? "common"
        c.microsoftRedirectURI = s("MicrosoftRedirectURI") ?? ""
        c.passkeyRelyingParty = s("PasskeyRelyingParty") ?? ""
        c.assmBaseURL = s("ASSMBaseURL") ?? ""
        c.assmEnrollEntriesPath = s("ASSMEnrollEntriesPath") ?? "/api/rsync/entries"
        c.assmFallbackBaseURL = s("ASSMFallbackBaseURL") ?? ""
        c.assmDefaultProfile = s("ASSMDefaultProfile") ?? ""
        c.defaultServerURL = s("DefaultSyncServerURL") ?? ""
        c.cloudKitEnabled = dict["CloudKitEnabled"] as? Bool ?? false
        c.cloudKitContainer = s("CloudKitContainer") ?? ""
        return c
    }
}
