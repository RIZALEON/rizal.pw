import Foundation
import AuthenticationServices

/// Google and Microsoft sign-in: OAuth 2.0 authorization code + PKCE in ASWebAuthenticationSession.
/// Public clients only: no client secret is used or stored. Client IDs come from RCODEAuthConfig.plist.
@MainActor
public final class OAuthPKCEProvider: NSObject, AuthProvider, ASWebAuthenticationPresentationContextProviding {
    public struct Endpoints {
        public let authorize: URL
        public let token: URL
        public let clientID: String
        public let redirectURI: String
        public let scopes: [String]
        public var extra: [String: String] = [:]
    }

    public let kind: AuthProviderKind
    private let endpoints: Endpoints?
    private var session: ASWebAuthenticationSession?

    public init(kind: AuthProviderKind, endpoints: Endpoints?) {
        self.kind = kind
        self.endpoints = endpoints
    }

    public static func google(_ c: AuthConfig) -> OAuthPKCEProvider {
        let ok = !AuthConfig.isPlaceholder(c.googleClientID) && !AuthConfig.isPlaceholder(c.googleRedirectURI)
        return OAuthPKCEProvider(kind: .google, endpoints: ok ? Endpoints(
            authorize: URL(string: "https://accounts.google.com/o/oauth2/v2/auth")!,
            token: URL(string: "https://oauth2.googleapis.com/token")!,
            clientID: c.googleClientID, redirectURI: c.googleRedirectURI,
            scopes: ["openid", "email", "profile"]) : nil)
    }

    public static func microsoft(_ c: AuthConfig) -> OAuthPKCEProvider {
        let ok = !AuthConfig.isPlaceholder(c.microsoftClientID) && !AuthConfig.isPlaceholder(c.microsoftRedirectURI)
        let tenant = c.microsoftTenant.isEmpty ? "common" : c.microsoftTenant
        return OAuthPKCEProvider(kind: .microsoft, endpoints: ok ? Endpoints(
            authorize: URL(string: "https://login.microsoftonline.com/\(tenant)/oauth2/v2.0/authorize")!,
            token: URL(string: "https://login.microsoftonline.com/\(tenant)/oauth2/v2.0/token")!,
            clientID: c.microsoftClientID, redirectURI: c.microsoftRedirectURI,
            scopes: ["openid", "profile", "email", "offline_access"]) : nil)
    }

    public var isConfigured: Bool { endpoints != nil }

    public func signIn(mode: AuthMode) async throws -> ProviderCredential {
        guard let e = endpoints else { throw AuthError.notConfigured("\(kind.displayName) client ID") }
        let verifier = PKCE.verifier()
        let state = Nonce.random(bytes: 16)
        let nonce = Nonce.random(bytes: 16)
        var comps = URLComponents(url: e.authorize, resolvingAgainstBaseURL: false)!
        comps.queryItems = [
            .init(name: "client_id", value: e.clientID),
            .init(name: "redirect_uri", value: e.redirectURI),
            .init(name: "response_type", value: "code"),
            .init(name: "scope", value: e.scopes.joined(separator: " ")),
            .init(name: "code_challenge", value: PKCE.challenge(for: verifier)),
            .init(name: "code_challenge_method", value: "S256"),
            .init(name: "state", value: state),
            .init(name: "nonce", value: nonce),
            .init(name: "prompt", value: "select_account"),
        ] + e.extra.map { .init(name: $0.key, value: $0.value) }
        guard let scheme = URL(string: e.redirectURI)?.scheme else { throw AuthError.notConfigured("\(kind.displayName) redirect URI") }

        let callback = try await authenticate(url: comps.url!, scheme: scheme)
        let items = URLComponents(url: callback, resolvingAgainstBaseURL: false)?.queryItems ?? []
        func q(_ n: String) -> String? { items.first { $0.name == n }?.value }
        if let err = q("error") { throw err == "access_denied" ? AuthError.cancelled : AuthError.server(q("error_description") ?? err) }
        guard q("state") == state, let code = q("code") else { throw AuthError.invalidResponse }

        let tokens = try await exchange(code: code, verifier: verifier, e: e)
        guard let idToken = tokens.idToken else { throw AuthError.invalidResponse }
        let claims = JWT.claims(idToken)
        guard (claims["nonce"] as? String) == nonce,
              let subject = (claims["oid"] as? String) ?? (claims["sub"] as? String) else { throw AuthError.invalidResponse }
        let email = (claims["email"] as? String) ?? (claims["preferred_username"] as? String)
        // Only the id_token goes to the RCODE server; Google/Microsoft access/refresh tokens are not kept.
        return ProviderCredential(provider: kind, subject: subject, email: email,
                                  displayName: claims["name"] as? String,
                                  proof: ["id_token": idToken, "nonce": nonce])
    }

    private struct TokenResponse: Decodable { let idToken: String?; let accessToken: String? }

    private func exchange(code: String, verifier: String, e: Endpoints) async throws -> TokenResponse {
        var req = URLRequest(url: e.token)
        req.httpMethod = "POST"
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "content-type")
        var form = URLComponents()
        form.queryItems = [
            .init(name: "grant_type", value: "authorization_code"),
            .init(name: "code", value: code),
            .init(name: "redirect_uri", value: e.redirectURI),
            .init(name: "client_id", value: e.clientID),
            .init(name: "code_verifier", value: verifier),
        ]
        req.httpBody = form.percentEncodedQuery?.replacingOccurrences(of: "+", with: "%2B").data(using: .utf8)
        let (data, resp) = try await URLSession.shared.data(for: req)
        guard (resp as? HTTPURLResponse)?.statusCode == 200 else { throw AuthError.server("\(kind.displayName) token exchange failed") }
        return try JSONCoding.decoder.decode(TokenResponse.self, from: data)
    }

    private func authenticate(url: URL, scheme: String) async throws -> URL {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<URL, Error>) in
            let s = ASWebAuthenticationSession(url: url, callbackURLScheme: scheme) { @Sendable callback, error in
                if let callback { cont.resume(returning: callback); return }
                if let e = error as? ASWebAuthenticationSessionError, e.code == .canceledLogin {
                    cont.resume(throwing: AuthError.cancelled)
                } else {
                    cont.resume(throwing: error ?? AuthError.invalidResponse)
                }
            }
            s.presentationContextProvider = self
            session = s
            if !s.start() { cont.resume(throwing: AuthError.unavailable("Couldn't open the \(kind.displayName) sign-in window.")) }
        }
    }

    public func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        PresentationAnchor.current()
    }
}
