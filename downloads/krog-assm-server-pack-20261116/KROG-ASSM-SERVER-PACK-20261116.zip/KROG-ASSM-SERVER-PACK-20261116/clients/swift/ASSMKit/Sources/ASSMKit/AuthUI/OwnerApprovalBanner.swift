import SwiftUI

/// Slim first-launch banner: this install is signed in as the bundled owner, but the
/// device still needs one approval from a trusted ASSM device. Chat keeps working offline.
public struct OwnerApprovalBanner: View {
    /// Public initializer (ASSMKit): implicit memberwise inits are internal to the package.
    public init() {}
    @EnvironmentObject private var auth: AuthManager

    public var body: some View {
        if auth.ownerPending != nil || auth.ownerEnrollmentMessage != nil, !auth.ownerDeviceApproved {
            HStack(alignment: .center, spacing: 10) {
                Image(systemName: "iphone.and.arrow.forward")
                    .foregroundStyle(Color(rcodeHex: 0xC17BF2))
                VStack(alignment: .leading, spacing: 2) {
                    Text(auth.ownerBannerTitle)
                        .font(.footnote.weight(.semibold))
                        .foregroundStyle(.white)
                    if let code = auth.ownerPending?.shortCode {
                        Text(code)
                            .font(.system(.body, design: .monospaced).weight(.bold))
                            .foregroundStyle(Color(rcodeHex: 0xC17BF2))
                            .textSelection(.enabled)
                    }
                    if let msg = auth.ownerEnrollmentMessage {
                        Text(msg)
                            .font(.caption2)
                            .foregroundStyle(ASSMTheme.C.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    } else if auth.ownerPending != nil {
                        Text("On a trusted device, open \(ASSMKitConfig.current.appName) › Approve a device and enter this code. Chat works offline in the meantime.")
                            .font(.caption2)
                            .foregroundStyle(ASSMTheme.C.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                Spacer(minLength: 0)
                if auth.ownerPending == nil {
                    Button("Register") { auth.retryOwnerEnrollment() }
                        .font(.caption.weight(.semibold))
                        .buttonStyle(.plain)
                        .foregroundStyle(Color(rcodeHex: 0xC17BF2))
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 8)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color(rcodeHex: 0xC17BF2, opacity: 0.12))
            .overlay(alignment: .bottom) {
                Rectangle().fill(Color(rcodeHex: 0xC17BF2, opacity: 0.35)).frame(height: 1)
            }
        }
    }
}
