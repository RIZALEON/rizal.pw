import Foundation
#if canImport(UIKit)
import UIKit
#endif
#if os(macOS)
import IOKit
#endif

/// This install, as other devices and the server see it.
public struct DeviceInfo: Codable, Hashable, Sendable {
    public let id: String
    public let name: String
    public let os: String
    public let model: String
    public let appVersion: String

    /// Human marketing name, e.g. "iPhone 17e" (not the generic UIDevice "iPhone").
    public var marketingModel: String { model }

    /// Label used for ASSM enroll / trust, e.g. "RCODE iPhone 17e".
    public var assmDeviceName: String { "\(ASSMKitConfig.current.appName) \(marketingModel)" }

    @MainActor public static var current: DeviceInfo {
        let v = ProcessInfo.processInfo.operatingSystemVersion
        let ver = "\(v.majorVersion).\(v.minorVersion)"
        #if os(visionOS)
        let os = "visionOS \(ver)", name = UIDevice.current.name, model = "Apple Vision Pro"
        #elseif canImport(UIKit)
        let pad = UIDevice.current.userInterfaceIdiom == .pad
        let os = (pad ? "iPadOS " : "iOS ") + ver, name = UIDevice.current.name
        let model = marketingName(for: unameMachine()) ?? (pad ? "iPad" : "iPhone")
        #else
        let os = "macOS \(ver)", name = Host.current().localizedName ?? "Mac"
        let model = macMarketingName() ?? "Mac"
        #endif
        let app = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0"
        return DeviceInfo(id: installID, name: name, os: os, model: model, appVersion: app)
    }

    /// Random per-install id kept in the device-only Keychain (survives reinstall on Apple platforms).
    @MainActor private static let installID: String = {
        // Preview / screenshot mode: ephemeral id, no Keychain read or write.
        if ASSMKitConfig.current.isIsolatedLaunch { return "preview-" + UUID().uuidString.lowercased() }
        let store = KeychainStore(service: ASSMKitConfig.current.keychainService("device"))
        if let d = store.data(for: "id"), let s = String(data: d, encoding: .utf8) { return s }
        let id = UUID().uuidString.lowercased()
        try? store.set(Data(id.utf8), for: "id")
        return id
    }()

    /// hw.machine / utsname identifier, e.g. "iPhone18,5".
    public static func unameMachine() -> String {
        var u = utsname()
        uname(&u)
        return withUnsafePointer(to: &u.machine) {
            $0.withMemoryRebound(to: CChar.self, capacity: Int(_SYS_NAMELEN)) { String(cString: $0) }
        }
    }

    /// Known Apple product identifiers → marketing names. Unknown identifiers fall back to nil.
    public static func marketingName(for identifier: String) -> String? {
        let map: [String: String] = [
            // iPhone 17 family (17e is iPhone18,5 — confirmed on Neo's attached 17e)
            "iPhone18,1": "iPhone 17 Pro",
            "iPhone18,2": "iPhone 17 Pro Max",
            "iPhone18,3": "iPhone 17",
            "iPhone18,4": "iPhone Air",
            "iPhone18,5": "iPhone 17e",
            "iPhone17,1": "iPhone 16 Pro",
            "iPhone17,2": "iPhone 16 Pro Max",
            "iPhone17,3": "iPhone 16",
            "iPhone17,4": "iPhone 16 Plus",
            "iPhone17,5": "iPhone 16e",
            "iPhone16,1": "iPhone 15 Pro",
            "iPhone16,2": "iPhone 15 Pro Max",
            "iPhone15,4": "iPhone 15",
            "iPhone15,5": "iPhone 15 Plus",
            "iPhone15,2": "iPhone 14 Pro",
            "iPhone15,3": "iPhone 14 Pro Max",
            "iPhone14,7": "iPhone 14",
            "iPhone14,8": "iPhone 14 Plus",
            "iPhone14,2": "iPhone 13 Pro",
            "iPhone14,3": "iPhone 13 Pro Max",
            "iPhone14,5": "iPhone 13",
            "iPhone14,4": "iPhone 13 mini",
            "iPhone14,6": "iPhone SE (3rd generation)",
            "iPhone13,1": "iPhone 12 mini",
            "iPhone13,2": "iPhone 12",
            "iPhone13,3": "iPhone 12 Pro",
            "iPhone13,4": "iPhone 12 Pro Max",
            "iPad15,8": "iPad (A16)",
            "iPad15,7": "iPad (A16)",
        ]
        if let name = map[identifier] { return name }
        if identifier.hasPrefix("iPhone") { return "iPhone" }
        if identifier.hasPrefix("iPad") { return "iPad" }
        if identifier.hasPrefix("iPod") { return "iPod touch" }
        if identifier.hasPrefix("Reality") || identifier.hasPrefix("AppleTV") { return nil }
        return nil
    }

    #if os(macOS)
    public static func macMarketingName() -> String? {
        // Prefer the IORegistry product name (e.g. "MacBook Pro"); fall back to hw.model.
        let service = IOServiceGetMatchingService(kIOMainPortDefault, IOServiceMatching("IOPlatformExpertDevice"))
        if service != 0 {
            defer { IOObjectRelease(service) }
            if let cf = IORegistryEntryCreateCFProperty(service, "product-name" as CFString, kCFAllocatorDefault, 0)?.takeRetainedValue() {
                if let d = cf as? Data, let s = String(data: d, encoding: .utf8)?.trimmingCharacters(in: .controlCharacters.union(.whitespacesAndNewlines)), !s.isEmpty {
                    return s
                }
                if let s = cf as? String, !s.isEmpty { return s }
            }
        }
        var size = 0
        sysctlbyname("hw.model", nil, &size, nil, 0)
        var buf = [CChar](repeating: 0, count: max(size, 1))
        sysctlbyname("hw.model", &buf, &size, nil, 0)
        let id = String(cString: buf)
        return marketingName(for: id) ?? (id.hasPrefix("Mac") ? "Mac" : nil)
    }
    #endif
}

/// One device on the account (Devices screen).
public struct RegisteredDevice: Codable, Hashable, Identifiable, Sendable {
    public let id: String
    public var name: String
    public var os: String
    public var lastSeen: Date
    /// Trusted devices can approve new devices. Changed only by an explicit tap on a named device.
    public var trusted: Bool
}

/// A one-time link code made on a signed-in device (shown as QR + short code).
public struct DeviceLinkCode: Codable, Sendable {
    public let code: String          // e.g. "K7Q-4MX-29P"
    public let expiresAt: Date
    public var linkUrl: String?

    public var qrPayload: String { linkUrl ?? "\(ASSMKitConfig.current.urlScheme)://link?code=\(code)" }
}
