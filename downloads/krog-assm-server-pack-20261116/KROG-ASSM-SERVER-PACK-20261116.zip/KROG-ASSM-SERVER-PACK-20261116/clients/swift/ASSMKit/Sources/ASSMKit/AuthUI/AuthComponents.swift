import SwiftUI
import CoreImage
import CoreImage.CIFilterBuiltins

/// RCODE's mark (the project has no AppIcon asset yet; swap for Image("AppIcon") once it does).
public struct RCODEAppMark: View {
    /// Public initializer (ASSMKit): implicit memberwise inits are internal to the package.
    public init(size: CGFloat = 64) { self.size = size }
    public var size: CGFloat = 64
    public var body: some View {
        RoundedRectangle(cornerRadius: size * 0.24, style: .continuous)
            .fill(LinearGradient(colors: [Color(hex: "#A97EFE"), Color(hex: "#5B2BD6")], startPoint: .topLeading, endPoint: .bottomTrailing))
            .frame(width: size, height: size)
            .overlay(Text("R").font(.system(size: size * 0.55, weight: .heavy, design: .rounded)).foregroundStyle(.white))
            .shadow(color: .black.opacity(0.35), radius: min(10, size * 0.16), y: 4)
            .accessibilityLabel("\(ASSMKitConfig.current.appName)")
    }
}

public enum AuthIcon {
    case google, apple, email, passkey, microsoft, assm, password

    @ViewBuilder public var view: some View {
        switch self {
        case .google:
            Text("G").font(.system(.body, design: .rounded).weight(.heavy))
                .foregroundStyle(AngularGradient(colors: [.red, .yellow, .green, .blue, .red], center: .center))
        case .apple: Image(systemName: "apple.logo")
        case .email: Image(systemName: "envelope")
        case .passkey: Image(systemName: "person.badge.key")
        case .microsoft:
            Grid(horizontalSpacing: 1.5, verticalSpacing: 1.5) {
                GridRow { Rectangle().fill(Color(hex: "#F25022")); Rectangle().fill(Color(hex: "#7FBA00")) }
                GridRow { Rectangle().fill(Color(hex: "#00A4EF")); Rectangle().fill(Color(hex: "#FFB900")) }
            }.frame(width: 15, height: 15)
        case .assm: Text("Я").font(.system(.body, design: .monospaced).weight(.heavy)).foregroundStyle(Color(hex: "#B388FF"))
        case .password: Image(systemName: "person.text.rectangle")
        }
    }
}

/// Full-width pill like Rakazo's sign-in buttons. Grows with Dynamic Type.
public struct AuthPillButton: View {
    /// Public initializer (ASSMKit): implicit memberwise inits are internal to the package.
    public init(title: String, icon: AuthIcon, highlighted: Bool = false, loading: Bool = false, dimmed: Bool = false, action: @escaping () -> Void) {
        self.title = title; self.icon = icon; self.highlighted = highlighted; self.loading = loading; self.dimmed = dimmed; self.action = action
    }
    public let title: String
    public let icon: AuthIcon
    public var highlighted = false
    public var loading = false
    public var dimmed = false
    public let action: () -> Void

    public var body: some View {
        Button(action: action) {
            HStack(spacing: 10) {
                Group { if loading { ProgressView().controlSize(.small) } else { icon.view } }
                    .frame(minWidth: 20)
                Text(title).font(.body.weight(.medium)).lineLimit(2).minimumScaleFactor(0.85)
            }
            .frame(maxWidth: .infinity, minHeight: 44)
            .padding(.horizontal, 14)
            .contentShape(Capsule())
            .background(Capsule().fill(highlighted ? Color.white.opacity(0.16) : Color.white.opacity(loading ? 0.06 : 0.0)))
            .overlay(Capsule().strokeBorder(Color.white.opacity(highlighted ? 0.45 : 0.35), lineWidth: 1))
            .foregroundStyle(.white.opacity(dimmed ? 0.55 : 1))
        }
        .buttonStyle(.plain)
        .accessibilityHint(dimmed ? "Not set up yet" : "")
    }
}

public struct QRCodeView: View {
    /// Public initializer (ASSMKit): implicit memberwise inits are internal to the package.
    public init(payload: String) { self.payload = payload }
    public let payload: String
    public var body: some View {
        if let img = Self.image(for: payload) {
            Image(decorative: img, scale: 1).interpolation(.none).resizable().scaledToFit()
                .padding(8).background(Color.white).clipShape(RoundedRectangle(cornerRadius: 10))
                .accessibilityLabel("QR code")
        } else {
            Text(payload).font(.caption.monospaced())
        }
    }

    public static func image(for payload: String) -> CGImage? {
        let f = CIFilter.qrCodeGenerator()
        f.message = Data(payload.utf8)
        f.correctionLevel = "M"
        guard let out = f.outputImage?.transformed(by: CGAffineTransform(scaleX: 8, y: 8)) else { return nil }
        return CIContext().createCGImage(out, from: out.extent)
    }
}
