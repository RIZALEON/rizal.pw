import Foundation

/// One synced item (a chat, a message, or a setting). Payload is the app's own JSON for that item.
public struct SyncRecord: Codable, Hashable, Identifiable, Sendable {
    /// Public initializer (ASSMKit): implicit memberwise inits are internal to the package.
    public init(id: String, kind: Kind, updatedAt: Date, deviceId: String, deleted: Bool, payload: Data) {
        self.id = id; self.kind = kind; self.updatedAt = updatedAt; self.deviceId = deviceId; self.deleted = deleted; self.payload = payload
    }
    public enum Kind: String, Codable, Sendable { case chat, message, setting }
    public let id: String
    public let kind: Kind
    public var updatedAt: Date
    public var deviceId: String
    public var deleted: Bool
    public var payload: Data
}

/// Pluggable sync backend. Conflicts resolve last-writer-wins on `updatedAt` (ties: higher deviceId).
@MainActor
public protocol SyncService: AnyObject {
    var name: String { get }
    func push(_ records: [SyncRecord]) async throws
    /// Returns changes after `cursor` and the new cursor to store.
    func pull(since cursor: String?) async throws -> (records: [SyncRecord], cursor: String?)
    /// Live updates (WebSocket / CloudKit push). Optional.
    func startLive(onChange: @escaping @MainActor ([SyncRecord]) -> Void)
    func stopLive()
}

/// Signed out or no server: everything stays on this device (offline mode keeps working).
@MainActor
public final class LocalOnlySyncService: SyncService {
    public let name = "This device only"
    public func push(_ records: [SyncRecord]) async throws {}
    public func pull(since cursor: String?) async throws -> (records: [SyncRecord], cursor: String?) { ([], cursor) }
    public func startLive(onChange: @escaping @MainActor ([SyncRecord]) -> Void) {}
    public func stopLive() {}
}

/// Generic REST + WebSocket backend so Android/Linux/any client can join (BACKEND-AUTH-SYNC.md §Sync).
@MainActor
public final class RESTSyncService: SyncService {
    public let name = "\(ASSMKitConfig.current.appName) server"
    private let api: BackendClient
    private var socket: URLSessionWebSocketTask?
    private var liveTask: Task<Void, Never>?

    public init(api: BackendClient) { self.api = api }

    private struct Changes: Codable { var records: [SyncRecord]; var cursor: String? }

    public func push(_ records: [SyncRecord]) async throws {
        guard !records.isEmpty else { return }
        try await api.raw("POST", "/v1/sync/changes", body: Changes(records: records, cursor: nil))
    }

    public func pull(since cursor: String?) async throws -> (records: [SyncRecord], cursor: String?) {
        var path = "/v1/sync/changes"
        if let cursor, let enc = cursor.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) { path += "?since=\(enc)" }
        let c: Changes = try await api.send("GET", path)
        return (c.records, c.cursor)
    }

    public func startLive(onChange: @escaping @MainActor ([SyncRecord]) -> Void) {
        stopLive()
        guard var comps = URLComponents(url: api.baseURL.appendingPathComponent("v1/sync/stream"), resolvingAgainstBaseURL: false) else { return }
        comps.scheme = comps.scheme == "https" ? "wss" : "ws"
        guard let url = comps.url else { return }
        var req = URLRequest(url: url)
        if let t = api.accessToken { req.setValue("Bearer \(t)", forHTTPHeaderField: "authorization") }
        let ws = URLSession.shared.webSocketTask(with: req)
        socket = ws
        ws.resume()
        liveTask = Task { [weak self] in
            while !Task.isCancelled {
                guard let msg = try? await ws.receive() else { break }
                var data: Data?
                switch msg {
                case .data(let d): data = d
                case .string(let s): data = Data(s.utf8)
                @unknown default: data = nil
                }
                if let data, let c = try? JSONCoding.decoder.decode(Changes.self, from: data) { onChange(c.records) }
                _ = self
            }
        }
    }

    public func stopLive() {
        liveTask?.cancel(); liveTask = nil
        socket?.cancel(with: .goingAway, reason: nil); socket = nil
    }
}
