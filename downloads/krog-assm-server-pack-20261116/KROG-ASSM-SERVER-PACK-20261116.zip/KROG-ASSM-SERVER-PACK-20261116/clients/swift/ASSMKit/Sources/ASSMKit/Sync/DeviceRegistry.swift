import Foundation
import Combine

/// Devices on the RCODE account. Server-backed when a sync server is set; otherwise just this device.
@MainActor
public final class DeviceRegistry: ObservableObject {
    @Published public private(set) var devices: [RegisteredDevice] = []
    @Published public private(set) var lastError: String?

    /// (server URL, access token) when signed in to a server.
    public var backend: () -> BackendClient? = { nil }

    private static let cacheKey = ASSMKitConfig.current.defaultsKey("devices.cache")   // non-secret list only

    public init() {
        if let d = UserDefaults.standard.data(forKey: Self.cacheKey),
           let list = try? JSONCoding.decoder.decode([RegisteredDevice].self, from: d) { devices = list }
        ensureCurrent()
    }

    public var currentID: String { DeviceInfo.current.id }

    public func refresh() async {
        ensureCurrent()
        guard let api = backend() else { return }
        do {
            struct List: Decodable { let devices: [RegisteredDevice] }
            let list: List = try await api.send("GET", "/v1/devices")
            devices = list.devices
            save()
            lastError = nil
        } catch { lastError = error.localizedDescription }
    }

    /// Called after every successful sign-in or device link.
    public func registerCurrent() async {
        ensureCurrent()
        guard let api = backend() else { return }
        _ = try? await api.raw("POST", "/v1/devices/register", body: DeviceInfo.current)
        await refresh()
    }

    /// Removing a device revokes its session on the server. Only from an explicit user action.
    public func remove(_ device: RegisteredDevice) async throws {
        if let api = backend() { try await api.raw("DELETE", "/v1/devices/\(device.id)") }
        devices.removeAll { $0.id == device.id }
        save()
    }

    /// Only for a device the user picked by name on the Devices screen.
    public func setTrusted(_ device: RegisteredDevice, _ trusted: Bool) async throws {
        struct Body: Encodable { let trusted: Bool }
        if let api = backend() { try await api.raw("PATCH", "/v1/devices/\(device.id)", body: Body(trusted: trusted)) }
        if let i = devices.firstIndex(where: { $0.id == device.id }) { devices[i].trusted = trusted }
        save()
    }

    /// On a signed-in device: make a one-time code + QR for a new device.
    public func startLink() async throws -> DeviceLinkCode {
        guard let api = backend() else { throw AuthError.needsServer("Linking Android, Linux or another account's devices") }
        return try await api.send("POST", "/v1/devices/link/start", body: DeviceInfo.current)
    }

    /// On the new device: claim a code typed in or scanned. Returns a session for this device.
    public func claimLink(code: String, server: URL) async throws -> SessionResponse {
        struct Body: Encodable { let code: String; let device: DeviceInfo }
        let clean = code.uppercased().filter { $0.isLetter || $0.isNumber }
        return try await BackendClient(baseURL: server).send("POST", "/v1/devices/link/claim",
                                                             body: Body(code: clean, device: .current))
    }

    public func clearLocal() {
        devices = []
        UserDefaults.standard.removeObject(forKey: Self.cacheKey)
        ensureCurrent()
    }

    private func ensureCurrent() {
        let me = DeviceInfo.current
        if let i = devices.firstIndex(where: { $0.id == me.id }) {
            devices[i].lastSeen = Date(); devices[i].name = me.name; devices[i].os = me.os
        } else {
            devices.insert(RegisteredDevice(id: me.id, name: me.name, os: me.os, lastSeen: Date(), trusted: true), at: 0)
        }
    }

    private func save() {
        if let d = try? JSONCoding.encoder.encode(devices) { UserDefaults.standard.set(d, forKey: Self.cacheKey) }
    }
}
