import Foundation

/// Bridge from the native ASSMKit session to a host app's web ASSM card (GHOSTMACHINE's WKWebView
/// `assm/login/rlogin-strip.js`). That card listens for `window` CustomEvent `"rlogin-session"` with
/// `detail: {handle, from, out}`. ASSMKit only builds the payload / script; the host decides when to
/// post it (e.g. `webView.evaluateJavaScript(ASSMKitBridge.sessionEventScript(...))`).
///
/// Read-only with respect to the web side: does not write the card's localStorage session
/// (`rdragon.csp.rlogin-session.v1`), does not touch ЯSYNC 0.3.2 entries (:8799, rizal.pw/rsync/…),
/// and never includes tokens, keys or passwords. Fields: handle, from (ASSM profile id), out, plus
/// informational `source`, `app`, `deviceApproved`, `at`.
public enum ASSMKitBridge {
    /// Event name the web card listens for.
    public static let sessionEventName = "rlogin-session"

    /// Public session snapshot. `handle` is "@name" (lower-cased, like rlogin-strip.js `H()`).
    public struct SessionEvent: Codable, Equatable, Sendable {
        public var handle: String?
        public var from: String?
        public var out: Bool
        public var source: String
        public var app: String
        public var deviceApproved: Bool
        public var at: String

        public init(handle: String?, from: String?, out: Bool, source: String = "assmkit",
                    app: String = ASSMKitConfig.current.appName, deviceApproved: Bool = false, at: Date = Date()) {
            self.handle = handle; self.from = from; self.out = out; self.source = source
            self.app = app; self.deviceApproved = deviceApproved
            let f = ISO8601DateFormatter(); f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            self.at = f.string(from: at)
        }
    }

    /// rlogin-strip.js `H()`: trim, strip leading "@", lower-case, prefix "@".
    public static func normalizedHandle(_ raw: String?) -> String? {
        var h = (raw ?? "").trimmingCharacters(in: .whitespaces)
        while h.hasPrefix("@") { h.removeFirst() }
        return h.isEmpty ? nil : "@" + h.lowercased()
    }

    /// Snapshot from the AuthManager: the ASSM identity every provider resolves to.
    public static func sessionEvent(from auth: AuthManager) -> SessionEvent {
        guard let acct = auth.account else { return SessionEvent(handle: nil, from: nil, out: true) }
        let owner = OwnerProfile.shared
        let assm = acct.identities.first { $0.provider == .assm && (owner == nil || $0.subject == owner?.profileID) }
        let handle = normalizedHandle(owner?.handle ?? assm?.displayName ?? acct.displayName)
        let from = assm?.subject ?? owner?.profileID
        return SessionEvent(handle: handle, from: from, out: false, deviceApproved: auth.ownerDeviceApproved)
    }

    /// JSON for `detail`. Sorted keys so it is stable.
    public static func sessionEventJSON(_ event: SessionEvent) -> String {
        let enc = JSONEncoder(); enc.outputFormatting = [.sortedKeys, .withoutEscapingSlashes]
        guard let d = try? enc.encode(event), let s = String(data: d, encoding: .utf8) else { return "{\"out\":true}" }
        return s
    }

    /// `sessionEventJSON(sessionEvent(from: .shared))`.
    public static func sessionEventJSON() -> String { sessionEventJSON(sessionEvent(from: AuthManager.shared)) }

    /// JavaScript that dispatches the event on `window` in the web card. JSON is a valid JS literal.
    public static func sessionEventScript(_ event: SessionEvent) -> String {
        "(function(){try{window.dispatchEvent(new CustomEvent(\"\(sessionEventName)\",{detail:\(sessionEventJSON(event))}))}catch(e){}})();"
    }

    public static func sessionEventScript() -> String { sessionEventScript(sessionEvent(from: AuthManager.shared)) }
}
