import Foundation
import Combine

/// Talks to the live ASSM rsync API (`server.py`) to look up a pending request and post a sealed approval.
/// Never talks to the real trusted-devices file; the server does that. The fallback static feed cannot approve.
@MainActor
public final class ASSMApproveClient: ObservableObject {
    @Published public var codeText = ""
    @Published public var profile: String
    @Published public var request: ASSMPendingRequest?
    @Published public var errorMessage: String?
    @Published public var untrusted = false
    @Published public var successMessage: String?
    @Published public var busy = false
    @Published public var deniedLocally = false
    @Published public var approverPub: String?
    @Published public var trustCommand: String?
    @Published public var keyError: String?

    private let config: AuthConfig

    public init(config: AuthConfig = .shared) {
        self.config = config
        let saved = UserDefaults.standard.string(forKey: ASSMKitConfig.current.defaultsKey("assmApproveProfile")) ?? ""
        if !saved.isEmpty {
            self.profile = saved
        } else if !config.assmDefaultProfile.isEmpty && !AuthConfig.isPlaceholder(config.assmDefaultProfile) {
            self.profile = config.assmDefaultProfile
        } else {
            self.profile = "\(ASSMKitConfig.current.appName)"
        }
        refreshApproverKey()
    }

    public func refreshApproverKey() {
        do {
            approverPub = try ASSMApproverKey.publicKeyBase64()
            let name = DeviceInfo.current.marketingModel
            trustCommand = try ASSMApproverKey.trustCommand(deviceName: name)
            keyError = nil
        } catch {
            approverPub = nil
            trustCommand = nil
            keyError = error.localizedDescription
        }
    }

    /// Live API base: env `RCODE_ASSM_BASE_URL`, then UserDefaults override, then the bundled live URL.
    /// The static fallback feed is never used for fetch/approve (it cannot accept an approval).
    public func liveBase() throws -> URL {
        if let env = ProcessInfo.processInfo.environment[ASSMKitConfig.current.baseURLEnvironmentKey], !env.trimmingCharacters(in: .whitespaces).isEmpty {
            return try BackendClient.validated(env)
        }
        if let u = UserDefaults.standard.string(forKey: ASSMKitConfig.current.defaultsKey("assmBaseURL")), !u.trimmingCharacters(in: .whitespaces).isEmpty {
            return try BackendClient.validated(u)
        }
        // Quick-tunnel URL learned from the rizal.pw feed (see ASSMLiveURL) when the bundled one died.
        if let u = UserDefaults.standard.string(forKey: ASSMKitConfig.current.defaultsKey("assmLearnedLive")), !u.trimmingCharacters(in: .whitespaces).isEmpty,
           let v = try? BackendClient.validated(u) {
            return v
        }
        let live = config.assmBaseURL
        guard !AuthConfig.isPlaceholder(live) else {
            throw ASSMApproveError.notConfigured
        }
        return try BackendClient.validated(live)
    }

    /// Accepts 8 digits, `XXXX-XXXX`, or a `rcode://assm-approve?...` QR payload.
    public static func normalizeCode(_ raw: String) -> String? {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if let url = URL(string: trimmed), url.scheme == ASSMKitConfig.current.urlScheme {
            let items = URLComponents(url: url, resolvingAgainstBaseURL: false)?.queryItems ?? []
            let device = items.first(where: { $0.name == "device" })?.value
            let nonce = items.first(where: { $0.name == "nonce" })?.value
            if let device, let nonce { return ASSMRsyncSeal.shortCode(device: device, nonce: nonce) }
        }
        let digits = trimmed.filter(\.isNumber)
        guard digits.count == 8 else { return nil }
        let s = String(digits)
        return String(s.prefix(4)) + "-" + String(s.suffix(4))
    }

    public func applyScanned(_ raw: String) {
        if let c = Self.normalizeCode(raw) {
            codeText = c
            Task { await fetch() }
        } else {
            errorMessage = "That QR or text is not an 8-digit approval code."
        }
    }

    public func fetch() async {
        errorMessage = nil
        untrusted = false
        successMessage = nil
        deniedLocally = false
        request = nil
        guard let code = Self.normalizeCode(codeText) else {
            errorMessage = "Enter the 8-digit code (1234-5678) from the other device."
            return
        }
        codeText = code
        busy = true
        defer { busy = false }
        do {
            let base = try liveBase()
            guard let url = URL(string: "/api/rsync/request/\(code)", relativeTo: base) else {
                throw ASSMApproveError.server(0, "Bad request URL.")
            }
            var r = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
            r.setValue("application/json", forHTTPHeaderField: "accept")
            let (data, resp) = try await URLSession.shared.data(for: r)
            let status = (resp as? HTTPURLResponse)?.statusCode ?? 0
            let obj = (try? JSONSerialization.jsonObject(with: data) as? [String: Any]) ?? [:]
            if status == 404 {
                throw ASSMApproveError.notFound
            }
            if status != 200 {
                let err = obj["error"] as? String ?? "HTTP \(status)"
                if err.lowercased().contains("expir") { throw ASSMApproveError.expired }
                throw ASSMApproveError.server(status, err)
            }
            guard let pending = ASSMPendingRequest.parse(obj) else {
                throw ASSMApproveError.server(status, "The server sent a request that \(ASSMKitConfig.current.appName) could not read.")
            }
            if pending.status == "expired" { throw ASSMApproveError.expired }
            request = pending
            if let p = pending.profile, !p.isEmpty { profile = p }
        } catch let e as ASSMApproveError {
            errorMessage = e.localizedDescription
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    public func approve() async {
        errorMessage = nil
        untrusted = false
        successMessage = nil
        guard let pending = request else {
            errorMessage = "Look up a pending code first."
            return
        }
        guard pending.isPending else {
            errorMessage = pending.isApproved
                ? "This request has already been approved."
                : "This request is not pending."
            return
        }
        let profile = self.profile.trimmingCharacters(in: .whitespaces)
        guard !profile.isEmpty else {
            errorMessage = "Enter the profile to enroll this device into."
            return
        }
        busy = true
        defer { busy = false }
        do {
            let pub = try ASSMApproverKey.publicKeyBase64()
            let unsigned = ASSMRsyncSeal.approveEntry(request: pending, profile: profile)
            // One sign, one biometric prompt. Bots never call this. RCODE never signs mints.
            let parts = ASSMRsyncSeal.sealParts(unsigned, pub: pub)
            let value: String
            do {
                value = try ASSMApproverKey.sign(parts.message)
            } catch let e as ASSMApproverKey.Failure {
                if case .cancelled = e { throw ASSMApproveError.cancelled }
                throw e
            }
            let sealed = ASSMRsyncSeal.finishSeal(body: parts.body, cid: parts.cid, pub: pub, value: value)
            let base = try liveBase()
            guard let url = URL(string: "/api/rsync/approve", relativeTo: base) else {
                throw ASSMApproveError.server(0, "Bad approve URL.")
            }
            var r = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20)
            r.httpMethod = "POST"
            r.setValue("application/json", forHTTPHeaderField: "content-type")
            r.setValue("application/json", forHTTPHeaderField: "accept")
            r.httpBody = try ASSMRsyncSeal.jsonData(sealed)
            let (data, resp) = try await URLSession.shared.data(for: r)
            let status = (resp as? HTTPURLResponse)?.statusCode ?? 0
            let obj = (try? JSONSerialization.jsonObject(with: data) as? [String: Any]) ?? [:]
            let err = obj["error"] as? String ?? ""
            if status == 201 || status == 200 {
                UserDefaults.standard.set(profile, forKey: ASSMKitConfig.current.defaultsKey("assmApproveProfile"))
                successMessage = "Approved \(pending.deviceName) into \(profile)."
                await fetch()
                return
            }
            if status == 403 || err.lowercased().contains("not an active trusted") || err.lowercased().contains("untrusted") {
                untrusted = true
                throw ASSMApproveError.untrusted(err.isEmpty ? "approver is not an ACTIVE trusted device" : err)
            }
            if status == 409 { throw ASSMApproveError.replay }
            if status == 400 && err.lowercased().contains("seal") { throw ASSMApproveError.invalidSeal(err) }
            throw ASSMApproveError.server(status, err.isEmpty ? "HTTP \(status)" : err)
        } catch let e as ASSMApproveError {
            errorMessage = e.localizedDescription
        } catch let e as ASSMApproverKey.Failure {
            errorMessage = e.localizedDescription
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    /// There is no deny endpoint. Dismiss locally; the pending request expires on the server (~5 min).
    public func denyLocally() {
        deniedLocally = true
        successMessage = nil
        errorMessage = "Denied on this device. The request was not sent to the server and will expire on its own (about 5 minutes)."
        request = nil
    }
}

public enum ASSMApproveError: LocalizedError {
    case notConfigured
    case notFound
    case expired
    case untrusted(String)
    case invalidSeal(String)
    case replay
    case server(Int, String)
    case cancelled

    public var errorDescription: String? {
        switch self {
        case .notConfigured:
            return "No live ASSM API URL is configured. Set ASSMBaseURL in \(ASSMKitConfig.current.authConfigPlistName).plist."
        case .notFound:
            return "No pending request for that code. Check the digits, or the request may have expired."
        case .expired:
            return "That request has expired. Ask the other device to start a new sign-in."
        case .untrusted(let server):
            return "This device’s approver key is not on the server’s ACTIVE trusted-devices list. Server said: \(server). Copy the command under “This device’s approver key” and run it on the ASSM server, then try Approve again. \(ASSMKitConfig.current.appName) will not add the key itself."
        case .invalidSeal(let server):
            return "The server rejected the approval signature (\(server))."
        case .replay:
            return "That request was already approved (replay protected)."
        case .server(_, let msg):
            return "ASSM server: \(msg)"
        case .cancelled:
            return "Approval cancelled — Face ID, Touch ID or the device passcode is required."
        }
    }
}
