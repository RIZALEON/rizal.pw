import Foundation
import CryptoKit
import Combine
import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

/// The single source of truth for "who is signed in on this device".
/// - Signed out is a normal state: the offline chat keeps working.
/// - One RCODE account links many providers (Apple, Google, Microsoft, ASSM, password, passkey).
/// - Sessions never expire on their own here: they end only on explicit sign-out or device removal.
@MainActor
public final class AuthManager: ObservableObject {
    public static let shared = AuthManager()

    @Published public private(set) var account: RCODEAccount?
    @Published public private(set) var busy: AuthProviderKind?
    @Published public var lastError: String?
    @Published public var presentSignIn = false
    @Published public private(set) var pendingASSM: ASSMEnrollRequest?
    /// First-launch pending link for the bundled owner identity. Chat keeps working while this is set.
    @Published public private(set) var ownerPending: ASSMEnrollRequest?
    @Published public private(set) var ownerEnrollmentMessage: String?
    @Published public private(set) var ownerDeviceApproved = false
    @Published public var serverURLString: String {
        didSet { UserDefaults.standard.set(serverURLString, forKey: Self.serverKey); reconfigureSync() }
    }

    public let config: AuthConfig
    public let devices = DeviceRegistry()
    public let sync = SyncCoordinator()

    public private(set) lazy var apple = AppleSignInProvider()
    public private(set) lazy var google = OAuthPKCEProvider.google(config)
    public private(set) lazy var microsoft = OAuthPKCEProvider.microsoft(config)
    public private(set) lazy var passkey = PasskeyProvider(relyingParty: config.passkeyRelyingParty) { [weak self] in self?.serverURL }
    public private(set) lazy var password = PasswordProvider { [weak self] in self?.serverURL }
    public private(set) lazy var assm: ASSMProvider = {
        let p = ASSMProvider(config: config)
        p.onPending = { [weak self] in self?.pendingASSM = $0 }
        return p
    }()

    private static let serverKey = ASSMKitConfig.current.defaultsKey("serverURL")
    /// Account record (not secret) → iCloud Keychain so Apple devices on the same Apple ID pick it up.
    private let syncedStore = KeychainStore(service: ASSMKitConfig.current.keychainService("account"), synchronizable: true)
    private let localStore = KeychainStore(service: ASSMKitConfig.current.keychainService("account.local"))
    /// Per-device tokens: this device only, never synced.
    private let tokenStore = KeychainStore(service: ASSMKitConfig.current.keychainService("session"))

    public init(config: AuthConfig = .shared) {
        self.config = config
        if ASSMKitConfig.current.isAuthPreview {
            // Screenshot / preview mode: no Keychain reads, no device key, no enrollment, no sync.
            serverURLString = ""
            account = nil
            presentSignIn = true
            return
        }
        let saved = UserDefaults.standard.string(forKey: Self.serverKey)
        serverURLString = saved ?? (AuthConfig.isPlaceholder(config.defaultServerURL) ? "" : config.defaultServerURL)
        // -RCODERemoteOpen is an isolated preview launch (unsigned test copies): no Keychain reads or writes.
        if !ASSMKitConfig.current.isIsolatedLaunch {
            account = syncedStore.codable(RCODEAccount.self, for: "account") ?? localStore.codable(RCODEAccount.self, for: "account")
            if account == nil { bootstrapOwnerIfNeeded() }
        }
        ownerDeviceApproved = UserDefaults.standard.bool(forKey: Self.ownerApprovedKey)
        presentSignIn = ProcessInfo.processInfo.arguments.contains(ASSMKitConfig.current.launchArg("ShowSignIn"))
        devices.backend = { [weak self] in self?.authedClient }
        reconfigureSync()
    }

    public var isSignedIn: Bool { account != nil }
    public var serverURL: URL? { try? BackendClient.validated(serverURLString) }
    private var tokens: SessionTokens? { tokenStore.codable(SessionTokens.self, for: "tokens") }
    public var authedClient: BackendClient? {
        guard let url = serverURL, let t = tokens else { return nil }
        return BackendClient(baseURL: url, accessToken: t.accessToken)
    }

    public func provider(_ kind: AuthProviderKind) -> AuthProvider {
        switch kind {
        case .apple: apple
        case .google: google
        case .microsoft: microsoft
        case .assm: assm
        case .password: password
        case .passkey: passkey
        }
    }

    // MARK: Sign in / link

    /// Signs in, or links another provider when already signed in.
    public func signIn(with kind: AuthProviderKind, mode: AuthMode = .signIn) async {
        await run(kind) { try await self.provider(kind).signIn(mode: mode) }
    }

    public func signInWithPassword(username: String, password pw: String, mode: AuthMode) async {
        await run(.password) { try await self.password.signIn(username: username, password: pw, mode: mode) }
    }

    /// ASSM username + password: on success the server marks THIS app's device key ACTIVE for the profile,
    /// then the normal flow links the ASSM identity and starts sync. The password is not kept anywhere.
    public func signInWithASSMPassword(user: String, password pw: String) async {
        await run(.assm) {
            let r = try await ASSMPasswordClient.login(user: user, password: pw, config: self.config)
            return ProviderCredential(provider: .assm, subject: r.profile, displayName: r.handle ?? r.profile,
                                      proof: ["method": "password"])
        }
    }

    /// New device: claim a link code from an already signed-in device.
    public func claimDeviceLink(code: String) async {
        await run(nil) {
            guard let url = self.serverURL else { throw AuthError.needsServer("Device linking") }
            let s = try await self.devices.claimLink(code: code, server: url)
            return ProviderCredential(provider: .password, subject: "device-link", displayName: s.account.displayName, session: s)
        }
    }

    public func cancelPending() {
        pendingTask?.cancel()
        pendingASSM = nil
        busy = nil
    }

    private var pendingTask: Task<Void, Never>?

    private func run(_ kind: AuthProviderKind?, _ body: @escaping @MainActor () async throws -> ProviderCredential) async {
        busy = kind ?? .password
        lastError = nil
        let task = Task { @MainActor in
            do {
                let cred = try await body()
                try await self.complete(cred, isDeviceLink: kind == nil)
                self.presentSignIn = false
            } catch AuthError.cancelled {
            } catch is CancellationError {
            } catch { self.lastError = error.localizedDescription }
        }
        pendingTask = task
        await task.value
        busy = nil
    }

    private func complete(_ cred: ProviderCredential, isDeviceLink: Bool) async throws {
        var session = cred.session
        let linking = isSignedIn && !isDeviceLink
        // Exchange a provider proof for an RCODE server session when a server is set.
        if session == nil, let url = serverURL {
            let api = BackendClient(baseURL: url, accessToken: linking ? tokens?.accessToken : nil)
            session = try await api.send("POST", "/v1/auth/\(cred.provider.rawValue)",
                                         body: ProviderExchangeBody(subject: cred.subject, proof: cred.proof,
                                                                    device: .current, link: linking))
        }
        let now = Date()
        let identity = LinkedIdentity(provider: cred.provider, subject: cred.subject, email: cred.email,
                                      displayName: cred.displayName, linkedAt: now, verified: session != nil)
        var acct: RCODEAccount
        if let s = session {
            acct = RCODEAccount(accountId: s.account.id,
                                displayName: s.account.displayName ?? cred.displayName ?? cred.email ?? "\(ASSMKitConfig.current.appName) user",
                                identities: s.account.identities ?? [], createdAt: account?.createdAt ?? now)
            if !isDeviceLink, !acct.identities.contains(where: { $0.id == identity.id }) { acct.identities.append(identity) }
            let t = SessionTokens(accessToken: s.accessToken, refreshToken: s.refreshToken,
                                  expiresAt: s.expiresIn.map { now.addingTimeInterval($0) }, deviceId: s.deviceId)
            try tokenStore.setCodable(t, for: "tokens")
        } else if var existing = account {
            existing.identities.removeAll { $0.id == identity.id }
            existing.identities.append(identity)
            acct = existing
        } else {
            acct = RCODEAccount(accountId: "local-" + UUID().uuidString.lowercased(),
                                displayName: cred.displayName ?? cred.email ?? cred.provider.displayName + " user",
                                identities: [identity], createdAt: now)
        }
        save(acct)
        unifyOnOwnerIdentity(after: cred)
        reconfigureSync()
        await devices.registerCurrent()
    }

    // MARK: One identity (ASSMKit)

    /// Every provider (ASSM, Apple, Google/Microsoft OAuth PKCE, password, passkey, device link) ends on the
    /// same ASSM identity from the bundled OwnerProfile (e.g. ЯID-0001-3QQS) and the same per-app device-key
    /// session. Adds the owner ASSM identity to the account if missing (unverified), treats an ASSM approval
    /// for the owner profile as this device's owner approval, and otherwise starts the owner device-key
    /// enrollment (an 8-digit code Rizal approves once from a trusted device). Never approves anything itself.
    public func unifyOnOwnerIdentity(after cred: ProviderCredential) {
        guard !ASSMKitConfig.current.isIsolatedLaunch,
              let owner = OwnerProfile.shared, owner.isConfigured, var acct = account else { return }
        if !acct.identities.contains(where: { $0.provider == .assm && $0.subject == owner.profileID }) {
            acct.identities.append(LinkedIdentity(provider: .assm, subject: owner.profileID, email: nil,
                                                  displayName: owner.handle.isEmpty ? owner.displayName : owner.handle,
                                                  linkedAt: Date(), verified: false))
            save(acct)
        }
        UserDefaults.standard.removeObject(forKey: Self.ownerSkippedKey)
        if cred.provider == .assm, cred.subject == owner.profileID {
            // The ASSM provider's approval used this app's device key: same key the owner session uses.
            markOwnerApproved(profile: owner.profileID)
            return
        }
        startOwnerEnrollmentIfNeeded()
    }

    /// The ASSM identity every sign-in method resolves to (from OwnerProfile.plist), if bundled.
    public var ownerIdentity: String? { OwnerProfile.shared.flatMap { $0.isConfigured ? $0.profileID : nil } }

    /// Sets `ASSMKitConfig.current` and returns the shared manager. Call from the host app's
    /// `@StateObject` initializer so the config is in place before anything touches the Keychain.
    /// A config that uses a reserved RSIGN / RMAIL name is refused (the previous config stays active).
    public static func configured(_ kit: ASSMKitConfig) -> AuthManager {
        do {
            try kit.validate()
            ASSMKitConfig.current = kit
        } catch {
            assertionFailure(error.localizedDescription)
        }
        return shared
    }

    public func unlink(_ identity: LinkedIdentity) async {
        guard var acct = account, acct.identities.count > 1 else {
            lastError = "Keep at least one sign-in method, or sign out instead."; return
        }
        if let api = authedClient {
            do { try await api.raw("DELETE", "/v1/account/identities/\(identity.provider.rawValue)/\(identity.subject)") }
            catch { lastError = error.localizedDescription; return }
        }
        acct.identities.removeAll { $0.id == identity.id }
        if identity.provider == .assm { ASSMDeviceKey.forget() }
        save(acct)
    }

    /// Explicit sign-out: revokes this device's session and clears local account data. Offline chat still works.
    public func signOut() async {
        if let api = authedClient { _ = try? await api.raw("POST", "/v1/auth/logout") }
        tokenStore.remove("tokens")
        syncedStore.remove("account")
        localStore.remove("account")
        account = nil
        ownerPoll?.cancel(); ownerPoll = nil
        ownerPending = nil
        ownerDeviceApproved = false
        UserDefaults.standard.removeObject(forKey: Self.ownerApprovedKey)
        UserDefaults.standard.set(true, forKey: Self.ownerSkippedKey)
        devices.clearLocal()
        sync.reset()
    }

    private func save(_ acct: RCODEAccount) {
        account = acct
        do { try syncedStore.setCodable(acct, for: "account") }
        catch { try? localStore.setCodable(acct, for: "account") }   // no Keychain Sharing entitlement yet
    }

    private static let ownerApprovedKey = ASSMKitConfig.current.defaultsKey("ownerDeviceApproved")
    private static let ownerPendingCodeKey = ASSMKitConfig.current.defaultsKey("ownerPendingCode")
    private static let ownerSkippedKey = ASSMKitConfig.current.defaultsKey("ownerPresetSkipped")
    private var ownerPoll: Task<Void, Never>?

    /// Device-aware banner title ("Approve this iPhone once" on the 17e).
    public var ownerBannerTitle: String {
        #if os(iOS)
        let pad: Bool
        #if canImport(UIKit)
        pad = UIDevice.current.userInterfaceIdiom == .pad
        #else
        pad = false
        #endif
        return pad ? "Approve this iPad once" : "Approve this iPhone once"
        #else
        return "Approve this Mac once"
        #endif
    }

    /// Local account from the bundled public OwnerProfile. No tokens or secrets are stored or created here.
    private func bootstrapOwnerIfNeeded() {
        guard !UserDefaults.standard.bool(forKey: Self.ownerSkippedKey),
              let owner = OwnerProfile.shared, owner.isConfigured else { return }
        let now = Date()
        let identity = LinkedIdentity(provider: .assm, subject: owner.profileID, email: nil,
                                      displayName: owner.handle.isEmpty ? owner.displayName : owner.handle,
                                      linkedAt: now, verified: false)
        let acct = RCODEAccount(accountId: "local-owner-" + owner.profileID,
                                displayName: owner.displayName,
                                identities: [identity], createdAt: now)
        save(acct)
    }

    /// Creates this install's device key and registers a pending ASSM link for the owner identity.
    /// Requires a biometric/passcode unlock to sign the request. Chat keeps working if this is deferred.
    public func startOwnerEnrollmentIfNeeded() {
        if ASSMKitConfig.current.isIsolatedLaunch { return }
        let args = ProcessInfo.processInfo.arguments
        if args.contains(ASSMKitConfig.current.launchArg("ThemePreview")) || args.contains(ASSMKitConfig.current.launchArg("ApprovePreview")) { return }
        guard !ownerDeviceApproved,
              let owner = OwnerProfile.shared, owner.isConfigured,
              account?.identities.contains(where: { $0.provider == .assm && $0.subject == owner.profileID }) == true
        else { return }
        if ownerPoll != nil || ownerPending != nil { return }
        ownerPoll = Task { await self.runOwnerEnrollment(profile: owner.profileID) }
    }

    public func retryOwnerEnrollment() {
        ownerPoll?.cancel()
        ownerPoll = nil
        ownerPending = nil
        UserDefaults.standard.removeObject(forKey: Self.ownerPendingCodeKey)
        startOwnerEnrollmentIfNeeded()
    }

    private func runOwnerEnrollment(profile: String) async {
        ownerEnrollmentMessage = nil
        await ASSMLiveURL.refresh(config: config)   // dead quick tunnel -> learn the new live URL first
        do {
            let key = try ASSMDeviceKey.loadOrCreate()
            let pub = key.publicKey.x963Representation.base64EncodedString()
            // Already trusted or enrolled (e.g. this 17e key is on the server list): no banner, start sync.
            if let st = await ASSMDeviceStatus.fetch(pub: pub, config: config), st.isApproved {
                markOwnerApproved(profile: st.profile ?? profile)
                return
            }
            try await UnlockGate.require(reason: "Unlock to register this device with your ASSM account")
            let req = try ASSMEnrollRequest.make(key: key, deviceName: DeviceInfo.current.assmDeviceName)
            ownerPending = req
            UserDefaults.standard.set(req.shortCode, forKey: Self.ownerPendingCodeKey)
            var posted = await postOwnerRequest(req)
            let deadline = Date().addingTimeInterval(10 * 60)
            while Date() < deadline, !Task.isCancelled {
                if await ownerIsApproved(pub: pub, request: req, profile: profile) {
                    markOwnerApproved(profile: profile)
                    return
                }
                if !posted { posted = await postOwnerRequest(req) }
                try await Task.sleep(nanoseconds: 5_000_000_000)
            }
            if ownerPending != nil {
                ownerEnrollmentMessage = "Still waiting for approval. The request expires in about 5 minutes; tap to try again."
            }
        } catch AuthError.cancelled, is CancellationError {
            ownerEnrollmentMessage = "Unlock to register this device, then approve it from a trusted device."
        } catch {
            ownerEnrollmentMessage = error.localizedDescription
        }
    }

    private func postOwnerRequest(_ req: ASSMEnrollRequest) async -> Bool {
        guard let base = ASSMDeviceStatus.liveBase(config: config),
              let url = URL(string: "/api/rsync/request", relativeTo: base) else { return false }
        var r = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
        r.httpMethod = "POST"
        r.setValue("application/json", forHTTPHeaderField: "content-type")
        r.setValue("application/json", forHTTPHeaderField: "accept")
        let body: [String: String] = ["t": "device.request", "device": req.device, "nonce": req.nonce,
                                      "req_ts": req.reqTs, "req_sig": req.reqSig, "device_name": req.deviceName]
        r.httpBody = try? JSONSerialization.data(withJSONObject: body)
        guard let (_, resp) = try? await URLSession.shared.data(for: r),
              let code = (resp as? HTTPURLResponse)?.statusCode else { return false }
        return code == 201 || code == 200
    }

    /// True if this device key is trusted, enrolled, or its pending request has been approved in the entries feed.
    private func ownerIsApproved(pub: String, request req: ASSMEnrollRequest, profile: String) async -> Bool {
        if let st = await ASSMDeviceStatus.fetch(pub: pub, config: config), st.isApproved {
            return true
        }
        // Fallback: live entries, then the static feed (same discovery as ASSMProvider).
        let live = ASSMDeviceStatus.liveBase(config: config)
        let fallback = try? BackendClient.validated(config.assmFallbackBaseURL)
        for base in [live, fallback].compactMap({ $0 }) {
            guard let url = URL(string: config.assmEnrollEntriesPath, relativeTo: base) else { continue }
            var r = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
            r.setValue("application/json", forHTTPHeaderField: "accept")
            guard let (data, resp) = try? await URLSession.shared.data(for: r),
                  (resp as? HTTPURLResponse)?.statusCode == 200,
                  let obj = try? JSONSerialization.jsonObject(with: data) else { continue }
            let entries: [[String: Any]]
            if let arr = obj as? [[String: Any]] { entries = arr }
            else if let dict = obj as? [String: Any] { entries = (dict["entries"] as? [[String: Any]]) ?? [] }
            else { continue }
            if entries.contains(where: {
                ($0["t"] as? String) == "device.enroll" && ($0["device"] as? String) == req.device
                    && ($0["nonce"] as? String) == req.nonce
                    && ($0["profile"] as? String == profile || profile.isEmpty)
            }) { return true }
        }
        return false
    }


    private func markOwnerApproved(profile: String) {
        ownerPending = nil
        ownerEnrollmentMessage = nil
        ownerDeviceApproved = true
        UserDefaults.standard.set(true, forKey: Self.ownerApprovedKey)
        UserDefaults.standard.removeObject(forKey: Self.ownerPendingCodeKey)
        if var acct = account {
            if let i = acct.identities.firstIndex(where: { $0.provider == .assm && $0.subject == profile }) {
                acct.identities[i].verified = true
                save(acct)
            }
        }
        reconfigureSync()
    }

    private func reconfigureSync() {
        if isSignedIn, ownerDeviceApproved, let owner = OwnerProfile.shared,
           let base = ASSMDeviceStatus.liveBase(config: config) {
            let svc = ASSMSyncService(base: base, identity: owner.profileID, deviceName: DeviceInfo.current.assmDeviceName, config: config)
            sync.configureService(svc)
            return
        }
        sync.configure(api: isSignedIn ? authedClient : nil, config: isSignedIn ? config : AuthConfig())
    }
}
