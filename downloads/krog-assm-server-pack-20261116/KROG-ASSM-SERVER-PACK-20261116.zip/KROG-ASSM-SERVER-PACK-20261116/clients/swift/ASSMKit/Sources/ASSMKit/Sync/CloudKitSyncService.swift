import Foundation
import CloudKit

/// Apple-device sync through the user's private iCloud database (zone "RCODESync").
/// STUB: compiles and follows CloudKit's zone-changes pattern but is untested. It is only created when
/// `CloudKitEnabled` is true in RCODEAuthConfig.plist, because touching CKContainer without the iCloud
/// capability crashes the app. Rizal must enable iCloud → CloudKit with container iCloud.info.rizal.rcode.
@MainActor
public final class CloudKitSyncService: SyncService {
    public let name = "iCloud (CloudKit)"
    private let database: CKDatabase
    private let zoneID = CKRecordZone.ID(zoneName: ASSMKitConfig.current.cloudKitZoneName, ownerName: CKCurrentUserDefaultName)
    private var zoneReady = false

    public init(containerIdentifier: String) {
        database = CKContainer(identifier: containerIdentifier).privateCloudDatabase
    }

    private func ensureZone() async throws {
        guard !zoneReady else { return }
        _ = try await database.modifyRecordZones(saving: [CKRecordZone(zoneID: zoneID)], deleting: [])
        zoneReady = true
    }

    public func push(_ records: [SyncRecord]) async throws {
        guard !records.isEmpty else { return }
        try await ensureZone()
        let ck = records.map { r -> CKRecord in
            let rec = CKRecord(recordType: "SyncRecord", recordID: CKRecord.ID(recordName: r.id, zoneID: zoneID))
            rec["kind"] = r.kind.rawValue
            rec["updatedAt"] = r.updatedAt
            rec["deviceId"] = r.deviceId
            rec["deleted"] = r.deleted
            rec["payload"] = r.payload
            return rec
        }
        _ = try await database.modifyRecords(saving: ck, deleting: [], savePolicy: .changedKeys)
    }

    public func pull(since cursor: String?) async throws -> (records: [SyncRecord], cursor: String?) {
        try await ensureZone()
        var token: CKServerChangeToken?
        if let cursor, let d = Data(base64Encoded: cursor) {
            token = try? NSKeyedUnarchiver.unarchivedObject(ofClass: CKServerChangeToken.self, from: d)
        }
        var out: [SyncRecord] = []
        var more = true
        while more {
            let changes = try await database.recordZoneChanges(inZoneWith: zoneID, since: token)
            for (_, result) in changes.modificationResultsByID {
                guard let rec = try? result.get().record,
                      let kind = (rec["kind"] as? String).flatMap(SyncRecord.Kind.init(rawValue:)) else { continue }
                out.append(SyncRecord(id: rec.recordID.recordName, kind: kind,
                                      updatedAt: rec["updatedAt"] as? Date ?? .distantPast,
                                      deviceId: rec["deviceId"] as? String ?? "",
                                      deleted: rec["deleted"] as? Bool ?? false,
                                      payload: rec["payload"] as? Data ?? Data()))
            }
            token = changes.changeToken
            more = changes.moreComing
        }
        let next = token.flatMap { try? NSKeyedArchiver.archivedData(withRootObject: $0, requiringSecureCoding: true) }?.base64EncodedString()
        return (out, next)
    }

    // TODO: CKDatabaseSubscription + silent push for live updates (needs Push Notifications capability).
    public func startLive(onChange: @escaping @MainActor ([SyncRecord]) -> Void) {}
    public func stopLive() {}
}
