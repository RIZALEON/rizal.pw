import Foundation

/// Per-host-app identity for ASSMKit. Every Keychain service, UserDefaults key, URL scheme,
/// launch argument and user-facing app name the moved RCODE code used to hard-code now comes
/// from here. `ASSMKitConfig.rcode` reproduces RCODE's original strings byte-for-byte, so keys
/// that RCODE devices already enrolled keep working. Another app (GHOSTMACHINE) sets its own
/// `keychainPrefix`, which gives it its own device key and its own Keychain items.
///
/// Set `ASSMKitConfig.current` once, before the first use of `AuthManager.shared` (use
/// `AuthManager.configured(_:)` from a property initializer). Never contains secrets.
public nonisolated struct ASSMKitConfig: Sendable, Equatable {
    /// User-facing app name ("RCODE", "GHOSTMACHINE"): device labels, sign-in copy.
    public var appName: String
    /// Keychain service prefix. Services are `<prefix>.assm-device-key`, `.account`, `.account.local`,
    /// `.session`, `.device`, `.assm-approver-key` (also the approver key's application tag).
    public var keychainPrefix: String
    /// UserDefaults key prefix, e.g. `rcode` -> `rcode.serverURL`, `rcode.sync.cursor`.
    public var defaultsPrefix: String
    /// Custom URL scheme for QR / link payloads (`rcode://assm-approve?...`).
    public var urlScheme: String
    /// Launch-argument prefix: `-<prefix>ShowSignIn`, `-<prefix>ThemePreview`, `-<prefix>ApprovePreview`.
    public var launchArgPrefix: String
    /// Environment variable that overrides the live ASSM API base URL.
    public var baseURLEnvironmentKey: String
    /// Bundled plist names (in the host app's main bundle) for AuthConfig and the owner's public profile.
    public var authConfigPlistName: String
    public var ownerProfilePlistName: String
    /// CloudKit zone name (only used when CloudKitEnabled is true in the auth config plist).
    public var cloudKitZoneName: String
    /// Bundle the plists are read from.
    public var bundle: Bundle

    public init(appName: String,
                keychainPrefix: String,
                defaultsPrefix: String,
                urlScheme: String,
                launchArgPrefix: String,
                baseURLEnvironmentKey: String,
                authConfigPlistName: String,
                ownerProfilePlistName: String = "OwnerProfile",
                cloudKitZoneName: String,
                bundle: Bundle = .main) {
        self.appName = appName
        self.keychainPrefix = keychainPrefix
        self.defaultsPrefix = defaultsPrefix
        self.urlScheme = urlScheme
        self.launchArgPrefix = launchArgPrefix
        self.baseURLEnvironmentKey = baseURLEnvironmentKey
        self.authConfigPlistName = authConfigPlistName
        self.ownerProfilePlistName = ownerProfilePlistName
        self.cloudKitZoneName = cloudKitZoneName
        self.bundle = bundle
    }

    /// RCODE's original values. Do not change: existing RCODE Keychain items and enrolled keys depend on them.
    public static let rcode = ASSMKitConfig(
        appName: "RCODE",
        keychainPrefix: "info.rizal.rcode",
        defaultsPrefix: "rcode",
        urlScheme: "rcode",
        launchArgPrefix: "RCODE",
        baseURLEnvironmentKey: "RCODE_ASSM_BASE_URL",
        authConfigPlistName: "RCODEAuthConfig",
        cloudKitZoneName: "RCODESync")

    /// GHOSTMACHINE-macOS: its own Keychain service and defaults, so its own device key (approved once by Rizal).
    public static let ghostmachineMac = ASSMKitConfig(
        appName: "GHOSTMACHINE",
        keychainPrefix: "info.rizal.ghostmachine.mac",
        defaultsPrefix: "ghostmachine.mac",
        urlScheme: "ghostmachine",
        launchArgPrefix: "GHOSTMACHINE",
        baseURLEnvironmentKey: "GHOSTMACHINE_ASSM_BASE_URL",
        authConfigPlistName: "ASSMAuthConfig",
        cloudKitZoneName: "GHOSTMACHINESync")

    /// GHOSTMACHINE-iOS: separate service from the Mac app, so each device/app pair gets its own key.
    public static let ghostmachineIOS = ASSMKitConfig(
        appName: "GHOSTMACHINE",
        keychainPrefix: "info.rizal.ghostmachine.ios",
        defaultsPrefix: "ghostmachine.ios",
        urlScheme: "ghostmachine",
        launchArgPrefix: "GHOSTMACHINE",
        baseURLEnvironmentKey: "GHOSTMACHINE_ASSM_BASE_URL",
        authConfigPlistName: "ASSMAuthConfig",
        cloudKitZoneName: "GHOSTMACHINESync")

    /// The GHOSTMACHINE preset for the platform being compiled.
    public static var ghostMachine: ASSMKitConfig {
        #if os(macOS)
        return .ghostmachineMac
        #else
        return .ghostmachineIOS
        #endif
    }

    // MARK: Reserved names (never used, never collided with)

    /// Keychain service, tag prefix and access group owned by RSIGN / RMAIL. ASSMKit refuses them.
    public static let reservedServices: Set<String> = ["info.rizal.rsign.assm"]
    public static let reservedPrefixes: [String] = ["info.rizal.rsign."]
    public static let reservedAccessGroups: Set<String> = ["7D3P5F4V9M.info.rizal.rdragon.rmail"]

    /// True if `name` is (or falls under) a reserved RSIGN / RMAIL Keychain name.
    public static func isReserved(_ name: String) -> Bool {
        let n = name.trimmingCharacters(in: .whitespaces)
        if reservedServices.contains(n) || reservedAccessGroups.contains(n) { return true }
        if n == "info.rizal.rsign" { return true }
        return reservedPrefixes.contains { n.hasPrefix($0) }
    }

    public enum ValidationError: Error, Equatable, LocalizedError {
        case reservedName(String)
        public var errorDescription: String? {
            switch self { case .reservedName(let n): "ASSMKit refuses reserved Keychain name \(n) (RSIGN/RMAIL)." }
        }
    }

    /// Every Keychain service / tag this config would use.
    public var keychainNames: [String] {
        ["assm-device-key", "assm-approver-key", "account", "account.local", "session", "device"].map(keychainService)
    }

    /// Throws if this config would use or collide with a reserved RSIGN / RMAIL name.
    public func validate() throws {
        for n in [keychainPrefix] + keychainNames where Self.isReserved(n) { throw ValidationError.reservedName(n) }
    }

    /// The active config. Defaults to RCODE so RCODE needs no setup.
    nonisolated(unsafe) public static var current: ASSMKitConfig = .rcode

    /// `<keychainPrefix>.<suffix>`
    public func keychainService(_ suffix: String) -> String { keychainPrefix + "." + suffix }
    /// `<defaultsPrefix>.<suffix>`
    public func defaultsKey(_ suffix: String) -> String { defaultsPrefix + "." + suffix }
    /// `-<launchArgPrefix><name>`
    public func launchArg(_ name: String) -> String { "-" + launchArgPrefix + name }
    /// True when the process was launched with `-<launchArgPrefix><name>`.
    public func hasLaunchArg(_ name: String) -> Bool { ProcessInfo.processInfo.arguments.contains(launchArg(name)) }

    /// Preview / screenshot mode: `-<prefix>AuthPreview`. AuthManager then skips Keychain reads,
    /// device-key creation and enrollment, so a sign-in screen can be shown without touching keys.
    public var isAuthPreview: Bool { hasLaunchArg("AuthPreview") }

    /// Isolated launch (unsigned test copies): `-<prefix>AuthPreview` or `-<prefix>RemoteOpen` (RCODE's REMOTE
    /// screen, moved here from RCODE's AuthManager). No Keychain account read, no device key, no enrollment.
    /// Unlike AuthPreview, RemoteOpen does not force the sign-in sheet open.
    public var isIsolatedLaunch: Bool { isAuthPreview || hasLaunchArg("RemoteOpen") }
}
