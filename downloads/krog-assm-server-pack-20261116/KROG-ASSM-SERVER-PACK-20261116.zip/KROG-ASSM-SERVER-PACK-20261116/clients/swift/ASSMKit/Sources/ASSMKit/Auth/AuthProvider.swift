import Foundation

/// A sign-in method. Providers only run their own UI and return a credential;
/// `AuthManager` turns that into an RCODE account/session and links identities.
@MainActor
public protocol AuthProvider: AnyObject {
    var kind: AuthProviderKind { get }
    /// false while required config (client id, endpoint, relying party, ...) is still a placeholder.
    var isConfigured: Bool { get }
    func signIn(mode: AuthMode) async throws -> ProviderCredential
}
