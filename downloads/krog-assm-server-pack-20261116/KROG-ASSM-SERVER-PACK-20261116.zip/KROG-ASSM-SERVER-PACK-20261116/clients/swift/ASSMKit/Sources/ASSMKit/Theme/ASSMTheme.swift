// ASSMTheme.swift — visual tokens used by ASSMKit's sign-in / approve / account views.
// Moved from RCODE's RCodeTheme (RCODE keeps `typealias RCodeTheme = ASSMTheme`), values unchanged.

import SwiftUI

extension Color {
    public init(assmHex hex: UInt32, opacity: Double = 1) {
        self.init(.sRGB,
                  red:   Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8)  & 0xFF) / 255,
                  blue:  Double(hex & 0xFF) / 255,
                  opacity: opacity)
    }

    /// Same as `init(assmHex:opacity:)`; RCODE's original name, moved here from RCodeTheme.swift.
    public init(rcodeHex hex: UInt32, opacity: Double = 1) {
        self.init(assmHex: hex, opacity: opacity)
    }

    /// "#RRGGBB" / "RRGGBB" string form, moved here from RCODE's ContentView.swift (unchanged).
    public init(hex: String) {
        let scanner = Scanner(string: hex.trimmingCharacters(in:CharacterSet.alphanumerics.inverted))
        var hexNumber: UInt64 = 0
        scanner.scanHexInt64(&hexNumber)
        let r = Double((hexNumber & 0xff0000) >> 16) / 255
        let g = Double((hexNumber & 0x00ff00) >> 8) / 255
        let b = Double(hexNumber & 0x0000ff) / 255
        self.init(.sRGB, red: r, green: g, blue: b, opacity: 1)
    }
}

public enum ASSMTheme {
    public enum C {
        public static let background      = Color(assmHex: 0x0B0B0E)
        public static let userBubble      = Color(assmHex: 0x8A5CD6)
        public static let userBubbleTop   = Color(assmHex: 0x9466E0)
        public static let assistantBubble = Color(assmHex: 0x232327)
        public static let bubbleText      = Color.white
        public static let codeCard        = Color(assmHex: 0x2C2C31)
        public static let codeLabelBar    = Color(assmHex: 0x36363C)
        public static let secondary       = Color(assmHex: 0x8E8E93)
        public static let headerGlass     = Color(assmHex: 0x1C1C20, opacity: 0.80)
        public static let inputGlass      = Color(assmHex: 0x1E1E22)
        public static let glassCard       = Color(assmHex: 0x3A3A3E, opacity: 0.70)
        public static let glassBorder     = Color.white.opacity(0.12)
        public static let sendFill        = Color.white
        public static let sendGlyph       = Color.black
    }

    public enum Syntax {
        public static let keyword  = Color(assmHex: 0xC17BF2)
        public static let function = Color(assmHex: 0x6CB6FF)
        public static let type     = Color(assmHex: 0xE8A86B)
        public static let comment  = Color(assmHex: 0x7A7A80)
        public static let text     = Color(assmHex: 0xE6E6EA)
        public static let string   = Color(assmHex: 0xE8A86B)
        public static let number   = Color(assmHex: 0xC17BF2)
    }

    public enum R {
        public static let bubble: CGFloat    = 22
        public static let glassCard: CGFloat = 16
        public static let codeCard: CGFloat  = 14
    }

    public enum F {
        public static let body      = Font.system(size: 17)
        public static let title     = Font.system(size: 20, weight: .semibold)
        public static let timestamp = Font.system(size: 13, weight: .semibold)
        public static let code      = Font.system(size: 13, design: .monospaced)
        public static let codeLabel = Font.system(size: 12, weight: .semibold, design: .monospaced)
    }
}
