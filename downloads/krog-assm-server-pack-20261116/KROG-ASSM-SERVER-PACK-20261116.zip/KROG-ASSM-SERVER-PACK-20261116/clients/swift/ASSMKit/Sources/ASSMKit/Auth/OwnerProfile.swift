import Foundation

/// Bundled public ASSM identity for this install's owner. No tokens, secrets, or private keys.
public nonisolated struct OwnerProfile: Sendable {
    public var profileID: String
    public var handle: String
    public var displayName: String

    public static let shared = OwnerProfile.load()

    public var isConfigured: Bool { !profileID.isEmpty }

    public static func load(bundle: Bundle = .main) -> OwnerProfile? {
        guard let url = bundle.url(forResource: ASSMKitConfig.current.ownerProfilePlistName, withExtension: "plist"),
              let data = try? Data(contentsOf: url),
              let dict = try? PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any]
        else { return nil }
        let id = (dict["ASSMProfileID"] as? String ?? "").trimmingCharacters(in: .whitespaces)
        guard !id.isEmpty, !id.hasPrefix("REPLACE_") else { return nil }
        let handle = (dict["Handle"] as? String ?? "").trimmingCharacters(in: .whitespaces)
        let name = (dict["DisplayName"] as? String ?? "").trimmingCharacters(in: .whitespaces)
        return OwnerProfile(profileID: id,
                            handle: handle,
                            displayName: name.isEmpty ? (handle.isEmpty ? id : handle) : name)
    }
}
