import Foundation
import CryptoKit

/// REST chat/message sync against the live ASSM API (`POST /v1/sync/changes` and `/v1/sync/pull`).
/// Each call is signed by this install's ASSM device key (P-256). The server accepts the key only
/// after it is enrolled or on the trusted-devices list. RCODE never signs mints with this key.
@MainActor
public final class ASSMSyncService: SyncService {
    public let name = "ASSM sync"
    public let identity: String
    private let base: URL
    private let deviceName: String
    /// When set, the base is re-resolved on every call (learned live URL) and a dead tunnel is healed.
    private var config: AuthConfig?

    public init(base: URL, identity: String, deviceName: String) {
        self.base = base
        self.identity = identity
        self.deviceName = deviceName
    }

    /// Self-healing variant: resolves `ASSMDeviceStatus.liveBase` per call.
    public convenience init(base: URL, identity: String, deviceName: String, config: AuthConfig) {
        self.init(base: base, identity: identity, deviceName: deviceName)
        self.config = config
    }

    private var currentBase: URL {
        if let config, let b = ASSMDeviceStatus.liveBase(config: config) { return b }
        return base
    }

    public func push(_ records: [SyncRecord]) async throws {
        guard !records.isEmpty else { return }
        try await signedCall(path: "/v1/sync/changes", action: "push", since: nil, records: records)
    }

    public func pull(since cursor: String?) async throws -> (records: [SyncRecord], cursor: String?) {
        let obj = try await signedCall(path: "/v1/sync/pull", action: "pull", since: cursor, records: nil)
        let raw = (obj["records"] as? [[String: Any]]) ?? []
        let recs = raw.compactMap { Self.record(from: $0) }
        return (recs, obj["cursor"] as? String)
    }

    public func startLive(onChange: @escaping @MainActor ([SyncRecord]) -> Void) {}
    public func stopLive() {}

    @discardableResult
    private func signedCall(path: String, action: String, since: String?, records: [SyncRecord]?) async throws -> [String: Any] {
        do {
            return try await signedCallOnce(base: currentBase, path: path, action: action, since: since, records: records)
        } catch let e as URLError {
            // Dead quick tunnel (URL changed): learn the new live URL from rizal.pw and retry once.
            guard let config, await ASSMLiveURL.refresh(config: config, force: true) else { throw e }
            return try await signedCallOnce(base: currentBase, path: path, action: action, since: since, records: records)
        }
    }

    @discardableResult
    private func signedCallOnce(base: URL, path: String, action: String, since: String?, records: [SyncRecord]?) async throws -> [String: Any] {
        let key = try ASSMDeviceKey.loadOrCreate()
        let pub = key.publicKey.x963Representation.base64EncodedString()
        var nonceRaw = Data(count: 12)
        _ = nonceRaw.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault, 12, $0.baseAddress!) }
        let nonce = nonceRaw.base64EncodedString().filter { !"+/=".contains($0) }
        let ts = ASSMRsyncSeal.jsISO8601()
        let recObjs = records?.map { Self.json(for: $0) }
        let hash: String
        if let recObjs {
            let digest = SHA256.hash(data: Data(ASSMRsyncSeal.canon(recObjs).utf8))
            hash = digest.map { String(format: "%02x", $0) }.joined()
        } else {
            hash = (since?.isEmpty == false) ? since! : ""
        }
        let msg = "rcode-sync-v1\n" + action + "\n" + identity + "\n" + pub + "\n" + nonce + "\n" + ts + "\n" + hash
        let sig = try key.signature(for: Data(msg.utf8)).rawRepresentation.base64EncodedString()
        var obj: [String: Any] = [
            "identity": identity,
            "device": pub,
            "ts": ts,
            "nonce": nonce,
            "sig": sig,
        ]
        if let recObjs { obj["records"] = recObjs }
        if action == "pull", let since { obj["since"] = since }
        guard let url = URL(string: path, relativeTo: base) else { throw AuthError.invalidResponse }
        var r = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20)
        r.httpMethod = "POST"
        r.setValue("application/json", forHTTPHeaderField: "content-type")
        r.setValue("application/json", forHTTPHeaderField: "accept")
        r.httpBody = try JSONSerialization.data(withJSONObject: obj, options: [.sortedKeys])
        let (data, resp) = try await URLSession.shared.data(for: r)
        let status = (resp as? HTTPURLResponse)?.statusCode ?? 0
        let parsed = (try? JSONSerialization.jsonObject(with: data) as? [String: Any]) ?? [:]
        if status == 403 {
            throw AuthError.server(parsed["error"] as? String ?? "device is not a trusted or enrolled signer for this identity")
        }
        if status == 409 { throw AuthError.server(parsed["error"] as? String ?? "replayed sync nonce") }
        if status == 530 || status == 502 || status == 503 || status == 504 || (status == 404 && parsed.isEmpty) {
            throw URLError(.cannotConnectToHost)
        }
        if status != 200 {
            throw AuthError.server(parsed["error"] as? String ?? "HTTP \(status)")
        }
        return parsed
    }

    private static func json(for rec: SyncRecord) -> [String: Any] {
        var o: [String: Any] = [
            "id": rec.id,
            "kind": rec.kind.rawValue,
            "updated_at": ASSMRsyncSeal.jsISO8601(rec.updatedAt),
            "device_id": rec.deviceId,
            "deleted": rec.deleted,
        ]
        if let payload = try? JSONSerialization.jsonObject(with: rec.payload) {
            o["payload"] = payload
            if let d = payload as? [String: Any], let sent = d["sent_at"] as? String {
                o["sent_at"] = sent
            }
        }
        return o
    }

    private static func record(from obj: [String: Any]) -> SyncRecord? {
        guard let id = obj["id"] as? String,
              let kindRaw = obj["kind"] as? String,
              let kind = SyncRecord.Kind(rawValue: kindRaw),
              let device = obj["device_id"] as? String else { return nil }
        let upd: Date
        if let s = obj["updated_at"] as? String {
            let f = ISO8601DateFormatter()
            f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            upd = f.date(from: s) ?? Date()
        } else { upd = Date() }
        let payload: Data
        if let p = obj["payload"] {
            payload = (try? JSONSerialization.data(withJSONObject: p, options: [.sortedKeys])) ?? Data()
        } else { payload = Data() }
        return SyncRecord(id: id, kind: kind, updatedAt: upd, deviceId: device,
                          deleted: obj["deleted"] as? Bool ?? false, payload: payload)
    }
}
