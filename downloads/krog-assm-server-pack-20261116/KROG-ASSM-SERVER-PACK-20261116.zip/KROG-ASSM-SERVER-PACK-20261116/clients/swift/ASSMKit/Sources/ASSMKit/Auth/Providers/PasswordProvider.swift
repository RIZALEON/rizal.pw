import Foundation

/// Username (or email) + password against the RCODE server.
/// The password is sent once over HTTPS and never stored, cached or logged; the server keeps only
/// an Argon2id hash. Only the resulting session tokens are kept, in the device-only Keychain.
@MainActor
public final class PasswordProvider: AuthProvider {
    public let kind: AuthProviderKind = .password
    private let server: () -> URL?

    public init(server: @escaping () -> URL?) { self.server = server }

    public var isConfigured: Bool { server() != nil }

    public func signIn(mode: AuthMode) async throws -> ProviderCredential {
        throw AuthError.unavailable("Use the email/password form.")
    }

    private struct Body: Encodable { let username: String; let password: String; let device: DeviceInfo }

    public func signIn(username: String, password: String, mode: AuthMode) async throws -> ProviderCredential {
        let user = username.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !user.isEmpty, !password.isEmpty else { throw AuthError.server("Enter a username and password.") }
        if mode == .signUp, password.count < 10 { throw AuthError.server("Use at least 10 characters for a new password.") }
        guard let base = server() else { throw AuthError.needsServer("Email/password sign-in") }
        let path = mode == .signUp ? "/v1/auth/password/signup" : "/v1/auth/password/login"
        let session: SessionResponse = try await BackendClient(baseURL: base)
            .send("POST", path, body: Body(username: user, password: password, device: .current))
        return ProviderCredential(provider: .password, subject: user.lowercased(),
                                  email: user.contains("@") ? user : nil,
                                  displayName: session.account.displayName ?? user, session: session)
    }
}
