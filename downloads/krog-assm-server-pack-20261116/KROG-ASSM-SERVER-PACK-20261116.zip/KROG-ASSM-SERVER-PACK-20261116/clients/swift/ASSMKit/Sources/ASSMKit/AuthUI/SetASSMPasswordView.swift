import SwiftUI

/// "Set ASSM password": only reachable on a device whose approver key is ACTIVE on the server
/// (AccountView shows the row only then). Rizal types it himself; the app sends a PBKDF2/HMAC verifier
/// signed by the approver key after a Face ID / passcode unlock. Fields are cleared after sending.
public struct SetASSMPasswordView: View {
    public init() {}
    @EnvironmentObject private var auth: AuthManager
    @Environment(\.dismiss) private var dismiss
    @State private var password = ""
    @State private var confirm = ""
    @State private var busy = false
    @State private var message: String?
    @State private var done = false

    private var owner: OwnerProfile? { OwnerProfile.shared }
    private var problem: ASSMPasswordClient.Failure? {
        password.isEmpty && confirm.isEmpty ? nil : ASSMPasswordClient.strengthProblem(password, confirm: confirm)
    }

    public var body: some View {
        Form {
            Section {
                LabeledContent("ASSM account", value: owner?.profileID ?? "—")
                if let h = owner?.handle, !h.isEmpty { LabeledContent("Username", value: h) }
            }
            Section {
                SecureField("New password (12+ characters)", text: $password).textContentType(assmPasswordContentType(signUp: true))
                SecureField("Confirm password", text: $confirm).textContentType(assmPasswordContentType(signUp: true))
                if let p = problem { Text(p.localizedDescription).font(.footnote).foregroundStyle(.orange) }
            } footer: {
                Text("Only a derived verifier leaves this device. The password itself is never stored or sent. Setting it again changes it.")
            }
            Section {
                Button {
                    submit()
                } label: {
                    if busy { ProgressView() } else { Text(done ? "Password set" : "Set password") }
                }
                .disabled(busy || done || password.isEmpty || problem != nil || owner == nil)
                if let m = message { Text(m).font(.footnote).foregroundStyle(done ? .green : .red) }
            }
        }
        .navigationTitle("Set ASSM password")
        #if os(macOS)
        .formStyle(.grouped).frame(minWidth: 420, minHeight: 360)
        #endif
    }

    private func submit() {
        guard let owner else { return }
        let pw = password, cf = confirm
        password = ""; confirm = ""            // clear immediately; never stored
        busy = true; message = nil
        let handle = owner.handle.isEmpty ? owner.profileID : owner.handle
        Task {
            defer { busy = false }
            do {
                try await ASSMPasswordClient.setPassword(pw, confirm: cf, handle: handle, profile: owner.profileID, config: auth.config)
                done = true; message = "Done. Sign in on a new device with \(handle) and this password."
            } catch AuthError.cancelled {
                message = "Unlock was cancelled. Nothing was sent."
            } catch {
                message = error.localizedDescription
            }
        }
    }
}
