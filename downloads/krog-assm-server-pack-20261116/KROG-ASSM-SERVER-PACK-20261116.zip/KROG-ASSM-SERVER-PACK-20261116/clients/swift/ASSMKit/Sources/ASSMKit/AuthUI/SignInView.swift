import SwiftUI
#if canImport(UIKit)
import UIKit
#else
import AppKit
#endif

/// Sign-in screen modelled on Rakazo's: centred dark translucent card, app mark, "Welcome back",
/// stacked pill buttons, sign-up toggle footer, and a "Change server" link under the card.
public struct SignInView: View {
    /// Public initializer (ASSMKit): implicit memberwise inits are internal to the package.
    public init() {}
    @EnvironmentObject private var auth: AuthManager
    @Environment(\.dismiss) private var dismiss
    @State private var mode: AuthMode = .signIn
    @State private var showEmail = false
    @State private var username = ""
    @State private var password = ""
    @State private var linkCode = ""
    @State private var showServer = false
    @State private var showApprove = false
    @State private var showASSMPassword = false
    @State private var assmUser = OwnerProfile.shared.map { $0.handle.isEmpty ? $0.profileID : $0.handle } ?? ""
    @State private var assmPassword = ""
    @FocusState private var focus: Field?
    private enum Field { case user, pass, code }

    public var body: some View {
        GeometryReader { geo in
            ScrollView {
                VStack(spacing: 14) {
                    card
                    Button("Change server") { showServer = true }
                        .font(.footnote).buttonStyle(.plain).foregroundStyle(.white.opacity(0.7))
                    if !auth.serverURLString.isEmpty {
                        Text(auth.serverURLString).font(.caption2).foregroundStyle(.white.opacity(0.45)).lineLimit(1)
                    }
                    Button("Not now. Keep using \(ASSMKitConfig.current.appName) offline") { auth.presentSignIn = false; dismiss() }
                        .font(.footnote).buttonStyle(.plain).foregroundStyle(.white.opacity(0.55))
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 24)
                .frame(maxWidth: .infinity, minHeight: geo.size.height)
            }
            .assmScrollBounceBasedOnSize()
        }
        .background(background.ignoresSafeArea())
        .environment(\.colorScheme, .dark)
        .sheet(isPresented: $showServer) { ServerSettingsView().environmentObject(auth) }
        .sheet(isPresented: $showApprove) { ApproveDeviceView() }
        #if os(macOS)
        .frame(minWidth: 460, idealWidth: 520, minHeight: 680, idealHeight: 760)
        #endif
    }

    private var background: some View {
        ZStack {
            ASSMTheme.C.background
            RadialGradient(colors: [ASSMTheme.C.userBubble.opacity(0.35), .clear], center: .top, startRadius: 10, endRadius: 520)
        }
    }

    private var card: some View {
        VStack(spacing: 12) {
            RCODEAppMark().padding(.bottom, 4)
            Text(mode == .signIn ? "Welcome back" : "Create your \(ASSMKitConfig.current.appName) account")
                .font(ASSMTheme.F.title).multilineTextAlignment(.center)
            Text("One account on your Mac, iPhone, iPad and Android, synced.")
                .font(.subheadline).foregroundStyle(.white.opacity(0.6)).multilineTextAlignment(.center)
                .padding(.bottom, 6)

            pill("Continue with Google", .google, kind: .google)
            pill("Continue with Apple", .apple, kind: .apple)
            AuthPillButton(title: "Continue with email", icon: .email, loading: auth.busy == .password && showEmail) {
                withAnimation { showEmail.toggle() }; focus = showEmail ? .user : nil
            }
            if showEmail { emailForm }
            pill("Continue with passkey", .passkey, kind: .passkey, highlighted: true)
            pill("Continue with Microsoft", .microsoft, kind: .microsoft)
            pill("Continue with ASSM", .assm, kind: .assm)
            Button { withAnimation { showASSMPassword.toggle() } } label: {
                Label("ASSM username + password", systemImage: showASSMPassword ? "chevron.down" : "chevron.right")
            }
            .font(.footnote).buttonStyle(.plain).foregroundStyle(.white.opacity(0.75))
            if showASSMPassword { assmPasswordForm }

            if let req = auth.pendingASSM { assmPending(req) }
            if let err = auth.lastError {
                Text(err).font(.footnote).foregroundStyle(Color(hex: "#FF8A80")).multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }

            linkThisDevice

            Button("Approve a device") { showApprove = true }
                .font(.footnote.weight(.semibold)).buttonStyle(.plain)
                .foregroundStyle(Color(rcodeHex: 0xC17BF2))

            HStack(spacing: 4) {
                Text(mode == .signIn ? "Don't have an account?" : "Already have an account?").foregroundStyle(.white.opacity(0.6))
                Button(mode == .signIn ? "Sign up" : "Sign in") { withAnimation { mode = mode == .signIn ? .signUp : .signIn } }
                    .buttonStyle(.plain).fontWeight(.semibold)
            }
            .font(.footnote).padding(.top, 6)
        }
        .padding(24)
        .frame(maxWidth: 420)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: ASSMTheme.R.glassCard, style: .continuous))
        .background(ASSMTheme.C.glassCard, in: RoundedRectangle(cornerRadius: ASSMTheme.R.glassCard, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: ASSMTheme.R.glassCard, style: .continuous).strokeBorder(ASSMTheme.C.glassBorder, lineWidth: 1))
        .disabled(auth.busy != nil && auth.pendingASSM == nil)
    }

    private func pill(_ title: String, _ icon: AuthIcon, kind: AuthProviderKind, highlighted: Bool = false) -> some View {
        AuthPillButton(title: title, icon: icon, highlighted: highlighted, loading: auth.busy == kind,
                       dimmed: !auth.provider(kind).isConfigured) {
            Task { await auth.signIn(with: kind, mode: mode) }
        }
    }

    /// ASSM username + password (ASSM-RSYNC /api/rsync/password/login). The password is cleared right after
    /// sending and never stored; only a PBKDF2-derived proof leaves the device.
    private var assmPasswordForm: some View {
        VStack(spacing: 8) {
            TextField("ЯID-0001-3QQS or @handle", text: $assmUser)
                .textContentType(.username).autocorrectionDisabled()
                #if os(iOS)
                .textInputAutocapitalization(.never)
                #endif
                .fieldStyle()
            SecureField("ASSM password", text: $assmPassword)
                .textContentType(.password).onSubmit(submitASSMPassword)
                .fieldStyle()
            AuthPillButton(title: "Sign in with ASSM password", icon: .assm, highlighted: true,
                           loading: auth.busy == .assm && auth.pendingASSM == nil,
                           dimmed: assmUser.isEmpty || assmPassword.isEmpty, action: submitASSMPassword)
        }
        .font(.footnote).tint(.white.opacity(0.7)).padding(.top, 4)
    }

    private func submitASSMPassword() {
        let u = assmUser, pw = assmPassword
        assmPassword = ""                      // clear the field immediately; never stored
        guard !u.isEmpty, !pw.isEmpty else { return }
        Task { await auth.signInWithASSMPassword(user: u, password: pw) }
    }

    private var emailForm: some View {
        VStack(spacing: 8) {
            TextField("Email or username", text: $username)
                .textContentType(.username).autocorrectionDisabled()
                #if os(iOS)
                .textInputAutocapitalization(.never).keyboardType(.emailAddress)
                #endif
                .focused($focus, equals: .user).submitLabel(.next).onSubmit { focus = .pass }
                .fieldStyle()
            SecureField("Password", text: $password)
                .textContentType(assmPasswordContentType(signUp: mode == .signUp))
                .focused($focus, equals: .pass).submitLabel(.go).onSubmit(submitPassword)
                .fieldStyle()
            AuthPillButton(title: mode == .signUp ? "Create account" : "Sign in", icon: .password, highlighted: true,
                           loading: auth.busy == .password, dimmed: !auth.password.isConfigured, action: submitPassword)
        }
        .transition(.opacity.combined(with: .move(edge: .top)))
    }

    private func submitPassword() {
        let u = username, p = password
        password = ""   // never kept in view state longer than the request
        Task { await auth.signInWithPassword(username: u, password: p, mode: mode) }
    }

    private func assmPending(_ req: ASSMEnrollRequest) -> some View {
        VStack(spacing: 8) {
            Text("Approve on a trusted ASSM device").font(.footnote.weight(.semibold))
            Text(req.shortCode).font(.system(.title, design: .monospaced).weight(.bold)).foregroundStyle(Color(hex: "#B388FF"))
                .textSelection(.enabled)
            QRCodeView(payload: req.qrPayload).frame(maxWidth: 180)
            Text("rizal.pw › ЯLOGIN › Other options › approve from another device")
                .font(.caption2).foregroundStyle(.white.opacity(0.55)).multilineTextAlignment(.center)
            Button("Cancel") { auth.cancelPending() }.font(.footnote).buttonStyle(.plain)
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 16).fill(Color.white.opacity(0.05)))
    }

    private var linkThisDevice: some View {
        DisclosureGroup("Have a link code from another device?") {
            HStack {
                TextField("ABC-123-XYZ", text: $linkCode)
                    .focused($focus, equals: .code).autocorrectionDisabled()
                    #if os(iOS)
                    .textInputAutocapitalization(.characters)
                    #endif
                    .fieldStyle()
                Button("Link") { Task { await auth.claimDeviceLink(code: linkCode) } }
                    .disabled(linkCode.count < 4)
            }
            .padding(.top, 6)
        }
        .font(.footnote).tint(.white.opacity(0.7)).padding(.top, 4)
    }
}

/// `.newPassword` is macOS 14+ / iOS 12+; older macOS falls back to `.password`.
#if canImport(UIKit)
typealias ASSMTextContentType = UITextContentType
#else
typealias ASSMTextContentType = NSTextContentType
#endif
func assmPasswordContentType(signUp: Bool) -> ASSMTextContentType? {
    if signUp, #available(macOS 14.0, iOS 12.0, *) { return .newPassword }
    return .password
}

private extension View {
    /// `scrollBounceBehavior` is macOS 13.3+ / iOS 16.4+; no-op before that.
    @ViewBuilder func assmScrollBounceBasedOnSize() -> some View {
        if #available(macOS 13.3, iOS 16.4, *) { self.scrollBounceBehavior(.basedOnSize) } else { self }
    }

    func fieldStyle() -> some View {
        self.textFieldStyle(.plain)
            .padding(.horizontal, 14).frame(minHeight: 44)
            .background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.06)))
            .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(Color.white.opacity(0.15)))
    }
}

/// "Change server": the RCODE auth/sync backend URL, saved in UserDefaults.
public struct ServerSettingsView: View {
    /// Public initializer (ASSMKit): implicit memberwise inits are internal to the package.
    public init() {}
    @EnvironmentObject private var auth: AuthManager
    @Environment(\.dismiss) private var dismiss
    @State private var text = ""
    @State private var error: String?

    public var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("https://rcode.example.com", text: $text)
                        .autocorrectionDisabled()
                        #if os(iOS)
                        .textInputAutocapitalization(.never).keyboardType(.URL)
                        #endif
                } header: { Text("Sync server") } footer: {
                    Text("Used for email/password, passkeys, device linking and syncing with Android/Linux. https:// only (http:// is allowed for localhost). Leave empty to stay offline/iCloud-only.")
                }
                if let error { Text(error).foregroundStyle(.red).font(.footnote) }
            }
            .formStyle(.grouped)
            .navigationTitle("Change server")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Save", action: save) }
            }
        }
        .onAppear { text = auth.serverURLString }
        #if os(macOS)
        .frame(minWidth: 420, minHeight: 240)
        #endif
    }

    private func save() {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.isEmpty { auth.serverURLString = ""; dismiss(); return }
        do { _ = try BackendClient.validated(t); auth.serverURLString = t; dismiss() }
        catch { self.error = error.localizedDescription }
    }
}
