import Foundation
import CryptoKit
import CommonCrypto

/// ASSM username + password (ASSM-RSYNC `pwlogin.py`, scheme `pbkdf2-sha256-hmac-v1`).
///
///   dk       = PBKDF2-HMAC-SHA256(password, salt, iter >= 600000, 32 bytes)   — on this device only
///   verifier = HMAC-SHA256(key: dk, "assm-password-verifier-v1")             — the only thing `set` sends
///   proof    = base64(dk)                                                     — what `login` sends (HTTPS)
///
/// The plaintext password is never sent, stored, logged, or put in UserDefaults / Keychain. Callers clear
/// their text fields right after calling. Setting requires this device's approver key to be ACTIVE on the
/// server (Rizal's own trusted device) and a Face ID / passcode unlock. Login enrolls THIS app's device key
/// (`ASSMDeviceKey`) as ACTIVE when the password is right; typing his password is Rizal's approval.
public enum ASSMPasswordClient {
    public static let scheme = "pbkdf2-sha256-hmac-v1"
    nonisolated public static let iterations = 600_000
    public static let minimumLength = 12
    nonisolated static let verifierMessage = Data("assm-password-verifier-v1".utf8)

    public enum Failure: LocalizedError, Equatable {
        case tooShort, mismatch, notTrustedApprover, noServer, noPasswordSet, wrong, lockedOut(Int), replay, server(Int, String)
        public var errorDescription: String? {
            switch self {
            case .tooShort: "Use at least \(ASSMPasswordClient.minimumLength) characters."
            case .mismatch: "The two passwords don't match."
            case .notTrustedApprover: "Set the password on a device whose approver key is already trusted."
            case .noServer: "The ASSM server isn't reachable right now."
            case .noPasswordSet: "No ASSM password is set yet. Set one on a trusted device first."
            case .wrong: "Wrong username or password."
            case .lockedOut(let s): "Too many attempts. Try again in \(max(1, s)) s."
            case .replay: "That request was already used. Try again."
            case .server(let code, let msg): "Server error \(code): \(msg)"
            }
        }
    }

    // MARK: Pure helpers (unit-tested)

    /// PBKDF2-HMAC-SHA256, 32-byte output.
    nonisolated public static func derive(password: String, salt: Data, iterations: Int) -> Data {
        var out = Data(count: 32)
        let pw = Array(password.utf8)
        _ = out.withUnsafeMutableBytes { o in
            salt.withUnsafeBytes { s in
                CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2), pw.map { Int8(bitPattern: $0) }, pw.count,
                                     s.bindMemory(to: UInt8.self).baseAddress, salt.count,
                                     CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA256), UInt32(iterations),
                                     o.bindMemory(to: UInt8.self).baseAddress, 32)
            }
        }
        return out
    }

    nonisolated public static func verifier(derivedKey dk: Data) -> Data {
        Data(HMAC<SHA256>.authenticationCode(for: verifierMessage, using: SymmetricKey(data: dk)))
    }

    public static func strengthProblem(_ password: String, confirm: String) -> Failure? {
        if password.count < minimumLength { return .tooShort }
        if password != confirm { return .mismatch }
        return nil
    }

    public static func setMessage(profile: String, handle: String, salt: String, iter: Int, verifier: String,
                                  signer: String, nonce: String, ts: String) -> String {
        "assm-password-set-v1\n" + [profile, handle, salt, String(iter), verifier, signer, nonce, ts].joined(separator: "\n")
    }

    public static func loginMessage(user: String, proof: String, device: String, deviceName: String,
                                    nonce: String, ts: String) -> String {
        let ph = SHA256.hash(data: Data(proof.utf8)).map { String(format: "%02x", $0) }.joined()
        return "assm-password-login-v1\n" + [user, ph, device, deviceName, nonce, ts].joined(separator: "\n")
    }

    static func nonce() -> String { String(Nonce.random().filter { $0.isASCII && ($0.isLetter || $0.isNumber) }.prefix(32)) }
    static func now() -> String {
        let f = ISO8601DateFormatter(); f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return f.string(from: Date())
    }

    // MARK: Network

    /// True only if this device ALREADY has an approver key and the server lists it as trusted. Creates nothing.
    @MainActor
    public static func approverIsTrusted(config: AuthConfig = .shared) async -> Bool {
        guard let pub = ASSMApproverKey.existingPublicKeyBase64(),
              let st = await ASSMDeviceStatus.fetch(pub: pub, config: config) else { return false }
        return st.trusted
    }

    /// Sets or changes the ASSM password. Unlock first; the approver key signature prompts again (user presence).
    @MainActor
    public static func setPassword(_ password: String, confirm: String, handle: String, profile: String,
                                   config: AuthConfig = .shared) async throws {
        if let p = strengthProblem(password, confirm: confirm) { throw p }
        guard let base = ASSMDeviceStatus.liveBase(config: config) else { throw Failure.noServer }
        guard let signer = ASSMApproverKey.existingPublicKeyBase64() else { throw Failure.notTrustedApprover }
        try await UnlockGate.require(reason: "Unlock to set your ASSM password")
        var saltBytes = Data(count: 16)
        _ = saltBytes.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault, 16, $0.baseAddress!) }
        let salt = saltBytes.base64EncodedString()
        let dk = await Task.detached { ASSMPasswordClient.derive(password: password, salt: saltBytes, iterations: iterations) }.value
        let ver = verifier(derivedKey: dk).base64EncodedString()
        let n = nonce(), ts = now()
        let msg = setMessage(profile: profile, handle: handle, salt: salt, iter: iterations, verifier: ver, signer: signer, nonce: n, ts: ts)
        let sig = try ASSMApproverKey.sign(msg)
        let body: [String: Any] = ["t": "password.set", "profile": profile, "handle": handle, "salt": salt, "iter": iterations,
                                   "verifier": ver, "signer": signer, "nonce": n, "ts": ts, "sig": sig]
        _ = try await post(base, "/api/rsync/password/set", body)
    }

    /// Logs in with username (ЯID or @handle) + password. On success this app's device key is ACTIVE.
    /// Returns the ASSM profile id.
    @MainActor
    public static func login(user: String, password: String, config: AuthConfig = .shared) async throws -> (profile: String, handle: String?) {
        guard let base = ASSMDeviceStatus.liveBase(config: config) else { throw Failure.noServer }
        let u = user.trimmingCharacters(in: .whitespacesAndNewlines)
        guard var comps = URLComponents(url: base.appendingPathComponent("api/rsync/password/params"), resolvingAgainstBaseURL: false)
        else { throw Failure.noServer }
        comps.queryItems = [URLQueryItem(name: "user", value: u)]
        var r = URLRequest(url: comps.url!, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
        r.setValue("application/json", forHTTPHeaderField: "accept")
        guard let (pdata, presp) = try? await URLSession.shared.data(for: r), let pcode = (presp as? HTTPURLResponse)?.statusCode
        else { throw Failure.noServer }
        if pcode == 404 { throw Failure.wrong }          // same message as a wrong password
        guard pcode == 200, let params = try? JSONSerialization.jsonObject(with: pdata) as? [String: Any],
              let saltB64 = params["salt"] as? String, let salt = Data(base64Encoded: saltB64),
              let iter = params["iter"] as? Int, iter >= iterations else { throw Failure.server(pcode, "bad params") }
        let dk = await Task.detached { ASSMPasswordClient.derive(password: password, salt: salt, iterations: iter) }.value
        let proof = dk.base64EncodedString()
        let key = try ASSMDeviceKey.loadOrCreate()
        let pub = key.publicKey.x963Representation.base64EncodedString()
        let name = DeviceInfo.current.assmDeviceName
        let n = nonce(), ts = now()
        let sig = try key.signature(for: Data(loginMessage(user: u, proof: proof, device: pub, deviceName: name, nonce: n, ts: ts).utf8))
            .rawRepresentation.base64EncodedString()
        let body: [String: Any] = ["t": "password.login", "user": u, "proof": proof, "device": pub, "device_name": name,
                                   "nonce": n, "ts": ts, "sig": sig]
        let out = try await post(base, "/api/rsync/password/login", body)
        guard let profile = out["profile"] as? String else { throw Failure.server(200, "no profile") }
        return (profile, out["handle"] as? String)
    }

    @MainActor
    private static func post(_ base: URL, _ path: String, _ body: [String: Any]) async throws -> [String: Any] {
        guard let url = URL(string: path, relativeTo: base) else { throw Failure.noServer }
        var r = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20)
        r.httpMethod = "POST"
        r.setValue("application/json", forHTTPHeaderField: "content-type")
        r.setValue("application/json", forHTTPHeaderField: "accept")
        r.httpBody = try JSONSerialization.data(withJSONObject: body)
        guard let (data, resp) = try? await URLSession.shared.data(for: r), let code = (resp as? HTTPURLResponse)?.statusCode
        else { throw Failure.noServer }
        let obj = (try? JSONSerialization.jsonObject(with: data) as? [String: Any]) ?? [:]
        switch code {
        case 200, 201: return obj
        case 401: throw Failure.wrong
        case 403 where path.hasSuffix("/set"): throw Failure.notTrustedApprover
        case 409: throw Failure.replay
        case 429: throw Failure.lockedOut((obj["retry_after_s"] as? Int) ?? 60)
        default: throw Failure.server(code, obj["error"] as? String ?? "unexpected response")
        }
    }
}
