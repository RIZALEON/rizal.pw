import Foundation
import CryptoKit

/// ASSM (rizal.pw ЯLOGIN / CryptoSocial) sign-in, ported from the existing web client
/// `rizal.pw/rdragon-cryptosocial/rsync-core.js` (enrollRequest / shortCode / approveEntry):
///
/// 1. RCODE makes a P-256 device key (Keychain, this device only, never synced, never exported).
/// 2. After a Face ID / Touch ID / password unlock it signs `rsync-enroll-v1\n<pub>\n<nonce>\n<ts>`
///    and shows the request as an 8-digit short code + QR ("approve from another device").
/// 3. An already-trusted ASSM device approves it, which appends a `device.enroll` entry to the
///    rsync log; RCODE polls `<ASSMBaseURL><ASSMEnrollEntriesPath>` until it sees that entry.
///
/// RCODE never signs mints or wallet actions; this key only proves "this RCODE install" to ASSM.
/// Sessions from a trusted device stay signed in until explicit sign-out or device removal.
///
/// Endpoints: `ASSMBaseURL` is the live ASSM rsync API on Neo (`ASSM-RSYNC/server.py`, behind a cloudflared
/// quick tunnel, so its URL can change). `ASSMFallbackBaseURL` (https://rizal.pw) serves a static copy of
/// `/api/rsync/entries` whose `live` field names the current live URL; RCODE switches to it when the
/// configured live URL stops answering. The live server verifies the approver's seal against its
/// trusted-devices list; RCODE still stores ASSM identities as `verified: false` until the RCODE server
/// re-verifies them.
@MainActor
public final class ASSMProvider: AuthProvider {
    public let kind: AuthProviderKind = .assm
    private var baseURL: String
    private let fallbackURL: String
    private let entriesPath: String
    /// Called with the short code + QR payload while waiting for approval.
    public var onPending: ((ASSMEnrollRequest?) -> Void)?

    public init(config: AuthConfig) {
        baseURL = config.assmBaseURL
        fallbackURL = config.assmFallbackBaseURL
        entriesPath = config.assmEnrollEntriesPath
    }

    public var isConfigured: Bool {
        (try? BackendClient.validated(baseURL)) != nil || (try? BackendClient.validated(fallbackURL)) != nil
    }

    public func signIn(mode: AuthMode) async throws -> ProviderCredential {
        guard isConfigured else { throw AuthError.notConfigured("ASSM endpoint") }
        try await UnlockGate.require(reason: "Unlock to sign \(ASSMKitConfig.current.appName)'s ASSM device request")
        let key = try ASSMDeviceKey.loadOrCreate()
        let request = try ASSMEnrollRequest.make(key: key, deviceName: DeviceInfo.current.assmDeviceName)
        onPending?(request)
        defer { onPending?(nil) }
        var posted = await postRequest(request)

        let deadline = Date().addingTimeInterval(10 * 60)
        while Date() < deadline {
            try Task.checkCancellation()
            if let profile = await findApproval(for: request) {
                return ProviderCredential(provider: .assm, subject: profile, displayName: profile,
                                          proof: ["device": request.device, "nonce": request.nonce,
                                                  "req_ts": request.reqTs, "req_sig": request.reqSig,
                                                  "device_name": request.deviceName])
            }
            if !posted { posted = await postRequest(request) }
            try await Task.sleep(nanoseconds: 5_000_000_000)
        }
        throw AuthError.server("No ASSM approval within 10 minutes. Try again.")
    }

    /// Registers the request with the live API so an approver can look it up by its 8-digit code.
    /// Best effort: the QR carries the full request, so approval still works if this fails.
    private func postRequest(_ req: ASSMEnrollRequest) async -> Bool {
        guard let base = try? BackendClient.validated(baseURL),
              let url = URL(string: "/api/rsync/request", relativeTo: base) else { return false }
        var r = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
        r.httpMethod = "POST"
        r.setValue("application/json", forHTTPHeaderField: "content-type")
        r.setValue("application/json", forHTTPHeaderField: "accept")
        let body: [String: String] = ["t": "device.request", "device": req.device, "nonce": req.nonce,
                                      "req_ts": req.reqTs, "req_sig": req.reqSig, "device_name": req.deviceName]
        r.httpBody = try? JSONSerialization.data(withJSONObject: body)
        guard let (_, resp) = try? await URLSession.shared.data(for: r),
              let code = (resp as? HTTPURLResponse)?.statusCode else { return false }
        return code == 201 || code == 200
    }

    /// Polls the live API; if it does not answer, reads the static fallback feed (which may also
    /// name a newer live URL, adopted for the next poll).
    private func findApproval(for req: ASSMEnrollRequest) async -> String? {
        if let base = try? BackendClient.validated(baseURL), let feed = await fetchFeed(base) {
            return match(feed.entries, req)
        }
        guard let fb = try? BackendClient.validated(fallbackURL), let feed = await fetchFeed(fb) else { return nil }
        if let live = feed.live, live != baseURL, (try? BackendClient.validated(live)) != nil { baseURL = live }
        return match(feed.entries, req)
    }

    /// Reads `{entries:[...], live?}`, a bare JSON array, or JSONL.
    private func fetchFeed(_ base: URL) async -> (entries: [[String: Any]], live: String?)? {
        guard let url = URL(string: entriesPath, relativeTo: base) else { return nil }
        var r = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 15)
        r.setValue("application/json", forHTTPHeaderField: "accept")
        guard let (data, resp) = try? await URLSession.shared.data(for: r),
              (resp as? HTTPURLResponse)?.statusCode == 200 else { return nil }
        if let obj = try? JSONSerialization.jsonObject(with: data) {
            if let arr = obj as? [[String: Any]] { return (arr, nil) }
            if let dict = obj as? [String: Any] {
                return ((dict["entries"] as? [[String: Any]]) ?? [], dict["live"] as? String)
            }
            return nil
        }
        guard let text = String(data: data, encoding: .utf8) else { return nil }
        let lines = text.split(separator: "\n").compactMap {
            try? JSONSerialization.jsonObject(with: Data($0.utf8)) as? [String: Any]
        }
        return (lines, nil)
    }

    private func match(_ entries: [[String: Any]], _ req: ASSMEnrollRequest) -> String? {
        let m = entries.last {
            ($0["t"] as? String) == "device.enroll" && ($0["device"] as? String) == req.device && ($0["nonce"] as? String) == req.nonce
        }
        return m?["profile"] as? String
    }
}

/// `t:"device.request"` from rsync-core.js, field-for-field.
public struct ASSMEnrollRequest: Sendable, Equatable {
    public let device: String      // base64 raw (uncompressed X9.63) P-256 public key, as WebCrypto exportKey('raw')
    public let nonce: String       // 12 random bytes, base64 without + / =
    public let reqTs: String       // ISO-8601
    public let reqSig: String      // base64 raw r||s ECDSA-SHA256 signature, as WebCrypto
    public let deviceName: String
    public let shortCode: String   // "1234-5678"

    public var qrPayload: String {
        var c = URLComponents()
        c.scheme = ASSMKitConfig.current.urlScheme; c.host = "assm-approve"
        c.queryItems = [.init(name: "device", value: device), .init(name: "nonce", value: nonce),
                        .init(name: "ts", value: reqTs), .init(name: "sig", value: reqSig),
                        .init(name: "name", value: deviceName)]
        return c.string ?? shortCode
    }

    public static func make(key: P256.Signing.PrivateKey, deviceName: String) throws -> ASSMEnrollRequest {
        let pub = key.publicKey.x963Representation.base64EncodedString()
        var raw = Data(count: 12)
        _ = raw.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault, 12, $0.baseAddress!) }
        let nonce = raw.base64EncodedString().filter { !"+/=".contains($0) }
        let iso = ISO8601DateFormatter()
        iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let ts = iso.string(from: Date())
        let msg = "rsync-enroll-v1\n" + pub + "\n" + nonce + "\n" + ts
        let sig = try key.signature(for: Data(msg.utf8)).rawRepresentation.base64EncodedString()
        return ASSMEnrollRequest(device: pub, nonce: nonce, reqTs: ts, reqSig: sig, deviceName: deviceName,
                                 shortCode: shortCode(device: pub, nonce: nonce))
    }

    /// sha256(device + "\n" + nonce) → first 10 hex digits → mod 1e8 → "XXXX-XXXX".
    public static func shortCode(device: String, nonce: String) -> String {
        let hex = Nonce.sha256Hex(device + "\n" + nonce)
        let n = (UInt64(hex.prefix(10), radix: 16) ?? 0) % 100_000_000
        let s = String(format: "%08llu", n)
        return String(s.prefix(4)) + "-" + String(s.suffix(4))
    }
}

/// The per-install ASSM device key. Device-only Keychain item; never synced, exported or logged.
public enum ASSMDeviceKey {
    private static let store = KeychainStore(service: ASSMKitConfig.current.keychainService("assm-device-key"))

    public static func loadOrCreate() throws -> P256.Signing.PrivateKey {
        if let d = store.data(for: "p256"), let k = try? P256.Signing.PrivateKey(rawRepresentation: d) { return k }
        let k = P256.Signing.PrivateKey()
        try store.set(k.rawRepresentation, for: "p256")
        return k
    }

    /// Only on explicit sign-out of ASSM / device removal.
    public static func forget() { store.remove("p256") }
}
