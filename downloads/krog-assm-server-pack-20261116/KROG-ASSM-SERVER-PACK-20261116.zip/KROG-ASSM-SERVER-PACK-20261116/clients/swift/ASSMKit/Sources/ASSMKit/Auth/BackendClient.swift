import Foundation

/// Minimal JSON client for the RCODE auth/sync server described in BACKEND-AUTH-SYNC.md.
public struct BackendClient: Sendable {
    public let baseURL: URL
    public var accessToken: String?

    /// https only, except loopback for local testing (same rule as Rakazo's device client).
    public static func validated(_ string: String) throws -> URL {
        let trimmed = string.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !AuthConfig.isPlaceholder(trimmed),
              let url = URL(string: trimmed), let scheme = url.scheme?.lowercased(), let host = url.host?.lowercased()
        else { throw AuthError.needsServer("This") }
        let loopback = host == "localhost" || host == "127.0.0.1" || host == "::1"
        guard scheme == "https" || (scheme == "http" && loopback) else { throw AuthError.insecureURL }
        return url
    }

    public func send<Response: Decodable>(_ method: String, _ path: String, body: (any Encodable)? = nil,
                                   as: Response.Type = Response.self) async throws -> Response {
        let data = try await raw(method, path, body: body)
        do { return try JSONCoding.decoder.decode(Response.self, from: data) }
        catch { throw AuthError.invalidResponse }
    }

    @discardableResult
    public func raw(_ method: String, _ path: String, body: (any Encodable)? = nil) async throws -> Data {
        guard let url = URL(string: path, relativeTo: baseURL) else { throw AuthError.invalidResponse }
        var req = URLRequest(url: url, timeoutInterval: 20)
        req.httpMethod = method
        req.setValue("application/json", forHTTPHeaderField: "accept")
        if let token = accessToken { req.setValue("Bearer \(token)", forHTTPHeaderField: "authorization") }
        if let body {
            req.setValue("application/json", forHTTPHeaderField: "content-type")
            req.httpBody = try JSONCoding.encoder.encode(body)
        }
        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse else { throw AuthError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            let msg = (try? JSONCoding.decoder.decode(ServerError.self, from: data))?.error
            throw AuthError.server(msg ?? "Server returned \(http.statusCode)")
        }
        return data
    }
}

public struct ServerError: Decodable { let error: String }

public struct ServerAccount: Codable, Sendable {
    public let id: String
    public var displayName: String?
    public var identities: [LinkedIdentity]?
}

/// Every sign-in / link / device-claim endpoint returns this.
public struct SessionResponse: Codable, Sendable {
    public let account: ServerAccount
    public let accessToken: String
    public var refreshToken: String?
    public var expiresIn: Double?
    public var deviceId: String?
}

/// Body for POST /v1/auth/{apple|google|microsoft|assm}.
public struct ProviderExchangeBody: Encodable {
    public let subject: String
    public let proof: [String: String]
    public let device: DeviceInfo
    /// true = link this identity to the account behind the bearer token instead of signing in.
    public let link: Bool
}
