import Foundation
import Security
import LocalAuthentication
import CryptoKit

/// RCODE's own ASSM *approver* key — not the enroll-request key in `ASSMDeviceKey`.
///
/// P-256 in the Secure Enclave when one is available; otherwise a Keychain-resident
/// software key on Macs without an Enclave. The private key is created on this device,
/// never exported, never synced, and never logged. Access control is `.userPresence`,
/// so every `sign` prompts Face ID / Touch ID / passcode. Bots never sign. RCODE never
/// uses this key to sign mints — only `device.enroll` approval payloads.
@MainActor
public enum ASSMApproverKey {
    public static let service = ASSMKitConfig.current.keychainService("assm-approver-key")
    private static let seAccount = "p256-se-blob"
    private static let tag = Data(ASSMKitConfig.current.keychainService("assm-approver-key").utf8)
    private static let store = KeychainStore(service: service)

    public enum Failure: LocalizedError {
        case cancelled
        case unavailable(String)
        case os(String)

        public var errorDescription: String? {
            switch self {
            case .cancelled: return "Approval was cancelled — Face ID, Touch ID or the device passcode is required to sign."
            case .unavailable(let s): return s
            case .os(let s): return s
            }
        }
    }

    /// Base64 of the uncompressed 65-byte public key (`0x04 || X || Y`), same as WebCrypto `exportKey('raw')`.
    public static func publicKeyBase64() throws -> String {
        try holder().pubBase64
    }

    /// Public key only if this device ALREADY has an approver key; never creates one, never prompts.
    public static func existingPublicKeyBase64() -> String? {
        if ASSMKitConfig.isReserved(service) { return nil }
        if SecureEnclave.isAvailable {
            guard store.data(for: seAccount) != nil else { return nil }
        } else {
            guard (try? loadSoftwareKey()) != nil else { return nil }
        }
        return try? holder().pubBase64
    }

    /// ECDSA-SHA256 signature as base64 raw r||s (64 bytes). Prompts for user presence.
    public static func sign(_ message: String) throws -> String {
        try holder().sign(message).base64EncodedString()
    }

    /// One-line command Rizal can run on the ASSM server to trust this key. RCODE never runs it.
    public static func trustCommand(deviceName: String) throws -> String {
        let pub = try publicKeyBase64()
        let label = "\(ASSMKitConfig.current.appName) \(deviceName)"
        return "python3 add-trusted-device.py add \"\(pub)\" \"\(label)\""
    }

    private struct Holder {
        let pubBase64: String
        let sign: (String) throws -> Data
    }

    private static func holder() throws -> Holder {
        if ASSMKitConfig.isReserved(service) { throw ASSMKitConfig.ValidationError.reservedName(service) }
        if SecureEnclave.isAvailable {
            do { return try secureEnclaveHolder() }
            catch {
                // A missing blob or a failed SE create falls through to a Keychain software key
                // only when the Enclave itself is unavailable mid-call; otherwise surface the error.
                if let f = error as? Failure { throw f }
                throw Failure.os(error.localizedDescription)
            }
        }
        return try softwareHolder()
    }

    private static func secureEnclaveHolder() throws -> Holder {
        var acErr: Unmanaged<CFError>?
        guard let access = SecAccessControlCreateWithFlags(
            kCFAllocatorDefault,
            kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
            [.privateKeyUsage, .userPresence],
            &acErr
        ) else {
            throw Failure.os((acErr?.takeRetainedValue() as Error?)?.localizedDescription ?? "Could not create Secure Enclave access control.")
        }

        let key: SecureEnclave.P256.Signing.PrivateKey
        if let blob = store.data(for: seAccount) {
            do {
                key = try SecureEnclave.P256.Signing.PrivateKey(dataRepresentation: blob)
            } catch {
                throw Failure.os("Could not load this device's approver key: \(error.localizedDescription)")
            }
        } else {
            do {
                key = try SecureEnclave.P256.Signing.PrivateKey(accessControl: access)
                try store.set(key.dataRepresentation, for: seAccount)
            } catch {
                throw Failure.os("Could not create this device's approver key: \(error.localizedDescription)")
            }
        }
        let pub = key.publicKey.x963Representation.base64EncodedString()
        return Holder(pubBase64: pub) { msg in
            do {
                return try key.signature(for: Data(msg.utf8)).rawRepresentation
            } catch let err as NSError {
                if err.domain == NSOSStatusErrorDomain && (err.code == Int(errSecUserCanceled) || err.code == Int(errSecAuthFailed)) {
                    throw Failure.cancelled
                }
                // LAError cancel codes
                if err.domain == LAError.errorDomain &&
                    (err.code == LAError.userCancel.rawValue || err.code == LAError.appCancel.rawValue || err.code == LAError.systemCancel.rawValue) {
                    throw Failure.cancelled
                }
                throw Failure.os(err.localizedDescription)
            }
        }
    }

    /// Keychain-resident P-256 (no Enclave). Private key is non-extractable; each sign requires user presence.
    private static func softwareHolder() throws -> Holder {
        if let existing = try? loadSoftwareKey() {
            return try softwareHolder(from: existing)
        }
        var acErr: Unmanaged<CFError>?
        guard let access = SecAccessControlCreateWithFlags(
            kCFAllocatorDefault,
            kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
            [.userPresence],
            &acErr
        ) else {
            throw Failure.os((acErr?.takeRetainedValue() as Error?)?.localizedDescription ?? "Could not create Keychain access control.")
        }
        let attrs: [String: Any] = [
            kSecAttrKeyType as String: kSecAttrKeyTypeECSECPrimeRandom,
            kSecAttrKeySizeInBits as String: 256,
            kSecPrivateKeyAttrs as String: [
                kSecAttrIsPermanent: true,
                kSecAttrApplicationTag: tag,
                kSecAttrLabel: "\(ASSMKitConfig.current.appName) ASSM approver",
                kSecAttrAccessControl: access,
            ] as [String: Any],
        ]
        var createErr: Unmanaged<CFError>?
        guard let priv = SecKeyCreateRandomKey(attrs as CFDictionary, &createErr) else {
            throw Failure.os((createErr?.takeRetainedValue() as Error?)?.localizedDescription ?? "Could not create the approver key.")
        }
        return try softwareHolder(from: priv)
    }

    private static func loadSoftwareKey() throws -> SecKey {
        let query: [String: Any] = [
            kSecClass as String: kSecClassKey,
            kSecAttrApplicationTag as String: tag,
            kSecAttrKeyType as String: kSecAttrKeyTypeECSECPrimeRandom,
            kSecReturnRef as String: true,
        ]
        var out: CFTypeRef?
        let st = SecItemCopyMatching(query as CFDictionary, &out)
        guard st == errSecSuccess, let key = out else {
            throw Failure.os("No Keychain approver key (status \(st)).")
        }
        // swiftlint:disable:next force_cast
        return (key as! SecKey)
    }

    private static func softwareHolder(from priv: SecKey) throws -> Holder {
        guard let pubKey = SecKeyCopyPublicKey(priv) else {
            throw Failure.os("Approver public key is missing.")
        }
        var expErr: Unmanaged<CFError>?
        guard let pubData = SecKeyCopyExternalRepresentation(pubKey, &expErr) as Data?, pubData.count == 65 else {
            throw Failure.os((expErr?.takeRetainedValue() as Error?)?.localizedDescription ?? "Could not export the approver public key.")
        }
        let pub = pubData.base64EncodedString()
        return Holder(pubBase64: pub) { msg in
            var signErr: Unmanaged<CFError>?
            let data = Data(msg.utf8) as CFData
            // DER first (widely supported); convert to raw r||s to match WebCrypto / rsync-core.
            guard let der = SecKeyCreateSignature(priv, .ecdsaSignatureMessageX962SHA256, data, &signErr) as Data? else {
                let err = signErr?.takeRetainedValue()
                if let e = err, (e as NSError).code == Int(errSecUserCanceled) || (e as NSError).code == Int(errSecAuthFailed) {
                    throw Failure.cancelled
                }
                throw Failure.os((err as Error?)?.localizedDescription ?? "Signing failed.")
            }
            return derToRaw(der)
        }
    }

    /// ITU X.962 DER ECDSA signature → 64-byte raw r||s.
    public static func derToRaw(_ der: Data) -> Data {
        if der.count == 64 { return der }
        let b = [UInt8](der)
        guard b.count > 8, b[0] == 0x30 else { return der }
        var i = 2 // skip sequence tag + length (assume short form)
        if b[1] & 0x80 != 0 { i = 2 + Int(b[1] & 0x7F) }
        func component() -> Data {
            // i at INTEGER tag
            let start = i
            _ = start
            guard i + 1 < b.count, b[i] == 0x02 else { return Data(repeating: 0, count: 32) }
            let len = Int(b[i + 1])
            i += 2
            var bytes = Array(b[i ..< (i + len)])
            i += len
            while bytes.count > 32 && bytes.first == 0 { bytes.removeFirst() }
            if bytes.count < 32 { bytes = Array(repeating: 0, count: 32 - bytes.count) + bytes }
            if bytes.count > 32 { bytes = Array(bytes.suffix(32)) }
            return Data(bytes)
        }
        let r = component()
        let s = component()
        return r + s
    }
}
