import Foundation

/// Every way into an RCODE account. One account can link several of these.
public enum AuthProviderKind: String, Codable, CaseIterable, Identifiable, Sendable {
    case apple, google, microsoft, assm, password, passkey

    public var id: String { rawValue }

    public var displayName: String {
        switch self {
        case .apple: "Apple"
        case .google: "Google"
        case .microsoft: "Microsoft"
        case .assm: "ASSM (rizal.pw)"
        case .password: "Email & password"
        case .passkey: "Passkey"
        }
    }
}

public enum AuthMode: Sendable { case signIn, signUp }

/// One provider identity linked to an RCODE account.
public struct LinkedIdentity: Codable, Hashable, Identifiable, Sendable {
    public var id: String { provider.rawValue + ":" + subject }
    public let provider: AuthProviderKind
    /// Stable provider user id: Apple user id, Google `sub`, Microsoft `oid`/`sub`, ASSM profile id, username.
    public let subject: String
    public var email: String?
    public var displayName: String?
    public var linkedAt: Date
    /// false when only the client saw it (no backend verified the token / ASSM approval signature yet).
    public var verified: Bool
}

/// The cross-device RCODE account. Not secret: safe to sync via iCloud Keychain.
public struct RCODEAccount: Codable, Hashable, Sendable {
    /// Server account id, or `local-<uuid>` until a backend is configured.
    public var accountId: String
    public var displayName: String
    public var identities: [LinkedIdentity]
    public var createdAt: Date

    public var isLocalOnly: Bool { accountId.hasPrefix("local-") }
    public func has(_ kind: AuthProviderKind) -> Bool { identities.contains { $0.provider == kind } }
}

/// Per-device session tokens. Device-only Keychain item, never synced (like Rakazo's per-device token).
public struct SessionTokens: Codable, Sendable {
    public var accessToken: String
    public var refreshToken: String?
    public var expiresAt: Date?
    public var deviceId: String?
}

/// What a provider hands back after its own sign-in UI finishes.
public struct ProviderCredential: Sendable {
    public let provider: AuthProviderKind
    public let subject: String
    public var email: String?
    public var displayName: String?
    /// Proof for the backend (id_token, authorization_code, nonce, ASSM enroll entry, ...). Never a password.
    public var proof: [String: String] = [:]
    /// Set when the provider already produced an RCODE session (password, passkey, device link).
    public var session: SessionResponse?
}

public enum AuthError: LocalizedError {
    case notConfigured(String)
    case needsServer(String)
    case cancelled
    case server(String)
    case invalidResponse
    case insecureURL
    case unavailable(String)

    public var errorDescription: String? {
        switch self {
        case .notConfigured(let what): "\(what) isn't set up yet. Add it in \(ASSMKitConfig.current.authConfigPlistName).plist (see AUTH-SETUP.md)."
        case .needsServer(let what): "\(what) needs a sync server. Tap \"Change server\" to set one."
        case .cancelled: "Sign-in was cancelled."
        case .server(let msg): msg
        case .invalidResponse: "The server sent an unexpected response."
        case .insecureURL: "The server must use https:// (http:// is only allowed for localhost)."
        case .unavailable(let msg): msg
        }
    }
}
