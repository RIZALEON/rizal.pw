# ASSMKit integration: native apps, the web ASSM sign-in, and the two sync systems

Status legend: **works now** · **needs web key + approval screen** (a browser-held device key enrolled through the rizal.pw web approval screen, which does not exist yet) · **gap** (not built).

## 1. Identities

| Piece | How it works | Status |
|---|---|---|
| Owner identity | `OwnerProfile.plist` → `ЯID-0001-3QQS` (`@chaserizal`). Public data only. | works now |
| All native providers → one identity | `AuthManager.unifyOnOwnerIdentity(after:)` runs after ASSM, Apple, Google/Microsoft PKCE, password, passkey and device-link sign-ins. Adds the owner ASSM identity to the account, then starts (or marks) the owner device-key enrollment. | works now (Apple/Google/Microsoft/passkey still need their client IDs / RP domain in the auth plist to be clickable) |
| Per-app device key | `ASSMDeviceKey` under `<keychainPrefix>.assm-device-key`; RCODE `info.rizal.rcode…`, GHOSTMACHINE-macOS `info.rizal.ghostmachine.mac…`, iOS `…ghostmachine.ios…`. | works now; each new key needs Rizal's one-time approval |
| Approval | Short code / QR (`device.request`, `rsync-enroll-v1` signature) → approved from a trusted device (`/api/rsync/approve`) → `device-status` shows trusted. | works now (native approver: RCODE Approve screen) |

## 2. rizal.pw web ASSM sign-in (read-only look, 2026-11-16)

- `https://rizal.pw/login/` (ЯLOGIN) loads `/rdragon-cryptosocial/rsync-core.js`, `rsite-auth.js`, `rfounder.js`, `rlogin-page.js`, `rsync-qr.js`.
- `rsync-core.js` (ЯSYNC core) is a peer-to-peer, append-only, signed-entry log. Device keys are WebCrypto P-256. Its `enrollRequest` / `shortCode` / `approveEntry` are the **same formats** ASSMKit ported (`rsync-enroll-v1\n<pub>\n<nonce>\n<ts>`, sha256(device+"\n"+nonce) → `XXXX-XXXX`, `device.enroll` entries). It also has `session.start` / `session.end` entries (`sessionId = "ss-" + sha256("rsync-session-v1\n"+pub)[0:20] + "-" + seq`) and a username+password device login (`passwordDeviceLogin`) that enrolls a fresh browser key for the founder profile.
- `https://rizal.pw/api/rsync/entries` is the static feed whose `live` field names the current ASSM-RSYNC tunnel (today `https://ASSM_SERVER_URL`).

| Web piece | Maps to | Status |
|---|---|---|
| Web device request / short code | Same `device.request` + short code as ASSMKit; a trusted native device can approve it via `/api/rsync/approve` | works now (format-compatible) |
| Web key → same identity | `device.enroll` with `profile = ЯID-0001-3QQS` | needs web key + approval screen |
| Web sync to `/v1/sync/*` on :8752 | Browser would sign `rcode-sync-v1` with its enrolled key and call the live URL | needs web key + approval screen (plus CORS on server.py — not changed here) |
| Native ↔ web single sign-on (shared token / cookie) | None. ASSM-RSYNC has no OAuth / refresh-token endpoint; each client has its own key | gap (would be a new auth system; needs Rizal's GO) |

## 3. GHOSTMACHINE's existing web card (two different sync systems)

GHOSTMACHINE today signs in through a **web ASSM card in WKWebView** (`GHOSTMACHINE/Resources/web/assm/login/rlogin-page.js`, `rlogin-strip.js`). It uses **ЯSYNC 0.3.2 entries** via a peer on `:8799` and `rizal.pw/rsync/entries.jsonl`. That is a different system from **ASSM-RSYNC** (`server.py` on `127.0.0.1:8752`, `/v1/sync/changes|pull`) that RCODE/ASSMKit use.

| | ЯSYNC 0.3.2 (web card) | ASSM-RSYNC (ASSMKit) |
|---|---|---|
| Transport | P2P signed append-only entries; httpPeer `:8799`, static `entries.jsonl` | REST, `127.0.0.1:8752` behind quick tunnel |
| Record shape | `{id, t, …}` entries (`profile.*`, `device.*`, `session.*`, wallet/profile updates) | `SyncRecord {id, kind: chat|message|setting, updatedAt, deviceId, deleted, payload}` |
| Session | localStorage `rdragon.csp.rlogin-session.v1` `{v, handle, at, out, profile?, seq?}`; `rlogin-session` CustomEvent `{handle, from, out}` | `AuthManager` account + owner device-key approval |

**Bridge (works now, one-way, display only):** `ASSMKitBridge.sessionEventScript()` returns JS that dispatches `rlogin-session` with `detail {handle, from, out, source:"assmkit", app, deviceApproved, at}`. The host posts it with `webView.evaluateJavaScript(...)` after sign-in / sign-out. It does not write the card's localStorage, does not append ЯSYNC entries, and carries no secrets. No web sync endpoint was changed.

**Missing record mapping (gap):** there is no mapping between ЯSYNC entries and `SyncRecord`s. Needed before the two can share data:
1. Decide which ЯSYNC entry types (if any) mirror into ASSM-RSYNC `setting` records (e.g. `profile.update` name/handle/avatar ref).
2. Chat/message records have no ЯSYNC equivalent; they stay in ASSM-RSYNC.
3. A `session.start` for the native key would require the native key to be enrolled in the ЯSYNC profile log too (a second approval in that system).
4. Wallet entries (`profile.wallet`) stay out of ASSMKit entirely.

## 4. ASSM username + password (Option A, Rizal's GO t251u) — built

Earlier finding (t249u): no server-side verifier existed (ASSM-RSYNC had none; :8799 not running; rizal.pw's
password login is browser-only vault decryption). Rizal chose Option A: he sets a password once on a trusted
device and ASSM-RSYNC checks it.

**Scheme `pbkdf2-sha256-hmac-v1` (option a: client-side KDF; the plaintext never reaches the server)**

    dk       = PBKDF2-HMAC-SHA256(password_utf8, salt (16 random bytes), iter = 600000 (server minimum), 32 bytes)
    verifier = HMAC-SHA256(key = dk, message = "assm-password-verifier-v1")
    proof    = base64(dk)

Server (`ASSM-RSYNC/pwlogin.py`, wired into `server.py`) stores only `{scheme, handle, salt, iter, verifier, set_at, set_by}`
in `data/assm-password.json` (0600, atomic write). Login recomputes `HMAC(proof)` and compares with
`hmac.compare_digest`. `proof` is password-equivalent for this server only and only travels over HTTPS (tunnel);
it is never stored or logged.

**Routes** (base = live URL from `https://rizal.pw/api/rsync/entries` → `live`; aliases under `/v1/assm/password/*`)

| Route | Body / query | Signed by | Responses |
|---|---|---|---|
| `GET /api/rsync/password/params?user=<ЯID-0001-3QQS or @chaserizal>` | — | — | 200 `{ok, scheme, profile, handle, salt, iter}` · 404 not set / unknown user |
| `POST /api/rsync/password/set` | `{t:"password.set", profile, handle, salt, iter, verifier, signer, nonce, ts, sig}` | ACTIVE trusted (approver) key = `signer` | 200 `{ok, profile, handle, changed}` · 400 bad body / plaintext present · 403 not an ACTIVE approver / bad sig · 409 replayed nonce |
| `POST /api/rsync/password/login` | `{t:"password.login", user, proof, device, device_name, nonce, ts, sig}` | the new device key = `device` | 200 `{ok, profile, handle, status:"trusted", already}` · 401 `wrong username or password` · 403 bad device sig · 409 replayed nonce · 429 `{retry_after_s}` |

Signature messages (ECDSA P-256 SHA-256, base64 raw r||s or DER; keys are base64 raw 65-byte X9.63):

    set:   "assm-password-set-v1\n" + profile \n handle \n salt \n iter \n verifier \n signer \n nonce \n ts
    login: "assm-password-login-v1\n" + user \n sha256hex(proof) \n device \n device_name \n nonce \n ts

`nonce` = 8–64 alphanumerics, single use (persisted in `data/assm-password-nonces.jsonl`); `ts` ISO-8601 UTC within ±120 s.
Lockout: per IP and per profile, 5 failures → 60 s, doubling each further failure (max 24 h), persisted in
`data/assm-password-lockout.json` across restarts; a correct login or a new password resets it.
On success: timestamped copy to `data/backups/trusted-devices.pre-pwlogin-<ts>.json`, only that device key appended
as `{pub, name, status:"ACTIVE", profiles:["ЯID-0001-3QQS"], method:"password"}`, and a `device.enroll` entry with
`method:"password"` in `entries.jsonl`. `password.set` writes an audit line (no salt/verifier).

**Apps (ASSMKit)**
- `SignInView` › "ASSM username + password" (under Continue with ASSM) → `AuthManager.signInWithASSMPassword` →
  `ASSMPasswordClient.login`: derives `dk`, signs with this app's `ASSMDeviceKey`, POSTs login; on 200 the normal
  flow links `ЯID-0001-3QQS`, marks the device approved and starts RSYNC.
- `AccountView` › "Set ASSM password" (shown only if this device's existing approver key is trusted;
  `ASSMApproverKey.existingPublicKeyBase64` never creates a key) → `SetASSMPasswordView`: 12+ characters,
  confirm, Face ID / passcode, then the approver key signature (user presence) → `/password/set`.
- Fields are cleared right after sending; the password is never stored (no UserDefaults, Keychain, logs).

**Android / Linux**: same routes, same derivation (`PBKDF2WithHmacSHA256`, 600000, 256 bits), proof = base64(dk),
same login signature string with the app's own device key.

## 5. Sign in with Apple on unsigned builds

ASAuthorizationError 1000 (`.unknown`) is what a build without the `com.apple.developer.applesignin` entitlement gets. ASSMKit maps it to "Apple sign-in needs a signed build. Use ASSM for now" (`AppleSignInProvider.friendlyError`). On macOS the entitlement is read from the running process (`SecTaskCopyValueForEntitlement`); when it is missing the Apple button is dimmed and tapping it shows the same message without calling Apple. On iOS that check is not public API, so the button stays enabled and only the error is mapped. ASSMKit adds no entitlements.

## 6. Hard limits kept
No signing, installs, enrolls or approvals by bots; no changes to `server.py`, `trusted-devices.json`, rizal.pw, `:8799`, `:8741`, App.swift, `.bak`, `rmint-onetap.js`, `rwallet-ghost.js`, RWALLET/ROSCRYPTO keys or wallets; never `info.rizal.rsign.*` or the rmail access group.
