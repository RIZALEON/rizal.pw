// swift-tools-version: 6.2
// ASSMKit — the one shared copy of RCODE's sign-in (ASSM + Apple + OAuth PKCE + password + passkey)
// and RSYNC chat/data sync. Lives in GHOSTMACHINE/Packages/ASSMKit; RCODE and GHOSTMACHINE-macOS
// both reference it by local path. Build settings mirror RCODE's app target (Swift 5 mode,
// MainActor default isolation, approachable concurrency) so the moved code compiles unchanged.
import PackageDescription

let settings: [SwiftSetting] = [
    .defaultIsolation(MainActor.self),
    .enableUpcomingFeature("MemberImportVisibility"),
    .enableUpcomingFeature("NonisolatedNonsendingByDefault"),
    .enableUpcomingFeature("InferIsolatedConformances"),
    .enableUpcomingFeature("InferSendableFromCaptures"),
    .enableUpcomingFeature("GlobalActorIsolatedTypesUsability"),
    .enableUpcomingFeature("DisableOutwardActorInference"),
]

let package = Package(
    name: "ASSMKit",
    platforms: [.iOS(.v17), .macOS(.v13), .visionOS(.v1)],
    products: [
        .library(name: "ASSMKit", targets: ["ASSMKit"]),
    ],
    targets: [
        .target(name: "ASSMKit", path: "Sources/ASSMKit", swiftSettings: settings),
        .testTarget(name: "ASSMKitTests", dependencies: ["ASSMKit"], path: "Tests/ASSMKitTests", swiftSettings: settings),
    ],
    swiftLanguageModes: [.v5]
)
