import Testing
import Foundation
@testable import ASSMKit

/// RCODE's enrolled keys depend on these exact strings. No Keychain access here.
@Suite struct ASSMKitConfigTests {
    @Test func rcodeStringsAreUnchanged() {
        let c = ASSMKitConfig.rcode
        #expect(c.keychainService("assm-device-key") == "info.rizal.rcode.assm-device-key")
        #expect(c.keychainService("assm-approver-key") == "info.rizal.rcode.assm-approver-key")
        #expect(c.keychainService("account") == "info.rizal.rcode.account")
        #expect(c.keychainService("account.local") == "info.rizal.rcode.account.local")
        #expect(c.keychainService("session") == "info.rizal.rcode.session")
        #expect(c.keychainService("device") == "info.rizal.rcode.device")
        #expect(c.defaultsKey("serverURL") == "rcode.serverURL")
        #expect(c.defaultsKey("sync.cursor") == "rcode.sync.cursor")
        #expect(c.launchArg("ShowSignIn") == "-RCODEShowSignIn")
        #expect(c.baseURLEnvironmentKey == "RCODE_ASSM_BASE_URL")
        #expect(c.authConfigPlistName == "RCODEAuthConfig")
        #expect(c.cloudKitZoneName == "RCODESync")
        #expect(ASSMKitConfig.current == .rcode)
    }

    @Test func ghostMachineHasItsOwnKeychainService() {
        #expect(ASSMKitConfig.ghostMachine.keychainPrefix.hasPrefix("info.rizal.ghostmachine."))
        let g = ASSMKitConfig.ghostMachine
        #expect(g.keychainService("assm-device-key").hasPrefix("info.rizal.ghostmachine."))
        #expect(g.keychainService("assm-device-key") != ASSMKitConfig.rcode.keychainService("assm-device-key"))
    }

    @Test func shortCodeIsStable() {
        let a = ASSMEnrollRequest.shortCode(device: "AAAA", nonce: "n1")
        #expect(a.count == 9 && a.contains("-"))
        #expect(a == ASSMEnrollRequest.shortCode(device: "AAAA", nonce: "n1"))
    }
}

@Suite struct ASSMKitSafetyAndBridgeTests {
    @Test func reservedNamesAreRefused() {
        #expect(ASSMKitConfig.isReserved("info.rizal.rsign.assm"))
        #expect(ASSMKitConfig.isReserved("info.rizal.rsign.anything"))
        #expect(ASSMKitConfig.isReserved("7D3P5F4V9M.info.rizal.rdragon.rmail"))
        #expect(!ASSMKitConfig.isReserved("info.rizal.rcode.assm-device-key"))
        var bad = ASSMKitConfig.ghostmachineMac; bad.keychainPrefix = "info.rizal.rsign"
        #expect(throws: ASSMKitConfig.ValidationError.self) { try bad.validate() }
        #expect(throws: Never.self) { try ASSMKitConfig.rcode.validate() }
        #expect(throws: Never.self) { try ASSMKitConfig.ghostmachineMac.validate() }
        #expect(throws: Never.self) { try ASSMKitConfig.ghostmachineIOS.validate() }
        // Store with a reserved service never touches the Keychain.
        let s = KeychainStore(service: "info.rizal.rsign.assm")
        #expect(s.isReserved)
        #expect(s.data(for: "x") == nil)
        #expect(throws: ASSMKitConfig.ValidationError.self) { try s.set(Data([1]), for: "x") }
    }

    @Test func ghostmachinePresets() {
        #expect(ASSMKitConfig.ghostmachineMac.keychainService("assm-device-key") == "info.rizal.ghostmachine.mac.assm-device-key")
        #expect(ASSMKitConfig.ghostmachineMac.defaultsKey("serverURL") == "ghostmachine.mac.serverURL")
        #expect(ASSMKitConfig.ghostmachineIOS.keychainPrefix == "info.rizal.ghostmachine.ios")
    }

    @Test func bridgeEventShape() {
        let e = ASSMKitBridge.SessionEvent(handle: ASSMKitBridge.normalizedHandle("@@ChaseRizal"), from: "ЯID-0001-3QQS", out: false, app: "GHOSTMACHINE")
        let js = ASSMKitBridge.sessionEventJSON(e)
        #expect(js.contains("\"handle\":\"@chaserizal\""))
        #expect(js.contains("\"from\":\"ЯID-0001-3QQS\""))
        #expect(js.contains("\"out\":false"))
        #expect(ASSMKitBridge.sessionEventScript(e).contains("new CustomEvent(\"rlogin-session\""))
    }
}

import AuthenticationServices

@Suite struct AppleSignInMessageTests {
    @MainActor @Test func error1000IsFriendly() {
        let e = AppleSignInProvider.friendlyError(ASAuthorizationError(.unknown))
        #expect(e.localizedDescription == "Apple sign-in needs a signed build. Use ASSM for now")
        #expect(ASAuthorizationError.Code.unknown.rawValue == 1000)
    }
    @MainActor @Test func unsignedTestRunnerHasNoEntitlement() {
        #if os(macOS)
        #expect(AppleSignInProvider.hasAppleSignInEntitlement != true)
        #expect(AppleSignInProvider().isConfigured == (AppleSignInProvider.hasAppleSignInEntitlement != false))
        #endif
    }
}

import CryptoKit

@Suite struct ASSMPasswordTests {
    /// Matches pwlogin.py: PBKDF2-HMAC-SHA256 (RFC 6070-style vector for SHA-256, 1 iteration) and HMAC verifier.
    @Test func pbkdf2KnownVector() {
        let dk = ASSMPasswordClient.derive(password: "password", salt: Data("salt".utf8), iterations: 1)
        #expect(dk.map { String(format: "%02x", $0) }.joined() == "120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b")
    }
    @Test func strength() {
        #expect(ASSMPasswordClient.strengthProblem("short", confirm: "short") == .tooShort)
        #expect(ASSMPasswordClient.strengthProblem("twelve-chars-ok", confirm: "different-12chars") == .mismatch)
        #expect(ASSMPasswordClient.strengthProblem("twelve-chars-ok", confirm: "twelve-chars-ok") == nil)
    }
    @Test func messagesMatchServer() {
        let m = ASSMPasswordClient.setMessage(profile: "P", handle: "@h", salt: "S", iter: 600000, verifier: "V", signer: "K", nonce: "N", ts: "T")
        #expect(m == "assm-password-set-v1\nP\n@h\nS\n600000\nV\nK\nN\nT")
        let l = ASSMPasswordClient.loginMessage(user: "@h", proof: "abc", device: "D", deviceName: "n", nonce: "N", ts: "T")
        #expect(l == "assm-password-login-v1\n@h\nba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad\nD\nn\nN\nT")
        #expect(ASSMPasswordClient.nonce().count >= 8)
    }
}
