# ASSMKit

The **one copy** of RCODE's sign-in and RSYNC sync, shared by RCODE and GHOSTMACHINE.

- Path: `~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit` (local Swift package, tools 6.2)
- Product: `ASSMKit` (library). Platforms: iOS 17, macOS 13, visionOS 1. Newer APIs are gated with `#available`.
- Build settings mirror RCODE's target: Swift 5 language mode, `MainActor` default isolation, approachable concurrency, `MemberImportVisibility`.
- Moved from RCODE (`RCODE/Auth`, `RCODE/Auth/Providers`, `RCODE/AuthUI`, `RCODE/Sync` minus `ChatStore`). Behavior unchanged; `public` added and app-specific strings routed through `ASSMKitConfig`.

## What's inside

| Area | Types |
|---|---|
| Config | `ASSMKitConfig` (`.rcode`, `.ghostmachineMac`, `.ghostmachineIOS`, `.ghostMachine` = per-platform), reserved-name guard |
| Sign-in (one manager) | `AuthManager` (`.shared`, `.configured(_:)`), providers `ASSMProvider`, `AppleSignInProvider`, `OAuthPKCEProvider` (Google / Microsoft), `PasswordProvider`, `PasskeyProvider`, `AuthProvider`, `AuthProviderKind`, `AuthMode`, `ProviderCredential`, `RCODEAccount`, `LinkedIdentity`, `SessionTokens`, `AuthError` |
| ASSM device key / approval | `ASSMDeviceKey` (per-app device key), `ASSMEnrollRequest` (8-digit code + QR), `ASSMDeviceStatus`, `ASSMLiveURL`, `ASSMApproverKey`, `ASSMApproveClient`, `ASSMRsyncSeal`, `ASSMPendingRequest`, `OwnerProfile` |
| Sync | `SyncCoordinator` (outbox, LWW merge, 20 s polling, `incoming`), `SyncService`, `ASSMSyncService` (`/v1/sync/changes`, `/v1/sync/pull`), `RESTSyncService`, `LocalOnlySyncService`, `CloudKitSyncService`, `SyncRecord`, `DeviceInfo`, `DeviceRegistry` |
| UI (SwiftUI) | `SignInView`, `ServerSettingsView`, `AccountView`, `AccountBadge`, `DevicesView`, `ApproveDeviceView`, `OwnerApprovalBanner`, `RCODEAppMark`, `AuthPillButton`, `QRCodeView`, `ASSMTheme` (+ `Color(assmHex:)`, `Color(rcodeHex:)`, `Color(hex:)`) |
| ASSM password | `ASSMPasswordClient` (`login`, `setPassword`, `approverIsTrusted`, `derive`, `verifier`), `SetASSMPasswordView`, `AuthManager.signInWithASSMPassword` — see INTEGRATION.md §4 |
| Web bridge | `ASSMKitBridge.sessionEventJSON()`, `.sessionEventScript()` — posts an `rlogin-session` event into a web ASSM card |
| Helpers | `KeychainStore`, `BackendClient`, `AuthConfig`, `UnlockGate`, `PKCE`, `JWT`, `Nonce`, `Base64URL`, `JSONCoding`, `PresentationAnchor` |

### One identity
Every provider (ASSM, Apple, Google/Microsoft PKCE, password, passkey, device link) goes through `AuthManager.complete` and then `unifyOnOwnerIdentity(after:)`: the account always carries the bundled owner ASSM identity (`OwnerProfile.plist`, e.g. `ЯID-0001-3QQS`), and the device-key session is the owner enrollment for **this app's** device key. ASSMKit never approves or trusts a key itself; Rizal approves each new key once from a trusted device.

## Config (per host app)

```swift
import ASSMKit

@main struct GhostMachineApp: App {   // illustrative; ABOT owns GHOSTMACHINE's app sources
    @StateObject private var auth = AuthManager.configured(.ghostmachineMac)   // set before first Keychain use
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(auth)
                .sheet(isPresented: $auth.presentSignIn) { SignInView().environmentObject(auth) }
                .safeAreaInset(edge: .top) { OwnerApprovalBanner().environmentObject(auth) }
                .task { auth.startOwnerEnrollmentIfNeeded(); auth.sync.startPolling() }
        }
    }
}
```

| Preset | Keychain prefix | Defaults prefix | Scheme | Launch-arg prefix | Plist |
|---|---|---|---|---|---|
| `.rcode` (default) | `info.rizal.rcode` | `rcode` | `rcode` | `-RCODE…` | `RCODEAuthConfig.plist` |
| `.ghostmachineMac` | `info.rizal.ghostmachine.mac` | `ghostmachine.mac` | `ghostmachine` | `-GHOSTMACHINE…` | `ASSMAuthConfig.plist` |
| `.ghostmachineIOS` | `info.rizal.ghostmachine.ios` | `ghostmachine.ios` | `ghostmachine` | `-GHOSTMACHINE…` | `ASSMAuthConfig.plist` |

Keychain services = `<prefix>.assm-device-key`, `.assm-approver-key` (also the approver key tag), `.account`, `.account.local`, `.session`, `.device`. The `.rcode` preset reproduces RCODE's original strings byte-for-byte (unit-tested), so RCODE's already-enrolled keys keep working.

**Reserved, refused at runtime:** service `info.rizal.rsign.assm`, anything under `info.rizal.rsign.*`, access group `7D3P5F4V9M.info.rizal.rdragon.rmail`. `ASSMKitConfig.validate()` throws, `AuthManager.configured(_:)` refuses such a config, and `KeychainStore` / `ASSMApproverKey` will not read, write or delete those items. ASSMKit sets no access group.

**Isolated launch:** `-<prefix>RemoteOpen` (RCODE REMOTE screen) or `-<prefix>AuthPreview` → `ASSMKitConfig.isIsolatedLaunch`: no Keychain account read, no device key, no enrollment.

**Preview / screenshot mode:** launch with `-<prefix>AuthPreview` (e.g. `-RCODEAuthPreview`, `-GHOSTMACHINEAuthPreview`). `AuthManager` then shows the sign-in sheet without reading the Keychain, creating a device key, enrolling, or syncing; `DeviceInfo` uses an ephemeral id.

## Adding it to GHOSTMACHINE-macOS (ABOT)

XcodeGen `project.yml` (relative to the GHOSTMACHINE project root):

```yaml
packages:
  ASSMKit:
    path: Packages/ASSMKit
targets:
  GHOSTMACHINE-macOS:
    dependencies:
      - package: ASSMKit
        product: ASSMKit
```

Then bundle two plists in the app target: `ASSMAuthConfig.plist` (copy of RCODE's `RCODEAuthConfig.plist` keys: `ASSMBaseURL`, `ASSMFallbackBaseURL` = `https://rizal.pw`, `ASSMEnrollEntriesPath`, `ASSMDefaultProfile`, optional Google/Microsoft client IDs, `DefaultSyncServerURL`) and `OwnerProfile.plist` (public `ASSMProfileID` `ЯID-0001-3QQS`, `Handle`, `DisplayName`; no secrets). Network client entitlement is required for a sandboxed Mac app. Keychain Sharing is **not** required (the iCloud-synced account record falls back to a local item). Leave RWALLET / ROSCRYPTO key and wallet code alone.

RCODE references the same folder from `RCODE.xcodeproj` (`XCLocalSwiftPackageReference`, relativePath `../../../../../R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit`). RCODE has no copy of its own.

## Server

- ASSM-RSYNC: `~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC/server.py`, bound to `127.0.0.1:8752`, reached through the cloudflared quick tunnel. Its URL changes on restart; apps rediscover it from `https://rizal.pw/api/rsync/entries` (`live` field), published by `publish-live-url.sh`.
- Enrollment: `POST /api/rsync/request` (device.request), `/api/rsync/approve` (sealed device.enroll from a trusted approver), `GET /api/rsync/device-status?pub=`.
- Password: `GET /api/rsync/password/params`, `POST /api/rsync/password/set` (approver-signed verifier), `POST /api/rsync/password/login` (device-signed proof → that key ACTIVE).
- Sync: `POST /v1/sync/changes` (push, batches of 25, backoff on 429), `POST /v1/sync/pull` (cursor), signed `rcode-sync-v1` by the device key, identity = owner ASSM profile. Last-writer-wins on `updatedAt`, ties by deviceId.
- Each app on each device has its own P-256 key, approved once by Rizal. Bots never enroll or approve.

## Verify

```sh
swift build && swift test          # config strings, reserved-name guard, bridge shape, short code
xcodebuild -scheme ASSMKit -destination 'generic/platform=iOS' CODE_SIGNING_ALLOWED=NO build
```
