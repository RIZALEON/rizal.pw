import SwiftUI
import Foundation
import CryptoKit
import CommonCrypto
import Security

// MARK: - KROG bot sign-in (TEST ONLY) — ASSM-RSYNC-BOTTEST-20261116 on http://127.0.0.1:8753
//
// KROG (@krog, ЯID-BOT-0001) is a LIMITED bot profile: role "bot", scopes signin / post / reply only.
// The test server refuses KROG on every wallet, RWALLET, approve, sign, mint, trade, swap, buy, sell and
// password-set route, and a KROG login never adds a device to the owner's trusted-devices.json.
//
// * Password: read from THIS app's own Keychain item `<keychainPrefix>.saved-login.krog` (account "@krog").
//   If it isn't there (e.g. iOS / Designed-for-iPad), `importPassword(_:)` adds it once (add-only, never updates).
//   The plaintext is never logged, never sent (only proof = base64(PBKDF2) goes out), never put in UserDefaults.
// * Device key: a SEPARATE P-256 key `<keychainPrefix>.krog-bot.devicekey`, never the owner's ASSM device key
//   (the server refuses owner trusted keys on bot login).
// * Session: bearer token kept in memory only.
// * Never uses `info.rizal.rsign.*` names or any shared access group.
// Base URL override: environment `KROG_BOT_BASE_URL` (default http://127.0.0.1:8753).
enum KROGBot {
    static let handle = "@krog"
    static let profile = "ЯID-BOT-0001"
    static let display = "KROG"
    static let scheme = "pbkdf2-sha256-hmac-v1"
    static let minIterations = 600_000
    nonisolated static var baseURL: URL {
        if let s = ProcessInfo.processInfo.environment["KROG_BOT_BASE_URL"], let u = URL(string: s) { return u }
        return URL(string: "http://127.0.0.1:8753")!
    }
}

enum KROGBotError: LocalizedError {
    case reservedName, noPassword, noServer, wrong, lockedOut(Int), refused(String), server(Int, String)
    var errorDescription: String? {
        switch self {
        case .reservedName: return "Refusing a reserved Keychain name."
        case .noPassword: return "No KROG password saved in this app yet. Import it once from the test server's secrets file."
        case .noServer: return "The KROG test server (127.0.0.1:8753) isn't reachable."
        case .wrong: return "Wrong KROG username or password."
        case .lockedOut(let s): return "Too many attempts. Try again in \(max(1, s)) s."
        case .refused(let m): return "Refused: \(m)"
        case .server(let c, let m): return "Server error \(c): \(m)"
        }
    }
}

@MainActor
final class KROGBotClient: ObservableObject {
    let keychainPrefix: String
    let base: URL
    @Published private(set) var signedIn = false
    @Published private(set) var status = "KROG: signed out"
    @Published private(set) var scopes: [String] = []
    private var session: String?

    init(keychainPrefix: String, base: URL = KROGBot.baseURL) {
        self.keychainPrefix = keychainPrefix
        self.base = base
    }

    var loginService: String { keychainPrefix + ".saved-login.krog" }
    var deviceService: String { keychainPrefix + ".krog-bot.devicekey" }

    private func checkNames() throws {
        for n in [loginService, deviceService] where n.hasPrefix("info.rizal.rsign") || n.contains("rdragon.rmail") {
            throw KROGBotError.reservedName
        }
    }

    // MARK: Keychain (this app's own generic-password items, no access group)
    nonisolated private static func kcRead(_ service: String, _ account: String) -> Data? {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service,
                                kSecAttrAccount as String: account, kSecReturnData as String: true,
                                kSecMatchLimit as String: kSecMatchLimitOne]
        var out: CFTypeRef?
        return SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess ? out as? Data : nil
    }
    /// Add-only. Returns false if an item already exists (never overwrites).
    nonisolated private static func kcAdd(_ service: String, _ account: String, _ label: String, _ data: Data) -> Bool {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service,
                                kSecAttrAccount as String: account, kSecAttrLabel as String: label, kSecValueData as String: data,
                                kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly]
        return SecItemAdd(q as CFDictionary, nil) == errSecSuccess
    }

    var hasSavedPassword: Bool { Self.kcRead(loginService, KROGBot.handle) != nil }

    /// One-time import of the KROG password into this app's Keychain (add-only). Clear the text field after calling.
    @discardableResult
    func importPassword(_ password: String) throws -> Bool {
        try checkNames()
        let pw = password.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !pw.isEmpty else { throw KROGBotError.noPassword }
        return Self.kcAdd(loginService, KROGBot.handle, "KROG", Data(pw.utf8))
    }

    private func deviceKey() throws -> P256.Signing.PrivateKey {
        try checkNames()
        if let raw = Self.kcRead(deviceService, "krog-bot"), let k = try? P256.Signing.PrivateKey(rawRepresentation: raw) { return k }
        let k = P256.Signing.PrivateKey()
        _ = Self.kcAdd(deviceService, "krog-bot", "KROG bot device key (test)", k.rawRepresentation)
        return k
    }

    // MARK: Protocol helpers (match botauth.py)
    nonisolated static func derive(password: String, salt: Data, iterations: Int) -> Data {
        var out = Data(count: 32)
        let pw = Array(password.utf8)
        _ = out.withUnsafeMutableBytes { o in
            salt.withUnsafeBytes { s in
                CCKeyDerivationPBKDF(CCPBKDFAlgorithm(kCCPBKDF2), pw.map { Int8(bitPattern: $0) }, pw.count,
                                     s.bindMemory(to: UInt8.self).baseAddress, salt.count,
                                     CCPseudoRandomAlgorithm(kCCPRFHmacAlgSHA256), UInt32(iterations),
                                     o.bindMemory(to: UInt8.self).baseAddress, 32)
            }
        }
        return out
    }
    nonisolated static func loginMessage(user: String, proof: String, device: String, deviceName: String, nonce: String, ts: String) -> String {
        let ph = SHA256.hash(data: Data(proof.utf8)).map { String(format: "%02x", $0) }.joined()
        return "assm-bot-login-v1\n" + [user, ph, device, deviceName, nonce, ts].joined(separator: "\n")
    }
    nonisolated private static func nonce() -> String {
        var b = [UInt8](repeating: 0, count: 16); _ = SecRandomCopyBytes(kSecRandomDefault, b.count, &b)
        return b.map { String(format: "%02x", $0) }.joined()
    }
    nonisolated private static func now() -> String {
        let f = ISO8601DateFormatter(); f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return f.string(from: Date())
    }

    // MARK: Network
    private func request(_ method: String, _ path: String, _ body: [String: Any]? = nil, query: [URLQueryItem] = [],
                         auth: Bool = false) async throws -> (Int, [String: Any]) {
        guard var c = URLComponents(url: base.appendingPathComponent(path), resolvingAgainstBaseURL: false) else { throw KROGBotError.noServer }
        if !query.isEmpty { c.queryItems = query }
        var r = URLRequest(url: c.url!, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20)
        r.httpMethod = method
        if let body { r.setValue("application/json", forHTTPHeaderField: "Content-Type"); r.httpBody = try JSONSerialization.data(withJSONObject: body) }
        if auth, let s = session { r.setValue("Bearer " + s, forHTTPHeaderField: "Authorization") }
        guard let (d, resp) = try? await URLSession.shared.data(for: r), let code = (resp as? HTTPURLResponse)?.statusCode else { throw KROGBotError.noServer }
        return (code, (try? JSONSerialization.jsonObject(with: d) as? [String: Any]) ?? [:])
    }

    /// Signs KROG in with the saved password and a bot-only device key. Returns the granted scopes.
    @discardableResult
    func login(deviceName: String = "KROG test") async throws -> [String] {
        try checkNames()
        guard let pwData = Self.kcRead(loginService, KROGBot.handle), let password = String(data: pwData, encoding: .utf8) else { throw KROGBotError.noPassword }
        let (pc, params) = try await request("GET", "api/rsync/bot/params", query: [URLQueryItem(name: "user", value: KROGBot.handle)])
        if pc == 404 { throw KROGBotError.wrong }
        guard pc == 200, (params["role"] as? String) == "bot", let sb = params["salt"] as? String, let salt = Data(base64Encoded: sb),
              let iter = params["iter"] as? Int, iter >= KROGBot.minIterations else { throw KROGBotError.server(pc, "bad params") }
        let dk = await Task.detached { KROGBotClient.derive(password: password, salt: salt, iterations: iter) }.value
        let proof = dk.base64EncodedString()
        let key = try deviceKey()
        let pub = key.publicKey.x963Representation.base64EncodedString()
        let n = Self.nonce(), ts = Self.now()
        let sig = try key.signature(for: Data(Self.loginMessage(user: KROGBot.handle, proof: proof, device: pub, deviceName: deviceName, nonce: n, ts: ts).utf8))
            .rawRepresentation.base64EncodedString()
        let (code, out) = try await request("POST", "api/rsync/bot/login", ["t": "bot.login", "user": KROGBot.handle, "proof": proof, "device": pub,
                                                                           "device_name": deviceName, "nonce": n, "ts": ts, "sig": sig])
        switch code {
        case 200:
            guard (out["role"] as? String) == "bot", let tok = out["session"] as? String else { throw KROGBotError.server(200, "not a bot session") }
            session = tok; scopes = out["scopes"] as? [String] ?? []; signedIn = true
            status = "KROG: signed in (\(scopes.joined(separator: ", ")))"
            return scopes
        case 401: throw KROGBotError.wrong
        case 429: throw KROGBotError.lockedOut(out["retry_after_s"] as? Int ?? 60)
        case 403: throw KROGBotError.refused(out["error"] as? String ?? "forbidden")
        default: throw KROGBotError.server(code, out["error"] as? String ?? "")
        }
    }

    func whoami() async throws -> [String: Any] {
        let (c, o) = try await request("GET", "api/rsync/bot/whoami", auth: true)
        guard c == 200 else { signedIn = false; throw KROGBotError.server(c, o["error"] as? String ?? "") }
        return o
    }

    /// Posts a test post as KROG (scope "post"). Returns the stored record.
    func post(_ text: String) async throws -> [String: Any] {
        let (c, o) = try await request("POST", "api/rsync/bot/post", ["text": text], auth: true)
        guard c == 201, let rec = o["record"] as? [String: Any] else { throw KROGBotError.server(c, o["error"] as? String ?? "") }
        return rec
    }

    /// Posts a test reply as KROG under `parentId` (scope "reply"), next to RDRAGON's reply.
    func reply(to parentId: String, text: String, parentAuthor: String? = nil) async throws -> [String: Any] {
        var b: [String: Any] = ["text": text, "parent_id": parentId]
        if let parentAuthor { b["parent_author"] = parentAuthor }
        let (c, o) = try await request("POST", "api/rsync/bot/reply", b, auth: true)
        guard c == 201, let rec = o["record"] as? [String: Any] else { throw KROGBotError.server(c, o["error"] as? String ?? "") }
        return rec
    }

    func logout() async {
        _ = try? await request("POST", "api/rsync/bot/logout", [:], auth: true)
        session = nil; signedIn = false; scopes = []; status = "KROG: signed out"
    }
}

// MARK: - RCODE: KROG test panel (opened from the menu's "KROG bot (test)" row)

struct KROGTestPanel: View {
    @StateObject private var krog = KROGBotClient(keychainPrefix: "info.rizal.rcode")
    @State private var importText = ""
    @State private var parentId = ""
    @State private var replyText = "KROG test reply"
    @State private var log: [String] = []
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack { Text("KROG bot (test)").font(.headline); Spacer(); Button("Done") { dismiss() } }
            Text("@krog · ЯID-BOT-0001 · role bot · sign-in, post, reply only. Test server \(krog.base.absoluteString). No wallet, approve, sign or mint.")
                .font(.caption).foregroundStyle(.secondary).fixedSize(horizontal: false, vertical: true)
            Text(krog.status).font(.footnote)
            if !krog.hasSavedPassword {
                SecureField("Import KROG password once (from secrets/bot-login.txt)", text: $importText)
                Button("Save to this app's Keychain") {
                    let ok = (try? krog.importPassword(importText)) ?? false
                    importText = ""
                    log.append(ok ? "Saved KROG login to Keychain." : "Not saved (already there or refused).")
                }
            }
            HStack {
                Button(krog.signedIn ? "Sign out" : "Sign in as KROG") {
                    Task {
                        if krog.signedIn { await krog.logout(); return }
                        do { let s = try await krog.login(deviceName: "RCODE KROG test"); log.append("Signed in: " + s.joined(separator: ", ")) }
                        catch { log.append(error.localizedDescription) }
                    }
                }
                Button("Test post") {
                    Task {
                        do { let r = try await krog.post("KROG test post from RCODE"); parentId = r["id"] as? String ?? ""; log.append("Posted \(parentId)") }
                        catch { log.append(error.localizedDescription) }
                    }
                }.disabled(!krog.signedIn)
            }
            TextField("Reply to post id", text: $parentId)
            TextField("Reply text", text: $replyText)
            Button("Test reply") {
                Task {
                    do { let r = try await krog.reply(to: parentId, text: replyText); log.append("Replied \(r["id"] as? String ?? "")") }
                    catch { log.append(error.localizedDescription) }
                }
            }.disabled(!krog.signedIn || parentId.isEmpty)
            ScrollView { VStack(alignment: .leading) { ForEach(Array(log.enumerated()), id: \.offset) { Text($0.element).font(.caption.monospaced()) } } }
        }
        .padding(16)
        .frame(minWidth: 360, minHeight: 420)
    }
}
