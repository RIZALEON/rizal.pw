# MANIFEST — KROG-ASSM-SERVER-PACK-20261116

Generated Monday, Nov 16, 2026 (America/Denver). `RC` = `~/R/ЯLAB/RCRYPTOFORGE` on the MacBook Neo. Neo sources were copied at 6:13 PM MST.
Dates are the source file's modification time in America/Denver (MST); for new files, when they were written on the box.

## Redactions and edits
- `server/server.py`: patched: bot/create route, HOST env, health mode env
- `server/bot-bootstrap.py`: unsigned bootstrap gated off by default
- `wallet/rwallet/rmint-transport.js`: LAN hosts (2) + LAN IP + subnet comment redacted
- `clients/swift/RCODE-Auth-plists/RCODEAuthConfig.plist`: tunnel URL → https://ASSM_SERVER_URL
- `clients/linux/assm-linux/assm_linux/config.py`: tunnel URL → https://ASSM_SERVER_URL
- `clients/linux/assm-linux/tests/test_assm_linux.py`: example tunnel host → x.example
- `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/AssmKitConfig.kt`: tunnel URL → https://ASSM_SERVER_URL
- `clients/swift/ASSMKit/INTEGRATION.md`: tunnel URL → ASSM_SERVER_URL
- Wallet note: `wallet/rwallet/RWALLET.sha256` still lists the original `rmint-transport.js` hash; regenerate it before shipping this bundle.

## Excluded by rule (never copied)
- every `data/`, `secrets/` (incl. `bot-login.txt`), `keys/`, `*.pem/*.key/*.p8/*.p12`, `*.log`, `*.pid`, `trusted-devices*.json`, `.git`, `.DS_Store`, AppleDouble `._*`
- `ASSM-RSYNC/info.rizal.assm-rsync*.plist` (Neo launchd), `ASSM-RSYNC/publish-live-url.sh` (tunnel publisher), `server.py.pre-*` backups, `ASSM-RSYNC/add-trusted-device.py` (owner trust-store tool, Neo only)

## Files (175)

| File | Bytes | Source | Source date (MST) | Note |
|---|---:|---|---|---|
| `README.md` | 2268 | new in this pack (box) | 2026-11-16 18:18 |  |
| `clients/android/assmkit-android/README.md` | 4419 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/README.md | 2026-11-16 14:07 |  |
| `clients/android/assmkit-android/build.gradle.kts` | 1853 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/build.gradle.kts | 2026-11-16 13:48 |  |
| `clients/android/assmkit-android/consumer-rules.pro` | 69 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/consumer-rules.pro | 2026-11-16 13:48 |  |
| `clients/android/assmkit-android/src/main/AndroidManifest.xml` | 1188 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/AndroidManifest.xml | 2026-11-16 13:48 |  |
| `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/AssmKitConfig.kt` | 2597 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/java/info/rizal/assmkit/AssmKitConfig.kt | 2026-11-16 13:47 | tunnel URL → https://ASSM_SERVER_URL |
| `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/assm/Assm.kt` | 8562 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/java/info/rizal/assmkit/assm/Assm.kt | 2026-11-16 13:45 |  |
| `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/auth/AssmAuth.kt` | 8374 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/java/info/rizal/assmkit/auth/AssmAuth.kt | 2026-11-16 14:05 |  |
| `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/auth/AuthModels.kt` | 2992 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/java/info/rizal/assmkit/auth/AuthModels.kt | 2026-11-16 13:46 |  |
| `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/auth/Pkce.kt` | 940 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/java/info/rizal/assmkit/auth/Pkce.kt | 2026-11-16 13:49 |  |
| `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/auth/Providers.kt` | 18594 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/java/info/rizal/assmkit/auth/Providers.kt | 2026-11-16 14:04 |  |
| `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/auth/Redirect.kt` | 1223 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/java/info/rizal/assmkit/auth/Redirect.kt | 2026-11-16 13:46 |  |
| `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/core/Canon.kt` | 3909 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/java/info/rizal/assmkit/core/Canon.kt | 2026-11-16 13:45 |  |
| `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/core/Config.kt` | 4368 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/java/info/rizal/assmkit/core/Config.kt | 2026-11-16 13:45 |  |
| `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/core/DeviceKey.kt` | 7227 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/java/info/rizal/assmkit/core/DeviceKey.kt | 2026-11-16 13:45 |  |
| `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/core/Http.kt` | 3218 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/java/info/rizal/assmkit/core/Http.kt | 2026-11-16 13:47 |  |
| `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/core/UnlockGate.kt` | 3148 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/java/info/rizal/assmkit/core/UnlockGate.kt | 2026-11-16 13:45 |  |
| `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/sync/Sync.kt` | 6080 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/java/info/rizal/assmkit/sync/Sync.kt | 2026-11-16 13:45 |  |
| `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/sync/SyncCoordinator.kt` | 5253 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/java/info/rizal/assmkit/sync/SyncCoordinator.kt | 2026-11-16 13:45 |  |
| `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/ui/Qr.kt` | 1504 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/java/info/rizal/assmkit/ui/Qr.kt | 2026-11-16 13:48 |  |
| `clients/android/assmkit-android/src/main/java/info/rizal/assmkit/ui/SignInScreen.kt` | 13689 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/main/java/info/rizal/assmkit/ui/SignInScreen.kt | 2026-11-16 14:05 |  |
| `clients/android/assmkit-android/src/test/java/info/rizal/assmkit/AssmKitContractTest.kt` | 1912 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/test/java/info/rizal/assmkit/AssmKitContractTest.kt | 2026-11-16 13:50 |  |
| `clients/android/assmkit-android/src/test/java/info/rizal/assmkit/AssmPasswordTest.kt` | 7456 | ~/Library/Developer/Xcode/UntitledProjects/RCODE-android/android/assmkit-android/src/test/java/info/rizal/assmkit/AssmPasswordTest.kt | 2026-11-16 14:06 |  |
| `clients/krog/krog-reply.rzl.js` | 9282 | new in this pack (box) | 2026-11-16 18:00 |  |
| `clients/linux/assm-linux/README.md` | 4406 | RCODE git branch `linux`: tools/assm-linux/README.md (in ~/Library/Developer/Xcode/UntitledProjects/RCODE) | 2026-11-16 14:13 |  |
| `clients/linux/assm-linux/assm-linux` | 219 | RCODE git branch `linux`: tools/assm-linux/assm-linux (in ~/Library/Developer/Xcode/UntitledProjects/RCODE) | 2026-11-16 14:13 |  |
| `clients/linux/assm-linux/assm_linux/__init__.py` | 509 | RCODE git branch `linux`: tools/assm-linux/assm_linux/__init__.py (in ~/Library/Developer/Xcode/UntitledProjects/RCODE) | 2026-11-16 14:13 |  |
| `clients/linux/assm-linux/assm_linux/__main__.py` | 50 | RCODE git branch `linux`: tools/assm-linux/assm_linux/__main__.py (in ~/Library/Developer/Xcode/UntitledProjects/RCODE) | 2026-11-16 14:13 |  |
| `clients/linux/assm-linux/assm_linux/assm.py` | 8663 | RCODE git branch `linux`: tools/assm-linux/assm_linux/assm.py (in ~/Library/Developer/Xcode/UntitledProjects/RCODE) | 2026-11-16 14:13 |  |
| `clients/linux/assm-linux/assm_linux/auth.py` | 14710 | RCODE git branch `linux`: tools/assm-linux/assm_linux/auth.py (in ~/Library/Developer/Xcode/UntitledProjects/RCODE) | 2026-11-16 14:13 |  |
| `clients/linux/assm-linux/assm_linux/canon.py` | 1843 | RCODE git branch `linux`: tools/assm-linux/assm_linux/canon.py (in ~/Library/Developer/Xcode/UntitledProjects/RCODE) | 2026-11-16 14:13 |  |
| `clients/linux/assm-linux/assm_linux/cli.py` | 5974 | RCODE git branch `linux`: tools/assm-linux/assm_linux/cli.py (in ~/Library/Developer/Xcode/UntitledProjects/RCODE) | 2026-11-16 14:13 |  |
| `clients/linux/assm-linux/assm_linux/config.py` | 2139 | RCODE git branch `linux`: tools/assm-linux/assm_linux/config.py (in ~/Library/Developer/Xcode/UntitledProjects/RCODE) | 2026-11-16 14:13 | tunnel URL → https://ASSM_SERVER_URL |
| `clients/linux/assm-linux/assm_linux/keystore.py` | 6090 | RCODE git branch `linux`: tools/assm-linux/assm_linux/keystore.py (in ~/Library/Developer/Xcode/UntitledProjects/RCODE) | 2026-11-16 14:13 |  |
| `clients/linux/assm-linux/assm_linux/loopback.py` | 14267 | RCODE git branch `linux`: tools/assm-linux/assm_linux/loopback.py (in ~/Library/Developer/Xcode/UntitledProjects/RCODE) | 2026-11-16 14:13 |  |
| `clients/linux/assm-linux/assm_linux/net.py` | 4755 | RCODE git branch `linux`: tools/assm-linux/assm_linux/net.py (in ~/Library/Developer/Xcode/UntitledProjects/RCODE) | 2026-11-16 14:13 |  |
| `clients/linux/assm-linux/assm_linux/page.py` | 8866 | RCODE git branch `linux`: tools/assm-linux/assm_linux/page.py (in ~/Library/Developer/Xcode/UntitledProjects/RCODE) | 2026-11-16 14:13 |  |
| `clients/linux/assm-linux/assm_linux/sync.py` | 3118 | RCODE git branch `linux`: tools/assm-linux/assm_linux/sync.py (in ~/Library/Developer/Xcode/UntitledProjects/RCODE) | 2026-11-16 14:13 |  |
| `clients/linux/assm-linux/tests/test_assm_linux.py` | 22618 | RCODE git branch `linux`: tools/assm-linux/tests/test_assm_linux.py (in ~/Library/Developer/Xcode/UntitledProjects/RCODE) | 2026-11-16 14:13 | example tunnel host → x.example |
| `clients/swift/ASSMKit/.gitignore` | 35 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/.gitignore | 2026-11-16 13:13 |  |
| `clients/swift/ASSMKit/INTEGRATION.md` | 9788 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/INTEGRATION.md | 2026-11-16 13:55 | tunnel URL → ASSM_SERVER_URL |
| `clients/swift/ASSMKit/Package.swift` | 1318 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Package.swift | 2026-11-16 13:04 |  |
| `clients/swift/ASSMKit/README.md` | 7410 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/README.md | 2026-11-16 13:55 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/ASSMKitConfig.swift` | 7577 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/ASSMKitConfig.swift | 2026-11-16 13:55 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/ASSMApproveClient.swift` | 11464 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/ASSMApproveClient.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/ASSMApproverKey.swift` | 9985 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/ASSMApproverKey.swift | 2026-11-16 13:53 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/ASSMDeviceStatus.swift` | 5746 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/ASSMDeviceStatus.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/ASSMPasswordClient.swift` | 10143 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/ASSMPasswordClient.swift | 2026-11-16 13:54 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/ASSMRsyncSeal.swift` | 9845 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/ASSMRsyncSeal.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/AuthConfig.swift` | 2569 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/AuthConfig.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/AuthHelpers.swift` | 3073 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/AuthHelpers.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/AuthManager.swift` | 21846 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/AuthManager.swift | 2026-11-16 13:55 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/AuthModels.swift` | 3461 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/AuthModels.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/AuthProvider.swift` | 477 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/AuthProvider.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/BackendClient.swift` | 3250 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/BackendClient.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/KeychainStore.swift` | 3357 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/KeychainStore.swift | 2026-11-16 13:05 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/OwnerProfile.swift` | 1302 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/OwnerProfile.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/Providers/ASSMProvider.swift` | 9816 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/Providers/ASSMProvider.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/Providers/AppleSignInProvider.swift` | 4816 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/Providers/AppleSignInProvider.swift | 2026-11-16 13:42 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/Providers/OAuthPKCEProvider.swift` | 6886 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/Providers/OAuthPKCEProvider.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/Providers/PasskeyProvider.swift` | 5365 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/Providers/PasskeyProvider.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Auth/Providers/PasswordProvider.swift` | 1866 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Auth/Providers/PasswordProvider.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/AuthUI/AccountViews.swift` | 9546 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/AuthUI/AccountViews.swift | 2026-11-16 13:55 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/AuthUI/ApproveDeviceView.swift` | 16910 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/AuthUI/ApproveDeviceView.swift | 2026-11-16 13:05 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/AuthUI/AuthComponents.swift` | 4618 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/AuthUI/AuthComponents.swift | 2026-11-16 13:02 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/AuthUI/OwnerApprovalBanner.swift` | 2727 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/AuthUI/OwnerApprovalBanner.swift | 2026-11-16 13:02 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/AuthUI/SetASSMPasswordView.swift` | 3148 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/AuthUI/SetASSMPasswordView.swift | 2026-11-16 13:54 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/AuthUI/SignInView.swift` | 13081 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/AuthUI/SignInView.swift | 2026-11-16 13:54 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Bridge/ASSMKitBridge.swift` | 3821 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Bridge/ASSMKitBridge.swift | 2026-11-16 13:07 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Sync/ASSMSyncService.swift` | 6917 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Sync/ASSMSyncService.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Sync/CloudKitSyncService.swift` | 3431 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Sync/CloudKitSyncService.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Sync/DeviceInfo.swift` | 6293 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Sync/DeviceInfo.swift | 2026-11-16 13:55 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Sync/DeviceRegistry.swift` | 3927 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Sync/DeviceRegistry.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Sync/SyncCoordinator.swift` | 5617 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Sync/SyncCoordinator.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Sync/SyncService.swift` | 4235 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Sync/SyncService.swift | 2026-11-16 13:02 |  |
| `clients/swift/ASSMKit/Sources/ASSMKit/Theme/ASSMTheme.swift` | 3365 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Sources/ASSMKit/Theme/ASSMTheme.swift | 2026-11-16 13:01 |  |
| `clients/swift/ASSMKit/Tests/ASSMKitTests/ASSMKitConfigTests.swift` | 5888 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/GHOSTMACHINE/Packages/ASSMKit/Tests/ASSMKitTests/ASSMKitConfigTests.swift | 2026-11-16 13:53 |  |
| `clients/swift/KROG/KROGBotLogin-RCODE.swift` | 14630 | ~/Library/Developer/Xcode/UntitledProjects/RCODE/RCODE/Auth/KROGBotLogin.swift | 2026-11-16 17:27 |  |
| `clients/swift/KROG/KROGBotLogin-RDRAGON-bottest-variant.swift` | 14818 | ~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC-BOTTEST-20261116/clients/KROGBotLogin-RDRAGON.swift | 2026-11-16 17:26 |  |
| `clients/swift/KROG/KROGBotLogin-RDRAGON.swift` | 14990 | ~/R/ЯLAB/RCRYPTOFORGE/cryptoapp/RDRAGON/RDRAGONSKULL/source/ios/App/Sources/KROGBotLogin.swift | 2026-11-16 18:13 |  |
| `clients/swift/RCODE-Auth-plists/OwnerProfile.plist` | 420 | ~/Library/Developer/Xcode/UntitledProjects/RCODE/RCODE/Auth/OwnerProfile.plist | 2026-11-16 00:59 |  |
| `clients/swift/RCODE-Auth-plists/RCODEAuthConfig.plist` | 1283 | ~/Library/Developer/Xcode/UntitledProjects/RCODE/RCODE/Auth/RCODEAuthConfig.plist | 2026-11-16 11:41 | tunnel URL → https://ASSM_SERVER_URL |
| `clients/web/assm-web-client.js` | 8254 | new in this pack (box) | 2026-11-16 18:05 |  |
| `docs/ASSM-RCODE-LOGIN-INSTALL-GUIDE.md` | 24570 | new in this pack (box) | 2026-11-16 18:17 |  |
| `docs/INSTALL-PER-DEVICE.md` | 6405 | new in this pack (box) | 2026-11-16 18:17 |  |
| `docs/VPS-HOST-OPTIONS.md` | 4700 | new in this pack (box) | 2026-11-16 18:01 |  |
| `plans/PLAN-20261116-KROG-RDRAGON-both-reply.md` | 8108 | box:/workspace/RINTEGRATE/PLAN-20261116-KROG-RDRAGON-both-reply.md | 2026-11-16 17:10 |  |
| `plans/PLAN-20261116-bot-login-site-rdragon.md` | 6235 | box:/workspace/RINTEGRATE/PLAN-20261116-bot-login-site-rdragon.md | 2026-11-16 17:29 |  |
| `server/Dockerfile` | 1059 | new in this pack (box) | 2026-11-16 18:01 |  |
| `server/README-BOTTEST.md` | 4049 | ~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC-BOTTEST-20261116/README.md | 2026-11-16 17:28 |  |
| `server/README-LIVE-ASSM-RSYNC.md` | 3913 | ~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC-BOTTEST-20261116/README-LIVE-COPY.md | 2026-11-16 01:23 |  |
| `server/README-SERVER.md` | 2674 | new in this pack (box) | 2026-11-16 18:18 |  |
| `server/bot-bootstrap.py` | 4066 | ~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC-BOTTEST-20261116/bot-bootstrap.py | 2026-11-16 17:21 | unsigned bootstrap gated off by default |
| `server/bot-selftest.py` | 13024 | ~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC-BOTTEST-20261116/bot-selftest.py | 2026-11-16 17:21 |  |
| `server/botauth.py` | 11222 | ~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC-BOTTEST-20261116/botauth.py | 2026-11-16 17:21 |  |
| `server/botcreate-selftest.py` | 5866 | new in this pack (box) | 2026-11-16 18:15 |  |
| `server/botcreate.py` | 5407 | new in this pack (box) | 2026-11-16 18:01 |  |
| `server/config/assm-server.env.example` | 1258 | new in this pack (box) | 2026-11-16 18:16 |  |
| `server/deploy/Caddyfile.example` | 499 | new in this pack (box) | 2026-11-16 18:15 |  |
| `server/deploy/assm-rsync.service` | 517 | new in this pack (box) | 2026-11-16 18:01 |  |
| `server/owner-tools/make-bot-create.py` | 2641 | new in this pack (box) | 2026-11-16 18:01 |  |
| `server/p256.py` | 3474 | ~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC-BOTTEST-20261116/p256.py | 2026-11-16 00:33 |  |
| `server/pwlogin-selftest.py` | 8747 | ~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC-BOTTEST-20261116/pwlogin-selftest.py | 2026-11-16 13:51 |  |
| `server/pwlogin.py` | 12178 | ~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC-BOTTEST-20261116/pwlogin.py | 2026-11-16 13:50 |  |
| `server/run.sh` | 988 | new in this pack (box) | 2026-11-16 18:01 |  |
| `server/selftest.py` | 5683 | ~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC-BOTTEST-20261116/selftest.py | 2026-11-16 01:22 |  |
| `server/server.py` | 24069 | ~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC-BOTTEST-20261116/server.py | 2026-11-16 17:21 | patched: bot/create route, HOST env, health mode env |
| `server/sync-selftest.py` | 9082 | ~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC-BOTTEST-20261116/sync-selftest.py | 2026-11-16 00:58 |  |
| `server/sync.py` | 8289 | ~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC-BOTTEST-20261116/sync.py | 2026-11-16 00:56 |  |
| `server/tools-patch_botcreate.py` | 1388 | new in this pack (box) | 2026-11-16 18:10 |  |
| `server/tools-patch_server.py` | 5957 | ~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC-BOTTEST-20261116/tools-patch_server.py | 2026-11-16 17:21 |  |
| `server/tools/publish_feed.py` | 1354 | ~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC/tools/publish_feed.py | 2026-11-16 00:36 |  |
| `wallet/rwallet/RWALLET.sha256` | 4534 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/RWALLET.sha256 | 2026-11-16 16:51 |  |
| `wallet/rwallet/RWALLET.version` | 6 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/RWALLET.version | 2026-11-16 16:51 |  |
| `wallet/rwallet/assets.json` | 1378 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/assets.json | 2026-11-15 16:18 |  |
| `wallet/rwallet/assets.json.sha256` | 78 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/assets.json.sha256 | 2026-11-15 16:18 |  |
| `wallet/rwallet/avatar.jpg` | 2541 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/avatar.jpg | 2026-11-15 16:16 |  |
| `wallet/rwallet/banner.jpg` | 31694 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/banner.jpg | 2026-11-15 16:16 |  |
| `wallet/rwallet/ghostmachine-logo.jpg` | 77514 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/ghostmachine-logo.jpg | 2026-11-15 16:16 |  |
| `wallet/rwallet/icons/favicon.ico` | 12166 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/icons/favicon.ico | 2026-11-11 08:57 |  |
| `wallet/rwallet/icons/walet-1024.png` | 473610 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/icons/walet-1024.png | 2026-11-11 08:57 |  |
| `wallet/rwallet/icons/walet-120.png` | 15012 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/icons/walet-120.png | 2026-11-11 08:57 |  |
| `wallet/rwallet/icons/walet-152.png` | 21701 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/icons/walet-152.png | 2026-11-11 08:57 |  |
| `wallet/rwallet/icons/walet-16.png` | 577 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/icons/walet-16.png | 2026-11-11 08:57 |  |
| `wallet/rwallet/icons/walet-180.png` | 27981 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/icons/walet-180.png | 2026-11-11 08:57 |  |
| `wallet/rwallet/icons/walet-192.png` | 30984 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/icons/walet-192.png | 2026-11-11 08:57 |  |
| `wallet/rwallet/icons/walet-256.png` | 48885 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/icons/walet-256.png | 2026-11-11 08:57 |  |
| `wallet/rwallet/icons/walet-32.png` | 1917 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/icons/walet-32.png | 2026-11-11 08:57 |  |
| `wallet/rwallet/icons/walet-512.png` | 153753 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/icons/walet-512.png | 2026-11-11 08:57 |  |
| `wallet/rwallet/icons/walet-64.png` | 5804 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/icons/walet-64.png | 2026-11-11 08:57 |  |
| `wallet/rwallet/icons/walet-76.png` | 7475 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/icons/walet-76.png | 2026-11-11 08:57 |  |
| `wallet/rwallet/index.html` | 3598 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/index.html | 2026-11-16 16:51 |  |
| `wallet/rwallet/rgen-assets.js` | 2973 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rgen-assets.js | 2026-11-04 19:21 |  |
| `wallet/rwallet/rgenerator-status.js` | 857 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rgenerator-status.js | 2026-10-30 13:49 |  |
| `wallet/rwallet/rgenerator/rgenerator-ridtags-ui.js` | 2401 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rgenerator/rgenerator-ridtags-ui.js | 2026-11-10 15:43 |  |
| `wallet/rwallet/rgenerator/rgenerator-ridtags.js` | 4722 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rgenerator/rgenerator-ridtags.js | 2026-11-10 15:43 |  |
| `wallet/rwallet/rgenerator/rid.js` | 2833 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rgenerator/rid.js | 2026-11-10 15:43 |  |
| `wallet/rwallet/rghostchain-view.js` | 3356 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rghostchain-view.js | 2026-11-15 16:34 |  |
| `wallet/rwallet/rghostkey-api.js` | 5156 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rghostkey-api.js | 2026-11-09 02:18 |  |
| `wallet/rwallet/rid-link.js` | 655 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rid-link.js | 2026-11-04 19:21 |  |
| `wallet/rwallet/rmail-approve.js` | 8455 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rmail-approve.js | 2026-11-11 08:57 |  |
| `wallet/rwallet/rmint-cast.js` | 6488 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rmint-cast.js | 2026-11-09 00:40 |  |
| `wallet/rwallet/rmint-gate.js` | 5240 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rmint-gate.js | 2026-11-09 00:20 |  |
| `wallet/rwallet/rmint-onetap.js` | 16001 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rmint-onetap.js | 2026-11-16 16:51 |  |
| `wallet/rwallet/rmint-press.js` | 7087 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rmint-press.js | 2026-11-09 02:18 |  |
| `wallet/rwallet/rmint-session.js` | 6016 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rmint-session.js | 2026-11-09 00:20 |  |
| `wallet/rwallet/rmint-transport.js` | 9383 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rmint-transport.js | 2026-11-16 16:51 | LAN hosts (2) + LAN IP + subnet comment redacted |
| `wallet/rwallet/rsign-verify.js` | 13271 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rsign-verify.js | 2026-10-30 22:52 |  |
| `wallet/rwallet/rtrackr-button.js` | 656 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rtrackr-button.js | 2026-11-04 19:21 |  |
| `wallet/rwallet/rtrackr-feed.js` | 3604 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rtrackr-feed.js | 2026-10-30 12:57 |  |
| `wallet/rwallet/rwallet-assmkit-adapter.js` | 1841 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-assmkit-adapter.js | 2026-11-16 16:51 |  |
| `wallet/rwallet/rwallet-botlatch.js` | 2880 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-botlatch.js | 2026-10-30 09:23 |  |
| `wallet/rwallet/rwallet-drift.js` | 3830 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-drift.js | 2026-11-12 13:23 |  |
| `wallet/rwallet/rwallet-ghost.css` | 4543 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-ghost.css | 2026-11-04 19:21 |  |
| `wallet/rwallet/rwallet-ghost.js` | 16319 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-ghost.js | 2026-11-15 16:47 |  |
| `wallet/rwallet/rwallet-ghost2.css` | 30866 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-ghost2.css | 2026-11-15 16:47 |  |
| `wallet/rwallet/rwallet-ghost2.js` | 26717 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-ghost2.js | 2026-11-15 16:54 |  |
| `wallet/rwallet/rwallet-guard.js` | 1986 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-guard.js | 2026-11-10 15:46 |  |
| `wallet/rwallet/rwallet-intent.js` | 4639 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-intent.js | 2026-11-10 12:52 |  |
| `wallet/rwallet/rwallet-linked.js` | 5750 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-linked.js | 2026-11-15 16:34 |  |
| `wallet/rwallet/rwallet-pair.js` | 7436 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-pair.js | 2026-11-15 16:48 |  |
| `wallet/rwallet/rwallet-rmail-card.js` | 2339 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-rmail-card.js | 2026-11-11 08:57 |  |
| `wallet/rwallet/rwallet-rmail-panel.js` | 7319 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-rmail-panel.js | 2026-11-11 08:58 |  |
| `wallet/rwallet/rwallet-roster.css` | 3187 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-roster.css | 2026-11-10 15:12 |  |
| `wallet/rwallet/rwallet-roster.js` | 25006 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-roster.js | 2026-11-10 15:14 |  |
| `wallet/rwallet/rwallet-rtdata-embed.js` | 13676 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-rtdata-embed.js | 2026-11-15 16:45 |  |
| `wallet/rwallet/rwallet-rtdata.js` | 2806 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-rtdata.js | 2026-11-15 16:46 |  |
| `wallet/rwallet/rwallet-rvault.js` | 2462 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-rvault.js | 2026-10-30 09:23 |  |
| `wallet/rwallet/rwallet-thundr-panel.js` | 1322 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-thundr-panel.js | 2026-11-10 15:46 |  |
| `wallet/rwallet/rwallet-unified.js` | 14322 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/rwallet-unified.js | 2026-11-04 19:21 |  |
| `wallet/rwallet/thundr/hub/index.html` | 144095 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/thundr/hub/index.html | 2026-11-07 13:19 |  |
| `wallet/rwallet/vendor/rassm.js` | 1411 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/vendor/rassm.js | 2026-11-11 08:32 |  |
| `wallet/rwallet/vendor/rmail-nokey-surface.js` | 32284 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/vendor/rmail-nokey-surface.js | 2026-11-11 08:44 |  |
| `wallet/rwallet/vendor/rsocial-rmail.js` | 9149 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/vendor/rsocial-rmail.js | 2026-11-10 15:43 |  |
| `wallet/rwallet/vendor/rsync-core.js` | 34957 | ~/R/ЯLAB/RCRYPTOFORGE/APPS/RWALLET-V6-UNIFIED-20261116/rwallet/vendor/rsync-core.js | 2026-11-10 15:43 |  |
