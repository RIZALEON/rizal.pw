"""Pure-stdlib P-256 ECDSA *verification only* (no key generation, no signing)."""
import hashlib, base64

P = 0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff
A = P - 3
B = 0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b
N = 0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551
G = (0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296,
     0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5)

def _on_curve(pt):
    x, y = pt
    return 0 <= x < P and 0 <= y < P and (y * y - (x * x * x + A * x + B)) % P == 0

# Jacobian coordinates; None = point at infinity
def _jdouble(Pt):
    if Pt is None: return None
    X, Y, Z = Pt
    if Y == 0: return None
    S = 4 * X * Y * Y % P
    Z2 = Z * Z % P
    M = 3 * (X - Z2) * (X + Z2) % P  # a = -3
    X3 = (M * M - 2 * S) % P
    Y3 = (M * (S - X3) - 8 * Y ** 4) % P
    Z3 = 2 * Y * Z % P
    return (X3, Y3, Z3)

def _jadd(P1, P2):
    if P1 is None: return P2
    if P2 is None: return P1
    X1, Y1, Z1 = P1; X2, Y2, Z2 = P2
    Z1s, Z2s = Z1 * Z1 % P, Z2 * Z2 % P
    U1, U2 = X1 * Z2s % P, X2 * Z1s % P
    S1, S2 = Y1 * Z2s * Z2 % P, Y2 * Z1s * Z1 % P
    if U1 == U2:
        return _jdouble(P1) if S1 == S2 else None
    H = (U2 - U1) % P; R = (S2 - S1) % P
    H2 = H * H % P; H3 = H * H2 % P
    X3 = (R * R - H3 - 2 * U1 * H2) % P
    Y3 = (R * (U1 * H2 - X3) - S1 * H3) % P
    Z3 = H * Z1 * Z2 % P
    return (X3, Y3, Z3)

def _mul2(u1, Pa, u2, Pb):
    """u1*Pa + u2*Pb (Shamir's trick)."""
    ja, jb = (Pa[0], Pa[1], 1), (Pb[0], Pb[1], 1)
    jab = _jadd(ja, jb)
    R = None
    for i in range(max(u1.bit_length(), u2.bit_length()) - 1, -1, -1):
        R = _jdouble(R)
        b1, b2 = (u1 >> i) & 1, (u2 >> i) & 1
        if b1 and b2: R = _jadd(R, jab)
        elif b1: R = _jadd(R, ja)
        elif b2: R = _jadd(R, jb)
    if R is None: return None
    X, Y, Z = R
    zi = pow(Z, -1, P)
    return (X * zi * zi % P, Y * zi * zi * zi % P)

def parse_pub(b64):
    """base64 raw uncompressed (65 bytes, 0x04||X||Y) -> point, or None."""
    try:
        raw = base64.b64decode(b64, validate=True)
    except Exception:
        return None
    if len(raw) != 65 or raw[0] != 4: return None
    pt = (int.from_bytes(raw[1:33], 'big'), int.from_bytes(raw[33:], 'big'))
    return pt if _on_curve(pt) else None

def _parse_sig(raw):
    if len(raw) == 64:
        return int.from_bytes(raw[:32], 'big'), int.from_bytes(raw[32:], 'big')
    # DER: 30 len 02 rl r 02 sl s
    try:
        if raw[0] != 0x30: return None
        i = 2
        if raw[i] != 2: return None
        rl = raw[i + 1]; r = int.from_bytes(raw[i + 2:i + 2 + rl], 'big'); i += 2 + rl
        if raw[i] != 2: return None
        sl = raw[i + 1]; s = int.from_bytes(raw[i + 2:i + 2 + sl], 'big')
        return r, s
    except Exception:
        return None

def verify(msg, sig_b64, pub_b64):
    """True iff sig (base64 raw r||s or DER) is a valid ECDSA-P256-SHA256 signature of msg (str) by pub."""
    Q = parse_pub(pub_b64)
    if Q is None: return False
    try:
        rs = _parse_sig(base64.b64decode(sig_b64, validate=True))
    except Exception:
        return False
    if not rs: return False
    r, s = rs
    if not (1 <= r < N and 1 <= s < N): return False
    e = int.from_bytes(hashlib.sha256(msg.encode('utf-8')).digest(), 'big')
    w = pow(s, -1, N)
    X = _mul2(e * w % N, G, r * w % N, Q)
    return X is not None and X[0] % N == r
