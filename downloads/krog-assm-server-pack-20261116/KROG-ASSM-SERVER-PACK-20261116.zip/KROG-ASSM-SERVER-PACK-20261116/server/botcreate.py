"""Owner-signed bot account creation for the ASSM-RSYNC multi-profile server (production path).

Added for KROG-ASSM-SERVER-PACK-20261116 (Nov 16, 2026). Replaces the unsigned, test-only bot-bootstrap.py
on any production host. Route: POST /api/rsync/bot/create

Body (JSON):
  {"t": "bot.create", "profile": "ЯID-BOT-0002", "handle": "@krog", "display": "KROG",
   "scheme": "pbkdf2-sha256-hmac-v1", "salt": b64(16+ bytes), "iter": >= 600000,
   "verifier": b64(HMAC-SHA256(PBKDF2(pw,salt,iter,32), "assm-password-verifier-v1")),
   "signer": b64(raw 65-byte P-256 pub of an ACTIVE owner trusted device), "nonce": ..., "ts": ISO-8601,
   "sig": P-256 signature by signer over create_msg(body)}

  create_msg = "assm-bot-create-v1\n" + "\n".join([profile, handle, display, scheme, salt, str(iter),
                                                     sha256hex(verifier), signer, nonce, ts])

Rules:
  * The signer must be one of the owner's trusted devices (same trust store as /password/set and /approve).
    Bot device keys and bot sessions are refused. The plaintext password never reaches the server.
  * profile must start with "ЯID-BOT-"; handle must not be an owner identifier; profile/handle must be new.
  * iter >= 600000, scheme == pbkdf2-sha256-hmac-v1, nonce single-use, ts inside pwlogin's window.
  * Scopes are fixed to signin/post/reply; wallet/approve/sign/mint/trade/swap/buy/sell/password-set denied.
"""
import base64, hashlib, json, os
import pwlogin as P
import botauth as B

CREATE_PREFIX = "assm-bot-create-v1\n"
FIELDS = ("profile", "handle", "display", "scheme", "salt", "iter", "verifier", "signer", "nonce", "ts", "sig")

def create_msg(o):
    vh = hashlib.sha256(str(o["verifier"]).encode("utf-8")).hexdigest()
    return CREATE_PREFIX + "\n".join([str(o["profile"]), str(o["handle"]), str(o.get("display") or ""), str(o["scheme"]),
                                      str(o["salt"]), str(int(o["iter"])), vh, str(o["signer"]), str(o["nonce"]), str(o["ts"])])

def unsigned_bootstrap_allowed():
    """The old local bot-bootstrap.py may only run when explicitly enabled AND not in production mode."""
    return os.environ.get("ASSM_ALLOW_UNSIGNED_BOOTSTRAP", "0") == "1" and os.environ.get("ASSM_MODE", "production") != "production"

def handle_create(o, data, p256, trusted_devices, trusted_path, log):
    if not isinstance(o, dict) or o.get("t") != "bot.create": return 400, {"ok": False, "error": "t must be bot.create"}
    for k in FIELDS:
        if k not in o: return 400, {"ok": False, "error": "missing " + k}
    if "password" in o: return 400, {"ok": False, "error": "send the verifier, never the password"}
    err = P._common(o, ("signer", "nonce", "ts", "sig"))
    if err: return 400, {"ok": False, "error": err}
    if o["scheme"] != P.SCHEME: return 400, {"ok": False, "error": "scheme must be " + P.SCHEME}
    try: it = int(o["iter"])
    except Exception: return 400, {"ok": False, "error": "bad iter"}
    if it < 600000: return 400, {"ok": False, "error": "iter must be >= 600000"}
    salt = P._b64d(o["salt"]); ver = P._b64d(o["verifier"])
    if not salt or len(salt) < 16 or not ver or len(ver) != 32: return 400, {"ok": False, "error": "bad salt or verifier"}
    prof, handle = str(o["profile"]).strip(), P.norm_handle(o["handle"])
    if not prof.startswith("ЯID-BOT-") or len(prof) > 40: return 400, {"ok": False, "error": "profile must look like ЯID-BOT-NNNN"}
    disp = str(o.get("display") or "")[:40]
    owners = B.owner_names(data, trusted_path)
    if prof.lower() in owners or (handle or "").lower() in owners: return 403, {"ok": False, "error": "owner identifiers can't become bots"}
    if B.is_bot_device(data, o["signer"]): return 403, {"ok": False, "error": "bot devices can't create bots"}
    if o["signer"] not in trusted_devices(): return 403, {"ok": False, "error": "signer is not an owner trusted device"}
    if not p256.verify(create_msg(o), o["sig"], o["signer"]): return 403, {"ok": False, "error": "bad owner signature"}
    with B._lock:
        if not B._use_nonce(data, o["signer"], o["nonce"], o["ts"]): return 409, {"ok": False, "error": "replayed nonce"}
        pp = B.bpaths(data)["profiles"]
        doc = P._load(pp, {"version": 1, "scheme": P.SCHEME, "profiles": {}})
        if prof in doc["profiles"] or any(r.get("handle") == handle for r in doc["profiles"].values()):
            return 409, {"ok": False, "error": "bot profile or handle already exists"}
        doc["profiles"][prof] = {"scheme": P.SCHEME, "handle": handle, "display": disp or handle, "role": B.ROLE,
                                 "scopes": list(B.ALLOWED), "denied": list(B.DENIED), "salt": o["salt"], "iter": it,
                                 "verifier": o["verifier"], "set_at": P._iso(), "set_by": "owner-signed bot.create",
                                 "signer_fp": hashlib.sha256(o["signer"].encode()).hexdigest()[:16]}
        P._atomic_write(pp, doc)
        B._append(B.bpaths(data)["audit"], {"t": "bot.create", "profile": prof, "handle": handle, "by": "owner-signed",
                                             "signer_fp": hashlib.sha256(o["signer"].encode()).hexdigest()[:16], "ts": P._iso()})
    log("bot profile created by owner signature: %s (%s)" % (handle, prof))
    return 201, {"ok": True, "profile": prof, "handle": handle, "role": B.ROLE, "scopes": list(B.ALLOWED), "denied": list(B.DENIED)}
