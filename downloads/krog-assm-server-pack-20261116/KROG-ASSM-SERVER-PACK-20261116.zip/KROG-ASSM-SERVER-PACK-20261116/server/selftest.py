#!/usr/bin/env python3
"""Self-test with THROWAWAY keys (openssl, in a temp dir). Starts a test server on a temp data dir.
Never uses or touches real ASSM keys. Run: python3 selftest.py"""
import base64, json, os, subprocess, sys, tempfile, time, urllib.request, urllib.error, hashlib
from datetime import datetime, timezone
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import server as S
tmp = tempfile.mkdtemp(prefix="assm-selftest-")
def key(name):
    k = os.path.join(tmp, name + ".pem")
    subprocess.run(["openssl", "ecparam", "-genkey", "-name", "prime256v1", "-noout", "-out", k], check=True)
    der = subprocess.run(["openssl", "ec", "-in", k, "-pubout", "-outform", "DER"], capture_output=True, check=True).stdout
    return k, base64.b64encode(der[-65:]).decode()
def sign(k, msg):
    return base64.b64encode(subprocess.run(["openssl", "dgst", "-sha256", "-sign", k], input=msg.encode(), capture_output=True, check=True).stdout).decode()
def iso(): return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
port = 18752
data = os.path.join(tmp, "data"); os.makedirs(data)
newk, newpub = key("new"); trk, trpub = key("trusted"); badk, badpub = key("untrusted")
json.dump({"version": 1, "devices": [{"pub": trpub, "name": "selftest-trusted", "status": "ACTIVE"}]}, open(os.path.join(data, "trusted-devices.json"), "w"))
env = dict(os.environ, ASSM_RSYNC_PORT=str(port), ASSM_RSYNC_DATA=data, ASSM_RSYNC_PUBLIC_URL="http://selftest")
proc = subprocess.Popen([sys.executable, os.path.join(HERE, "server.py")], env=env, stderr=subprocess.DEVNULL)
time.sleep(0.8)
B = "http://127.0.0.1:%d" % port
def call(m, path, obj=None, ct="application/json"):
    req = urllib.request.Request(B + path, method=m, data=json.dumps(obj).encode() if obj is not None else None)
    if obj is not None: req.add_header("Content-Type", ct)
    try:
        with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read())
ok = True
def expect(name, got, want):
    global ok
    good = got[0] == want; ok &= good
    print(("PASS" if good else "FAIL"), name, got[0], got[1].get("error") or got[1].get("status") or "")
try:
    expect("health", call("GET", "/health"), 200)
    nonce = "abcDEF123456xyz0"; ts = iso()
    req = {"t": "device.request", "device": newpub, "nonce": nonce, "req_ts": ts, "req_sig": sign(newk, S.enroll_msg(newpub, nonce, ts)), "device_name": "selftest"}
    r = call("POST", "/api/rsync/request", req); expect("request", r, 201); code = r[1].get("code")
    expect("request bad sig", call("POST", "/api/rsync/request", dict(req, req_sig=sign(badk, "x"))), 400)
    expect("non-json rejected", call("POST", "/api/rsync/request", req, ct="text/plain"), 415)
    expect("status pending", call("GET", "/api/rsync/request/" + code), 200)
    def ds(pub):
        return call("GET", "/api/rsync/device-status?pub=" + urllib.parse.quote(pub, safe=""))
    def no_list_leak(body, *forbidden):
        blob = json.dumps(body)
        return all(x not in blob for x in forbidden) and "devices" not in body
    expect("device-status missing pub", call("GET", "/api/rsync/device-status"), 400)
    expect("device-status bad pub", call("GET", "/api/rsync/device-status?pub=not-a-key"), 400)
    r = ds(trpub); expect("device-status trusted", r, 200)
    ok &= r[1].get("trusted") is True and r[1].get("status") == "trusted" and no_list_leak(r[1], newpub, badpub)
    r = ds(newpub); expect("device-status pending", r, 200)
    ok &= r[1].get("pending") is True and r[1].get("code") == code and r[1].get("trusted") is False and no_list_leak(r[1], trpub, badpub)
    r = ds(badpub); expect("device-status unknown", r, 200)
    ok &= r[1].get("status") == "unknown" and r[1].get("trusted") is False and r[1].get("enrolled") is False and r[1].get("pending") is False
    ok &= no_list_leak(r[1], trpub, newpub)
    def sealed(signer_k, signer_pub, **over):
        e = {"id": "enroll-" + nonce + "-t", "t": "device.enroll", "profile": "RP-selftest", "device": newpub, "nonce": nonce,
             "req_ts": ts, "req_sig": req["req_sig"], "device_name": "selftest", "ts": iso()}
        e.update(over); e["signer"] = signer_pub
        cid = S.cid_of(e); msg = S.PREFIX + cid
        e["cid"] = cid; e["rgen"] = {"scope": S.SCOPE, "msg": msg, "pub": signer_pub, "value": sign(signer_k, msg)}
        return e
    expect("approve by untrusted", call("POST", "/api/rsync/approve", sealed(badk, badpub)), 403)
    t = sealed(trk, trpub); t["profile"] = "RP-tampered"
    expect("approve tampered", call("POST", "/api/rsync/approve", t), 400)
    expect("approve by trusted", call("POST", "/api/rsync/approve", sealed(trk, trpub)), 201)
    expect("replay", call("POST", "/api/rsync/approve", sealed(trk, trpub)), 409)
    st = call("GET", "/api/rsync/request/" + code); expect("status approved", st, 200); ok &= st[1].get("status") == "approved"
    r = ds(newpub); expect("device-status enrolled", r, 200)
    ok &= r[1].get("enrolled") is True and r[1].get("profile") == "RP-selftest" and no_list_leak(r[1], trpub, badpub)
    en = call("GET", "/api/rsync/entries"); expect("entries", en, 200); ok &= len(en[1]["entries"]) == 1 and en[1]["mode"] == "live"
    old = "2020-01-01T00:00:00.000Z"
    expect("expired request", call("POST", "/api/rsync/request", dict(req, req_ts=old, req_sig=sign(newk, S.enroll_msg(newpub, nonce, old)))), 400)
    for i in range(12): r = call("POST", "/api/rsync/request", {"x": 1})
    expect("rate limit", r, 429)
finally:
    proc.terminate()
print("ALL PASS" if ok else "SOME FAILED"); sys.exit(0 if ok else 1)
