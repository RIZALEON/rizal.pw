"""ASSM username + password login for ASSM-RSYNC (t251u, Rizal's GO for Option A).

Scheme "pbkdf2-sha256-hmac-v1" (client-side KDF; the server never sees the plaintext password):
  dk       = PBKDF2-HMAC-SHA256(password_utf8, salt, iter >= 600000, dkLen = 32)
  verifier = HMAC-SHA256(key = dk, msg = "assm-password-verifier-v1")
  * password/set   stores {salt, iter, verifier} only. Signed by an ACTIVE trusted (approver) key.
  * password/login sends proof = base64(dk); the server recomputes HMAC(proof) and compares with
    hmac.compare_digest. Signed by the NEW device key (proves possession of the key being trusted).
The plaintext never leaves the client. Bodies are never logged. data/assm-password.json is 0600 and
written atomically. Lockouts persist in data/assm-password-lockout.json; used nonces in
data/assm-password-nonces.jsonl.
"""
import base64, hashlib, hmac, json, os, re, secrets, shutil, tempfile, threading, time
from datetime import datetime, timezone

SCHEME = "pbkdf2-sha256-hmac-v1"
VERIFIER_MSG = b"assm-password-verifier-v1"
MIN_ITER = 600000
MAX_ITER = 10000000
SKEW = 120
MAX_FAILS = 5
LOCK_BASE = float(os.environ.get("ASSM_PW_LOCK_BASE_S", "60"))   # first lockout; doubles each further failure
LOCK_MAX = 24 * 3600
SET_PREFIX = "assm-password-set-v1\n"
LOGIN_PREFIX = "assm-password-login-v1\n"
_lock = threading.Lock()
_nonces = None

def _now(): return time.time()
def _iso(t=None): return datetime.fromtimestamp(t if t is not None else _now(), timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
def _parse_iso(s):
    try: return datetime.fromisoformat(str(s).replace("Z", "+00:00")).timestamp()
    except Exception: return None
def _b64d(s):
    try: return base64.b64decode(s, validate=True)
    except Exception: return None

def paths(data):
    return (os.path.join(data, "assm-password.json"), os.path.join(data, "assm-password-lockout.json"),
            os.path.join(data, "assm-password-nonces.jsonl"))

def _atomic_write(path, obj):
    d = os.path.dirname(path)
    fd, tmp = tempfile.mkstemp(prefix=".tmp-", dir=d)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
        os.chmod(path, 0o600)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise

def _load(path, default):
    try:
        with open(path) as f: return json.load(f)
    except Exception: return default

def norm_handle(h):
    h = str(h or "").strip().lstrip("@").lower()
    return "@" + h if h else ""

def set_msg(o):
    return SET_PREFIX + "\n".join([o["profile"], o["handle"], o["salt"], str(o["iter"]), o["verifier"], o["signer"], o["nonce"], o["ts"]])

def login_msg(o):
    ph = hashlib.sha256(o["proof"].encode("utf-8")).hexdigest()
    return LOGIN_PREFIX + "\n".join([o["user"], ph, o["device"], o.get("device_name") or "", o["nonce"], o["ts"]])

def _use_nonce(data, key_pub, nonce, ts):
    """True if fresh (and records it); False if replayed. Persistent across restarts."""
    global _nonces
    _, _, npath = paths(data)
    if _nonces is None:
        _nonces = set()
        try:
            with open(npath) as f:
                for line in f:
                    try: o = json.loads(line); _nonces.add((o["pub"], o["nonce"]))
                    except Exception: pass
        except OSError: pass
    k = (key_pub, nonce)
    if k in _nonces: return False
    _nonces.add(k)
    with open(npath, "a") as f:
        f.write(json.dumps({"pub": key_pub, "nonce": nonce, "ts": ts}) + "\n")
    try: os.chmod(npath, 0o600)
    except OSError: pass
    return True

def _common(o, keys):
    for k in keys:
        if not isinstance(o.get(k), str) or not o[k] or len(o[k]) > 1024: return "missing or bad " + k
    if not re.fullmatch(r"[A-Za-z0-9]{8,64}", o["nonce"]): return "bad nonce"
    t = _parse_iso(o["ts"])
    if t is None or abs(t - _now()) > SKEW: return "ts missing or not within 120 s of now"
    return None

def identity_of(trusted_path):
    doc = _load(trusted_path, {})
    return doc.get("approver_identity") or "ЯID-0001-3QQS"

# ---- lockout (per IP and per handle, persisted) ----
def _lock_state(data):
    return _load(paths(data)[1], {})

def locked_for(data, keys):
    st = _lock_state(data); t = _now()
    wait = max([st.get(k, {}).get("until", 0) - t for k in keys] + [0])
    return wait

def _record(data, keys, ok):
    lp = paths(data)[1]
    st = _lock_state(data); t = _now()
    for k in keys:
        if ok: st.pop(k, None); continue
        e = st.get(k, {"fails": 0, "until": 0}); e["fails"] = int(e.get("fails", 0)) + 1
        if e["fails"] >= MAX_FAILS: e["until"] = t + min(LOCK_MAX, LOCK_BASE * (2 ** (e["fails"] - MAX_FAILS)))
        e["last"] = _iso(t); st[k] = e
    if len(st) > 2000:
        for k in sorted(st, key=lambda k: st[k].get("last", ""))[:500]: st.pop(k, None)
    _atomic_write(lp, st)

# ---- routes ----
def handle_params(user, data, trusted_path):
    rec = _load(paths(data)[0], {}).get("profiles", {})
    ident = identity_of(trusted_path)
    r = rec.get(ident)
    u = str(user or "").strip()
    if not r or not (u == ident or norm_handle(u) == r.get("handle")):
        return 404, {"ok": False, "error": "no ASSM password is set for that username"}
    return 200, {"ok": True, "scheme": r["scheme"], "profile": ident, "handle": r.get("handle"), "salt": r["salt"], "iter": r["iter"]}

def handle_set(o, data, p256, trusted_devices, trusted_path, entries_path, log):
    if o.get("t", "password.set") != "password.set": return 400, {"ok": False, "error": "t must be password.set"}
    err = _common(o, ("profile", "handle", "salt", "verifier", "signer", "nonce", "ts", "sig"))
    if err: return 400, {"ok": False, "error": err}
    if "password" in o or "proof" in o: return 400, {"ok": False, "error": "send a verifier only, never the password"}
    try: it = int(o.get("iter"))
    except Exception: return 400, {"ok": False, "error": "bad iter"}
    if it < MIN_ITER or it > MAX_ITER: return 400, {"ok": False, "error": "iter must be >= %d" % MIN_ITER}
    o = dict(o); o["iter"] = it
    salt = _b64d(o["salt"]); ver = _b64d(o["verifier"])
    if not salt or not (16 <= len(salt) <= 64): return 400, {"ok": False, "error": "salt must be 16-64 random bytes (base64)"}
    if not ver or len(ver) != 32: return 400, {"ok": False, "error": "verifier must be 32 bytes (base64)"}
    ident = identity_of(trusted_path)
    if o["profile"] != ident: return 403, {"ok": False, "error": "unknown profile"}
    handle = norm_handle(o["handle"])
    if not re.fullmatch(r"@[a-z0-9_.-]{1,64}", handle): return 400, {"ok": False, "error": "bad handle"}
    td = trusted_devices().get(o["signer"])
    if not td: return 403, {"ok": False, "error": "signer is not an ACTIVE trusted approver key"}
    profs = td.get("profiles")
    if isinstance(profs, list) and profs and ident not in profs: return 403, {"ok": False, "error": "approver may not act for this profile"}
    if not p256.verify(set_msg(o), o["sig"], o["signer"]): return 403, {"ok": False, "error": "bad approver signature"}
    with _lock:
        if not _use_nonce(data, o["signer"], o["nonce"], o["ts"]): return 409, {"ok": False, "error": "replayed nonce"}
        pp = paths(data)[0]
        doc = _load(pp, {"version": 1, "scheme": SCHEME, "profiles": {}})
        prev = doc.get("profiles", {}).get(ident)
        doc.setdefault("profiles", {})[ident] = {"scheme": SCHEME, "handle": handle, "salt": o["salt"], "iter": it,
                                                 "verifier": o["verifier"], "set_at": _iso(), "set_by": td.get("name", "?")}
        _atomic_write(pp, doc)
        _record(data, ["user:" + ident], True)   # a fresh password clears the handle lockout
        audit = {"id": "pwset-" + o["nonce"], "t": "password.set", "profile": ident, "handle": handle,
                 "by": td.get("name", "?"), "changed": bool(prev), "ts": _iso()}
        with open(entries_path, "a") as f: f.write(json.dumps(audit, ensure_ascii=False, separators=(",", ":")) + "\n")
    log("password %s for %s by trusted device %s" % ("changed" if prev else "set", ident, td.get("name", "?")))
    return 200, {"ok": True, "profile": ident, "handle": handle, "changed": bool(prev)}

def handle_login(o, ip, data, p256, trusted_devices, trusted_path, entries_path, log):
    GENERIC = (401, {"ok": False, "error": "wrong username or password"})
    if o.get("t", "password.login") != "password.login": return 400, {"ok": False, "error": "t must be password.login"}
    err = _common(o, ("user", "proof", "device", "nonce", "ts", "sig"))
    if err: return 400, {"ok": False, "error": err}
    if "password" in o: return 400, {"ok": False, "error": "send the derived proof, never the password"}
    dn = o.get("device_name") or ""
    if not isinstance(dn, str) or len(dn) > 80: return 400, {"ok": False, "error": "bad device_name"}
    if not p256.parse_pub(o["device"]): return 400, {"ok": False, "error": "device must be a base64 raw 65-byte P-256 public key"}
    if not p256.verify(login_msg(o), o["sig"], o["device"]): return 403, {"ok": False, "error": "request not signed by that device key"}
    ident = identity_of(trusted_path)
    keys = ["ip:" + str(ip), "user:" + ident]
    with _lock:
        wait = locked_for(data, keys)
        if wait > 0: return 429, {"ok": False, "error": "too many attempts, try again later", "retry_after_s": int(wait) + 1}
        if not _use_nonce(data, o["device"], o["nonce"], o["ts"]): return 409, {"ok": False, "error": "replayed nonce"}
        rec = _load(paths(data)[0], {}).get("profiles", {}).get(ident)
        u = o["user"].strip()
        user_ok = bool(rec) and (u == ident or norm_handle(u) == rec.get("handle"))
        proof = _b64d(o["proof"]) or b""
        expect = _b64d(rec["verifier"]) if rec else b"\0" * 32
        got = hmac.new(proof, VERIFIER_MSG, hashlib.sha256).digest()
        pw_ok = hmac.compare_digest(got, expect or b"")
        if not (user_ok and pw_ok and len(proof) == 32):
            _record(data, keys, False)
            log("password login failed from %s" % ip)
            return GENERIC
        _record(data, keys, True)
        # Success: this exact device key becomes ACTIVE. Timestamped backup first; add only this key.
        doc = _load(trusted_path, None)
        if not isinstance(doc, dict): return 500, {"ok": False, "error": "trusted list unreadable"}
        devs = doc.setdefault("devices", [])
        already = any(isinstance(d, dict) and d.get("pub") == o["device"] and d.get("status", "ACTIVE") == "ACTIVE" for d in devs)
        if not already:
            bdir = os.path.join(data, "backups"); os.makedirs(bdir, exist_ok=True)
            shutil.copy2(trusted_path, os.path.join(bdir, "trusted-devices.pre-pwlogin-%s.json" % time.strftime("%Y%m%d-%H%M%S")))
            devs.append({"pub": o["device"], "name": (dn or "device")[:80], "status": "ACTIVE", "profiles": [ident],
                         "added": _iso(), "method": "password"})
            _atomic_write_plain(trusted_path, doc)
        ent = {"id": "pwenroll-" + o["nonce"], "t": "device.enroll", "method": "password", "profile": ident,
               "device": o["device"], "nonce": o["nonce"], "device_name": (dn or "device")[:80], "ts": _iso()}
        with open(entries_path, "a") as f: f.write(json.dumps(ent, ensure_ascii=False, separators=(",", ":")) + "\n")
    log("password login: device %s ACTIVE for %s%s" % ((dn or "device")[:40], ident, " (already)" if already else ""))
    return 200, {"ok": True, "profile": ident, "handle": rec.get("handle"), "status": "trusted", "already": already}

def _atomic_write_plain(path, obj):
    """Atomic write keeping the file's existing mode (trusted list is not secret)."""
    mode = os.stat(path).st_mode & 0o777 if os.path.exists(path) else 0o644
    fd, tmp = tempfile.mkstemp(prefix=".tmp-", dir=os.path.dirname(path))
    with os.fdopen(fd, "w") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2); f.flush(); os.fsync(f.fileno())
    os.chmod(tmp, mode); os.replace(tmp, path)
