#!/usr/bin/env bash
# Run the ASSM-RSYNC multi-profile server on any Linux VPS (or the Neo for local tests).
# Usage: ./run.sh [path/to/assm-server.env]     (defaults to /etc/assm-rsync/assm-server.env, then config/assm-server.env)
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ENVF="${1:-/etc/assm-rsync/assm-server.env}"
[ -f "$ENVF" ] || ENVF="$HERE/config/assm-server.env"
[ -f "$ENVF" ] || { echo "no env file; copy config/assm-server.env.example first" >&2; exit 1; }
set -a; . "$ENVF"; set +a
if [ "${ASSM_MODE:-production}" = "production" ] && [ "${ASSM_ALLOW_UNSIGNED_BOOTSTRAP:-0}" != "0" ]; then
  echo "refusing: unsigned bot bootstrap can't be enabled in production" >&2; exit 1
fi
case "${ASSM_SERVER_URL:-}" in *ASSM_SERVER_URL*) echo "note: ASSM_SERVER_URL is still the placeholder" >&2;; esac
mkdir -p "${ASSM_RSYNC_DATA:?}"; chmod 700 "$ASSM_RSYNC_DATA"
command -v python3 >/dev/null || { echo "python3 needed" >&2; exit 1; }
cd "$HERE"
exec python3 server.py
