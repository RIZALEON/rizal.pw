#!/usr/bin/env python3
"""Prepare an owner-signed bot.create request ON RIZAL'S TRUSTED DEVICE (the Neo). Nothing is sent.

1. Generates a strong bot password locally and writes it ONLY to --secrets (0600, refuses to overwrite).
2. Derives salt / PBKDF2-SHA256 (600000 iterations) / verifier exactly like bot-bootstrap.py and pwlogin.py.
3. Writes request.json with every field except "sig", plus "msg_to_sign" (create_msg) for the trusted device.
4. Rizal signs msg_to_sign with his ACTIVE trusted ASSM device key (ASSMKit DeviceKey.sign, or the RCODE
   approver flow), puts the base64 signature in "sig", removes "msg_to_sign", and POSTs it to
   ASSM_SERVER_URL/api/rsync/bot/create. This tool never reads or touches any private key.
Usage: python3 make-bot-create.py --signer <base64 trusted pub> --profile ЯID-BOT-0001 --handle @krog --display KROG \
         --secrets ./bot-login-krog.txt --out ./bot-create-krog.json
"""
import argparse, base64, hashlib, hmac, json, os, secrets, sys, datetime
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(HERE))
import botcreate as C

ap = argparse.ArgumentParser()
for a, d in (("--signer", None), ("--profile", "ЯID-BOT-0001"), ("--handle", "@krog"), ("--display", "KROG"),
             ("--secrets", None), ("--out", None)):
    ap.add_argument(a, default=d, required=d is None)
a = ap.parse_args()
if os.path.exists(a.secrets) or os.path.exists(a.out): sys.exit("refusing: output exists (never overwrite)")
pw = secrets.token_urlsafe(32); salt = os.urandom(16); it = 600000
dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, it, 32)
ver = hmac.new(dk, b"assm-password-verifier-v1", hashlib.sha256).digest()
fd = os.open(a.secrets, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, "w") as f:
    f.write("# bot login. Never paste in chat, logs, git, Drive or a website.\nusername=%s\nprofile=%s\npassword=%s\n" % (a.handle, a.profile, pw))
o = {"t": "bot.create", "profile": a.profile, "handle": a.handle, "display": a.display, "scheme": "pbkdf2-sha256-hmac-v1",
     "salt": base64.b64encode(salt).decode(), "iter": it, "verifier": base64.b64encode(ver).decode(), "signer": a.signer,
     "nonce": secrets.token_hex(16), "ts": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
o["msg_to_sign"] = C.create_msg(o); o["sig"] = ""
fd = os.open(a.out, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, "w") as f: json.dump(o, f, ensure_ascii=False, indent=1)
print("wrote %s (unsigned) and %s (0600). Sign msg_to_sign on the trusted device, then POST /api/rsync/bot/create." % (a.out, a.secrets))
