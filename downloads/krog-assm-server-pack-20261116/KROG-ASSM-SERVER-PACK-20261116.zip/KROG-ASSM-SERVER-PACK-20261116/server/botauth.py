"""ASSM bot login (TEST COPY ONLY, ASSM-RSYNC-BOTTEST-20261116, 127.0.0.1:8753).

A separate, limited "bot" profile (KROG, @krog, ЯID-BOT-0001) next to the owner profile.
Same password scheme as pwlogin.py ("pbkdf2-sha256-hmac-v1", >= 600000 iterations, client-side KDF):
  dk = PBKDF2-HMAC-SHA256(password, salt, iter, 32); verifier = HMAC-SHA256(dk, "assm-password-verifier-v1")
  login sends proof = base64(dk), signed by the bot's own P-256 device key (message: botlogin_msg()).

Isolation rules (enforced here and in server.py of this test copy):
  * Bot profiles live in data/bot-profiles.json, never in assm-password.json or trusted-devices.json.
  * A bot login NEVER adds the device to trusted-devices.json; bot devices go to data/bot-devices.json.
  * A bot login returns a short-lived bearer session with scopes signin/post/reply only.
  * The owner identity/handle can never be logged into through /bot/login; bot devices and bot sessions
    are refused on owner password login, password set, approve, sync, and every wallet/sign/mint/trade route.
  * Bot profile creation here is by bot-bootstrap.py (local, unsigned, test only). A live version must
    require an owner-signed "bot.create" entry from Rizal's trusted ASSM device.
"""
import base64, hashlib, hmac, json, os, re, secrets, threading, time
import pwlogin as P

ROLE = "bot"
ALLOWED = ["signin", "post", "reply"]
DENIED = ["wallet", "rwallet", "approve", "device-approve", "sign", "mint", "trade", "swap", "buy", "sell", "password-set"]
SESSION_TTL = int(os.environ.get("ASSM_BOT_SESSION_TTL_S", str(12 * 3600)))
BOTLOGIN_PREFIX = "assm-bot-login-v1\n"
MAX_TEXT = 2000
_lock = threading.Lock()

def bpaths(data):
    j = lambda n: os.path.join(data, n)
    return {"profiles": j("bot-profiles.json"), "sessions": j("bot-sessions.json"), "devices": j("bot-devices.json"),
            "lock": j("bot-lockout.json"), "nonces": j("bot-nonces.jsonl"), "posts": j("bot-posts.jsonl"),
            "audit": j("bot-audit.jsonl")}

def _append(path, obj):
    with open(path, "a") as f: f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n")
    try: os.chmod(path, 0o600)
    except OSError: pass

def owner_names(data, trusted_path):
    """Every identifier that belongs to the owner side (refused on bot login)."""
    names = {P.identity_of(trusted_path)}
    for ident, rec in P._load(P.paths(data)[0], {}).get("profiles", {}).items():
        names.add(ident)
        if rec.get("handle"): names.add(rec["handle"])
    names.update({"ЯID-0001-3QQS", "@chaserizal", "@rizal"})
    return {n.lower() for n in names}

def find_bot(data, user):
    u = str(user or "").strip()
    for ident, rec in P._load(bpaths(data)["profiles"], {}).get("profiles", {}).items():
        if u == ident or P.norm_handle(u) == rec.get("handle"):
            return ident, rec
    return None, None

def bot_devices(data):
    return P._load(bpaths(data)["devices"], {}).get("devices", {})

def is_bot_device(data, pub):
    return isinstance(pub, str) and pub in bot_devices(data)

def botlogin_msg(o):
    ph = hashlib.sha256(o["proof"].encode("utf-8")).hexdigest()
    return BOTLOGIN_PREFIX + "\n".join([o["user"], ph, o["device"], o.get("device_name") or "", o["nonce"], o["ts"]])

# ---- lockout (own file, same policy as pwlogin) ----
def _locked(data, keys):
    st = P._load(bpaths(data)["lock"], {}); t = time.time()
    return max([st.get(k, {}).get("until", 0) - t for k in keys] + [0])

def _record(data, keys, ok):
    lp = bpaths(data)["lock"]; st = P._load(lp, {}); t = time.time()
    for k in keys:
        if ok: st.pop(k, None); continue
        e = st.get(k, {"fails": 0, "until": 0}); e["fails"] = int(e.get("fails", 0)) + 1
        if e["fails"] >= P.MAX_FAILS: e["until"] = t + min(P.LOCK_MAX, P.LOCK_BASE * (2 ** (e["fails"] - P.MAX_FAILS)))
        e["last"] = P._iso(t); st[k] = e
    P._atomic_write(lp, st)

_seen = None
def _use_nonce(data, pub, nonce, ts):
    global _seen
    np_ = bpaths(data)["nonces"]
    if _seen is None:
        _seen = set()
        try:
            for line in open(np_):
                try: o = json.loads(line); _seen.add((o["pub"], o["nonce"]))
                except Exception: pass
        except OSError: pass
    if (pub, nonce) in _seen: return False
    _seen.add((pub, nonce)); _append(np_, {"pub": pub, "nonce": nonce, "ts": ts}); return True

# ---- sessions ----
def _th(tok): return hashlib.sha256(tok.encode("utf-8")).hexdigest()

def session_from_headers(data, headers):
    a = headers.get("Authorization") or ""
    if not a.lower().startswith("bearer "): return None
    tok = a[7:].strip()
    if not tok or len(tok) > 200: return None
    s = P._load(bpaths(data)["sessions"], {}).get(_th(tok))
    if not s or s.get("revoked") or s.get("exp", 0) < time.time(): return {"invalid": True}
    return s

def has_bearer(headers):
    return (headers.get("Authorization") or "").lower().startswith("bearer ")

# ---- routes ----
def handle_params(user, data):
    ident, rec = find_bot(data, user)
    if not rec: return 404, {"ok": False, "error": "no bot login for that username"}
    return 200, {"ok": True, "scheme": rec["scheme"], "profile": ident, "handle": rec["handle"], "display": rec.get("display"),
                 "role": ROLE, "salt": rec["salt"], "iter": rec["iter"], "login_msg": "assm-bot-login-v1"}

def handle_login(o, ip, data, p256, trusted_devices, trusted_path, log):
    GENERIC = (401, {"ok": False, "error": "wrong username or password"})
    if o.get("t", "bot.login") != "bot.login": return 400, {"ok": False, "error": "t must be bot.login"}
    err = P._common(o, ("user", "proof", "device", "nonce", "ts", "sig"))
    if err: return 400, {"ok": False, "error": err}
    if "password" in o: return 400, {"ok": False, "error": "send the derived proof, never the password"}
    dn = o.get("device_name") or ""
    if not isinstance(dn, str) or len(dn) > 80: return 400, {"ok": False, "error": "bad device_name"}
    if not p256.parse_pub(o["device"]): return 400, {"ok": False, "error": "device must be a base64 raw 65-byte P-256 public key"}
    if o["device"] in trusted_devices(): return 403, {"ok": False, "error": "owner trusted devices cannot sign in as a bot; use a separate bot device key"}
    if not p256.verify(botlogin_msg(o), o["sig"], o["device"]): return 403, {"ok": False, "error": "request not signed by that device key"}
    u = o["user"].strip()
    keys = ["botip:" + str(ip), "botuser:" + u.lower()]
    with _lock:
        wait = _locked(data, keys)
        if wait > 0: return 429, {"ok": False, "error": "too many attempts, try again later", "retry_after_s": int(wait) + 1}
        if not _use_nonce(data, o["device"], o["nonce"], o["ts"]): return 409, {"ok": False, "error": "replayed nonce"}
        ident, rec = find_bot(data, u)
        if u.lower() in owner_names(data, trusted_path) or P.norm_handle(u) in owner_names(data, trusted_path):
            ident, rec = None, None                     # the owner is never reachable here
        if rec and (rec.get("role") != ROLE or ident.lower() in owner_names(data, trusted_path)):
            ident, rec = None, None
        proof = P._b64d(o["proof"]) or b""
        expect = P._b64d(rec["verifier"]) if rec else b"\0" * 32
        got = hmac.new(proof, P.VERIFIER_MSG, hashlib.sha256).digest()
        ok = hmac.compare_digest(got, expect or b"") and bool(rec) and len(proof) == 32
        if not ok:
            _record(data, keys, False); log("bot login failed from %s" % ip); return GENERIC
        _record(data, keys, True)
        bp = bpaths(data)
        devs = P._load(bp["devices"], {"version": 1, "devices": {}})
        devs.setdefault("devices", {})[o["device"]] = {"profile": ident, "name": (dn or "bot device")[:80], "role": ROLE,
                                                       "added": devs["devices"].get(o["device"], {}).get("added") or P._iso()}
        P._atomic_write(bp["devices"], devs)
        tok = secrets.token_urlsafe(32)
        sess = P._load(bp["sessions"], {})
        t = time.time()
        sess = {k: v for k, v in sess.items() if v.get("exp", 0) > t - 86400}
        sess[_th(tok)] = {"profile": ident, "handle": rec["handle"], "role": ROLE, "scopes": list(ALLOWED), "denied": list(DENIED),
                          "device": o["device"], "iat": t, "exp": t + SESSION_TTL}
        P._atomic_write(bp["sessions"], sess)
        _append(bp["audit"], {"t": "bot.login", "profile": ident, "device_name": (dn or "bot device")[:80], "ts": P._iso()})
    log("bot login ok: %s (%s) session issued, role=bot" % (rec["handle"], ident))
    return 200, {"ok": True, "profile": ident, "handle": rec["handle"], "display": rec.get("display"), "role": ROLE,
                 "scopes": list(ALLOWED), "denied": list(DENIED), "session": tok, "expires_in": SESSION_TTL, "trusted": False}

def require(sess, scope):
    if not sess: return 401, {"ok": False, "error": "bot session required (Authorization: Bearer)"}
    if sess.get("invalid"): return 401, {"ok": False, "error": "bot session expired or invalid"}
    if scope in sess.get("denied", []) or scope not in sess.get("scopes", []):
        return 403, {"ok": False, "error": "bot role may not use scope " + scope}
    return None

def handle_whoami(sess):
    e = require(sess, "signin")
    if e: return e
    return 200, {"ok": True, **{k: sess[k] for k in ("profile", "handle", "role", "scopes", "denied", "exp")}}

def handle_post(sess, o, data, kind):
    e = require(sess, kind)
    if e: return e
    text = o.get("text")
    if not isinstance(text, str) or not text.strip() or len(text) > MAX_TEXT: return 400, {"ok": False, "error": "text 1-%d chars" % MAX_TEXT}
    rec = {"id": kind + "-" + secrets.token_hex(8), "t": "bot." + kind, "profile": sess["profile"], "handle": sess["handle"],
           "text": text, "ts": P._iso()}
    if kind == "reply":
        pid = o.get("parent_id")
        if not isinstance(pid, str) or not pid or len(pid) > 128: return 400, {"ok": False, "error": "parent_id required"}
        rec["parent_id"] = pid
        if isinstance(o.get("parent_author"), str): rec["parent_author"] = o["parent_author"][:80]
    _append(bpaths(data)["posts"], rec)    # append-only test log, never edited or deleted
    return 201, {"ok": True, "record": rec}

def handle_logout(sess, headers, data):
    if not sess or sess.get("invalid"): return 401, {"ok": False, "error": "bot session required"}
    tok = (headers.get("Authorization") or "")[7:].strip()
    with _lock:
        sp = bpaths(data)["sessions"]; s = P._load(sp, {})
        if _th(tok) in s: s[_th(tok)]["revoked"] = True; P._atomic_write(sp, s)
    return 200, {"ok": True}

# Paths a bot may use. Anything else with a bot session or bot device is refused.
BOT_OK = {"/api/rsync/bot/params", "/api/rsync/bot/login", "/api/rsync/bot/whoami", "/api/rsync/bot/post",
          "/api/rsync/bot/reply", "/api/rsync/bot/logout", "/health", "/api/rsync/health", "/"}
# Stub privileged routes (not implemented on this test server; present so the bot refusal is testable).
PRIV_RE = re.compile(r"^/api/rsync/(wallet|rwallet|sign|mint|trade|swap|buy|sell|device/approve|devices/approve)(/.*)?$")
