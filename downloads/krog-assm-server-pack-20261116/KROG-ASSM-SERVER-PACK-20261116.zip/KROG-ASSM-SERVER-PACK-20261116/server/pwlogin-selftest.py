#!/usr/bin/env python3
"""Self-test for ASSM password set/login (pwlogin.py) with THROWAWAY keys and a THROWAWAY password.
Starts a test server on a temp data dir (copy of nothing real) and a temp port. Never touches data/.
Run: python3 pwlogin-selftest.py"""
import base64, hashlib, hmac, json, os, secrets, subprocess, sys, tempfile, time, urllib.request, urllib.error
from datetime import datetime, timezone
HERE = os.path.dirname(os.path.abspath(__file__))
REAL_TRUSTED = os.path.join(HERE, "data", "trusted-devices.json")
def sha(p):
    try: return hashlib.sha256(open(p, "rb").read()).hexdigest()
    except OSError: return None
real_before = sha(REAL_TRUSTED)
tmp = tempfile.mkdtemp(prefix="assm-pw-selftest-")
data = os.path.join(tmp, "data"); os.makedirs(data)
def key(name):
    k = os.path.join(tmp, name + ".pem")
    subprocess.run(["openssl", "ecparam", "-genkey", "-name", "prime256v1", "-noout", "-out", k], check=True)
    der = subprocess.run(["openssl", "ec", "-in", k, "-pubout", "-outform", "DER"], capture_output=True, check=True).stdout
    return k, base64.b64encode(der[-65:]).decode()
def sign(k, msg):
    return base64.b64encode(subprocess.run(["openssl", "dgst", "-sha256", "-sign", k], input=msg.encode(), capture_output=True, check=True).stdout).decode()
def iso(): return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
def nonce(): return secrets.token_hex(12)
sys.path.insert(0, HERE); import pwlogin as P
apk, appub = key("approver"); bad, badpub = key("untrusted"); dev, devpub = key("newdevice")
json.dump({"version": 1, "approver_identity": "ЯID-0001-3QQS",
           "devices": [{"pub": appub, "name": "selftest-approver", "status": "ACTIVE"}]},
          open(os.path.join(data, "trusted-devices.json"), "w"), ensure_ascii=False)
PASSWORD = "selftest-" + secrets.token_hex(10)        # throwaway, never Rizal's
WRONG = "wrong-" + secrets.token_hex(10)
ITER = 600000
salt = os.urandom(16)
def derive(pw, s=salt, it=ITER): return hashlib.pbkdf2_hmac("sha256", pw.encode(), s, it, 32)
dk = derive(PASSWORD)
verifier = base64.b64encode(hmac.new(dk, P.VERIFIER_MSG, hashlib.sha256).digest()).decode()
port = int(os.environ.get("ASSM_PW_TEST_PORT", "18755"))
logf = open(os.path.join(tmp, "server.log"), "w")
env = dict(os.environ, ASSM_RSYNC_PORT=str(port), ASSM_RSYNC_DATA=data, ASSM_RSYNC_PUBLIC_URL="http://selftest", ASSM_PW_LOCK_BASE_S="2")
proc = subprocess.Popen([sys.executable, os.path.join(HERE, "server.py")], env=env, stderr=logf, stdout=logf)
time.sleep(0.8)
B = "http://127.0.0.1:%d" % port
def call(m, path, obj=None, ip="203.0.113.7"):
    req = urllib.request.Request(B + path, method=m, data=json.dumps(obj, ensure_ascii=False).encode() if obj is not None else None)
    if obj is not None: req.add_header("Content-Type", "application/json")
    req.add_header("CF-Connecting-IP", ip)
    try:
        with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read())
def set_body(signer_key, signer_pub, n=None):
    o = {"t": "password.set", "profile": "ЯID-0001-3QQS", "handle": "@chaserizal", "salt": base64.b64encode(salt).decode(),
         "iter": ITER, "verifier": verifier, "signer": signer_pub, "nonce": n or nonce(), "ts": iso()}
    o["sig"] = sign(signer_key, P.set_msg(o)); return o
def login_body(pwdk, user="@chaserizal", n=None):
    o = {"t": "password.login", "user": user, "proof": base64.b64encode(pwdk).decode(), "device": devpub,
         "device_name": "selftest device", "nonce": n or nonce(), "ts": iso()}
    o["sig"] = sign(dev, P.login_msg(o)); return o
results = []
def check(name, cond, extra=""):
    results.append((name, bool(cond))); print(("PASS " if cond else "FAIL ") + name + (" " + extra if extra and not cond else ""))
try:
    c, b = call("POST", "/api/rsync/password/set", set_body(bad, badpub)); check("set without approver -> 403", c == 403, str((c, b)))
    c, b = call("POST", "/api/rsync/password/set", dict(set_body(apk, appub), password=PASSWORD)); check("set carrying plaintext -> 400", c == 400, str((c, b)))
    sb = set_body(apk, appub)
    c, b = call("POST", "/api/rsync/password/set", sb); check("set with approver -> 200", c == 200, str((c, b)))
    c, b = call("POST", "/api/rsync/password/set", sb); check("set replayed nonce -> 409", c == 409, str((c, b)))
    pf = os.path.join(data, "assm-password.json")
    check("password file is 0600", oct(os.stat(pf).st_mode & 0o777) == "0o600")
    c, b = call("GET", "/api/rsync/password/params?user=%40chaserizal")
    check("params -> 200 without verifier", c == 200 and "verifier" not in b and b.get("iter") == ITER, str((c, b)))
    c, b = call("POST", "/api/rsync/password/login", login_body(derive(WRONG))); check("wrong password -> 401", c == 401 and b.get("error") == "wrong username or password", str((c, b)))
    c, b = call("POST", "/api/rsync/password/login", login_body(dk, user="@someoneelse")); check("wrong username -> 401 (same message)", c == 401 and b.get("error") == "wrong username or password", str((c, b)))
    for i in range(3): call("POST", "/api/rsync/password/login", login_body(derive(WRONG)))
    c, b = call("POST", "/api/rsync/password/login", login_body(dk)); check("lockout after 5 failures -> 429 (even correct password)", c == 429, str((c, b)))
    c, b = call("POST", "/api/rsync/password/login", login_body(dk), ip="198.51.100.9"); check("lockout is per handle too (other IP) -> 429", c == 429, str((c, b)))
    st = json.load(open(os.path.join(data, "assm-password-lockout.json")))
    check("lockout persisted to disk", any(v.get("until", 0) > time.time() for v in st.values()))
    # restart: lockout survives
    proc.terminate(); proc.wait(5)
    proc = subprocess.Popen([sys.executable, os.path.join(HERE, "server.py")], env=env, stderr=logf, stdout=logf); time.sleep(0.8)
    c, b = call("POST", "/api/rsync/password/login", login_body(dk)); check("lockout survives restart -> 429", c == 429, str((c, b)))
    time.sleep(2.5)
    trusted_before = json.load(open(os.path.join(data, "trusted-devices.json")))["devices"]
    good = login_body(dk)
    c, b = call("POST", "/api/rsync/password/login", good); check("correct password -> 200", c == 200 and b.get("status") == "trusted", str((c, b)))
    devs = json.load(open(os.path.join(data, "trusted-devices.json")))["devices"]
    added = [d for d in devs if d["pub"] == devpub]
    check("exact device key added ACTIVE (only that key)", len(devs) == len(trusted_before) + 1 and added and added[0]["status"] == "ACTIVE" and added[0]["method"] == "password")
    check("timestamped trusted-list backup made", any(f.startswith("trusted-devices.pre-pwlogin-") for f in os.listdir(os.path.join(data, "backups"))))
    ents = [json.loads(l) for l in open(os.path.join(data, "entries.jsonl"))]
    check("device.enroll entry with method password", any(e.get("t") == "device.enroll" and e.get("method") == "password" and e.get("device") == devpub for e in ents))
    check("password.set audit entry has no secret", all("verifier" not in e and "salt" not in e for e in ents if e.get("t") == "password.set") and any(e.get("t") == "password.set" for e in ents))
    c, b = call("POST", "/api/rsync/password/login", good); check("replayed login nonce -> 409", c == 409, str((c, b)))
    c, b = call("GET", "/api/rsync/device-status?pub=" + urllib.request.quote(devpub)); check("device-status shows trusted", c == 200 and b.get("trusted"), str((c, b)))
    # sync still accepts the new key (signed push envelope, rcode-sync-v1)
    import sync as S
    recs = []; n = nonce(); ts = iso()
    msg = S._sign_msg("pull", "ЯID-0001-3QQS", devpub, n, ts, None)
    c, b = call("POST", "/v1/sync/pull", {"identity": "ЯID-0001-3QQS", "device": devpub, "nonce": n, "ts": ts, "sig": sign(dev, msg)})
    check("new key can pull sync", c == 200, str((c, b)))
finally:
    proc.terminate(); proc.wait(5); logf.close()
    # plaintext / proof never on disk or in the log
    blobs = []
    for root, _, files in os.walk(tmp):
        for f in files:
            if f.endswith(".pem"): continue
            blobs.append(open(os.path.join(root, f), "rb").read())
    allb = b"\n".join(blobs)
    check("plaintext password never in any file or log", PASSWORD.encode() not in allb and WRONG.encode() not in allb)
    check("derived proof never in any file or log", base64.b64encode(dk) not in allb and dk.hex().encode() not in allb)
    check("real trusted-devices.json untouched", sha(REAL_TRUSTED) == real_before)
    ok = all(r for _, r in results)
    print("%d/%d passed" % (sum(r for _, r in results), len(results)))
    import shutil; shutil.rmtree(tmp, ignore_errors=True)
    sys.exit(0 if ok else 1)
