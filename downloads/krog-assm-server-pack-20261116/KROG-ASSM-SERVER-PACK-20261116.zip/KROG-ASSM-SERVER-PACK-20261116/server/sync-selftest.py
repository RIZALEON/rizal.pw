#!/usr/bin/env python3
"""Throwaway-key tests for additive /v1/sync/changes and /v1/sync/pull.
Starts a temp server (does NOT touch the real data/trusted-devices.json).
Run: python3 sync-selftest.py
"""
import base64, json, os, subprocess, sys, tempfile, time, urllib.request, urllib.error, hashlib, shutil
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import server as S
import sync as RS

REAL_TRUSTED = os.path.join(HERE, "data", "trusted-devices.json")
PORT = int(os.environ.get("RCODE_SYNC_TEST_PORT", "18754"))

def key(tmp, name):
    k = os.path.join(tmp, name + ".pem")
    subprocess.run(["openssl", "ecparam", "-genkey", "-name", "prime256v1", "-noout", "-out", k], check=True)
    der = subprocess.run(["openssl", "ec", "-in", k, "-pubout", "-outform", "DER"], capture_output=True, check=True).stdout
    return k, base64.b64encode(der[-65:]).decode()

def sign(k, msg):
    return base64.b64encode(subprocess.run(
        ["openssl", "dgst", "-sha256", "-sign", k],
        input=msg.encode(), capture_output=True, check=True).stdout).decode()

def iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

def call(base, method, path, obj=None):
    req = urllib.request.Request(base + path, method=method,
                                 data=json.dumps(obj).encode() if obj is not None else None)
    if obj is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read())
        except Exception:
            return e.code, {"error": "unreadable"}

def records_hash(records):
    return hashlib.sha256(RS._canon(records).encode("utf-8")).hexdigest()

def envelope(pem, pub, identity, action, records=None, since=None):
    nonce = base64.b64encode(os.urandom(12)).decode().replace("+", "").replace("/", "").replace("=", "")[:16]
    ts = iso()
    if action == "push":
        h = records_hash(records or [])
    else:
        h = "" if since in (None, "") else str(since)
    msg = RS._sign_msg(action, identity, pub, nonce, ts, h)
    obj = {"identity": identity, "device": pub, "ts": ts, "nonce": nonce, "sig": sign(pem, msg)}
    if action == "push":
        obj["records"] = records or []
    if action == "pull" and since is not None:
        obj["since"] = since
    return obj

ok = True
def expect(name, got, want):
    global ok
    good = got[0] == want
    ok &= good
    extra = got[1].get("error") or got[1].get("cursor") or got[1].get("status") or ""
    print(("PASS" if good else "FAIL"), name, got[0], extra)

def main():
    global ok
    real_stat = os.stat(REAL_TRUSTED) if os.path.isfile(REAL_TRUSTED) else None
    tmp = tempfile.mkdtemp(prefix="assm-sync-selftest-")
    proc = None
    try:
        data = os.path.join(tmp, "data"); os.makedirs(data)
        ak, apub = key(tmp, "device-a")
        bk, bpub = key(tmp, "device-b")
        ck, cpub = key(tmp, "untrusted")
        tk, tpub = key(tmp, "trusted-approver")
        with open(os.path.join(data, "trusted-devices.json"), "w") as f:
            json.dump({"version": 1, "devices": [{"pub": tpub, "name": "sync-selftest-approver", "status": "ACTIVE"}]}, f)

        env = dict(os.environ, ASSM_RSYNC_PORT=str(PORT), ASSM_RSYNC_DATA=data, ASSM_RSYNC_PUBLIC_URL="http://selftest")
        proc = subprocess.Popen([sys.executable, os.path.join(HERE, "server.py")], env=env,
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        base = "http://127.0.0.1:%d" % PORT
        for _ in range(25):
            try:
                if call(base, "GET", "/health")[0] == 200:
                    break
            except Exception:
                time.sleep(0.2)
        else:
            print("FAIL temp server did not start")
            return 1

        identity = "RP-selftest"

        def enroll(devk, devpub, name):
            nonce = "sync" + name + "xxxx"
            ts = iso()
            req = {"t": "device.request", "device": devpub, "nonce": nonce, "req_ts": ts,
                   "req_sig": sign(devk, S.enroll_msg(devpub, nonce, ts)), "device_name": name}
            st, body = call(base, "POST", "/api/rsync/request", req)
            if st != 201:
                return False
            e = {"id": "enroll-" + nonce + "-t", "t": "device.enroll", "profile": identity,
                 "device": devpub, "nonce": nonce, "req_ts": ts, "req_sig": req["req_sig"],
                 "device_name": name, "ts": iso()}
            e["signer"] = tpub
            cid = S.cid_of(e)
            msg = S.PREFIX + cid
            e["cid"] = cid
            e["rgen"] = {"scope": S.SCOPE, "msg": msg, "pub": tpub, "value": sign(tk, msg)}
            st, body = call(base, "POST", "/api/rsync/approve", e)
            return st == 201

        if not enroll(ak, apub, "deva"):
            print("FAIL enroll A"); return 1
        print("PASS enroll A")
        if not enroll(bk, bpub, "devb"):
            print("FAIL enroll B"); return 1
        print("PASS enroll B")

        rec = {
            "id": "msg-hello-1",
            "kind": "message",
            "updated_at": iso(),
            "sent_at": iso(),
            "device_id": "deva",
            "deleted": False,
            "payload": {"id": "msg-hello-1", "chat_id": "chat-1", "sender": "Rizal",
                        "text": "hello from A", "is_user": True},
        }
        # Untrusted cannot push
        st, body = call(base, "POST", "/v1/sync/changes",
                        envelope(ck, cpub, identity, "push", records=[rec]))
        expect("sync push untrusted", (st, body), 403)

        st, body = call(base, "POST", "/v1/sync/changes",
                        envelope(ak, apub, identity, "push", records=[rec]))
        expect("sync push A", (st, body), 200)
        if st == 200 and body.get("accepted") != 1:
            ok = False
            print("FAIL accepted != 1", body)

        # B pulls
        st, body = call(base, "POST", "/v1/sync/pull",
                        envelope(bk, bpub, identity, "pull", since="0"))
        expect("sync pull B", (st, body), 200)
        recs = (body.get("records") or []) if st == 200 else []
        if not any(r.get("id") == "msg-hello-1" and (r.get("payload") or {}).get("text") == "hello from A" for r in recs):
            ok = False
            print("FAIL B did not receive A's message", recs)
        else:
            print("PASS B received A's message")

        # Replay the exact envelope? new envelope with same nonce: craft manually
        env1 = envelope(ak, apub, identity, "push", records=[rec])
        st1, _ = call(base, "POST", "/v1/sync/changes", env1)
        st2, b2 = call(base, "POST", "/v1/sync/changes", env1)
        expect("sync replay", (st2, b2), 409)

        # LWW: older update rejected, newer accepted
        older = dict(rec, id="msg-hello-1", updated_at="2020-01-01T00:00:00.000Z",
                     payload=dict(rec["payload"], text="stale from B"))
        st, body = call(base, "POST", "/v1/sync/changes",
                        envelope(bk, bpub, identity, "push", records=[older]))
        expect("sync LWW stale ignored (HTTP)", (st, body), 200)
        if st == 200 and body.get("rejected", 0) < 1:
            ok = False
            print("FAIL stale should be rejected", body)
        else:
            print("PASS LWW rejected stale write")

        newer = dict(rec, id="msg-hello-1", updated_at=iso(),
                     payload=dict(rec["payload"], text="updated from B"))
        st, body = call(base, "POST", "/v1/sync/changes",
                        envelope(bk, bpub, identity, "push", records=[newer]))
        expect("sync LWW newer from B", (st, body), 200)

        st, body = call(base, "POST", "/v1/sync/pull",
                        envelope(ak, apub, identity, "pull", since="0"))
        texts = [(r.get("payload") or {}).get("text") for r in (body.get("records") or []) if r.get("id") == "msg-hello-1"]
        if texts != ["updated from B"]:
            ok = False
            print("FAIL LWW result", texts)
        else:
            print("PASS LWW converged on B's newer text")

    finally:
        if proc is not None:
            proc.terminate()
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()
        shutil.rmtree(tmp, ignore_errors=True)
        if real_stat is not None:
            after = os.stat(REAL_TRUSTED)
            if (after.st_mtime_ns, after.st_size, after.st_ino) != (real_stat.st_mtime_ns, real_stat.st_size, real_stat.st_ino):
                print("FAIL real trusted-devices.json changed")
                return 1
            print("PASS real trusted-devices.json untouched")
    print("ALL PASS" if ok else "SOME FAILED")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
