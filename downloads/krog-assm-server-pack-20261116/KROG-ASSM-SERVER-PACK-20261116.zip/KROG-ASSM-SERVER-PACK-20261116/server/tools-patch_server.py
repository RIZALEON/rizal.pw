import sys
p = sys.argv[1]; s = open(p, encoding="utf-8").read()
def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (a, s.count(a)); s = s.replace(a, b)
rep('"""ASSM rsync API (live)', '"""ASSM rsync API -- BOT TEST COPY (ASSM-RSYNC-BOTTEST-20261116, 127.0.0.1:8753, own data/, no tunnel).\nAdds the limited KROG bot login (botauth.py). Original header follows.\n\nASSM rsync API (live)')
rep('import pwlogin\n', 'import pwlogin\nimport botauth\n')
rep('PORT = int(os.environ.get("ASSM_RSYNC_PORT", "8752"))', 'PORT = int(os.environ.get("ASSM_RSYNC_PORT", "8753"))')
rep('FORBIDDEN_PORTS = {8741, 4991, 4995, 8319}', 'FORBIDDEN_PORTS = {8741, 4991, 4995, 8319, 8752}   # 8752 = LIVE ASSM-RSYNC, never bind it from the test copy\nLIVE_DATA = os.path.realpath(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ASSM-RSYNC", "data"))')
rep('VERSION = "1.0.0"', 'VERSION = "1.0.0-bottest"')
rep('"service": "assm-rsync", "version": VERSION, "mode": "live"', '"service": "assm-rsync-bottest", "version": VERSION, "mode": "bottest"')
rep('"Content-Type")\n        self.send_header("Access-Control-Max-Age"', '"Content-Type, Authorization")\n        self.send_header("Access-Control-Max-Age"')
# GET guard + routes
rep('''        if not rate_ok(self.client_ip(), "GET"): return self.send(429, {"ok": False, "error": "rate limited"})
        p = self.route()
''', '''        if not rate_ok(self.client_ip(), "GET"): return self.send(429, {"ok": False, "error": "rate limited"})
        p = self.route()
        g = self.bot_guard(p)
        if g: return self.send(*g)
        if p == "/api/rsync/bot/params":
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            return self.send(*botauth.handle_params((qs.get("user") or [""])[0], DATA))
        if p == "/api/rsync/bot/whoami":
            return self.send(*botauth.handle_whoami(botauth.session_from_headers(DATA, self.headers)))
''')
rep('''    def read_json(self, max_body=MAX_BODY):''', '''    def bot_guard(self, p, obj=None):
        """Refuse bot sessions / bot device keys anywhere outside the bot routes. Returns (code, body) or None."""
        sess = botauth.session_from_headers(DATA, self.headers)
        is_bot = botauth.has_bearer(self.headers)
        if is_bot and p not in botauth.BOT_OK:
            log("bot session refused on %s" % p)
            return 403, {"ok": False, "error": "bot role may not use this route", "role": "bot"}
        if isinstance(obj, dict):
            keys = [obj.get("signer"), obj.get("device"), obj.get("pub")]
            if isinstance(obj.get("rgen"), dict): keys.append(obj["rgen"].get("pub"))
            if any(botauth.is_bot_device(DATA, k) for k in keys) and p not in botauth.BOT_OK:
                log("bot device key refused on %s" % p)
                return 403, {"ok": False, "error": "bot device keys may not use this route", "role": "bot"}
        if botauth.PRIV_RE.match(p):
            return 501, {"ok": False, "error": "not implemented on the bot test server"}
        return None

    def read_json(self, max_body=MAX_BODY):''')
# POST: guard before anything, then bot routes; body guard after read_json
rep('''    def do_POST(self):
        p = self.route()
''', '''    def do_POST(self):
        p = self.route()
        g = self.bot_guard(p)
        if g: return self.send(*g)
        if p.startswith("/api/rsync/bot/"):
            if not rate_ok(self.client_ip(), "POST"): return self.send(429, {"ok": False, "error": "rate limited"})
            obj, err = self.read_json()   # bodies are never logged
            if err: return self.send(err[0], {"ok": False, "error": err[1]})
            sess = botauth.session_from_headers(DATA, self.headers)
            if p == "/api/rsync/bot/login":
                return self.send(*botauth.handle_login(obj, self.client_ip(), DATA, p256, trusted_devices, TRUSTED, log))
            if p == "/api/rsync/bot/post": return self.send(*botauth.handle_post(sess, obj, DATA, "post"))
            if p == "/api/rsync/bot/reply": return self.send(*botauth.handle_post(sess, obj, DATA, "reply"))
            if p == "/api/rsync/bot/logout": return self.send(*botauth.handle_logout(sess, self.headers, DATA))
            return self.send(404, {"ok": False, "error": "not found"})
''')
rep('''            obj, err = self.read_json(max_body=rcode_sync.SYNC_MAX_BODY)
            if err: return self.send(err[0], {"ok": False, "error": err[1]})
''', '''            obj, err = self.read_json(max_body=rcode_sync.SYNC_MAX_BODY)
            if err: return self.send(err[0], {"ok": False, "error": err[1]})
            g = self.bot_guard(p, obj)
            if g: return self.send(*g)
''')
rep('''            obj, err = self.read_json()   # bodies are never logged
            if err: return self.send(err[0], {"ok": False, "error": err[1]})
            if p == "/api/rsync/password/set":''', '''            obj, err = self.read_json()   # bodies are never logged
            if err: return self.send(err[0], {"ok": False, "error": err[1]})
            g = self.bot_guard(p, obj)
            if g: return self.send(*g)
            if p == "/api/rsync/password/set":''')
rep('''        obj, err = self.read_json()
        if err: return self.send(err[0], {"ok": False, "error": err[1]})
        if p == "/api/rsync/request": return self.post_request(obj)''', '''        obj, err = self.read_json()
        if err: return self.send(err[0], {"ok": False, "error": err[1]})
        g = self.bot_guard(p, obj)
        if g: return self.send(*g)
        if p == "/api/rsync/request": return self.post_request(obj)''')
rep('''    if PORT in FORBIDDEN_PORTS: sys.exit("refusing reserved port %d" % PORT)''', '''    if PORT in FORBIDDEN_PORTS: sys.exit("refusing reserved port %d" % PORT)
    if os.path.realpath(DATA) == LIVE_DATA: sys.exit("refusing the LIVE ASSM-RSYNC data folder")''')
open(p, "w", encoding="utf-8").write(s); print("patched")
