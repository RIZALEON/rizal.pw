#!/usr/bin/env python3
"""One-time LOCAL bootstrap of the KROG bot profile for the ASSM-RSYNC-BOTTEST-20261116 test server ONLY.

* Creates data/bot-profiles.json with KROG (@krog, ЯID-BOT-0001), role "bot", scopes signin/post/reply.
* Generates a strong random password ON THIS MACHINE and writes it ONLY to secrets/bot-login.txt (0600).
  The password is never printed, logged, or sent anywhere. Only salt/iter/verifier go into data/.
* Unsigned on purpose: bots do not hold Rizal's approver key. A LIVE version must instead accept a
  "bot.create" entry signed by Rizal's ACTIVE trusted ASSM device (same check as password/set).
* Refuses to run against the live ASSM-RSYNC/data, and refuses if the bot profile already exists.
Usage: python3 bot-bootstrap.py [--data DIR] [--secrets FILE]
"""
import argparse, base64, hashlib, hmac, json, os, secrets, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import pwlogin as P, botauth as B

ap = argparse.ArgumentParser()
ap.add_argument("--data", default=os.path.join(HERE, "data"))
ap.add_argument("--secrets", default=os.path.join(HERE, "secrets", "bot-login.txt"))
ap.add_argument("--profile", default="ЯID-BOT-0001"); ap.add_argument("--handle", default="@krog"); ap.add_argument("--display", default="KROG")
ap.add_argument("--server", default="http://127.0.0.1:8753")
a = ap.parse_args()
# KROG-ASSM-SERVER-PACK-20261116: unsigned bootstrap is DISABLED by default and always refused in production.
import botcreate as _C
if not _C.unsigned_bootstrap_allowed():
    sys.exit("refusing: unsigned bot bootstrap is disabled. In production, create bots only with an owner-signed "
             "POST /api/rsync/bot/create (owner-tools/make-bot-create.py). For a local test server only, set "
             "ASSM_MODE=test ASSM_ALLOW_UNSIGNED_BOOTSTRAP=1.")
live = os.path.realpath(os.path.join(os.path.dirname(HERE), "ASSM-RSYNC", "data"))
if os.path.realpath(a.data) == live: sys.exit("refusing: that is the LIVE ASSM-RSYNC data folder")
os.makedirs(a.data, exist_ok=True)
pp = B.bpaths(a.data)["profiles"]
doc = P._load(pp, {"version": 1, "scheme": P.SCHEME, "profiles": {}})
if a.profile in doc["profiles"] or any(r.get("handle") == P.norm_handle(a.handle) for r in doc["profiles"].values()):
    sys.exit("refusing: bot profile already exists (one-time bootstrap)")
if os.path.exists(a.secrets): sys.exit("refusing: %s already exists (never overwrite)" % a.secrets)
if a.profile.lower() in B.owner_names(a.data, os.path.join(a.data, "trusted-devices.json")): sys.exit("refusing: owner identity")
pw = secrets.token_urlsafe(32)                    # ~256 bits
salt = os.urandom(16); it = 600000
dk = hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), salt, it, 32)
ver = hmac.new(dk, P.VERIFIER_MSG, hashlib.sha256).digest()
os.makedirs(os.path.dirname(a.secrets), exist_ok=True); os.chmod(os.path.dirname(a.secrets), 0o700)
fd = os.open(a.secrets, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, "w") as f:
    f.write("# KROG bot login for the ASSM bot TEST server only. Never paste in chat, logs, or git.\n")
    f.write("display=%s\nusername=%s\nprofile=%s\nrole=bot\nserver=%s\npassword=%s\n" % (a.display, P.norm_handle(a.handle), a.profile, a.server, pw))
os.chmod(a.secrets, 0o600)
doc["profiles"][a.profile] = {"scheme": P.SCHEME, "handle": P.norm_handle(a.handle), "display": a.display, "role": B.ROLE,
                              "scopes": B.ALLOWED, "denied": B.DENIED, "salt": base64.b64encode(salt).decode(), "iter": it,
                              "verifier": base64.b64encode(ver).decode(), "set_at": P._iso(),
                              "set_by": "bot-bootstrap.py (TEST ONLY, unsigned; live needs Rizal's signed bot.create)"}
P._atomic_write(pp, doc)
B._append(B.bpaths(a.data)["audit"], {"t": "bot.create", "profile": a.profile, "handle": P.norm_handle(a.handle), "by": "bot-bootstrap", "ts": P._iso()})
print("created bot profile %s (%s) in %s; password written only to %s (0600)" % (P.norm_handle(a.handle), a.profile, a.data, a.secrets))
