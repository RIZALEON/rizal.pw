# server/ — ASSM-RSYNC multi-profile server (owner + bots), production-ready layout

Base: `RC/ASSM-RSYNC-BOTTEST-20261116` (the multi-profile bot version with KROG), copied Nov 16, 2026 6:13 PM MST.
Stdlib Python 3 only (no pip). **No `data/`, no `secrets/`, no keys, no logs, no trusted-devices.json are included.**

## Pack changes vs the Neo test copy
| File | Change |
|---|---|
| `botcreate.py` | **new**: owner-signed `POST /api/rsync/bot/create` (signer must be an ACTIVE owner trusted device) |
| `server.py` | patched by `tools-patch_botcreate.py` (adds the route); `HOST` from `ASSM_RSYNC_HOST` (default 127.0.0.1); health `mode` from `ASSM_MODE` |
| `bot-bootstrap.py` | unsigned bootstrap **disabled by default**; runs only with `ASSM_MODE=test ASSM_ALLOW_UNSIGNED_BOOTSTRAP=1` |
| `owner-tools/make-bot-create.py` | **new**: prepares a bot.create request on Rizal's Neo (password → 0600 file only; never touches keys) |
| `botcreate-selftest.py` | **new**: 14 checks for bot.create (throwaway server/port 18764) |
| `config/assm-server.env.example`, `run.sh`, `Dockerfile`, `deploy/assm-rsync.service`, `deploy/Caddyfile.example` | **new** VPS deploy files |

Still in server.py from the Neo copy (harmless on a VPS, kept to stay byte-close to the tested code): it refuses ports 8752/8741/4991/4995/8319
and the Neo's live `ASSM-RSYNC/data` path; `/api/rsync/(wallet|…|mint|…)` return 501 (not implemented here) and 403 for bots.

## Tests run on the box (Nov 16, 2026)
- `bot-selftest.py` (with `ASSM_MODE=test ASSM_ALLOW_UNSIGNED_BOOTSTRAP=1`): **53/53 passed**
- `botcreate-selftest.py`: **14/14 passed**
- `pwlogin-selftest.py`: **23/23 passed** · `sync-selftest.py`: **ALL PASS** · `selftest.py`: **ALL PASS**
- Production gate: `bot-bootstrap.py` refuses in production and when the flag is unset.

## Run
```
cp config/assm-server.env.example /etc/assm-rsync/assm-server.env   # fill ASSM_SERVER_URL, chmod 600
./run.sh                    # or: systemd unit in deploy/, or the Dockerfile
curl -s http://127.0.0.1:8753/health
```
Behind Caddy/nginx the proxy **must** set `CF-Connecting-IP` to the real client address (see `deploy/Caddyfile.example`),
because server.py rate-limits per client IP and reads that header for loopback peers.

The owner trust store (`trusted-devices.json`, ACTIVE owner device public keys) is created empty on first start. Only Rizal adds
his devices' public keys to it (see `README-LIVE-ASSM-RSYNC.md`). Nothing in this pack fills it.

## Not on this server
The RCODE account server (`/v1/auth/*`, `/v1/devices/*`, `/v1/account/*`, passkeys, email login, device link) is a separate service and is
not in this pack.
