#!/usr/bin/env python3
"""ASSM rsync API -- BOT TEST COPY (ASSM-RSYNC-BOTTEST-20261116, 127.0.0.1:8753, own data/, no tunnel).
Adds the limited KROG bot login (botauth.py). Original header follows.

ASSM rsync API (live) for RCODE / rizal.pw ASSM device approvals. Python stdlib only.

The server NEVER generates, holds, or signs with user keys. It only verifies:
  * a new device's own request signature  (rsync-enroll-v1, rsync-core.js enrollRequestMsg)
  * an approver's RGEN seal on a device.enroll entry (rsync-core.js seal/check), where the
    approver's public key must be ACTIVE in data/trusted-devices.json (edited by Rizal only).

Endpoints (JSON only; /v1/assm/* are aliases of /api/rsync/*):
  GET  /health
  POST /api/rsync/request          {t:"device.request", device, nonce, req_ts, req_sig, device_name}
  GET  /api/rsync/request/<code>   status of an 8-digit code (pending | approved | expired)
  POST /api/rsync/approve          sealed {t:"device.enroll", ...} entry (rsync-core seal(approveEntry(req, profile), signer))
  GET  /api/rsync/entries          {version, mode:"live", updated, live, entries:[approved device.enroll entries]}
  POST /v1/sync/changes            signed push of chat/message records (trusted or enrolled device key)
  POST /v1/sync/pull               signed pull of chat/message records since a cursor
  GET  /api/rsync/device-status?pub=<b64>  this key only: trusted / enrolled / pending / unknown (no list leak)
  GET  /api/rsync/password/params?user=<ЯID|@handle>  {scheme, profile, handle, salt, iter} (no verifier)
  POST /api/rsync/password/set     {profile, handle, salt, iter, verifier, signer, nonce, ts, sig} signed by an ACTIVE trusted key
  POST /api/rsync/password/login   {user, proof, device, device_name, nonce, ts, sig} signed by the device key; 200 -> device ACTIVE
  (password scheme and storage: see pwlogin.py; the plaintext password never reaches the server)
"""
import hashlib, json, os, re, sys, threading, time, urllib.parse
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import p256
import sync as rcode_sync
import pwlogin
import botauth
import botcreate

VERSION = "1.0.0-bottest"
HOST = os.environ.get("ASSM_RSYNC_HOST", "127.0.0.1")   # pack: env-configurable (VPS behind a reverse proxy keeps 127.0.0.1)
PORT = int(os.environ.get("ASSM_RSYNC_PORT", "8753"))
FORBIDDEN_PORTS = {8741, 4991, 4995, 8319, 8752}   # 8752 = LIVE ASSM-RSYNC, never bind it from the test copy
LIVE_DATA = os.path.realpath(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ASSM-RSYNC", "data"))
BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get("ASSM_RSYNC_DATA") or os.path.join(BASE, "data")
TRUSTED = os.path.join(DATA, "trusted-devices.json")
ENTRIES = os.path.join(DATA, "entries.jsonl")
TUNNEL_LOG = os.path.join(BASE, "assm-rsync-tunnel.log")
CODE_TTL = 300            # codes / requests expire after 5 minutes
ENTRY_WINDOW = 24 * 3600  # /entries serves approvals from the last 24 h
MAX_BODY = 16 * 1024
SCOPE = "yaseed.mint"
PREFIX = "yaseed-artifact-v1\n" + SCOPE + "\n"
LOCAL = {"seq", "prev", "hash", "cid", "rgen", "_src", "_rx", "cosig"}
LIMITS = {"GET": (60, 60), "POST": (10, 60), "SYNC": (60, 60)}   # per client: n requests per window seconds
GLOBAL_LIMIT = (600, 60)

lock = threading.Lock()
pending = {}      # code -> {req..., expires}
hits = {}         # (ip, method) -> [timestamps]
global_hits = []

def now(): return time.time()
def iso(t=None): return datetime.fromtimestamp(t if t is not None else now(), timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
def parse_iso(s):
    try:
        return datetime.fromisoformat(str(s).replace("Z", "+00:00")).timestamp()
    except Exception:
        return None

# ---- rsync-core.js compatible canon / cid ----
def canon(v):
    if isinstance(v, list): return "[" + ",".join(canon(x) for x in v) + "]"
    if isinstance(v, dict): return "{" + ",".join(json.dumps(k, ensure_ascii=False) + ":" + canon(v[k]) for k in sorted(v)) + "}"
    return json.dumps(v, ensure_ascii=False)
def body(e): return {k: v for k, v in e.items() if k not in LOCAL}
def cid_of(e): return hashlib.sha256(canon(body(e)).encode("utf-8")).hexdigest()
def enroll_msg(dev, nonce, ts): return "rsync-enroll-v1\n" + dev + "\n" + nonce + "\n" + ts
def short_code(dev, nonce):
    h = hashlib.sha256((dev + "\n" + nonce).encode("utf-8")).hexdigest()
    s = "%08d" % (int(h[:10], 16) % 100000000)
    return s[:4] + "-" + s[4:]

# ---- trusted devices (file-based, Rizal edits it) ----
_trusted_cache = {"mtime": None, "devices": {}}
def trusted_devices():
    try:
        m = os.path.getmtime(TRUSTED)
    except OSError:
        return {}
    if _trusted_cache["mtime"] != m:
        try:
            doc = json.load(open(TRUSTED))
            devs = {}
            for d in doc.get("devices", []):
                if isinstance(d, dict) and d.get("status", "ACTIVE") == "ACTIVE" and p256.parse_pub(d.get("pub", "")):
                    devs[d["pub"]] = d
            _trusted_cache.update(mtime=m, devices=devs)
        except Exception as ex:
            log("trusted-devices.json unreadable: %s" % type(ex).__name__)
            _trusted_cache.update(mtime=m, devices={})
    return _trusted_cache["devices"]

def load_entries():
    out = []
    try:
        with open(ENTRIES) as f:
            for line in f:
                try: out.append(json.loads(line))
                except Exception: pass
    except OSError:
        pass
    return out

_url_cache = {"mtime": None, "url": None}
def public_url():
    if os.environ.get("ASSM_RSYNC_PUBLIC_URL"): return os.environ["ASSM_RSYNC_PUBLIC_URL"]
    try:
        m = os.path.getmtime(TUNNEL_LOG)
    except OSError:
        return None
    if _url_cache["mtime"] != m:
        try:
            with open(TUNNEL_LOG, "rb") as f:
                f.seek(max(0, os.path.getsize(TUNNEL_LOG) - 256 * 1024))
                urls = re.findall(rb"https://[a-z0-9-]+\.trycloudflare\.com", f.read())
            _url_cache.update(mtime=m, url=urls[-1].decode() if urls else None)
        except OSError:
            pass
    return _url_cache["url"]

def log(msg):
    sys.stderr.write("%s %s\n" % (iso(), msg)); sys.stderr.flush()

def rate_ok(ip, method):
    t = now()
    n, win = LIMITS.get(method, (30, 60))
    with lock:
        global global_hits
        global_hits = [x for x in global_hits if t - x < GLOBAL_LIMIT[1]]
        if len(global_hits) >= GLOBAL_LIMIT[0]: return False
        k = (ip, method)
        lst = [x for x in hits.get(k, []) if t - x < win]
        if len(lst) >= n:
            hits[k] = lst; return False
        lst.append(t); hits[k] = lst; global_hits.append(t)
        if len(hits) > 5000:
            for kk in list(hits):
                if not [x for x in hits[kk] if t - x < 120]: del hits[kk]
        return True

def check_request(r):
    """Validate a device.request; returns (ok, why)."""
    for k in ("device", "nonce", "req_ts", "req_sig"):
        if not isinstance(r.get(k), str) or not r[k] or len(r[k]) > 512: return False, "missing or bad " + k
    if not re.fullmatch(r"[A-Za-z0-9]{8,64}", r["nonce"]): return False, "bad nonce"
    if r.get("device_name") is not None and (not isinstance(r["device_name"], str) or len(r["device_name"]) > 80): return False, "bad device_name"
    rt = parse_iso(r["req_ts"])
    if rt is None: return False, "bad req_ts"
    t = now()
    if rt > t + 60: return False, "request from the future"
    if t - rt > CODE_TTL: return False, "request expired (older than 5 minutes)"
    if not p256.verify(enroll_msg(r["device"], r["nonce"], r["req_ts"]), r["req_sig"], r["device"]):
        return False, "request not signed by the new device"
    return True, None

def gc_pending():
    t = now()
    for c in [c for c, p in pending.items() if p["expires"] < t - 600]:
        del pending[c]

def public_pending(code, p):
    st = p["status"] if p["status"] == "approved" or p["expires"] >= now() else "expired"
    return {"code": code, "status": st, "expires_at": iso(p["expires"]), "device": p["device"], "nonce": p["nonce"],
            "req_ts": p["req_ts"], "req_sig": p["req_sig"], "device_name": p.get("device_name") or "device",
            "profile": p.get("profile")}


def device_status(pub):
    """Lookup one public key. Returns only that key's flags; never the trusted/enrolled lists."""
    if not isinstance(pub, str) or not pub or len(pub) > 512:
        return 400, {"ok": False, "error": "missing or bad pub"}
    if not p256.parse_pub(pub):
        return 400, {"ok": False, "error": "pub must be a base64 raw 65-byte P-256 public key"}
    td = trusted_devices().get(pub)
    trusted = bool(td)
    name = td.get("name") if td else None
    profiles = []
    for e in load_entries():
        if e.get("t") == "device.enroll" and e.get("device") == pub:
            pr = e.get("profile")
            if isinstance(pr, str) and pr and pr not in profiles:
                profiles.append(pr)
    enrolled = bool(profiles)
    pending_info = None
    with lock:
        gc_pending()
        for code, pr in pending.items():
            if pr.get("device") == pub and pr.get("status") == "pending" and pr.get("expires", 0) >= now():
                pending_info = public_pending(code, pr)
                break
    is_pending = pending_info is not None
    if trusted:
        status = "trusted"
    elif enrolled:
        status = "enrolled"
    elif is_pending:
        status = "pending"
    else:
        status = "unknown"
    out = {"ok": True, "trusted": trusted, "enrolled": enrolled, "pending": is_pending, "status": status}
    if trusted and isinstance(name, str) and name:
        out["name"] = name
    if enrolled:
        out["profiles"] = profiles
        if len(profiles) == 1:
            out["profile"] = profiles[0]
    if pending_info:
        out["code"] = pending_info["code"]
        out["expires_at"] = pending_info["expires_at"]
    return 200, out

class H(BaseHTTPRequestHandler):
    server_version = "assm-rsync/" + VERSION
    sys_version = ""

    def client_ip(self):
        peer = self.client_address[0]
        if peer in ("127.0.0.1", "::1"):
            return self.headers.get("CF-Connecting-IP") or peer
        return peer

    def send(self, code, obj):
        data = (json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        if self.command != "HEAD": self.wfile.write(data)

    def log_message(self, fmt, *args):  # never log bodies; method/path/status only
        log("%s %s" % (self.client_ip(), fmt % args))

    def route(self):
        p = self.path.split("?", 1)[0].rstrip("/") or "/"
        if p.startswith("/v1/assm"): p = "/api/rsync" + p[len("/v1/assm"):]
        return p

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Access-Control-Max-Age", "600")
        self.end_headers()

    def do_HEAD(self): self.do_GET()

    def do_GET(self):
        if not rate_ok(self.client_ip(), "GET"): return self.send(429, {"ok": False, "error": "rate limited"})
        p = self.route()
        g = self.bot_guard(p)
        if g: return self.send(*g)
        if p == "/api/rsync/bot/params":
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            return self.send(*botauth.handle_params((qs.get("user") or [""])[0], DATA))
        if p == "/api/rsync/bot/whoami":
            return self.send(*botauth.handle_whoami(botauth.session_from_headers(DATA, self.headers)))
        if p in ("/health", "/api/rsync/health", "/"):
            with lock: gc_pending(); np = sum(1 for x in pending.values() if x["status"] == "pending" and x["expires"] >= now())
            return self.send(200, {"ok": True, "service": "assm-rsync-bottest", "version": VERSION, "mode": os.environ.get("ASSM_MODE", "bottest"), "time": iso(),
                                   "live": public_url(), "trusted_devices": len(trusted_devices()), "pending": np,
                                   "code_ttl_s": CODE_TTL})
        if p == "/api/rsync/entries" or p == "/api/rsync/entries.json":
            t = now()
            ents = [e for e in load_entries() if (parse_iso(e.get("ts")) or 0) >= t - ENTRY_WINDOW][-200:]
            return self.send(200, {"version": 1, "mode": "live", "updated": iso(), "live": public_url(),
                                   "entries_path": "/api/rsync/entries", "entries": ents})
        m = re.fullmatch(r"/api/rsync/request/(\d{4})-?(\d{4})", p)
        if m:
            code = m.group(1) + "-" + m.group(2)
            with lock:
                gc_pending(); pr = pending.get(code)
                out = public_pending(code, pr) if pr else None
            return self.send(200 if out else 404, out or {"ok": False, "status": "unknown", "code": code})
        if p == "/api/rsync/password/params":
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            code, body = pwlogin.handle_params((qs.get("user") or [""])[0], DATA, TRUSTED)
            return self.send(code, body)
        if p == "/api/rsync/device-status":
            qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            pub = (qs.get("pub") or [""])[0]
            # Clients that send base64 unencoded: parse_qs turns '+' into ' '. Base64 never has spaces.
            pub = pub.replace(" ", "+")
            code, body = device_status(pub)
            return self.send(code, body)
        return self.send(404, {"ok": False, "error": "not found"})

    def bot_guard(self, p, obj=None):
        """Refuse bot sessions / bot device keys anywhere outside the bot routes. Returns (code, body) or None."""
        sess = botauth.session_from_headers(DATA, self.headers)
        is_bot = botauth.has_bearer(self.headers)
        if is_bot and p not in botauth.BOT_OK:
            log("bot session refused on %s" % p)
            return 403, {"ok": False, "error": "bot role may not use this route", "role": "bot"}
        if isinstance(obj, dict):
            keys = [obj.get("signer"), obj.get("device"), obj.get("pub")]
            if isinstance(obj.get("rgen"), dict): keys.append(obj["rgen"].get("pub"))
            if any(botauth.is_bot_device(DATA, k) for k in keys) and p not in botauth.BOT_OK:
                log("bot device key refused on %s" % p)
                return 403, {"ok": False, "error": "bot device keys may not use this route", "role": "bot"}
        if botauth.PRIV_RE.match(p):
            return 501, {"ok": False, "error": "not implemented on the bot test server"}
        return None

    def read_json(self, max_body=MAX_BODY):
        ct = (self.headers.get("Content-Type") or "").lower()
        if "application/json" not in ct: return None, (415, "Content-Type must be application/json")
        try: n = int(self.headers.get("Content-Length") or "0")
        except ValueError: n = -1
        if n <= 0 or n > max_body: return None, (413, "body missing or too large")
        try:
            obj = json.loads(self.rfile.read(n).decode("utf-8"))
        except Exception:
            return None, (400, "invalid JSON")
        if not isinstance(obj, dict): return None, (400, "JSON object expected")
        return obj, None

    def do_POST(self):
        p = self.route()
        g = self.bot_guard(p)
        if g: return self.send(*g)
        if p.startswith("/api/rsync/bot/"):
            if not rate_ok(self.client_ip(), "POST"): return self.send(429, {"ok": False, "error": "rate limited"})
            obj, err = self.read_json()   # bodies are never logged
            if err: return self.send(err[0], {"ok": False, "error": err[1]})
            sess = botauth.session_from_headers(DATA, self.headers)
            if p == "/api/rsync/bot/login":
                return self.send(*botauth.handle_login(obj, self.client_ip(), DATA, p256, trusted_devices, TRUSTED, log))
            if p == "/api/rsync/bot/create":   # owner-signed only (Rizal's ACTIVE trusted device)
                return self.send(*botcreate.handle_create(obj, DATA, p256, trusted_devices, TRUSTED, log))
            if p == "/api/rsync/bot/post": return self.send(*botauth.handle_post(sess, obj, DATA, "post"))
            if p == "/api/rsync/bot/reply": return self.send(*botauth.handle_post(sess, obj, DATA, "reply"))
            if p == "/api/rsync/bot/logout": return self.send(*botauth.handle_logout(sess, self.headers, DATA))
            return self.send(404, {"ok": False, "error": "not found"})
        bucket = "SYNC" if p in ("/v1/sync/changes", "/v1/sync/pull") else "POST"
        if not rate_ok(self.client_ip(), bucket): return self.send(429, {"ok": False, "error": "rate limited"})
        if p in ("/v1/sync/changes", "/v1/sync/pull"):
            obj, err = self.read_json(max_body=rcode_sync.SYNC_MAX_BODY)
            if err: return self.send(err[0], {"ok": False, "error": err[1]})
            g = self.bot_guard(p, obj)
            if g: return self.send(*g)
            if p == "/v1/sync/changes":
                code, body = rcode_sync.handle_push(obj, DATA, p256, trusted_devices, load_entries)
            else:
                code, body = rcode_sync.handle_pull(obj, DATA, p256, trusted_devices, load_entries)
            return self.send(code, body)
        if p in ("/api/rsync/password/set", "/api/rsync/password/login"):
            obj, err = self.read_json()   # bodies are never logged
            if err: return self.send(err[0], {"ok": False, "error": err[1]})
            g = self.bot_guard(p, obj)
            if g: return self.send(*g)
            if p == "/api/rsync/password/set":
                code, body = pwlogin.handle_set(obj, DATA, p256, trusted_devices, TRUSTED, ENTRIES, log)
            else:
                code, body = pwlogin.handle_login(obj, self.client_ip(), DATA, p256, trusted_devices, TRUSTED, ENTRIES, log)
            return self.send(code, body)
        if p not in ("/api/rsync/request", "/api/rsync/approve"): return self.send(404, {"ok": False, "error": "not found"})
        obj, err = self.read_json()
        if err: return self.send(err[0], {"ok": False, "error": err[1]})
        g = self.bot_guard(p, obj)
        if g: return self.send(*g)
        if p == "/api/rsync/request": return self.post_request(obj)
        return self.post_approve(obj)

    def post_request(self, r):
        if r.get("t", "device.request") != "device.request": return self.send(400, {"ok": False, "error": "t must be device.request"})
        ok, why = check_request(r)
        if not ok: return self.send(400, {"ok": False, "error": why})
        code = short_code(r["device"], r["nonce"])
        exp = min(parse_iso(r["req_ts"]) + CODE_TTL, now() + CODE_TTL)
        with lock:
            gc_pending()
            if sum(1 for x in pending.values() if x["status"] == "pending") > 500:
                return self.send(503, {"ok": False, "error": "too many pending requests"})
            cur = pending.get(code)
            if cur and (cur["device"] != r["device"] or cur["nonce"] != r["nonce"]) and cur["expires"] >= now():
                return self.send(409, {"ok": False, "error": "code collision, make a new request"})
            if not cur:
                pending[code] = {"device": r["device"], "nonce": r["nonce"], "req_ts": r["req_ts"], "req_sig": r["req_sig"],
                                 "device_name": (r.get("device_name") or "device")[:80], "expires": exp, "status": "pending"}
            out = public_pending(code, pending[code])
        out["ok"] = True
        return self.send(201, out)

    def post_approve(self, e):
        if e.get("t") != "device.enroll": return self.send(400, {"ok": False, "error": "t must be device.enroll"})
        if not isinstance(e.get("id"), str) or not e["id"] or len(e["id"]) > 128: return self.send(400, {"ok": False, "error": "bad id"})
        if not isinstance(e.get("profile"), str) or not e["profile"] or len(e["profile"]) > 128: return self.send(400, {"ok": False, "error": "bad profile"})
        ok, why = check_request(e)
        if not ok: return self.send(400, {"ok": False, "error": why})
        et = parse_iso(e.get("ts"))
        if et is None or abs(et - now()) > CODE_TTL: return self.send(400, {"ok": False, "error": "approval ts missing or not within 5 minutes of now"})
        g = e.get("rgen")
        if not isinstance(g, dict): return self.send(403, {"ok": False, "error": "unsigned approval (rgen seal required)"})
        cid = cid_of(e)
        if e.get("cid") and e["cid"] != cid: return self.send(400, {"ok": False, "error": "tampered (cid mismatch)"})
        if g.get("scope") != SCOPE or g.get("msg") != PREFIX + cid: return self.send(400, {"ok": False, "error": "seal does not cover this content"})
        pub = g.get("pub")
        if not isinstance(pub, str) or (e.get("signer") and e["signer"] != pub): return self.send(400, {"ok": False, "error": "signer mismatch"})
        td = trusted_devices().get(pub)
        if not td: return self.send(403, {"ok": False, "error": "approver is not an ACTIVE trusted device"})
        profs = td.get("profiles")
        if isinstance(profs, list) and profs and e["profile"] not in profs:
            return self.send(403, {"ok": False, "error": "approver may not approve for this profile"})
        if not isinstance(g.get("value"), str) or not p256.verify(g["msg"], g["value"], pub):
            return self.send(403, {"ok": False, "error": "bad approver signature"})
        entry = dict(e); entry["cid"] = cid
        code = short_code(e["device"], e["nonce"])
        with lock:
            for old in load_entries():
                if old.get("nonce") == e["nonce"]: return self.send(409, {"ok": False, "error": "replayed enrollment (nonce already used)"})
                if old.get("device") == e["device"] and old.get("profile") == e["profile"]:
                    return self.send(409, {"ok": False, "error": "device already enrolled in this profile"})
            with open(ENTRIES, "a") as f:
                f.write(json.dumps(entry, ensure_ascii=False, separators=(",", ":")) + "\n")
            pr = pending.get(code)
            if pr and pr["device"] == e["device"] and pr["nonce"] == e["nonce"]:
                pr["status"] = "approved"; pr["profile"] = e["profile"]
        log("approved code %s for profile %s by trusted device %s" % (code, e["profile"], td.get("name", "?")))
        return self.send(201, {"ok": True, "code": code, "status": "approved", "cid": cid, "profile": e["profile"]})

def main():
    if PORT in FORBIDDEN_PORTS: sys.exit("refusing reserved port %d" % PORT)
    if os.path.realpath(DATA) == LIVE_DATA: sys.exit("refusing the LIVE ASSM-RSYNC data folder")
    os.makedirs(DATA, exist_ok=True)
    if not os.path.exists(TRUSTED):
        with open(TRUSTED, "w") as f:
            json.dump({"version": 1, "approver_identity": "ЯID-0001-3QQS",
                       "comment": "Only Rizal edits this file. Add ACTIVE trusted ASSM device PUBLIC keys (base64 raw P-256, 65 bytes). See README.md.",
                       "devices": []}, f, ensure_ascii=False, indent=2)
    srv = ThreadingHTTPServer((HOST, PORT), H)
    srv.daemon_threads = True
    log("assm-rsync %s listening on http://%s:%d (trusted devices: %d)" % (VERSION, HOST, PORT, len(trusted_devices())))
    srv.serve_forever()

if __name__ == "__main__":
    main()
