#!/usr/bin/env python3
"""Self-test for the KROG bot login (botauth.py) -- ASSM-RSYNC-BOTTEST-20261116.
Default: starts a THROWAWAY server (temp data dir, port 18763) with a throwaway bot password and
throwaway owner/approver keys. Never touches ASSM-RSYNC/data or this folder's data/.
--live: smoke-tests the running test server on 127.0.0.1:8753 with secrets/bot-login.txt
(login, whoami, post, reply, refusals). It never prints the password and never runs the lockout test there.
"""
import base64, hashlib, hmac, json, os, secrets, subprocess, sys, tempfile, time, urllib.request, urllib.error
from datetime import datetime, timezone
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import pwlogin as P, botauth as B
LIVE_DATA = os.path.join(os.path.dirname(HERE), "ASSM-RSYNC", "data")
def sha_dir(d):
    """Hash of the live owner files a bot must never change (trusted devices + owner password)."""
    h = hashlib.sha256()
    for f in ("trusted-devices.json", "assm-password.json"):
        try: h.update(f.encode()); h.update(open(os.path.join(d, f), "rb").read())
        except OSError: h.update(b"missing")
    return h.hexdigest()
live_before = sha_dir(LIVE_DATA)
tmp = tempfile.mkdtemp(prefix="assm-bot-selftest-")
def key(name):
    k = os.path.join(tmp, name + ".pem")
    subprocess.run(["openssl", "ecparam", "-genkey", "-name", "prime256v1", "-noout", "-out", k], check=True)
    der = subprocess.run(["openssl", "ec", "-in", k, "-pubout", "-outform", "DER"], capture_output=True, check=True).stdout
    return k, base64.b64encode(der[-65:]).decode()
def sign(k, msg): return base64.b64encode(subprocess.run(["openssl", "dgst", "-sha256", "-sign", k], input=msg.encode(), capture_output=True, check=True).stdout).decode()
def iso(): return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
def nonce(): return secrets.token_hex(12)
def readsecret(path):
    d = {}
    for line in open(path):
        if "=" in line and not line.startswith("#"): k, v = line.rstrip("\n").split("=", 1); d[k] = v
    return d
results = []
def check(name, cond, extra=""):
    results.append((name, bool(cond))); print(("PASS " if cond else "FAIL ") + name + (" [" + str(extra) + "]" if extra and not cond else ""))
B_URL = None
def call(m, path, obj=None, ip="198.51.100.1", tok=None):
    req = urllib.request.Request(B_URL + path, method=m, data=json.dumps(obj, ensure_ascii=False).encode() if obj is not None else None)
    if obj is not None: req.add_header("Content-Type", "application/json")
    req.add_header("CF-Connecting-IP", ip)
    if tok: req.add_header("Authorization", "Bearer " + tok)
    try:
        with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        try: return e.code, json.loads(e.read())
        except Exception: return e.code, {}
def derive(pw, prm): return hashlib.pbkdf2_hmac("sha256", pw.encode(), base64.b64decode(prm["salt"]), int(prm["iter"]), 32)
def bot_login(user, dk, devk, devpub, ip):
    o = {"t": "bot.login", "user": user, "proof": base64.b64encode(dk).decode(), "device": devpub, "device_name": "KROG selftest",
         "nonce": nonce(), "ts": iso()}
    o["sig"] = sign(devk, B.botlogin_msg(o)); return call("POST", "/api/rsync/bot/login", o, ip=ip)
DENY_POST = ["/api/rsync/approve", "/api/rsync/password/set", "/api/rsync/password/login", "/v1/sync/changes", "/v1/sync/pull",
             "/api/rsync/request", "/api/rsync/wallet/send", "/api/rsync/rwallet/balance", "/api/rsync/sign", "/api/rsync/mint",
             "/api/rsync/trade", "/api/rsync/swap", "/api/rsync/buy", "/api/rsync/sell", "/api/rsync/device/approve", "/v1/assm/approve"]
DENY_GET = ["/api/rsync/password/params?user=@krog", "/api/rsync/wallet", "/api/rsync/rwallet/balance", "/api/rsync/entries", "/api/rsync/device-status?pub=x"]
def refusals(tok, tag):
    for path in DENY_POST:
        c, b = call("POST", path, {"t": "x", "signer": "x"}, tok=tok); check("%s bot session refused POST %s" % (tag, path), c == 403, c)
    for path in DENY_GET:
        c, b = call("GET", path, tok=tok); check("%s bot session refused GET %s" % (tag, path.split("?")[0]), c == 403, c)

if "--live" in sys.argv:
    B_URL = "http://127.0.0.1:8753"
    sec = readsecret(os.path.join(HERE, "secrets", "bot-login.txt"))
    c, prm = call("GET", "/api/rsync/bot/params?user=" + sec["username"]); check("live params for " + sec["username"], c == 200 and prm.get("role") == "bot", c)
    dk = derive(sec["password"], prm)
    devk, devpub = key("krog-live-device")
    c, r = bot_login(sec["username"], dk, devk, devpub, "127.0.0.1"); check("live KROG login succeeds", c == 200 and r.get("role") == "bot" and r.get("trusted") is False, (c, r.get("error")))
    tok = r.get("session")
    c, w = call("GET", "/api/rsync/bot/whoami", tok=tok); check("live whoami scopes signin/post/reply", c == 200 and w.get("scopes") == ["signin", "post", "reply"], c)
    c, p = call("POST", "/api/rsync/bot/post", {"text": "KROG test post (selftest --live)"}, tok=tok); check("live post allowed", c == 201, c)
    c, p2 = call("POST", "/api/rsync/bot/reply", {"text": "KROG test reply (selftest --live)", "parent_id": p.get("record", {}).get("id", "x")}, tok=tok); check("live reply allowed", c == 201, c)
    refusals(tok, "live")
    c, _ = call("POST", "/api/rsync/bot/logout", {}, tok=tok); check("live logout", c == 200, c)
    check("LIVE ASSM-RSYNC trusted-devices.json + assm-password.json unchanged", sha_dir(LIVE_DATA) == live_before)
else:
    data = os.path.join(tmp, "data"); os.makedirs(data)
    apk, appub = key("approver"); botk, botpub = key("botdevice"); dev2, dev2pub = key("otherdevice")
    json.dump({"version": 1, "approver_identity": "ЯID-0001-3QQS", "devices": [{"pub": appub, "name": "selftest-approver", "status": "ACTIVE"}]},
              open(os.path.join(data, "trusted-devices.json"), "w"), ensure_ascii=False)
    sfile = os.path.join(tmp, "secrets", "bot-login.txt")
    subprocess.run([sys.executable, os.path.join(HERE, "bot-bootstrap.py"), "--data", data, "--secrets", sfile, "--server", "selftest"], check=True, capture_output=True)
    r2 = subprocess.run([sys.executable, os.path.join(HERE, "bot-bootstrap.py"), "--data", data, "--secrets", sfile + "2"], capture_output=True)
    check("bootstrap is one-time (second run refused)", r2.returncode != 0)
    check("secret file is 0600", (os.stat(sfile).st_mode & 0o777) == 0o600)
    BOTPW = readsecret(sfile)["password"]
    check("bot password is strong (>= 40 chars)", len(BOTPW) >= 40)
    # owner password (throwaway) set by throwaway approver
    OWNERPW = "owner-" + secrets.token_hex(12); osalt = os.urandom(16)
    odk = hashlib.pbkdf2_hmac("sha256", OWNERPW.encode(), osalt, 600000, 32)
    port = 18763; B_URL = "http://127.0.0.1:%d" % port
    logf = open(os.path.join(tmp, "server.log"), "w")
    env = dict(os.environ, ASSM_RSYNC_PORT=str(port), ASSM_RSYNC_DATA=data, ASSM_RSYNC_PUBLIC_URL="http://selftest", ASSM_PW_LOCK_BASE_S="2")
    proc = subprocess.Popen([sys.executable, os.path.join(HERE, "server.py")], env=env, stderr=logf, stdout=logf)
    time.sleep(1.0)
    try:
        so = {"t": "password.set", "profile": "ЯID-0001-3QQS", "handle": "@chaserizal", "salt": base64.b64encode(osalt).decode(), "iter": 600000,
              "verifier": base64.b64encode(hmac.new(odk, P.VERIFIER_MSG, hashlib.sha256).digest()).decode(), "signer": appub, "nonce": nonce(), "ts": iso()}
        so["sig"] = sign(apk, P.set_msg(so)); c, _ = call("POST", "/api/rsync/password/set", so); check("setup: throwaway owner password set by approver", c == 200, c)
        trusted_before = hashlib.sha256(open(os.path.join(data, "trusted-devices.json"), "rb").read()).hexdigest()
        c, prm = call("GET", "/api/rsync/bot/params?user=@krog"); check("bot params for @krog (role bot, 600000 iter)", c == 200 and prm.get("profile") == "ЯID-BOT-0001" and prm.get("iter") == 600000, c)
        c, _ = call("GET", "/api/rsync/password/params?user=@krog"); check("@krog is not an owner password profile (404)", c == 404, c)
        dk = derive(BOTPW, prm)
        c, r = bot_login("@krog", dk, botk, botpub, "198.51.100.10"); check("bot login succeeds (@krog)", c == 200 and r.get("role") == "bot" and r.get("trusted") is False and r.get("session"), (c, r.get("error")))
        tok = r.get("session")
        c, r = bot_login("ЯID-BOT-0001", dk, botk, botpub, "198.51.100.10"); check("bot login succeeds (ЯID-BOT-0001)", c == 200, c)
        td = json.load(open(os.path.join(data, "trusted-devices.json")))
        check("bot device NOT added to trusted-devices.json", botpub not in [d.get("pub") for d in td["devices"]])
        check("trusted-devices.json unchanged by bot login", hashlib.sha256(open(os.path.join(data, "trusted-devices.json"), "rb").read()).hexdigest() == trusted_before)
        c, w = call("GET", "/api/rsync/bot/whoami", tok=tok); check("whoami: role bot, scopes signin/post/reply only", c == 200 and w.get("scopes") == ["signin", "post", "reply"] and "wallet" in w.get("denied", []), c)
        c, p = call("POST", "/api/rsync/bot/post", {"text": "KROG test post"}, tok=tok); check("bot post allowed", c == 201, c)
        c, _ = call("POST", "/api/rsync/bot/reply", {"text": "KROG test reply", "parent_id": p["record"]["id"]}, tok=tok); check("bot reply allowed", c == 201, c)
        c, _ = call("POST", "/api/rsync/bot/post", {"text": "no session"}); check("post without session refused (401)", c == 401, c)
        refusals(tok, "")
        # bot DEVICE key (no bearer) on owner routes
        lo = {"t": "password.login", "user": "@chaserizal", "proof": base64.b64encode(odk).decode(), "device": botpub, "device_name": "x", "nonce": nonce(), "ts": iso()}
        lo["sig"] = sign(botk, P.login_msg(lo)); c, _ = call("POST", "/api/rsync/password/login", lo, ip="198.51.100.20")
        check("bot device key cannot become an owner device (even with owner password)", c == 403, c)
        so2 = dict(so, signer=botpub, nonce=nonce(), ts=iso()); so2["sig"] = sign(botk, P.set_msg(so2)); c, _ = call("POST", "/api/rsync/password/set", so2)
        check("bot device key cannot set passwords", c == 403, c)
        c, _ = call("POST", "/api/rsync/approve", {"t": "device.enroll", "rgen": {"pub": botpub}, "device": dev2pub}); check("bot device key cannot approve", c == 403, c)
        c, _ = call("POST", "/v1/sync/changes", {"device": botpub}); check("bot device key refused on sync", c == 403, c)
        # owner identity with the bot password
        for u in ("ЯID-0001-3QQS", "@chaserizal", "chaserizal"):
            c, r = bot_login(u, dk, dev2, dev2pub, "198.51.100.30"); check("owner %s NOT reachable via bot login with bot password" % u, c == 401 and not r.get("session"), c)
        ol = {"t": "password.login", "user": "@chaserizal", "proof": base64.b64encode(dk).decode(), "device": dev2pub, "device_name": "x", "nonce": nonce(), "ts": iso()}
        ol["sig"] = sign(dev2, P.login_msg(ol)); c, _ = call("POST", "/api/rsync/password/login", ol, ip="198.51.100.31")
        check("owner password login with the BOT password fails (401)", c == 401, c)
        ol2 = dict(ol, user="@krog", nonce=nonce(), ts=iso()); ol2["sig"] = sign(dev2, P.login_msg(ol2)); c, _ = call("POST", "/api/rsync/password/login", ol2, ip="198.51.100.31")
        check("@krog cannot use the owner login route (401)", c == 401, c)
        c, _ = bot_login("@krog", dk, apk, appub, "198.51.100.32"); check("owner trusted device key cannot sign in as bot (403)", c == 403, c)
        td2 = json.load(open(os.path.join(data, "trusted-devices.json")))
        check("no device was added to the owner profile", len(td2["devices"]) == 1)
        # wrong password + lockout
        wdk = derive("wrong-" + secrets.token_hex(8), prm); codes = []
        for i in range(5): codes.append(bot_login("@krog", wdk, dev2, dev2pub, "198.51.100.40")[0])
        check("wrong password fails x5 (401)", codes == [401] * 5, codes)
        c, _ = bot_login("@krog", dk, dev2, dev2pub, "198.51.100.40"); check("then locked out, even with the right password (429)", c == 429, c)
        time.sleep(2.5)
        c, _ = bot_login("@krog", dk, dev2, dev2pub, "198.51.100.40"); check("login works again after the lockout expires", c == 200, c)
        c, _ = call("POST", "/api/rsync/bot/logout", {}, tok=tok); check("logout", c == 200, c)
        c, _ = call("GET", "/api/rsync/bot/whoami", tok=tok); check("revoked session refused (401)", c == 401, c)
        log = open(os.path.join(tmp, "server.log")).read()
        check("password never appears in server log", BOTPW not in log and OWNERPW not in log)
    finally:
        proc.terminate(); proc.wait()
    check("LIVE ASSM-RSYNC trusted-devices.json + assm-password.json unchanged", sha_dir(LIVE_DATA) == live_before)
n = sum(1 for _, ok in results if ok)
print("\n%d/%d passed%s" % (n, len(results), "" if n == len(results) else "  <-- FAILURES"))
sys.exit(0 if n == len(results) else 1)
