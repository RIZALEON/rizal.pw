#!/usr/bin/env python3
"""Additive RCODE chat/message sync for ASSM-RSYNC.

Push/pull are signed by a P-256 device key that is either ACTIVE in
trusted-devices.json or already enrolled (device.enroll) for the identity.
Last-writer-wins on (updated_at, sent_at, device_id). Replay-protected by
(device, nonce). The server never holds or signs with user private keys.

Does not modify trusted-devices.json.
"""
import hashlib, json, os, re, threading
from datetime import datetime, timezone

SYNC_TTL = 300
SYNC_MAX_RECORDS = 200
SYNC_MAX_BODY = 512 * 1024
PREFIX = "rcode-sync-v1\n"

_lock = threading.Lock()
_nonces = set()  # (device, nonce)


def _iso_to_ts(s):
    try:
        return datetime.fromisoformat(str(s).replace("Z", "+00:00")).timestamp()
    except Exception:
        return None


def _canon(v):
    if isinstance(v, list):
        return "[" + ",".join(_canon(x) for x in v) + "]"
    if isinstance(v, dict):
        return "{" + ",".join(json.dumps(k, ensure_ascii=False) + ":" + _canon(v[k]) for k in sorted(v)) + "}"
    return json.dumps(v, ensure_ascii=False)


def _safe_identity(identity):
    if not isinstance(identity, str) or not identity or len(identity) > 128:
        return None
    if not re.fullmatch(r"[A-Za-z0-9._@\u042fID\-]+", identity) and not re.fullmatch(r"[^\s/\\]{1,128}", identity):
        return None
    # Path-safe folder name
    return "".join(c if c.isalnum() or c in "._@-" else "_" for c in identity)


def _paths(data_dir, identity):
    folder = os.path.join(data_dir, "sync", _safe_identity(identity))
    return folder, os.path.join(folder, "records.jsonl"), os.path.join(data_dir, "sync", "nonces.jsonl")


def _load_records(path):
    out = {}
    seq = 0
    try:
        with open(path) as f:
            for line in f:
                try:
                    rec = json.loads(line)
                except Exception:
                    continue
                seq = max(seq, int(rec.get("_seq") or 0))
                rid = rec.get("id")
                if isinstance(rid, str) and rid:
                    out[rid] = rec
    except OSError:
        pass
    return out, seq


def _load_nonces(path):
    global _nonces
    if _nonces:
        return
    try:
        with open(path) as f:
            for line in f:
                try:
                    o = json.loads(line)
                    _nonces.add((o["device"], o["nonce"]))
                except Exception:
                    pass
    except OSError:
        pass


def enrolled_or_trusted(pub, identity, trusted_devices, load_entries):
    td = trusted_devices().get(pub)
    if td:
        profs = td.get("profiles")
        if not isinstance(profs, list) or not profs or identity in profs:
            return True
    for e in load_entries():
        if e.get("t") == "device.enroll" and e.get("device") == pub and e.get("profile") == identity:
            return True
    return False


def _sign_msg(action, identity, device, nonce, ts, body_hash):
    return PREFIX + action + "\n" + identity + "\n" + device + "\n" + nonce + "\n" + ts + "\n" + (body_hash or "")


def _lww_key(rec):
    """Higher tuple wins. updated_at, then sent_at (messages), then device_id."""
    upd = _iso_to_ts(rec.get("updated_at")) or 0
    sent = _iso_to_ts(rec.get("sent_at")) or 0
    # Also peek payload for sent_at if present
    pl = rec.get("payload")
    if sent == 0 and isinstance(pl, dict):
        sent = _iso_to_ts(pl.get("sent_at")) or 0
    return (upd, sent, str(rec.get("device_id") or ""))


def verify_envelope(obj, action, body_hash, p256, trusted_devices, load_entries, nonce_path):
    identity = obj.get("identity")
    device = obj.get("device")
    ts = obj.get("ts")
    nonce = obj.get("nonce")
    sig = obj.get("sig")
    if not all(isinstance(x, str) and x for x in (identity, device, ts, nonce, sig)):
        return None, (400, "missing identity, device, ts, nonce, or sig")
    if len(identity) > 128 or len(device) > 512 or len(nonce) > 128 or len(sig) > 1024:
        return None, (400, "field too long")
    if not re.fullmatch(r"[A-Za-z0-9]{8,64}", nonce):
        return None, (400, "bad nonce")
    t = _iso_to_ts(ts)
    if t is None:
        return None, (400, "bad ts")
    now = datetime.now(timezone.utc).timestamp()
    if t > now + 60:
        return None, (400, "ts from the future")
    if now - t > SYNC_TTL:
        return None, (400, "ts expired")
    if not enrolled_or_trusted(device, identity, trusted_devices, load_entries):
        return None, (403, "device is not a trusted or enrolled signer for this identity")
    msg = _sign_msg(action, identity, device, nonce, ts, body_hash)
    if not p256.verify(msg, sig, device):
        return None, (403, "bad device signature")
    _load_nonces(nonce_path)
    key = (device, nonce)
    with _lock:
        if key in _nonces:
            return None, (409, "replayed sync nonce")
        _nonces.add(key)
        os.makedirs(os.path.dirname(nonce_path), exist_ok=True)
        with open(nonce_path, "a") as f:
            f.write(json.dumps({"device": device, "nonce": nonce, "ts": ts}, ensure_ascii=False) + "\n")
    return identity, None


def records_hash(records):
    return hashlib.sha256(_canon(records).encode("utf-8")).hexdigest()


def handle_push(obj, data_dir, p256, trusted_devices, load_entries):
    records = obj.get("records")
    if not isinstance(records, list):
        return 400, {"ok": False, "error": "records must be a list"}
    if len(records) > SYNC_MAX_RECORDS:
        return 400, {"ok": False, "error": "too many records"}
    identity = obj.get("identity")
    if not _safe_identity(identity or ""):
        return 400, {"ok": False, "error": "bad identity"}
    folder, rec_path, nonce_path = _paths(data_dir, identity)
    ident, err = verify_envelope(obj, "push", records_hash(records), p256, trusted_devices, load_entries, nonce_path)
    if err:
        return err[0], {"ok": False, "error": err[1]}
    accepted, rejected = 0, 0
    with _lock:
        os.makedirs(folder, exist_ok=True)
        store, seq = _load_records(rec_path)
        appended = []
        for rec in records:
            if not isinstance(rec, dict) or not isinstance(rec.get("id"), str) or not rec["id"] or len(rec["id"]) > 128:
                rejected += 1
                continue
            kind = rec.get("kind")
            if kind not in ("chat", "message", "setting"):
                rejected += 1
                continue
            incoming = dict(rec)
            old = store.get(incoming["id"])
            if old and _lww_key(old) >= _lww_key(incoming):
                rejected += 1
                continue
            seq += 1
            incoming["_seq"] = seq
            store[incoming["id"]] = incoming
            appended.append(incoming)
            accepted += 1
        if appended:
            with open(rec_path, "a") as f:
                for r in appended:
                    f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":")) + "\n")
    return 200, {"ok": True, "accepted": accepted, "rejected": rejected, "cursor": str(seq)}


def handle_pull(obj, data_dir, p256, trusted_devices, load_entries):
    identity = obj.get("identity") or ""
    if not _safe_identity(identity):
        return 400, {"ok": False, "error": "bad identity"}
    since = obj.get("since")
    try:
        since_n = int(since) if since not in (None, "") else 0
    except (TypeError, ValueError):
        return 400, {"ok": False, "error": "bad since cursor"}
    folder, rec_path, nonce_path = _paths(data_dir, identity)
    ident, err = verify_envelope(obj, "pull", str(since_n) if since not in (None, "") else "",
                                 p256, trusted_devices, load_entries, nonce_path)
    if err:
        return err[0], {"ok": False, "error": err[1]}
    with _lock:
        store, seq = _load_records(rec_path)
        items = [r for r in store.values() if int(r.get("_seq") or 0) > since_n]
        items.sort(key=lambda r: int(r.get("_seq") or 0))
        # Strip internal seq from the public payload but include cursor
        out = []
        for r in items:
            pub = {k: v for k, v in r.items() if k != "_seq"}
            out.append(pub)
    return 200, {"ok": True, "records": out, "cursor": str(seq)}
