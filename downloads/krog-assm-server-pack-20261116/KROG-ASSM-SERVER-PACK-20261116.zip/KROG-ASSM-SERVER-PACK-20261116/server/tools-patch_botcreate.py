#!/usr/bin/env python3
"""Apply AFTER tools-patch_server.py: adds the owner-signed POST /api/rsync/bot/create route (botcreate.py)
(server.py already reads ASSM_RSYNC_PORT; how it picks its data folder and bind host must be checked
against the Neo's server.py before deploy, see README-SERVER.md). Usage: python3 tools-patch_botcreate.py server.py   (writes server.py.pre-botcreate first)"""
import shutil, sys
p = sys.argv[1]; s = open(p, encoding="utf-8").read()
if "botcreate" in s: sys.exit("already patched")
shutil.copy2(p, p + ".pre-botcreate")
def rep(a, b):
    global s
    assert s.count(a) == 1, ("anchor not found exactly once", a[:60], s.count(a)); s = s.replace(a, b)
rep('import botauth\n', 'import botauth\nimport botcreate\n')
rep('''            if p == "/api/rsync/bot/login":
                return self.send(*botauth.handle_login(obj, self.client_ip(), DATA, p256, trusted_devices, TRUSTED, log))''',
'''            if p == "/api/rsync/bot/login":
                return self.send(*botauth.handle_login(obj, self.client_ip(), DATA, p256, trusted_devices, TRUSTED, log))
            if p == "/api/rsync/bot/create":   # owner-signed only (Rizal's ACTIVE trusted device)
                return self.send(*botcreate.handle_create(obj, DATA, p256, trusted_devices, TRUSTED, log))''')
open(p, "w", encoding="utf-8").write(s); print("patched: /api/rsync/bot/create added")
