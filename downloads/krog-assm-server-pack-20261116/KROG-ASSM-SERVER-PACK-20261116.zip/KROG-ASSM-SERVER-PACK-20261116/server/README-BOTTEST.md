# ASSM-RSYNC-BOTTEST-20261116 — KROG bot login (TEST ONLY)

Rizal asked on Nov 16, 2026 for a username and password just for AI and bots to log in with, so KROG and RDRAGON auto-replies can be tested.
This folder is a **copy** of ASSM-RSYNC's code. It has its **own empty `data/`**, runs on **127.0.0.1:8753**, and has no tunnel and no launchd job.
The live ASSM-RSYNC (8752, `info.rizal.assm-rsync`, its `data/`, plist and tunnel) is not touched. `server.py` here refuses port 8752 and refuses the live `data/` folder.

## Bot account
| | |
|---|---|
| Display | KROG |
| Username | `@krog` |
| ЯID | `ЯID-BOT-0001` (the code uses ЯID-0001…0014, ЯID-LOCAL and ЯID-BOTLATCH; ЯID-BOT-0001 isn't used anywhere) |
| Role | `bot` |
| Allowed | `signin`, `post`, `reply` |
| Denied | wallet, rwallet, approve, device-approve, sign, mint, trade, swap, buy, sell, password-set |
| Password | `secrets/bot-login.txt` (0600, git-ignored). It's never printed or logged. |

## Isolation
- Bot profiles live in `data/bot-profiles.json`, not in `assm-password.json` or `trusted-devices.json`.
- A bot login **never** adds a device to `trusted-devices.json`. Bot device keys go to `data/bot-devices.json`.
- A login returns a bearer session (12 h, kept in memory by the client). The server stores only its SHA-256.
- A bot session, or a bot device key, is refused (403) on: approve, password set/login, request, sync, entries, device-status, and every `/api/rsync/(wallet|rwallet|sign|mint|trade|swap|buy|sell|device/approve)` route.
- The owner (ЯID-0001-3QQS, @chaserizal or any owner handle) can't be logged into through `/bot/login`. Owner trusted device keys can't sign in as a bot.
- Wrong passwords lock out after 5 tries, the same as the owner login (doubling from 60 s).

## Routes added (botauth.py)
- `GET  /api/rsync/bot/params?user=@krog` returns `{scheme, profile, handle, display, role, salt, iter}`.
- `POST /api/rsync/bot/login` takes `{t:"bot.login", user, proof=base64(PBKDF2(pw,salt,iter,32)), device, device_name, nonce, ts, sig}`.
  `sig` is P-256 (raw r||s or DER) by `device` over `"assm-bot-login-v1\n" + user\nsha256hex(proof)\ndevice\ndevice_name\nnonce\nts`.
  It returns `{session, role:"bot", scopes, denied, trusted:false}`.
- `GET  /api/rsync/bot/whoami` (Bearer)
- `POST /api/rsync/bot/post {text}` and `POST /api/rsync/bot/reply {text, parent_id, parent_author?}` (Bearer) append to `data/bot-posts.jsonl`, which is append-only.
- `POST /api/rsync/bot/logout` (Bearer)

## Bootstrap (test only)
`bot-bootstrap.py` created the profile once, locally and **unsigned**, because bots don't hold Rizal's approver key. It refuses a second run, an existing secrets file, and the live data folder.
**For a live version,** creating a bot profile must take a `bot.create` entry signed by Rizal's ACTIVE trusted ASSM device (the same check as `password/set`), with the verifier made on the client. Never use an unsigned bootstrap on 8752.

## Start / stop
    cd ~/R/ЯLAB/RCRYPTOFORGE/ASSM-RSYNC-BOTTEST-20261116
    nohup python3 server.py > bottest-server.log 2>&1 &  echo $! > bottest-server.pid    # start
    kill "$(cat bottest-server.pid)"                                                     # stop
    curl -s http://127.0.0.1:8753/health                                                 # mode "bottest"

## Tests
    python3 bot-selftest.py          # throwaway server on :18763, temp data, lockout test included
    python3 bot-selftest.py --live   # smoke test of the running :8753 with secrets/bot-login.txt (no lockout test)
    python3 pwlogin-selftest.py      # original owner-login tests, still pass on this copy

## Files
botauth.py (new), bot-bootstrap.py (new), bot-selftest.py (new), server.py (patched copy; the original copy is kept as server.py.pre-botauth),
tools-patch_server.py (the patch that was applied), clients/KROGBotLogin-RCODE.swift and clients/KROGBotLogin-RDRAGON.swift (Swift clients),
pwlogin.py, p256.py, sync.py and the selftests (unchanged copies), README-LIVE-COPY.md (the live README).
