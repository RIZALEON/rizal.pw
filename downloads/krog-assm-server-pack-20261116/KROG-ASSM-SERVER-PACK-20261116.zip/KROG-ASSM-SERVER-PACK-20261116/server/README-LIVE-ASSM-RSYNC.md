# ASSM-RSYNC: live ASSM approval API for RCODE (Rizal GO t224, 2026-11-16)

Verify-only server (Python 3 stdlib). It **never generates, holds, or signs with user keys**.
Bots never sign; approvals are signed on Rizal's own trusted ASSM device after Face ID / Touch ID / password unlock.

- Local: `http://127.0.0.1:8752`. Public: a cloudflared quick tunnel that exposes **only** this port.
  The URL changes when the tunnel restarts; `GET /health` → `live` shows the current one.
- launchd: `info.rizal.assm-rsync` (server) and `info.rizal.assm-rsync-tunnel` (tunnel). Plists here and in `~/Library/LaunchAgents/`.
- Static fallback/discovery feed: `https://rizal.pw/api/rsync/entries` (its `live` field points here). After a tunnel restart run `./publish-live-url.sh`.

## Endpoints (JSON only; `/v1/assm/*` are aliases)
| Method | Path | Notes |
|---|---|---|
| GET | `/health` | status, current `live` URL, trusted-device count |
| POST | `/api/rsync/request` | `{t:"device.request", device, nonce, req_ts, req_sig, device_name}` (rsync-core `enrollRequest`). `req_sig` must verify with `device`; `req_ts` ≤ 5 min old. Returns the 8-digit `code`. |
| GET | `/api/rsync/request/<code>` | `pending` / `approved` / `expired` + the public request fields (so an approver can type the code). |
| POST | `/api/rsync/approve` | `seal(approveEntry(req, profile), trustedSigner)` from rsync-core.js. Signer (`rgen.pub`) must be ACTIVE in `data/trusted-devices.json`; seal, cid and the new device's `req_sig` are verified; replays rejected. |
| GET | `/api/rsync/entries` | `{version:1, mode:"live", updated, live, entries:[approved device.enroll, last 24 h]}`. This is what RCODE polls. |

Limits: codes/requests expire after 5 minutes; 60 GET + 10 POST per minute per client IP (CF-Connecting-IP); 16 KB bodies; only P-256 approver keys.

## Adding trusted devices (Rizal only)
Trusted devices are **public keys** in `data/trusted-devices.json` (starts empty, so nothing can be approved yet).
1. On the approving device (e.g. the ASSM web client on rizal.pw or another enrolled device) get its device public key: base64 of the raw 65-byte P-256 key (`deviceSigner().pub` in rsync-core.js).
2. On Neo: `python3 add-trusted-device.py add "<that public key>" "iPhone 17e"` (optional `--profile RP-xxxx` to limit which profile it may approve for).
3. `python3 add-trusted-device.py list` to check; `python3 add-trusted-device.py revoke "iPhone 17e"` to deactivate. Takes effect immediately.
Never put a private key, seed, or password in this folder.

## Test
`python3 selftest.py` uses throwaway openssl keys and a temp data dir (port 18752). Verified interop with rsync-core.js 0.3.2 (seal, cid, shortCode).

## Stop / start
`launchctl bootout gui/$(id -u)/info.rizal.assm-rsync-tunnel` (and `.../info.rizal.assm-rsync`); start with `launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/<label>.plist`.

## RCODE chat sync (additive)

`POST /v1/sync/changes` (push) and `POST /v1/sync/pull` (pull) store chat and message records per identity.
Each call is signed by a P-256 device key that is ACTIVE in `trusted-devices.json` or already enrolled (`device.enroll`) for that identity.
Last-writer-wins on `(updated_at, sent_at, device_id)`. Replayed `(device, nonce)` pairs return 409.
The server never holds user private keys. Records live under `data/sync/` (or `$ASSM_RSYNC_DATA/sync/`).
The live process must be restarted to pick up this code; do not use the real trusted list in tests (`python3 sync-selftest.py`).

## Device status (additive)

`GET /api/rsync/device-status?pub=<base64 raw 65-byte P-256 public key>` looks up **that key only**.
The JSON is `{ok, trusted, enrolled, pending, status}` plus, when they apply to this key, `name`, `profile`/`profiles`, `code`, and `expires_at`.
`status` is `trusted`, `enrolled`, `pending`, or `unknown`. It never returns the trusted-devices list or any other key.
