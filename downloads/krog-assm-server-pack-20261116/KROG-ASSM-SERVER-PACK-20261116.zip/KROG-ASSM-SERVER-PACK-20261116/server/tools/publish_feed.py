import base64, datetime, json, subprocess, sys
R = "repos/RIZALEON/rizal.pw"
def api(m, p, b=None):
    r = subprocess.run(["gh", "api", "-X", m, p] + (["--input", "-"] if b is not None else []),
                       input=json.dumps(b) if b is not None else None, capture_output=True, text=True)
    if r.returncode: sys.exit(r.stderr + r.stdout)
    return json.loads(r.stdout)
live = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1] != "null" else None
u = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
feed = json.dumps({"version": 1, "mode": "static", "updated": u, "live": live, "entries_path": "/api/rsync/entries", "entries": []}, indent=2) + "\n"
head = api("GET", R + "/git/ref/heads/main")["object"]["sha"]
base = api("GET", R + "/git/commits/" + head)["tree"]["sha"]
blob = api("POST", R + "/git/blobs", {"content": base64.b64encode(feed.encode()).decode(), "encoding": "base64"})["sha"]
tree = api("POST", R + "/git/trees", {"base_tree": base, "tree": [{"path": p, "mode": "100644", "type": "blob", "sha": blob} for p in ("api/rsync/entries", "api/rsync/entries.json")]})
c = api("POST", R + "/git/commits", {"message": "ASSM rsync: static feed live URL -> %s" % live, "tree": tree["sha"], "parents": [head]})
api("PATCH", R + "/git/refs/heads/main", {"sha": c["sha"], "force": False})
print(c["sha"], c["html_url"])
