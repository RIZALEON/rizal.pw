#!/usr/bin/env python3
"""Self-test for the owner-signed POST /api/rsync/bot/create route (KROG-ASSM-SERVER-PACK-20261116).
Starts a THROWAWAY server (temp data dir, port 18764) with a throwaway owner trusted key; never touches real data."""
import base64, hashlib, hmac, json, os, secrets, subprocess, sys, tempfile, time, urllib.request, urllib.error
from datetime import datetime, timezone
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import botcreate as C
tmp = tempfile.mkdtemp(prefix="assm-botcreate-selftest-"); data = os.path.join(tmp, "data"); os.makedirs(data)
def key(n):
    k = os.path.join(tmp, n + ".pem")
    subprocess.run(["openssl", "ecparam", "-genkey", "-name", "prime256v1", "-noout", "-out", k], check=True)
    der = subprocess.run(["openssl", "ec", "-in", k, "-pubout", "-outform", "DER"], capture_output=True, check=True).stdout
    return k, base64.b64encode(der[-65:]).decode()
def sign(k, m): return base64.b64encode(subprocess.run(["openssl", "dgst", "-sha256", "-sign", k], input=m.encode(), capture_output=True, check=True).stdout).decode()
def iso(): return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
owner_k, owner_pub = key("owner"); other_k, other_pub = key("other"); bot_k, bot_pub = key("botdev")
json.dump({"version": 1, "approver_identity": "ЯID-0001-3QQS", "devices": [{"pub": owner_pub, "name": "selftest owner", "status": "ACTIVE"}]},
          open(os.path.join(data, "trusted-devices.json"), "w"))
port = 18764; URL = "http://127.0.0.1:%d" % port
env = dict(os.environ, ASSM_RSYNC_PORT=str(port), ASSM_RSYNC_DATA=data, ASSM_MODE="production", ASSM_ALLOW_UNSIGNED_BOOTSTRAP="0")
logf = open(os.path.join(tmp, "server.log"), "w")
proc = subprocess.Popen([sys.executable, os.path.join(HERE, "server.py")], env=env, stdout=logf, stderr=logf)
res = []
def check(n, c, x=""): res.append(c); print(("PASS " if c else "FAIL ") + n + ("" if c else " [%s]" % (x,)))
_n = [0]
def call(m, p, o=None, tok=None):
    r = urllib.request.Request(URL + p, method=m, data=json.dumps(o, ensure_ascii=False).encode() if o is not None else None)
    r.add_header("Content-Type", "application/json"); _n[0] += 1
    r.add_header("CF-Connecting-IP", "198.51.100.%d" % _n[0])   # distinct test IPs so the per-IP rate limit doesn't trip
    if tok: r.add_header("Authorization", "Bearer " + tok)
    try:
        with urllib.request.urlopen(r, timeout=10) as f: return f.status, json.loads(f.read() or b"{}")
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read() or b"{}")
try:
    for _ in range(50):
        try: urllib.request.urlopen(URL + "/health", timeout=1); break
        except Exception: time.sleep(0.1)
    pw = secrets.token_urlsafe(24); salt = os.urandom(16); it = 600000
    dk = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, it, 32); ver = hmac.new(dk, b"assm-password-verifier-v1", hashlib.sha256).digest()
    def req(signer_k, signer_pub, profile="ЯID-BOT-0001", handle="@krog"):
        o = {"t": "bot.create", "profile": profile, "handle": handle, "display": "KROG", "scheme": "pbkdf2-sha256-hmac-v1",
             "salt": base64.b64encode(salt).decode(), "iter": it, "verifier": base64.b64encode(ver).decode(),
             "signer": signer_pub, "nonce": secrets.token_hex(12), "ts": iso()}
        o["sig"] = sign(signer_k, C.create_msg(o)); return o
    c, b = call("POST", "/api/rsync/bot/create", req(other_k, other_pub)); check("untrusted signer refused (403)", c == 403, (c, b))
    o = req(owner_k, owner_pub); o["display"] = "TAMPERED"; c, b = call("POST", "/api/rsync/bot/create", o); check("tampered body refused (403)", c == 403, (c, b))
    c, b = call("POST", "/api/rsync/bot/create", req(owner_k, owner_pub, profile="ЯID-0001-3QQS")); check("owner ЯID can't become a bot (400/403)", c in (400, 403), (c, b))
    c, b = call("POST", "/api/rsync/bot/create", req(owner_k, owner_pub, handle="@chaserizal", profile="ЯID-BOT-0009")); check("owner handle can't become a bot (403)", c == 403, (c, b))
    o = req(owner_k, owner_pub); o["password"] = pw; c, b = call("POST", "/api/rsync/bot/create", o); check("plaintext password refused (400)", c == 400, (c, b))
    o = req(owner_k, owner_pub); c, b = call("POST", "/api/rsync/bot/create", o); check("owner-signed create works (201)", c == 201, (c, b))
    c, b = call("POST", "/api/rsync/bot/create", o); check("replay refused (409)", c == 409, (c, b))
    c, b = call("POST", "/api/rsync/bot/create", req(owner_k, owner_pub)); check("duplicate bot refused (409)", c == 409, (c, b))
    c, p = call("GET", "/api/rsync/bot/params?user=@krog"); check("params for new bot", c == 200 and p.get("iter") == it, (c, p))
    proof = base64.b64encode(dk).decode()
    lo = {"t": "bot.login", "user": "@krog", "proof": proof, "device": bot_pub, "device_name": "selftest bot", "nonce": secrets.token_hex(12), "ts": iso()}
    import botauth as B; lo["sig"] = sign(bot_k, B.botlogin_msg(lo))
    c, b = call("POST", "/api/rsync/bot/login", lo); check("new bot can log in (200)", c == 200 and b.get("role") == "bot", (c, b))
    tok = b.get("session")
    c, b = call("POST", "/api/rsync/bot/create", req(owner_k, owner_pub, profile="ЯID-BOT-0002", handle="@krog2"), tok=tok)
    check("bot session can't create bots (403)", c == 403, (c, b))
    c, b = call("POST", "/api/rsync/bot/create", req(bot_k, bot_pub, profile="ЯID-BOT-0003", handle="@krog3")); check("bot device can't create bots (403)", c == 403, (c, b))
    c, b = call("POST", "/api/rsync/bot/reply", {"parent_id": "post-1", "text": "KROG selftest reply"}, tok=tok); check("bot reply works (201)", c == 201, (c, b))
    check("password never in server log", pw not in open(os.path.join(tmp, "server.log")).read())
finally:
    proc.terminate(); proc.wait(5)
print("\n%d/%d passed" % (sum(res), len(res))); sys.exit(0 if all(res) else 1)
